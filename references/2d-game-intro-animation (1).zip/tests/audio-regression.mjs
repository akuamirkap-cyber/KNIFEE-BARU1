import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { chromium } from '@playwright/test';

const browser = await chromium.launch({
  args: ['--no-sandbox', '--autoplay-policy=document-user-activation-required'],
});
const page = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true });
const errors = [];
page.on('pageerror', (error) => errors.push(error.message));
const origin = process.env.APP_URL || 'http://localhost:5173';
await mkdir('artifacts', { recursive: true });

try {
  await page.goto(origin);
  await page.evaluate(async () => {
    // Vite may append an HMR timestamp; observe the instance actually used by React.
    window.audioModuleUrl = performance.getEntriesByType('resource')
      .find((entry) => entry.name.includes('/src/utils/juicyAudio.ts'))?.name
      || '/src/utils/juicyAudio.ts';
    const { juicyAudio } = await import(window.audioModuleUrl);
    window.audioEngine = juicyAudio;
    window.audioCalls = [];
    for (const method of [
      'playIntroBloom', 'playDropWhoosh', 'playSquishImpact', 'playManualSquish',
      'playReleaseBoing', 'playDropletBurst', 'playStudioLetterTick',
      'playMascotWink', 'playStudioResolveChord', 'playTransitionOut', 'playGameArrival',
    ]) {
      const original = juicyAudio[method].bind(juicyAudio);
      juicyAudio[method] = (...args) => {
        const cue = {
          method, time: performance.now(),
          audible: juicyAudio.ready && juicyAudio.enabled && juicyAudio.volume > 0,
          index: args[0], voicesStarted: 0,
        };
        window.audioCalls.push(cue);
        const before = juicyAudio.voices.size;
        const result = original(...args);
        cue.voicesStarted = juicyAudio.voices.size - before;
        return result;
      };
    }
  });

  assert.equal(await page.evaluate(() => window.audioEngine.ready), false);
  assert.equal(await page.evaluate(() => window.audioEngine.voices.size), 0);
  await page.getByRole('button', { name: 'Nyalakan suara dan putar intro' }).waitFor();
  await page.waitForTimeout(3600);
  await page.evaluate(() => { window.audioCalls = []; });
  await page.getByRole('button', { name: 'Nyalakan suara dan putar intro' }).click();
  await page.getByRole('button', { name: 'Matikan suara' }).waitFor();
  await page.waitForTimeout(3700);

  const fullFlow = await page.evaluate(() => window.audioCalls.filter((cue) => cue.audible));
  for (const cue of ['playIntroBloom', 'playMascotWink', 'playTransitionOut', 'playGameArrival']) {
    assert.equal(fullFlow.filter((event) => event.method === cue).length, 1, `${cue} fires once`);
  }
  const squeeze = fullFlow.find((cue) => cue.method === 'playManualSquish');
  const release = fullFlow.find((cue) => cue.method === 'playReleaseBoing');
  const wink = fullFlow.find((cue) => cue.method === 'playMascotWink');
  const landings = fullFlow.filter((cue) => cue.method === 'playSquishImpact');
  assert.deepEqual(landings.map((cue) => cue.index), [0, 1, 2, 3], 'All four letters have a landing cue');
  assert.ok(landings.every((cue) => cue.voicesStarted === 2), 'Every contact produces its own audible tap');
  const landingIntervals = landings.slice(1).map((cue, i) => cue.time - landings[i].time);
  assert.ok(landingIntervals.every((gap) => gap >= 60 && gap < 160), 'Landing sounds follow the regular visual beat');
  assert.ok(squeeze.time < release.time && release.time < wink.time, 'Wink cue follows the squeeze release');
  assert.ok(wink.time - release.time > 250, 'No wink sound on landing or during compression');

  await page.getByRole('button', { name: 'Matikan suara' }).click();
  assert.equal(await page.evaluate(() => window.audioEngine.enabled), false);
  await page.evaluate(() => { window.audioCalls = []; });
  await page.getByRole('button', { name: 'Ulangi Intro', exact: true }).click();
  await page.waitForTimeout(3700);
  assert.equal(await page.evaluate(() => window.audioCalls.filter((cue) => cue.audible).length), 0);

  await page.getByRole('button', { name: 'Nyalakan suara dan putar intro' }).click();
  await page.waitForTimeout(3700);
  await page.getByRole('button', { name: 'Tahan di Logo', exact: true }).click();
  await page.waitForTimeout(2300);
  await page.getByRole('button', { name: 'Squeeze!', exact: true }).click();
  await page.waitForTimeout(65);
  await page.evaluate(() => { window.audioCalls = []; });
  await page.getByRole('button', { name: 'Replay', exact: true }).click();
  await page.waitForTimeout(2300);
  assert.equal(await page.evaluate(() => window.audioCalls.filter((cue) => cue.method === 'playMascotWink').length), 1);

  await page.getByRole('button', { name: 'Pengaturan logo dan suara' }).click();
  const slider = page.getByRole('slider', { name: 'Volume suara', exact: true });
  await slider.focus();
  await slider.press('End');
  assert.equal(await page.evaluate(() => window.audioEngine.volume), 1);
  await slider.press('Home');
  assert.equal(await page.evaluate(() => window.audioEngine.volume), 0);
  await slider.evaluate((input) => {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(input, '70');
    input.dispatchEvent(new Event('input', { bubbles: true }));
  });
  assert.equal(await page.evaluate(() => window.audioEngine.volume), 0.7);
  await page.screenshot({ path: 'artifacts/mochi-audio-mobile.png' });
  await page.getByRole('button', { name: 'Dengarkan intro dengan suara Mochi Garden' }).click();
  await page.waitForTimeout(2400);
  assert.equal(await page.evaluate(() => window.audioEngine.voices.size), 0, 'All voices disconnect after playback');

  const mutedPeak = await page.evaluate(async () => {
    const { JuicyAudioEngine } = await import(window.audioModuleUrl);
    const context = new OfflineAudioContext(2, 44100, 44100);
    const engine = new JuicyAudioEngine(context);
    engine.enabled = false;
    engine.playIntroBloom();
    engine.playManualSquish();
    engine.playMascotWink();
    const buffer = await context.startRendering();
    return buffer.getChannelData(0).reduce((peak, sample) => Math.max(peak, Math.abs(sample)), 0);
  });
  assert.equal(mutedPeak, 0, 'Muted cues render true silence');

  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.getByRole('button', { name: 'Pengaturan logo dan suara' }).click();
  await page.getByRole('slider', { name: 'Volume suara', exact: true }).waitFor();
  await page.screenshot({ path: 'artifacts/mochi-audio-desktop.png' });
  const stage = await page.locator('#sans-stage-container').boundingBox();
  assert.ok(Math.abs(stage.width / stage.height - 9 / 16) < 0.02, 'Desktop portrait framing remains 9:16');
  assert.equal(errors.length, 0, errors.join('\n'));

  const rendered = await page.evaluate(async () => {
    const { JuicyAudioEngine } = await import(window.audioModuleUrl);
    const sampleRate = 44100;
    const context = new OfflineAudioContext(2, sampleRate * 4, sampleRate);
    const engine = new JuicyAudioEngine(context);
    engine.volume = 1;
    const tones = [];
    const originalTone = engine.tone.bind(engine);
    engine.tone = (options) => {
      tones.push({
        at: options.at, frequency: options.frequency,
        gain: options.gain, duration: options.duration,
      });
      return originalTone(options);
    };
    engine.playIntroBloom();
    for (let i = 0; i < 4; i++) {
      engine.playDropWhoosh(i, 0.05 + i * 0.1);
      engine.playSquishImpact(i, 0.87, 0.22 + i * 0.1);
    }
    engine.playManualSquish(1.15, 0.65);
    engine.playReleaseBoing(1.15, 0.94);
    engine.playDropletBurst(0.94);
    for (let i = 0; i < 6; i++) engine.playStudioLetterTick(i, 0.96 + i * 0.036);
    engine.playMascotWink(1.32);
    engine.playStudioResolveChord(1.32);
    const buffer = await context.startRendering();
    const left = buffer.getChannelData(0);
    const right = buffer.getChannelData(1);
    let peak = 0;
    let squares = 0;
    let maxStep = 0;
    let tailPeak = 0;
    for (let i = 0; i < left.length; i++) {
      peak = Math.max(peak, Math.abs(left[i]), Math.abs(right[i]));
      squares += left[i] ** 2 + right[i] ** 2;
      if (i > 0) maxStep = Math.max(maxStep, Math.abs(left[i] - left[i - 1]));
      if (i > sampleRate * 3.4) tailPeak = Math.max(tailPeak, Math.abs(left[i]));
    }
    return {
      sampleRate, peak, rms: Math.sqrt(squares / (left.length * 2)), maxStep, tailPeak,
      tones,
      left: Array.from(left), right: Array.from(right),
    };
  });

  const leads = rendered.tones.filter((tone) => tone.gain > 0.025);
  assert.deepEqual(
    leads.map((tone) => tone.frequency),
    [261.6256, 329.6276, 391.9954, 523.2511, 261.6256, 391.9954, 1046.5023],
    'The intro plays C-E-G-C landings, squeeze, release, and one star ting',
  );
  assert.equal(rendered.tones.length, 10, 'No extra bell runs, detuned layers, or stacked resolve chord');
  for (let i = 1; i < 4; i++) {
    assert.ok(Math.abs(leads[i].at - leads[i - 1].at - 0.1) < 0.00001, 'Landing notes are exactly 100 ms apart');
  }
  const starTones = rendered.tones.filter((tone) => tone.at >= 1.32);
  assert.equal(starTones.length, 3, 'One star strike has three quiet harmonic partials');
  assert.equal(new Set(starTones.map((tone) => tone.at)).size, 1, 'Wink is a single ting onset, not two notes');
  for (let i = 1; i < leads.length; i++) {
    const minimumGap = i < 4 ? 0.02 : 0.04;
    assert.ok(leads[i].at - (leads[i - 1].at + leads[i - 1].duration) >= minimumGap,
      'Each musical gesture has a quiet gap before the next');
  }
  assert.ok(rendered.peak > 0.02 && rendered.peak < 0.7, 'No clipping at maximum volume');
  assert.ok(rendered.rms > 0.005, 'Audible, non-silent mix');
  assert.ok(rendered.maxStep < 0.1, 'No abrupt full-scale sample discontinuities');
  assert.ok(rendered.tailPeak < 0.001, 'Reverb tail decays to silence');

  const frames = rendered.left.length;
  const wav = Buffer.alloc(44 + frames * 4);
  wav.write('RIFF', 0);
  wav.writeUInt32LE(wav.length - 8, 4);
  wav.write('WAVEfmt ', 8);
  wav.writeUInt32LE(16, 16);
  wav.writeUInt16LE(1, 20);
  wav.writeUInt16LE(2, 22);
  wav.writeUInt32LE(rendered.sampleRate, 24);
  wav.writeUInt32LE(rendered.sampleRate * 4, 28);
  wav.writeUInt16LE(4, 32);
  wav.writeUInt16LE(16, 34);
  wav.write('data', 36);
  wav.writeUInt32LE(frames * 4, 40);
  for (let i = 0; i < frames; i++) {
    wav.writeInt16LE(Math.round(rendered.left[i] * 32767), 44 + i * 4);
    wav.writeInt16LE(Math.round(rendered.right[i] * 32767), 46 + i * 4);
  }
  await writeFile('artifacts/mochi-garden-preview.wav', wav);
  console.log(JSON.stringify({
    status: 'passed', browserErrors: errors,
    winkCount: fullFlow.filter((cue) => cue.method === 'playMascotWink').length,
    winkAfterReleaseMs: Math.round(wink.time - release.time),
    landingCount: landings.length,
    landingIntervalsMs: landingIntervals.map(Math.round),
    winkBellStrikes: new Set(starTones.map((tone) => tone.at)).size,
    peakDb: +(20 * Math.log10(rendered.peak)).toFixed(2),
    rmsDb: +(20 * Math.log10(rendered.rms)).toFixed(2),
    maxSampleStep: +rendered.maxStep.toFixed(5),
    tailPeak: rendered.tailPeak,
    musicalGestures: leads.length,
    simultaneousLeadNotes: 1,
  }, null, 2));
} finally {
  await browser.close();
}