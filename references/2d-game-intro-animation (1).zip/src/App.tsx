import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  RotateCcw,
  Sparkles,
  Volume2,
  VolumeX,
  Gamepad2,
  Sliders,
  EyeOff,
  Download,
  Hand,
  Smartphone,
  Maximize2,
  Smile,
  Play,
} from 'lucide-react';
import {
  SansWordmarkSvg,
  LetterTransform,
  DropletTransform,
  FaceState,
  ImpactFxItem,
  StudioCharTransform,
} from './components/SansWordmarkSvg';
import { Game2DTransitionPreview } from './components/Game2DTransitionPreview';
import { ExportCodeModal } from './components/ExportCodeModal';
import { juicyAudio } from './utils/juicyAudio';

export type IntroPreset = 'classic' | 'mega_squeeze' | 'jelly_wave' | 'balloon_pop';

interface SpringValue {
  pos: number;
  vel: number;
  target: number;
}

interface LetterPhysics {
  x: SpringValue;
  y: SpringValue;
  // Unified phase-locked squash/stretch spring (s < 0 = wide squash, s > 0 = tall stretch)
  squash: SpringValue;
  rotation: SpringValue;
  skewX: SpringValue;
  jellyBendX: SpringValue;
  opacity: number;
  inAir: boolean;
}

function createSpring(initial: number, target: number = initial): SpringValue {
  return { pos: initial, vel: 0, target };
}

// 4x Sub-stepped Symplectic Spring Integrator for 120Hz/60Hz butter-smooth motion
function stepSpring(
  s: SpringValue,
  stiffness: number,
  damping: number,
  dt: number
) {
  const subSteps = 4;
  const subDt = dt / subSteps;
  const decay = Math.exp(-damping * subDt);

  for (let i = 0; i < subSteps; i++) {
    const force = (s.target - s.pos) * stiffness;
    s.vel = (s.vel + force * subDt) * decay;
    s.pos += s.vel * subDt;
  }
}

export function App() {
  // UI & Viewport Mode State (Default 9:16 Portrait Mobile Game Mode!)
  const [portrait916, setPortrait916] = useState<boolean>(true);
  const [preset, setPreset] = useState<IntroPreset>('classic');
  const [soundEnabled, setSoundEnabled] = useState(juicyAudio.enabled);
  const [soundReady, setSoundReady] = useState(juicyAudio.ready);
  const [soundVolume, setSoundVolume] = useState(juicyAudio.volume);
  const [cleanMode, setCleanMode] = useState<boolean>(false);
  const [flatRedBg, setFlatRedBg] = useState<boolean>(false);
  const [showShineMarks, setShowShineMarks] = useState<boolean>(false);
  const [showTuning, setShowTuning] = useState<boolean>(false);
  const [showExportModal, setShowExportModal] = useState<boolean>(false);

  // Logo Scale & Physics Tuning Sliders (Default 0.70 = 30% smaller as requested!)
  const [logoScale, setLogoScale] = useState<number>(0.70);
  const [juiciness, setJuiciness] = useState<number>(1.15); // Neat, cohesive juicy squash
  const [bounciness, setBounciness] = useState<number>(1.12); // Smooth, rhythmic "membal"
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1.0);

  // Fade-In / Fade-Out & 2D Game Page Transition State
  // Default true so user immediately experiences: Fade-In -> Neat Squeeze & Wink -> Fade-Out -> Main Game!
  const [autoEnterGame, setAutoEnterGame] = useState<boolean>(true);
  const [inGameScene, setInGameScene] = useState<boolean>(false);
  // Curtain overlay opacity: 1 = dark curtain (faded out), 0 = fully visible stage (faded in)
  const [fadeOverlayOpacity, setFadeOverlayOpacity] = useState<number>(1);
  const [stageExitScale, setStageExitScale] = useState<number>(1);

  // Interactive Hover & Squeeze State
  const [hoveredLetter, setHoveredLetter] = useState<number | null>(null);
  const [activeSqueezeLetter, setActiveSqueezeLetter] = useState<number | null>(null);
  const [isGlobalSqueezing, setIsGlobalSqueezing] = useState<boolean>(false);
  const [introPhaseLabel, setIntroPhaseLabel] = useState<string>('FADE IN INTRO');

  // Render State for SVG
  const [renderState, setRenderState] = useState<{
    letters: [LetterTransform, LetterTransform, LetterTransform, LetterTransform];
    droplets: [DropletTransform, DropletTransform, DropletTransform, DropletTransform];
    studioChars: StudioCharTransform[];
    face: FaceState;
    globalSqueeze: { scaleX: number; scaleY: number; y: number; rotation: number };
    impacts: ImpactFxItem[];
  }>(() => ({
    letters: [0, 1, 2, 3].map(() => ({
      x: 0,
      y: -210,
      scaleX: 0.9,
      scaleY: 1.12,
      rotation: 0,
      skewX: 0,
      jellyBendX: 0,
      jellySquishY: 0,
      opacity: 0,
    })) as [LetterTransform, LetterTransform, LetterTransform, LetterTransform],
    droplets: [0, 1, 2, 3].map(() => ({
      scale: 0,
      distance: 0,
      rotation: 0,
      stretch: 1,
      opacity: 0,
    })) as [DropletTransform, DropletTransform, DropletTransform, DropletTransform],
    studioChars: [0, 1, 2, 3, 4, 5].map(() => ({
      y: 20,
      scaleX: 0.6,
      scaleY: 0.6,
      opacity: 0,
      rotation: 0,
    })),
    face: {
      expression: 'normal',
      eyeLookX: 0,
      eyeLookY: 0,
      blinkAmount: 0,
      winkAmount: 0,
      eyeSquish: 0,
      mouthOpen: 1,
    },
    globalSqueeze: { scaleX: 1, scaleY: 1, y: 0, rotation: 0 },
    impacts: [],
  }));

  // Mutable Physics Refs for 60/120fps loop
  const animTimeRef = useRef<number>(0);
  const triggeredEventsRef = useRef<Set<string>>(new Set());
  const nextImpactIdRef = useRef<number>(1);
  const impactsRef = useRef<ImpactFxItem[]>([]);
  const pointerPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const dragStartRef = useRef<{ x: number; y: number; time: number } | null>(null);
  const activeLetterRef = useRef<number | null>(null);
  const isGlobalHoldRef = useRef<boolean>(false);
  const delayedActionsRef = useRef<Set<number>>(new Set());

  const scheduleAction = useCallback((action: () => void, delay: number) => {
    const timer = window.setTimeout(() => {
      delayedActionsRef.current.delete(timer);
      action();
    }, delay);
    delayedActionsRef.current.add(timer);
  }, []);

  const cancelDelayedActions = useCallback(() => {
    delayedActionsRef.current.forEach((timer) => window.clearTimeout(timer));
    delayedActionsRef.current.clear();
  }, []);

  useEffect(() => () => {
    cancelDelayedActions();
    juicyAudio.stopAll();
  }, [cancelDelayedActions]);

  const unlockSound = useCallback((event: React.SyntheticEvent) => {
    if ((event.target as Element).closest('[data-audio-toggle]')) return;
    if (juicyAudio.enabled) void juicyAudio.unlock().then(setSoundReady);
  }, []);

  const lettersPhysRef = useRef<[LetterPhysics, LetterPhysics, LetterPhysics, LetterPhysics]>([
    0, 1, 2, 3,
  ].map(() => ({
    x: createSpring(0, 0),
    y: createSpring(-210, 0),
    squash: createSpring(0.1, 0),
    rotation: createSpring(0, 0),
    skewX: createSpring(0, 0),
    jellyBendX: createSpring(0, 0),
    opacity: 0,
    inAir: true,
  })) as [LetterPhysics, LetterPhysics, LetterPhysics, LetterPhysics]);

  const dropletsPhysRef = useRef<
    Array<{
      scale: SpringValue;
      distance: SpringValue;
      rotation: SpringValue;
      stretch: SpringValue;
      opacity: number;
    }>
  >(
    [0, 1, 2, 3].map(() => ({
      scale: createSpring(0, 0),
      distance: createSpring(0, 0),
      rotation: createSpring(0, 0),
      stretch: createSpring(1, 1),
      opacity: 0,
    }))
  );

  const studioPhysRef = useRef<
    Array<{
      y: SpringValue;
      squash: SpringValue;
      rotation: SpringValue;
      opacity: number;
    }>
  >(
    [0, 1, 2, 3, 4, 5].map(() => ({
      y: createSpring(18, 18),
      squash: createSpring(-0.2, 0),
      rotation: createSpring(0, 0),
      opacity: 0,
    }))
  );

  const globalPhysRef = useRef<{
    squash: SpringValue;
    y: SpringValue;
    rotation: SpringValue;
  }>({
    squash: createSpring(0, 0),
    y: createSpring(0, 0),
    rotation: createSpring(0, 0),
  });

  const faceRef = useRef<FaceState>({
    expression: 'normal',
    eyeLookX: 0,
    eyeLookY: 0,
    blinkAmount: 0,
    winkAmount: 0,
    eyeSquish: 0,
    mouthOpen: 1,
  });

  const winkSpringRef = useRef<SpringValue>(createSpring(0, 0));
  const eyeSquishSpringRef = useRef<SpringValue>(createSpring(0, 0));

  // Helper to spawn 2D white cartoon impact FX
  const spawnImpact = useCallback(
    (x: number, y: number, type: ImpactFxItem['type'], scale: number = 1) => {
      impactsRef.current.push({
        id: nextImpactIdRef.current++,
        x,
        y,
        progress: 0,
        type,
        scale,
      });
    },
    []
  );

  // Trigger Mascot 'A' Cheeky Wink + Neat Hop!
  const triggerMascotWinkAction = useCallback(() => {
    juicyAudio.unlock();
    juicyAudio.playMascotWink();

    const j = juiciness;
    const lpA = lettersPhysRef.current[1];
    lpA.inAir = false;
    lpA.squash.vel -= 4.2 * j;
    lpA.y.vel = -150 * j;

    // Gentle, symmetrical mini-pulse on neighboring letters
    lettersPhysRef.current[0].squash.vel -= 1.8 * j;
    lettersPhysRef.current[2].squash.vel -= 1.8 * j;
    lettersPhysRef.current[3].squash.vel -= 1.4 * j;

    winkSpringRef.current.target = 1;
    winkSpringRef.current.vel = 6.0;
    faceRef.current.expression = 'wink';

    spawnImpact(362, 165, 'winkSparkle', 0.9 * j);

    scheduleAction(() => {
      winkSpringRef.current.target = 0;
      faceRef.current.expression = 'normal';
    }, 460);
  }, [juiciness, spawnImpact, scheduleAction]);

  // Trigger a Neat Xylophone Wave across S - T - U - D - I - O
  const triggerStudioSublabelWave = useCallback(() => {
    juicyAudio.unlock();
    const j = juiciness;
    [0, 1, 2, 3, 4, 5].forEach((idx) => {
      scheduleAction(() => {
        const sp = studioPhysRef.current[idx];
        sp.opacity = 1;
        sp.y.vel = -165 * j;
        sp.squash.vel = -4.2 * j;
        juicyAudio.playStudioLetterTick(idx);
      }, idx * 42);
    });
    triggerMascotWinkAction();
  }, [juiciness, triggerMascotWinkAction, scheduleAction]);

  // Start / Replay the Choreographed Intro Sequence
  const startIntro = useCallback(
    (selectedPreset: IntroPreset = preset, shouldTransitionToGame: boolean = autoEnterGame) => {
      cancelDelayedActions();
      juicyAudio.resetScene();
      void juicyAudio.unlock().then((ready) => {
        setSoundReady(ready);
        if (ready && animTimeRef.current < 0.15) juicyAudio.playIntroBloom();
      });
      activeLetterRef.current = null;
      isGlobalHoldRef.current = false;
      setActiveSqueezeLetter(null);
      setIsGlobalSqueezing(false);
      setInGameScene(false);
      setFadeOverlayOpacity(1); // Start from Fade-In curtain!
      setStageExitScale(1);
      animTimeRef.current = 0;
      triggeredEventsRef.current.clear();
      impactsRef.current = [];

      if (selectedPreset === 'classic') {
        lettersPhysRef.current.forEach((lp) => {
          lp.x = createSpring(0, 0);
          lp.y = createSpring(-210, 0);
          lp.squash = createSpring(0.1, 0);
          lp.rotation = createSpring(0, 0);
          lp.skewX = createSpring(0, 0);
          lp.jellyBendX = createSpring(0, 0);
          lp.opacity = 0;
          lp.inAir = true;
        });
      } else if (selectedPreset === 'mega_squeeze') {
        lettersPhysRef.current.forEach((lp) => {
          lp.x = createSpring(0, 0);
          lp.y = createSpring(0, 0);
          lp.squash = createSpring(0, 0);
          lp.rotation = createSpring(0, 0);
          lp.skewX = createSpring(0, 0);
          lp.jellyBendX = createSpring(0, 0);
          lp.opacity = 1;
          lp.inAir = false;
        });
      } else if (selectedPreset === 'jelly_wave') {
        lettersPhysRef.current.forEach((lp) => {
          lp.x = createSpring(0, 0);
          lp.y = createSpring(0, 0);
          lp.squash = createSpring(0.08, 0);
          lp.rotation = createSpring(0, 0);
          lp.skewX = createSpring(0, 0);
          lp.jellyBendX = createSpring(0, 0);
          lp.opacity = 1;
          lp.inAir = false;
        });
      } else {
        lettersPhysRef.current.forEach((lp) => {
          lp.x = createSpring(0, 0);
          lp.y = createSpring(0, 0);
          lp.squash = createSpring(-0.5, 0);
          lp.rotation = createSpring(0, 0);
          lp.skewX = createSpring(0, 0);
          lp.jellyBendX = createSpring(0, 0);
          lp.opacity = 0;
          lp.inAir = false;
        });
      }

      dropletsPhysRef.current.forEach((dp) => {
        dp.scale = createSpring(0, 0);
        dp.distance = createSpring(0.25, 0.25);
        dp.rotation = createSpring(0, 0);
        dp.stretch = createSpring(1.25, 1);
        dp.opacity = 0;
      });

      studioPhysRef.current.forEach((sp) => {
        sp.y = createSpring(18, 18);
        sp.squash = createSpring(-0.18, 0);
        sp.rotation = createSpring(0, 0);
        sp.opacity = 0;
      });

      globalPhysRef.current = {
        squash: createSpring(0, 0),
        y: createSpring(0, 0),
        rotation: createSpring(0, 0),
      };

      winkSpringRef.current = createSpring(0, 0);
      eyeSquishSpringRef.current = createSpring(0, 0);

      faceRef.current = {
        expression: 'normal',
        eyeLookX: 0,
        eyeLookY: 0,
        blinkAmount: 0,
        winkAmount: 0,
        eyeSquish: 0,
        mouthOpen: 1,
      };

      if (shouldTransitionToGame) {
        triggeredEventsRef.current.add('WANT_GAME_TRANSITION');
      }
    },
    [preset, autoEnterGame, cancelDelayedActions]
  );

  // Trigger a Super-Neat Manual Mega Squeeze -> Pop Out -> Then WINK 😉 right as Mega Squeeze finishes!
  const triggerManualMegaSqueeze = useCallback(() => {
    juicyAudio.unlock();
    juicyAudio.playManualSquish(1.25 * juiciness);

    const j = juiciness;
    // Step 1: Smooth, symmetrical inward Mega Squeeze (both capsule eyes cushion-squished, no wink yet)
    const symPull = [32, 11, -11, -32];
    lettersPhysRef.current.forEach((lp, i) => {
      lp.inAir = false;
      lp.y.pos = 0;
      lp.y.target = 0;
      lp.rotation.target = 0;
      lp.x.target = symPull[i] * j;
      lp.squash.target = -0.28 * j;
    });

    globalPhysRef.current.squash.target = -0.15 * j;
    eyeSquishSpringRef.current.target = 0.85;
    winkSpringRef.current.target = 0;
    faceRef.current.expression = 'happy';

    // Step 2: After 180ms compression, POP outward with Juicy Membal bounce!
    scheduleAction(() => {
      juicyAudio.playReleaseBoing(1.2);
      juicyAudio.playDropletBurst();

      globalPhysRef.current.squash.target = 0;
      globalPhysRef.current.squash.vel = 5.4 * j;

      lettersPhysRef.current.forEach((lp) => {
        lp.x.target = 0;
        lp.squash.target = 0;
        lp.squash.vel = 6.2 * j;
        lp.y.vel = -135 * j;
      });

      eyeSquishSpringRef.current.target = 0;
      eyeSquishSpringRef.current.vel = -3.8 * j;

      dropletsPhysRef.current.forEach((dp) => {
        dp.opacity = 1;
        dp.scale.target = 1;
        dp.scale.vel += 6.5 * j;
        dp.distance.target = 1;
        dp.distance.vel += 5.5 * j;
      });

      spawnImpact(484, 245, 'globalWave', 0.95 * j);
    }, 180);

    // Step 3: Right as the Mega Squeeze finishes its pop-back (420ms), Letter 'A' does the Cheeky WINK 😉!
    scheduleAction(() => {
      const lpA = lettersPhysRef.current[1];
      lpA.squash.vel -= 3.2 * j;
      lpA.y.vel = -115 * j;

      winkSpringRef.current.target = 1;
      winkSpringRef.current.vel = 7.5;
      faceRef.current.expression = 'wink';

      juicyAudio.playMascotWink();
      spawnImpact(362, 165, 'winkSparkle', 0.95 * j);
    }, 420);

    scheduleAction(() => {
      winkSpringRef.current.target = 0;
      faceRef.current.expression = 'normal';
    }, 880);
  }, [juiciness, spawnImpact, scheduleAction]);

  useEffect(() => {
    startIntro('classic', true);
  }, []);

  // Main Ultra-Smooth 60/120fps Choreographed Timeline & Neat Phase-Locked Spring Loop
  useEffect(() => {
    let rafId: number;
    let lastTime = performance.now();

    const groundPivotsX = [208, 396, 588, 768];

    const tick = (now: number) => {
      const rawDt = Math.min(0.025, (now - lastTime) / 1000);
      lastTime = now;
      const dt = rawDt * speedMultiplier;

      animTimeRef.current += dt;
      const t = animTimeRef.current;
      const events = triggeredEventsRef.current;
      const j = juiciness;
      const b = bounciness;

      const once = (key: string, timeThreshold: number, fn: () => void) => {
        if (t >= timeThreshold && !events.has(key)) {
          events.add(key);
          fn();
        }
      };

      // =====================================================================
      // 1. SMOOTH PAGE FADE-IN (t = 0.00s -> 0.34s)
      // =====================================================================
      if (t <= 0.34) {
        const p = Math.min(1, t / 0.34);
        const eased = 1 - Math.pow(1 - p, 3);
        setFadeOverlayOpacity(1 - eased);
      } else if (!events.has('WANT_GAME_TRANSITION') || t < 2.48) {
        setFadeOverlayOpacity(0);
      }

      // =====================================================================
      // 2. CHOREOGRAPHY TIMELINE BY PRESET (Neat, Cohesive & Synchronized)
      // =====================================================================
      if (preset === 'classic') {
        if (t < 0.62) setIntroPhaseLabel('1. DROP & LANDING');
        else if (t < 1.28) setIntroPhaseLabel('2. MEGA SQUEEZE & POP');
        else if (t < 1.85) setIntroPhaseLabel('3. SELESAI SQUEEZE → WINK 😉');
        else if (events.has('WANT_GAME_TRANSITION') && t >= 2.45)
          setIntroPhaseLabel('4. FADE OUT → GAME');
        else setIntroPhaseLabel('READY • TAP HURUF');

        // A. Drop & Landing (0.05s -> 0.62s) — Eyes stay 100% OPEN (ZERO wink on landing!)
        [0, 1, 2, 3].forEach((i) => {
          const dropStart = 0.05 + i * 0.1;
          const fallDuration = 0.17;
          const impactTime = dropStart + fallDuration;
          const lp = lettersPhysRef.current[i];

          once(`whoosh_${i}`, dropStart, () => {
            juicyAudio.playDropWhoosh(i);
          });

          if (t < dropStart) {
            lp.inAir = true;
            lp.opacity = 0;
            lp.y.pos = -210;
          } else if (t < impactTime) {
            lp.inAir = true;
            const p = (t - dropStart) / fallDuration;
            lp.opacity = Math.min(1, p * 3.5);
            lp.y.pos = -210 * (1 - p * p);
            lp.y.vel = 0;
            lp.y.target = 0;

            lp.squash.pos = 0.05 + 0.06 * p;
            lp.squash.vel = 0;
          }

          // Exact Moment of Floor Contact (y === 0.0) — Gentle landing settle, NO WINK!
          once(`impact_${i}`, impactTime, () => {
            lp.inAir = false;
            lp.opacity = 1;
            lp.y.pos = 0;
            lp.y.vel = 0;
            lp.y.target = 0;

            lp.squash.pos = -0.03;
            lp.squash.target = 0;
            lp.squash.vel = -3.8 * j;

            // Strictly guarantee 0 wink on landing
            winkSpringRef.current.pos = 0;
            winkSpringRef.current.vel = 0;
            winkSpringRef.current.target = 0;

            spawnImpact(groundPivotsX[i], 348, 'ring', 0.72 * j);
            juicyAudio.playSquishImpact(i, 0.75 * j, 0, speedMultiplier);
          });
        });

        // B. Distinct MEGA SQUEEZE Compression (0.65s -> 0.94s)
        // After all letters have landed on the floor, they pull inward & compress into a big Mega Squeeze!
        // Eyes remain 100% OPEN (still NO wink during compression!)
        once('neat_group_squeeze', 0.65, () => {
          const symPull = [42, 14, -14, -42];
          lettersPhysRef.current.forEach((lp, i) => {
            lp.x.target = symPull[i] * j;
            lp.squash.target = -0.30 * j;
          });
          globalPhysRef.current.squash.target = -0.16 * j;
          winkSpringRef.current.pos = 0;
          winkSpringRef.current.vel = 0;
          winkSpringRef.current.target = 0;
          faceRef.current.expression = 'happy';
          juicyAudio.playManualSquish(1.15);
        });

        // C. Mega Squeeze Releases / Pops Outward + 4 Side Droplets + STUDIO Wave! (0.94s -> 1.28s)
        once('neat_group_pop', 0.94, () => {
          juicyAudio.playReleaseBoing(1.15);
          juicyAudio.playDropletBurst();

          globalPhysRef.current.squash.target = 0;
          globalPhysRef.current.squash.vel = 5.2 * j;

          lettersPhysRef.current.forEach((lp) => {
            lp.x.target = 0;
            lp.squash.target = 0;
            lp.squash.vel = 6.2 * j;
            lp.y.vel = -130 * j;
          });

          dropletsPhysRef.current.forEach((dp, idx) => {
            dp.opacity = 1;
            dp.scale.pos = 0.25;
            dp.scale.target = 1;
            dp.scale.vel = 8.4 * j;

            dp.distance.pos = 0.3;
            dp.distance.target = 1;
            dp.distance.vel = 7.4 * j;

            dp.stretch.pos = 1.3;
            dp.stretch.target = 1;
            dp.rotation.pos = idx < 2 ? -10 : 10;
            dp.rotation.target = 0;
          });

          spawnImpact(484, 245, 'globalWave', 0.95 * j);
        });

        // D. S T U D I O Sub-label Neat Staggered Glide-In (0.96s - 1.18s)
        [0, 1, 2, 3, 4, 5].forEach((idx) => {
          once(`studio_char_${idx}`, 0.96 + idx * 0.036, () => {
            const sp = studioPhysRef.current[idx];
            sp.opacity = 1;
            sp.y.target = 0;
            sp.y.vel = -165 * j;
            sp.squash.pos = -0.16;
            sp.squash.target = 0;
            sp.squash.vel = 4.2 * j;
            sp.rotation.target = 0;
            juicyAudio.playStudioLetterTick(idx);
          });
        });

        // E. ONLY 1 WINK 😉 — RIGHT AFTER THE MEGA SQUEEZE FINISHES & SETTLES (1.32s)!
        once('mascot_wink_after_squeeze_done', 1.32, () => {
          winkSpringRef.current.target = 1;
          winkSpringRef.current.vel = 7.5;
          faceRef.current.expression = 'wink';

          spawnImpact(362, 165, 'winkSparkle', 0.95 * j);
          juicyAudio.playMascotWink();
          juicyAudio.playStudioResolveChord();
        });

        // F. Smoothly open the winking eye back to normal (1.82s)
        once('mascot_wink_end', 1.82, () => {
          if (activeLetterRef.current === null && !isGlobalHoldRef.current) {
            winkSpringRef.current.target = 0;
            faceRef.current.expression = 'normal';
          }
        });
      } else if (preset === 'mega_squeeze') {
        setIntroPhaseLabel('MEGA SQUEEZE → WINK');

        // 1. Mega Squeeze Compression (0.12s -> 0.52s) with both capsule eyes open/squished
        once('mega_1', 0.12, () => {
          juicyAudio.playManualSquish(1.3);
          winkSpringRef.current.target = 0;
          faceRef.current.expression = 'happy';
          eyeSquishSpringRef.current.target = 0.95;

          const pullIn = [52, 18, -18, -52];
          lettersPhysRef.current.forEach((lp, i) => {
            lp.x.target = pullIn[i] * j;
            lp.squash.target = -0.32 * j;
          });
          globalPhysRef.current.squash.target = -0.18 * j;
        });

        // 2. Mega Squeeze Pop-Out Release (0.52s)
        once('mega_pop', 0.52, () => {
          juicyAudio.playReleaseBoing(1.2);
          juicyAudio.playDropletBurst();

          eyeSquishSpringRef.current.target = 0;
          eyeSquishSpringRef.current.vel = -4.2 * j;

          globalPhysRef.current.squash.target = 0;
          globalPhysRef.current.squash.vel = 5.6 * j;

          lettersPhysRef.current.forEach((lp, i) => {
            lp.x.target = 0;
            lp.squash.target = 0;
            lp.squash.vel = 6.5 * j;
            lp.y.vel = -145 * j;
            spawnImpact(groundPivotsX[i], 348, 'ring', 0.85 * j);
          });

          dropletsPhysRef.current.forEach((dp) => {
            dp.opacity = 1;
            dp.scale.target = 1;
            dp.scale.vel = 8.5 * j;
            dp.distance.target = 1;
            dp.distance.vel = 7.5 * j;
          });

          studioPhysRef.current.forEach((sp) => {
            sp.opacity = 1;
            sp.y.target = 0;
            sp.squash.target = 0;
            sp.squash.vel = 4.6 * j;
          });

          spawnImpact(484, 240, 'globalWave', 1.05 * j);
        });

        // 3. RIGHT AS MEGA SQUEEZE FINISHES (0.88s): Letter 'A' performs the Cheeky WINK 😉!
        once('mega_wink_after_done', 0.88, () => {
          const lpA = lettersPhysRef.current[1];
          lpA.squash.vel -= 3.4 * j;
          lpA.y.vel = -120 * j;

          winkSpringRef.current.target = 1;
          winkSpringRef.current.vel = 7.5;
          faceRef.current.expression = 'wink';

          spawnImpact(362, 165, 'winkSparkle', 0.95 * j);
          juicyAudio.playMascotWink();
          juicyAudio.playStudioResolveChord();
        });

        once('mega_settle', 1.38, () => {
          winkSpringRef.current.target = 0;
          faceRef.current.expression = 'normal';
        });
      } else if (preset === 'jelly_wave') {
        setIntroPhaseLabel('SILKY JELLY WAVE');

        once('wave_droplet_l', 0.08, () => {
          juicyAudio.playDropletBurst();
          [0, 1].forEach((idx) => {
            const dp = dropletsPhysRef.current[idx];
            dp.opacity = 1;
            dp.scale.target = 1;
            dp.scale.vel = 8.0 * j;
            dp.distance.target = 1;
            dp.distance.vel = 7.0 * j;
          });
        });

        [0, 1, 2, 3].forEach((i) => {
          once(`wave_hit_${i}`, 0.16 + i * 0.11, () => {
            const lp = lettersPhysRef.current[i];
            lp.squash.vel = -7.2 * j;
            lp.y.vel = -135 * j;
            juicyAudio.playSquishImpact(i, 0.9 * j);
            spawnImpact(groundPivotsX[i], 348, 'ring', 0.78 * j);
          });
        });

        once('wave_droplet_r', 0.62, () => {
          juicyAudio.playDropletBurst();
          [2, 3].forEach((idx) => {
            const dp = dropletsPhysRef.current[idx];
            dp.opacity = 1;
            dp.scale.target = 1;
            dp.scale.vel = 8.0 * j;
            dp.distance.target = 1;
            dp.distance.vel = 7.0 * j;
          });
        });

        [0, 1, 2, 3, 4, 5].forEach((idx) => {
          once(`wave_studio_${idx}`, 0.56 + idx * 0.04, () => {
            const sp = studioPhysRef.current[idx];
            sp.opacity = 1;
            sp.y.target = 0;
            sp.squash.target = 0;
            sp.squash.vel = 4.6 * j;
            juicyAudio.playStudioLetterTick(idx);
          });
        });

        // Only 1 Wink after the wave finishes (0.88s)
        once('wave_wink_after_done', 0.88, () => {
          winkSpringRef.current.target = 1;
          winkSpringRef.current.vel = 7.5;
          faceRef.current.expression = 'wink';
          spawnImpact(362, 165, 'winkSparkle', 0.95 * j);
          juicyAudio.playMascotWink();
          juicyAudio.playStudioResolveChord();
        });

        once('wave_end', 1.38, () => {
          winkSpringRef.current.target = 0;
          faceRef.current.expression = 'normal';
        });
      } else if (preset === 'balloon_pop') {
        setIntroPhaseLabel('BALLOON INFLATE & BOING');

        [0, 1, 2, 3].forEach((i) => {
          const baseT = 0.08 + i * 0.085;
          once(`inf_1_${i}`, baseT, () => {
            const lp = lettersPhysRef.current[i];
            lp.opacity = 1;
            lp.squash.target = -0.22;
            juicyAudio.playManualSquish(0.6);
          });
          once(`inf_2_${i}`, baseT + 0.13, () => {
            const lp = lettersPhysRef.current[i];
            lp.squash.target = 0.18 * j;
          });
          once(`inf_3_${i}`, baseT + 0.26, () => {
            const lp = lettersPhysRef.current[i];
            lp.squash.target = 0;
            lp.squash.vel = -6.8 * j;
            lp.y.vel = -130 * j;
            juicyAudio.playSquishImpact(i, 0.9 * j);
            spawnImpact(groundPivotsX[i], 348, 'ring', 0.8 * j);
          });
        });

        once('inf_finish', 0.72, () => {
          juicyAudio.playDropletBurst();

          dropletsPhysRef.current.forEach((dp) => {
            dp.opacity = 1;
            dp.scale.target = 1;
            dp.scale.vel = 8.0 * j;
            dp.distance.target = 1;
            dp.distance.vel = 7.0 * j;
          });
          studioPhysRef.current.forEach((sp) => {
            sp.opacity = 1;
            sp.y.target = 0;
            sp.squash.target = 0;
            sp.squash.vel = 4.6 * j;
          });
        });

        // Only 1 Wink after balloon pop finishes (0.98s)
        once('inf_wink_after_done', 0.98, () => {
          winkSpringRef.current.target = 1;
          winkSpringRef.current.vel = 7.5;
          faceRef.current.expression = 'wink';
          spawnImpact(362, 165, 'winkSparkle', 0.95 * j);
          juicyAudio.playMascotWink();
          juicyAudio.playStudioResolveChord();
        });

        once('inf_end', 1.48, () => {
          winkSpringRef.current.target = 0;
          faceRef.current.expression = 'normal';
        });
      }

      // =====================================================================
      // 3. SMOOTH FADE-OUT PAGE TRANSITION TO MAIN GAME (t = 2.48s -> 3.02s)
      // =====================================================================
      if (events.has('WANT_GAME_TRANSITION')) {
        once('exit_anticipation', 2.42, () => {
          globalPhysRef.current.squash.vel -= 2.0 * j;
        });

        once('audio_fade_out', 2.48, () => {
          juicyAudio.playTransitionOut(0.54 / speedMultiplier);
        });

        if (t >= 2.48 && t <= 3.02) {
          const progress = Math.min(1, (t - 2.48) / 0.54);
          const eased =
            progress < 0.5
              ? 4 * progress * progress * progress
              : 1 - Math.pow(-2 * progress + 2, 3) / 2;
          setFadeOverlayOpacity(eased);
          setStageExitScale(1 - eased * 0.06);
        }

        once('enter_2d_game_now', 3.02, () => {
          juicyAudio.playGameArrival();
          setInGameScene(true);
        });
      }

      // =====================================================================
      // 4. LIVING IDLE BREATHING (No extra blink/wink — strictly 1 Wink only!)
      // =====================================================================
      if (t > 1.9 && activeLetterRef.current === null && !isGlobalHoldRef.current) {
        lettersPhysRef.current.forEach((lp, i) => {
          const wave = Math.sin(t * 3.0 + i * 0.75);
          lp.squash.target = wave * 0.014 * j;
        });
        faceRef.current.blinkAmount = 0;
      }

      // Smooth cursor eye tracking for letter 'A'
      const targetLookX = pointerPosRef.current.x;
      const targetLookY = pointerPosRef.current.y;
      faceRef.current.eyeLookX += (targetLookX - faceRef.current.eyeLookX) * 0.16;
      faceRef.current.eyeLookY += (targetLookY - faceRef.current.eyeLookY) * 0.16;

      // =====================================================================
      // 5. STEP ALL HOOKE'S LAW SPRINGS
      // =====================================================================
      const posStiffness = 295 * b;
      const posDamping = Math.max(14.0, 18.5 / Math.sqrt(b));

      const jellyStiffness = 330 * b;
      const jellyDamping = Math.max(7.8, 11.0 / Math.sqrt(b));

      lettersPhysRef.current.forEach((lp) => {
        stepSpring(lp.x, posStiffness, posDamping, dt);
        if (!lp.inAir) {
          stepSpring(lp.y, posStiffness, posDamping, dt);
          // Strict floor clamp ("anti-bablas"): letter can hop UP (y < 0), never sink below baseline (y > 0)
          if (lp.y.pos > 0 && activeLetterRef.current === null) {
            lp.y.pos = 0;
            if (lp.y.vel > 0) lp.y.vel = 0;
          }
          stepSpring(lp.squash, jellyStiffness, jellyDamping, dt);
        }
        stepSpring(lp.rotation, posStiffness, posDamping, dt);
        stepSpring(lp.skewX, posStiffness, posDamping, dt);
        stepSpring(lp.jellyBendX, jellyStiffness, jellyDamping, dt);
      });

      dropletsPhysRef.current.forEach((dp) => {
        stepSpring(dp.scale, jellyStiffness, jellyDamping, dt);
        stepSpring(dp.distance, jellyStiffness * 0.95, jellyDamping, dt);
        stepSpring(dp.rotation, posStiffness, posDamping, dt);
        stepSpring(dp.stretch, jellyStiffness, jellyDamping, dt);
      });

      studioPhysRef.current.forEach((sp) => {
        stepSpring(sp.y, posStiffness, posDamping, dt);
        stepSpring(sp.squash, jellyStiffness, jellyDamping, dt);
        stepSpring(sp.rotation, posStiffness, posDamping, dt);
      });

      stepSpring(globalPhysRef.current.squash, jellyStiffness, jellyDamping, dt);
      stepSpring(globalPhysRef.current.y, posStiffness, posDamping, dt);
      stepSpring(globalPhysRef.current.rotation, posStiffness, posDamping, dt);

      stepSpring(winkSpringRef.current, 320, 16, dt);
      stepSpring(eyeSquishSpringRef.current, jellyStiffness, jellyDamping, dt);

      faceRef.current.winkAmount = Math.max(0, winkSpringRef.current.pos);
      faceRef.current.eyeSquish = eyeSquishSpringRef.current.pos;

      impactsRef.current = impactsRef.current
        .map((item) => ({
          ...item,
          progress: item.progress + dt * 2.4,
        }))
        .filter((item) => item.progress < 1);

      // Commit to React state for SVG render using exact volume-preserving exponential mapping
      const gs = globalPhysRef.current.squash.pos;
      setRenderState({
        letters: lettersPhysRef.current.map((lp) => {
          const s = Math.max(-0.48, Math.min(0.45, lp.squash.pos));
          const scaleY = Math.exp(s);
          const scaleX = Math.exp(-s * 0.86);
          const jellySquishY = -s * 1.35;

          return {
            x: lp.x.pos,
            y: lp.y.pos,
            scaleX,
            scaleY,
            rotation: lp.rotation.pos,
            skewX: lp.skewX.pos,
            jellyBendX: lp.jellyBendX.pos,
            jellySquishY,
            opacity: lp.opacity,
          };
        }) as [LetterTransform, LetterTransform, LetterTransform, LetterTransform],
        droplets: dropletsPhysRef.current.map((dp) => ({
          scale: Math.max(0, dp.scale.pos),
          distance: Math.max(0, dp.distance.pos),
          rotation: dp.rotation.pos,
          stretch: Math.max(0.4, dp.stretch.pos),
          opacity: dp.opacity,
        })) as [DropletTransform, DropletTransform, DropletTransform, DropletTransform],
        studioChars: studioPhysRef.current.map((sp) => {
          const cs = Math.max(-0.36, Math.min(0.36, sp.squash.pos));
          return {
            y: sp.y.pos,
            scaleX: Math.exp(-cs * 0.85),
            scaleY: Math.exp(cs),
            opacity: sp.opacity,
            rotation: sp.rotation.pos,
          };
        }),
        face: { ...faceRef.current },
        globalSqueeze: {
          scaleX: Math.exp(-gs * 0.85),
          scaleY: Math.exp(gs),
          y: globalPhysRef.current.y.pos,
          rotation: globalPhysRef.current.rotation.pos,
        },
        impacts: [...impactsRef.current],
      });

      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [preset, juiciness, bounciness, speedMultiplier, spawnImpact]);

  // =========================================================================
  // INTERACTIVE POINTER / DRAG SQUEEZING ON INDIVIDUAL LETTERS OR FULL STAGE
  // =========================================================================
  const handleLetterPointerDown = (index: number, e: React.PointerEvent) => {
    e.stopPropagation();
    juicyAudio.unlock();
    juicyAudio.playManualSquish(1.18);

    // If user manually interacts with a letter, cancel auto-fade-out so they can play freely!
    triggeredEventsRef.current.delete('WANT_GAME_TRANSITION');
    setAutoEnterGame(false);
    setFadeOverlayOpacity(0);
    setStageExitScale(1);

    activeLetterRef.current = index;
    setActiveSqueezeLetter(index);
    dragStartRef.current = { x: e.clientX, y: e.clientY, time: performance.now() };

    const lp = lettersPhysRef.current[index];
    lp.inAir = false;
    const j = juiciness;

    lp.squash.target = -0.30 * j;

    lettersPhysRef.current.forEach((other, idx) => {
      if (idx !== index) {
        const dir = idx < index ? 1 : -1;
        other.x.target = dir * 12 * j;
        other.squash.target = -0.06;
      }
    });

    eyeSquishSpringRef.current.target = 0.85;
    winkSpringRef.current.target = 0;
    faceRef.current.expression = 'happy';
  };

  const handleStagePointerDown = (e: React.PointerEvent) => {
    if (inGameScene || showExportModal) return;
    if ((e.target as HTMLElement).closest('[data-ui-control="true"]')) return;

    juicyAudio.unlock();
    if (cleanMode) {
      startIntro(preset, autoEnterGame);
      return;
    }

    // Cancel auto-exit while user is manually squeezing the stage
    triggeredEventsRef.current.delete('WANT_GAME_TRANSITION');
    setAutoEnterGame(false);
    setFadeOverlayOpacity(0);
    setStageExitScale(1);

    isGlobalHoldRef.current = true;
    setIsGlobalSqueezing(true);
    dragStartRef.current = { x: e.clientX, y: e.clientY, time: performance.now() };
    juicyAudio.playManualSquish(1.22);

    const j = juiciness;
    globalPhysRef.current.squash.target = -0.18 * j;

    const pullIn = [26, 9, -9, -26];
    lettersPhysRef.current.forEach((lp, i) => {
      lp.inAir = false;
      lp.x.target = pullIn[i] * j;
      lp.squash.target = -0.20 * j;
    });

    eyeSquishSpringRef.current.target = 0.85;
    winkSpringRef.current.target = 0;
    faceRef.current.expression = 'happy';
  };

  const handleGlobalPointerMove = (e: React.PointerEvent) => {
    const vw = window.innerWidth || 1;
    const vh = window.innerHeight || 1;
    const nx = ((e.clientX / vw) - 0.5) * 2;
    const ny = ((e.clientY / vh) - 0.5) * 2;
    pointerPosRef.current = { x: nx, y: ny };

    if (activeLetterRef.current !== null && dragStartRef.current) {
      const idx = activeLetterRef.current;
      const dx = (e.clientX - dragStartRef.current.x) * 0.35;
      const dy = (e.clientY - dragStartRef.current.y) * 0.35;
      const lp = lettersPhysRef.current[idx];

      lp.x.target = Math.max(-40, Math.min(40, dx));
      lp.jellyBendX.target = Math.max(-1.0, Math.min(1.0, dx * 0.022));

      if (dy > 0) {
        const extraSquash = Math.min(0.20, dy * 0.0032);
        lp.y.target = 0;
        lp.squash.target = -0.28 - extraSquash;
        eyeSquishSpringRef.current.target = 0.9;
      } else {
        const extraStretch = Math.min(0.28, -dy * 0.0035);
        lp.squash.target = 0.10 + extraStretch;
        lp.y.target = Math.max(-42, dy * 0.42);
        eyeSquishSpringRef.current.target = -0.4;
      }
    }
  };

  const handleGlobalPointerUp = useCallback(() => {
    const j = juiciness;
    const groundX = [208, 396, 588, 768];

    if (activeLetterRef.current !== null) {
      const idx = activeLetterRef.current;
      activeLetterRef.current = null;
      setActiveSqueezeLetter(null);
      dragStartRef.current = null;

      juicyAudio.playReleaseBoing(idx);

      lettersPhysRef.current.forEach((lp, i) => {
        lp.x.target = 0;
        lp.y.target = 0;
        lp.squash.target = 0;
        lp.rotation.target = 0;
        lp.jellyBendX.target = 0;

        if (i === idx) {
          lp.squash.vel = 6.8 * j;
          lp.y.vel = -155 * j;
        } else {
          lp.squash.vel = 2.0 * j;
        }
      });

      if (idx === 0 || idx === 3) {
        dropletsPhysRef.current.forEach((dp) => {
          dp.scale.vel += 4.2 * j;
          dp.distance.vel += 3.5 * j;
        });
      }

      eyeSquishSpringRef.current.target = 0;
      eyeSquishSpringRef.current.vel = -3.8 * j;

      if (idx === 1) {
        juicyAudio.playMascotWink();
        winkSpringRef.current.target = 1;
        spawnImpact(362, 165, 'winkSparkle', 0.9 * j);
      }

      spawnImpact(groundX[idx], 348, 'ring', 0.8 * j);

      scheduleAction(() => {
        if (activeLetterRef.current === null && !isGlobalHoldRef.current) {
          winkSpringRef.current.target = 0;
          faceRef.current.expression = 'normal';
        }
      }, 460);
    }

    if (isGlobalHoldRef.current) {
      isGlobalHoldRef.current = false;
      setIsGlobalSqueezing(false);
      dragStartRef.current = null;

      juicyAudio.playReleaseBoing(1.3);
      juicyAudio.playDropletBurst();

      globalPhysRef.current.squash.target = 0;
      globalPhysRef.current.squash.vel = 5.4 * j;
      globalPhysRef.current.y.target = 0;

      lettersPhysRef.current.forEach((lp) => {
        lp.x.target = 0;
        lp.y.target = 0;
        lp.squash.target = 0;
        lp.squash.vel = 6.0 * j;
        lp.y.vel = -140 * j;
        lp.rotation.target = 0;
      });

      dropletsPhysRef.current.forEach((dp) => {
        dp.opacity = 1;
        dp.scale.target = 1;
        dp.scale.vel += 6.0 * j;
        dp.distance.target = 1;
        dp.distance.vel += 5.0 * j;
      });

      eyeSquishSpringRef.current.target = 0;
      eyeSquishSpringRef.current.vel = -4.0 * j;

      spawnImpact(484, 245, 'globalWave', 0.95 * j);

      // Right as the Mega Squeeze finishes its pop-back (~240ms), Letter 'A' performs the Cheeky WINK 😉!
      scheduleAction(() => {
        if (activeLetterRef.current === null && !isGlobalHoldRef.current) {
          const lpA = lettersPhysRef.current[1];
          lpA.squash.vel -= 3.2 * j;
          lpA.y.vel = -115 * j;

          winkSpringRef.current.target = 1;
          winkSpringRef.current.vel = 7.5;
          faceRef.current.expression = 'wink';
          juicyAudio.playMascotWink();
          spawnImpact(362, 165, 'winkSparkle', 0.95 * j);
        }
      }, 240);

      scheduleAction(() => {
        if (activeLetterRef.current === null && !isGlobalHoldRef.current) {
          winkSpringRef.current.target = 0;
          faceRef.current.expression = 'normal';
        }
      }, 720);
    }
  }, [juiciness, spawnImpact, scheduleAction]);

  const handleLetterPointerEnter = (index: number) => {
    setHoveredLetter(index);
    if (activeLetterRef.current === null && !isGlobalHoldRef.current && animTimeRef.current > 1.4) {
      const lp = lettersPhysRef.current[index];
      lp.squash.vel -= 2.8 * juiciness;
      if (index === 1) {
        faceRef.current.expression = 'happy';
      }
    }
  };

  const handleLetterPointerLeave = () => {
    setHoveredLetter(null);
    if (activeLetterRef.current === null && !isGlobalHoldRef.current && animTimeRef.current > 1.8) {
      faceRef.current.expression = 'normal';
    }
  };

  // Keyboard shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (inGameScene) return;
      if (e.code === 'Space') {
        e.preventDefault();
        startIntro(preset, autoEnterGame);
      } else if (e.code === 'KeyS') {
        e.preventDefault();
        triggerManualMegaSqueeze();
      } else if (e.code === 'KeyW') {
        e.preventDefault();
        triggerMascotWinkAction();
      } else if (e.code === 'KeyH' || e.code === 'Escape') {
        setCleanMode((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    inGameScene,
    preset,
    autoEnterGame,
    startIntro,
    triggerManualMegaSqueeze,
    triggerMascotWinkAction,
  ]);

  const toggleSound = async () => {
    if (soundEnabled && soundReady && soundVolume > 0) {
      juicyAudio.enabled = false;
      setSoundEnabled(false);
      return;
    }
    juicyAudio.enabled = true;
    setSoundEnabled(true);
    if (soundVolume === 0) {
      juicyAudio.volume = 0.7;
      setSoundVolume(0.7);
    }
    const ready = await juicyAudio.unlock();
    setSoundReady(ready);
    if (ready) startIntro(preset, autoEnterGame);
  };

  const changeSoundVolume = (value: number) => {
    juicyAudio.volume = value;
    setSoundVolume(value);
  };

  const previewSound = async () => {
    juicyAudio.enabled = true;
    setSoundEnabled(true);
    if (soundVolume === 0) changeSoundVolume(0.7);
    const ready = await juicyAudio.unlock();
    setSoundReady(ready);
    if (ready) {
      setAutoEnterGame(false);
      setShowTuning(false);
      startIntro(preset, false);
    }
  };

  // =========================================================================
  // RENDER: OUTER STUDIO SHELL + 9:16 PORTRAIT VIEWPORT FRAME (OR FULLSCREEN)
  // =========================================================================
  return (
    <div
      onPointerDownCapture={unlockSound}
      onKeyDownCapture={unlockSound}
      onPointerMove={handleGlobalPointerMove}
      onPointerUp={handleGlobalPointerUp}
      className="relative w-full h-full flex items-center justify-center overflow-hidden select-none bg-[#B80D0D]"
      style={{
        background: portrait916
          ? 'radial-gradient(circle at 50% 50%, #D91414 0%, #9E0B0B 65%, #6E0606 100%)'
          : undefined,
      }}
    >
      {/* Subtle ambient background info outside the 9:16 frame on desktop */}
      {portrait916 && !cleanMode && (
        <div className="hidden lg:flex fixed left-7 top-1/2 -translate-y-1/2 flex-col gap-2 text-white/55 text-xs max-w-[195px] pointer-events-none">
          <div className="inline-flex items-center gap-1.5 font-mono-code text-[11px] font-bold text-white/85 uppercase tracking-wider">
            <Smartphone className="w-3.5 h-3.5" />
            9:16 Splash → Game
          </div>
          <p className="leading-relaxed text-[11px] text-white/65">
            Alur lengkap: <strong>Fade-In</strong> → <strong>Neat Juicy Squeeze &amp; Wink 😉</strong> → <strong>Fade-Out</strong> lanjut ke <strong>Halaman Game Inti</strong>.
          </p>
        </div>
      )}

      {/* ===================================================================
          THE MAIN STAGE CONTAINER (9:16 Portrait Frame on Desktop / Full on Mobile)
         =================================================================== */}
      <div
        id="sans-stage-container"
        onPointerDown={handleStagePointerDown}
        className={`relative flex flex-col items-center justify-center overflow-hidden transition-all duration-300 ${
          flatRedBg ? 'studio-red-flat' : 'studio-red-stage'
        } ${
          portrait916
            ? 'w-full h-full sm:w-auto sm:h-[94dvh] sm:aspect-[9/16] sm:rounded-[40px] sm:shadow-[0_28px_90px_rgba(0,0,0,0.55)] sm:border-[4px] sm:border-white/25'
            : 'w-full h-full'
        }`}
      >
        {inGameScene ? (
          <Game2DTransitionPreview
            soundOn={soundEnabled && soundReady && soundVolume > 0}
            soundVolume={soundVolume}
            onSoundToggle={() => { void toggleSound(); }}
            onVolumeChange={changeSoundVolume}
            onBackToIntroHold={() => {
              setAutoEnterGame(false);
              startIntro(preset, false);
            }}
            onReplayFullFlow={() => {
              setAutoEnterGame(true);
              startIntro(preset, true);
            }}
          />
        ) : (
          <>
            {/* ===============================================================
                SMOOTH FADE-IN / FADE-OUT CINEMATIC CURTAIN OVERLAY
               =============================================================== */}
            <div
              className="absolute inset-0 z-30 pointer-events-none bg-[#12131F]"
              style={{
                opacity: fadeOverlayOpacity,
              }}
            />

            {/* ===============================================================
                TOP COMPACT STUDIO HEADER BAR (Neat & Balanced for 9:16)
               =============================================================== */}
            {!cleanMode && (
              <div
                data-ui-control="true"
                className="absolute top-3.5 left-3.5 right-3.5 z-20 flex items-center justify-between gap-2 pointer-events-auto"
              >
                {/* Left Phase Pill */}
                <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-black/20 backdrop-blur-md border border-white/20 text-white shadow-sm">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                  <span className="font-mono-code text-[10px] font-semibold tracking-wider uppercase truncate max-w-[130px] sm:max-w-none">
                    {introPhaseLabel}
                  </span>
                </div>

                {/* Right Compact Action Buttons */}
                <div className="flex items-center gap-1">
                  {/* Toggle Auto Lanjut ke Game Inti (Fade-Out) vs Tahan di Logo */}
                  <button
                    onClick={() => {
                      const next = !autoEnterGame;
                      setAutoEnterGame(next);
                      startIntro(preset, next);
                    }}
                    className={`flex items-center gap-1 px-2.5 py-1.5 rounded-full font-bold text-[10px] shadow-md transition cursor-pointer active:scale-95 ${
                      autoEnterGame
                        ? 'bg-white text-[#F11E1E]'
                        : 'bg-black/25 text-white border border-white/25'
                    }`}
                    title="Aktifkan/Matikan otomatis Fade-Out lanjut ke Halaman Game Inti"
                  >
                    <Gamepad2 className="w-3.5 h-3.5" />
                    <span>{autoEnterGame ? 'Auto ke Game: ON' : 'Tahan Logo'}</span>
                  </button>

                  {/* Toggle 9:16 vs Fullscreen */}
                  <button
                    onClick={() => setPortrait916((prev) => !prev)}
                    className="hidden sm:flex items-center gap-1 px-2 py-1.5 rounded-full bg-black/20 hover:bg-black/35 text-white text-[10px] font-semibold backdrop-blur-md border border-white/20 transition cursor-pointer"
                    title="Ganti rasio tampilan 9:16 Portrait atau Fullscreen"
                  >
                    {portrait916 ? (
                      <>
                        <Maximize2 className="w-3 h-3" />
                        <span>16:9</span>
                      </>
                    ) : (
                      <>
                        <Smartphone className="w-3 h-3" />
                        <span>9:16</span>
                      </>
                    )}
                  </button>

                  {/* Clean Mode */}
                  <button
                    onClick={() => setCleanMode(true)}
                    className="p-1.5 rounded-full bg-black/20 hover:bg-black/30 text-white backdrop-blur-md border border-white/20 transition cursor-pointer"
                    title="Mode Layar Bersih untuk Rekam Video (ESC untuk kembali)"
                  >
                    <EyeOff className="w-3.5 h-3.5" />
                  </button>

                  {/* Export / Download SVG */}
                  <button
                    onClick={() => setShowExportModal(true)}
                    className="p-1.5 rounded-full bg-black/20 hover:bg-black/30 text-white backdrop-blur-md border border-white/20 transition cursor-pointer"
                    title="Download SVG / Export"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>

                  {/* Sound SFX Toggle */}
                  <button
                    onClick={toggleSound}
                    data-audio-toggle="true"
                    className="p-1.5 rounded-full bg-black/20 hover:bg-black/30 text-white backdrop-blur-md border border-white/20 transition cursor-pointer"
                    aria-label={soundEnabled && soundReady && soundVolume > 0 ? 'Matikan suara' : 'Nyalakan suara dan putar intro'}
                    aria-pressed={soundEnabled && soundReady && soundVolume > 0}
                    title={soundEnabled && soundReady && soundVolume > 0 ? 'Mochi Garden: suara aktif' : 'Klik untuk mendengarkan intro dengan suara'}
                  >
                    {soundEnabled && soundReady && soundVolume > 0 ? (
                      <Volume2 className="w-3.5 h-3.5" />
                    ) : (
                      <VolumeX className="w-3.5 h-3.5 text-white/60" />
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* ===============================================================
                CENTER HERO STAGE: ULTRA-CLEAN SANS STUDIO WORDMARK (-30% SIZE)
               =============================================================== */}
            <div
              className={`relative z-10 w-full h-full flex items-center justify-center ${
                portrait916 ? 'px-2 pb-16 pt-8' : 'px-6 sm:px-14 pb-16 pt-12'
              }`}
              style={{
                transform: `scale(${stageExitScale})`,
              }}
            >
              <SansWordmarkSvg
                letters={renderState.letters}
                droplets={renderState.droplets}
                studioChars={renderState.studioChars}
                face={renderState.face}
                globalSqueeze={renderState.globalSqueeze}
                impacts={renderState.impacts}
                hoveredLetter={hoveredLetter}
                activeSqueezeLetter={activeSqueezeLetter}
                onLetterPointerDown={handleLetterPointerDown}
                onLetterPointerEnter={handleLetterPointerEnter}
                onLetterPointerLeave={handleLetterPointerLeave}
                onStudioSublabelClick={triggerStudioSublabelWave}
                redBgHex="#F11E1E"
                isPortrait916={portrait916}
                showShineMarks={showShineMarks}
                logoScaleFactor={logoScale}
              />
            </div>

            {/* ===============================================================
                FLOATING PHYSICS & SCALE TUNING DRAWER
               =============================================================== */}
            {!cleanMode && showTuning && (
              <div
                data-ui-control="true"
                className="absolute bottom-28 z-30 w-[90%] max-w-xs p-3.5 rounded-3xl bg-black/55 backdrop-blur-xl border border-white/25 text-white shadow-2xl animate-fadeIn"
              >
                <div className="flex items-center justify-between mb-2.5 pb-2 border-b border-white/15">
                  <span className="text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5" />
                    Kustomisasi Logo
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setShowShineMarks((prev) => !prev)}
                      className={`px-2 py-0.5 rounded-full text-[10px] font-semibold transition cursor-pointer ${
                        showShineMarks ? 'bg-white text-[#F11E1E]' : 'bg-white/15 text-white'
                      }`}
                    >
                      Shine: {showShineMarks ? 'ON' : 'OFF'}
                    </button>
                    <button
                      onClick={() => setFlatRedBg((prev) => !prev)}
                      className="px-2 py-0.5 rounded-full bg-white/15 hover:bg-white/25 text-[10px] font-semibold transition cursor-pointer"
                    >
                      {flatRedBg ? 'Flat' : 'Glow'}
                    </button>
                  </div>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-white/85 font-medium w-28 text-[11px]">
                      Ukuran ({Math.round(logoScale * 100)}%)
                    </span>
                    <input
                      type="range"
                      min="0.5"
                      max="1.0"
                      step="0.05"
                      value={logoScale}
                      onChange={(e) => setLogoScale(parseFloat(e.target.value))}
                      className="juicy-slider flex-1"
                    />
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <span className="text-white/85 font-medium w-28 text-[11px]">
                      Juicy ({Math.round(juiciness * 100)}%)
                    </span>
                    <input
                      type="range"
                      min="0.7"
                      max="1.5"
                      step="0.05"
                      value={juiciness}
                      onChange={(e) => setJuiciness(parseFloat(e.target.value))}
                      className="juicy-slider flex-1"
                    />
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <span className="text-white/85 font-medium w-28 text-[11px]">
                      Membal ({Math.round(bounciness * 100)}%)
                    </span>
                    <input
                      type="range"
                      min="0.75"
                      max="1.45"
                      step="0.05"
                      value={bounciness}
                      onChange={(e) => setBounciness(parseFloat(e.target.value))}
                      className="juicy-slider flex-1"
                    />
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <span className="text-white/85 font-medium w-28 text-[11px]">
                      Speed ({speedMultiplier.toFixed(1)}x)
                    </span>
                    <input
                      type="range"
                      min="0.5"
                      max="1.5"
                      step="0.1"
                      value={speedMultiplier}
                      onChange={(e) => setSpeedMultiplier(parseFloat(e.target.value))}
                      className="juicy-slider flex-1"
                    />
                  </div>
                </div>

                <div className="mt-3 border-t border-white/15 pt-3">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="flex items-center gap-1.5 text-xs font-semibold">
                        <Volume2 className="h-3.5 w-3.5" />
                        Mochi Garden
                      </p>
                      <p className="mt-1 text-[10px] text-white/65">Do-mi-sol-do saat mendarat, ting saat wink.</p>
                    </div>
                    <button
                      onClick={() => { void previewSound(); }}
                      className="flex min-h-9 items-center gap-1.5 rounded-full bg-white px-3 text-[11px] font-bold text-[#F11E1E] transition hover:bg-white/90 active:scale-95 cursor-pointer"
                      aria-label="Dengarkan intro dengan suara Mochi Garden"
                    >
                      <Play className="h-3 w-3 fill-current" />
                      Dengarkan
                    </button>
                  </div>
                  <div className="mt-3 flex items-center gap-3">
                    <label htmlFor="sound-volume" className="text-[11px] text-white/85">Volume</label>
                    <input
                      id="sound-volume"
                      type="range"
                      min="0"
                      max="100"
                      step="1"
                      value={Math.round(soundVolume * 100)}
                      onChange={(e) => changeSoundVolume(Number(e.target.value) / 100)}
                      className="juicy-slider min-w-0 flex-1"
                      aria-label="Volume suara"
                    />
                    <output htmlFor="sound-volume" className="w-7 text-right text-[10px] tabular-nums text-white/70">
                      {Math.round(soundVolume * 100)}%
                    </output>
                  </div>
                </div>
              </div>
            )}

            {/* ===============================================================
                BOTTOM COMPACT 9:16-FRIENDLY CONTROL DOCK
               =============================================================== */}
            {!cleanMode && (
              <div
                data-ui-control="true"
                className="absolute bottom-3.5 left-3 right-3 z-20 flex flex-col items-center gap-1.5 pointer-events-auto"
              >
                {/* Row 1: 4 Animation Style Presets */}
                <div className="flex items-center justify-center gap-1 px-2 py-1 rounded-full bg-black/20 backdrop-blur-xl border border-white/20 shadow-md max-w-full">
                  {(
                    [
                      { id: 'classic', label: '1. Drop & Squeeze' },
                      { id: 'mega_squeeze', label: '2. Mega Squeeze' },
                      { id: 'jelly_wave', label: '3. Wave' },
                      { id: 'balloon_pop', label: '4. Balloon' },
                    ] as const
                  ).map((item) => {
                    const active = preset === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setPreset(item.id);
                          startIntro(item.id, autoEnterGame);
                        }}
                        className={`px-2.5 py-1 rounded-full text-[10px] sm:text-[11px] font-semibold whitespace-nowrap transition cursor-pointer ${
                          active
                            ? 'bg-white text-[#F11E1E] shadow-sm font-bold'
                            : 'text-white/85 hover:bg-white/15'
                        }`}
                      >
                        {item.label}
                      </button>
                    );
                  })}
                </div>

                {/* Row 2: Primary Replay + Juicy Squeeze + Wink + Tuning */}
                <div className="flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-full bg-black/25 backdrop-blur-xl border border-white/25 shadow-xl">
                  <button
                    onClick={() => startIntro(preset, autoEnterGame)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white text-[#F11E1E] hover:bg-white/90 font-bold text-xs shadow-sm transition cursor-pointer active:scale-95"
                    title="Putar ulang animasi intro (Shortcut: SPACE)"
                  >
                    <RotateCcw className="w-3.5 h-3.5 stroke-[2.5]" />
                    <span>Replay</span>
                  </button>

                  <button
                    onClick={() => {
                      triggeredEventsRef.current.delete('WANT_GAME_TRANSITION');
                      setAutoEnterGame(false);
                      setFadeOverlayOpacity(0);
                      setStageExitScale(1);
                      triggerManualMegaSqueeze();
                    }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full font-bold text-xs transition cursor-pointer active:scale-90 ${
                      isGlobalSqueezing
                        ? 'bg-white text-[#F11E1E] scale-95'
                        : 'bg-white/20 hover:bg-white/30 text-white border border-white/25'
                    }`}
                    title="Remas & peras seluruh logo secara rapi! (Shortcut: S)"
                  >
                    <Hand className="w-3.5 h-3.5" />
                    <span>Squeeze!</span>
                  </button>

                  <button
                    onClick={() => {
                      triggeredEventsRef.current.delete('WANT_GAME_TRANSITION');
                      setAutoEnterGame(false);
                      setFadeOverlayOpacity(0);
                      setStageExitScale(1);
                      triggerMascotWinkAction();
                    }}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white border border-white/25 font-bold text-xs transition cursor-pointer active:scale-90"
                    title="Kedip Wink 😉 pada huruf A (Shortcut: W)"
                  >
                    <Smile className="w-3.5 h-3.5" />
                    <span>Wink 😉</span>
                  </button>

                  <button
                    onClick={() => {
                      if (!showTuning) {
                        triggeredEventsRef.current.delete('WANT_GAME_TRANSITION');
                        setAutoEnterGame(false);
                        setFadeOverlayOpacity(0);
                        setStageExitScale(1);
                      }
                      setShowTuning((prev) => !prev);
                    }}
                    className={`p-1.5 rounded-full transition cursor-pointer ${
                      showTuning
                        ? 'bg-white text-[#F11E1E]'
                        : 'bg-white/15 hover:bg-white/25 text-white'
                    }`}
                    aria-label="Pengaturan logo dan suara"
                    aria-expanded={showTuning}
                    title="Pengaturan logo, fisika, dan suara"
                  >
                    <Sliders className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* Clean Mode Exit Pill */}
            {cleanMode && (
              <button
                data-ui-control="true"
                onClick={() => setCleanMode(false)}
                className="absolute top-3.5 right-3.5 z-30 px-3 py-1.5 rounded-full bg-black/25 hover:bg-black/50 text-white/45 hover:text-white text-[11px] font-medium backdrop-blur-md transition opacity-35 hover:opacity-100 cursor-pointer flex items-center gap-1.5"
              >
                <Sparkles className="w-3 h-3" />
                <span>Kontrol (ESC)</span>
              </button>
            )}
          </>
        )}
      </div>

      {/* Export / Download SVG Modal */}
      <ExportCodeModal
        isOpen={showExportModal}
        onClose={() => setShowExportModal(false)}
        onEnterCleanRecordingMode={() => {
          setCleanMode(true);
          startIntro(preset, autoEnterGame);
        }}
      />
    </div>
  );
}

export default App;
