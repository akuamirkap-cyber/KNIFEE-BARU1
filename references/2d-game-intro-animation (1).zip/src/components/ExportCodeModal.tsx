import React, { useState } from 'react';
import { X, Copy, Check, Download, Code2, Sparkles } from 'lucide-react';

interface ExportCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onEnterCleanRecordingMode: () => void;
}

export const ExportCodeModal: React.FC<ExportCodeModalProps> = ({
  isOpen,
  onClose,
  onEnterCleanRecordingMode,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const embedSnippet = `<!-- SANS STUDIO — 2D Game Splash Intro (Red #F11E1E + White #FFFFFF) -->
<div id="sans-splash-intro" style="position:fixed;inset:0;background:#F11E1E;display:flex;align-items:center;justify-content:center;z-index:9999;overflow:hidden;">
  <!-- Panggil fungsi window.onSansIntroComplete() saat animasi selesai (2.8s) untuk masuk ke scene Game 2D -->
</div>`;

  const handleCopy = () => {
    navigator.clipboard.writeText(embedSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSvg = () => {
    const svgEl = document.querySelector('#sans-stage-container svg');
    if (!svgEl) return;
    const clone = svgEl.cloneNode(true) as SVGSVGElement;
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    // Prepend red background rect for standalone SVG export
    const bgRect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    bgRect.setAttribute('width', '1000');
    bgRect.setAttribute('height', '560');
    bgRect.setAttribute('fill', '#F11E1E');
    clone.insertBefore(bgRect, clone.firstChild);

    const svgData = new XMLSerializer().serializeToString(clone);
    const blob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'sans-studio-red-white-logo.svg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg rounded-3xl bg-[#1E1E2C] border border-white/15 p-6 text-white shadow-2xl">
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#F11E1E] flex items-center justify-center font-studio font-bold text-lg">
              S
            </div>
            <div>
              <h3 className="font-bold text-base">Pakai untuk Intro Game 2D</h3>
              <p className="text-xs text-white/60">
                Latar Merah (#F11E1E) • Tulisan Putih (#FFFFFF)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/10 text-white/70 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-4 text-sm">
          {/* Option 1: Clean Fullscreen Capture for Video / Sprite Sheet / MP4 */}
          <div className="p-4 rounded-2xl bg-[#F11E1E]/15 border border-[#F11E1E]/40">
            <div className="flex items-center gap-2 font-semibold text-white mb-1">
              <Sparkles className="w-4 h-4 text-[#FF6B6B]" />
              1. Rekam Layar Penuh Bersih (60 FPS) untuk Unity / Godot / Video Intro
            </div>
            <p className="text-xs text-white/75 leading-relaxed mb-3">
              Sembunyikan seluruh tombol kontrol sehingga layar 100% hanya latar merah dan animasi logo putih. Klik di mana saja untuk memutar ulang intro.
            </p>
            <button
              onClick={() => {
                onClose();
                onEnterCleanRecordingMode();
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-[#F11E1E] hover:bg-[#ff3232] text-white font-semibold text-xs transition cursor-pointer"
            >
              Masuk Mode Layar Bersih (Tekan H atau ESC untuk kembali)
            </button>
          </div>

          {/* Option 2: Download Clean Vector SVG */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between gap-3">
            <div>
              <div className="font-semibold text-white text-xs md:text-sm">
                2. Unduh Vector SVG (Latar Merah + Teks Putih)
              </div>
              <p className="text-xs text-white/60 mt-0.5">
                Resolusi tajam tak terbatas untuk aset UI game 2D Anda.
              </p>
            </div>
            <button
              onClick={handleDownloadSvg}
              className="shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-[#F11E1E] font-bold text-xs hover:bg-white/90 transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Download SVG
            </button>
          </div>

          {/* Option 3: HTML5 / Web Game Hook */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold text-xs flex items-center gap-1.5 text-white/90">
                <Code2 className="w-4 h-4 text-white/60" />
                3. Snippet Container HTML5 Game
              </span>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-xs transition cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-green-400" />
                    Tersalin
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    Salin
                  </>
                )}
              </button>
            </div>
            <pre className="p-3 rounded-xl bg-black/50 text-[11px] font-mono-code text-white/80 overflow-x-auto">
              {embedSnippet}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
