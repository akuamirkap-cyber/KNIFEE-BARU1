import React, { useEffect, useState } from 'react';
import { RotateCcw, Play, Sparkles, Gamepad2, Sliders } from 'lucide-react';
import { juicyAudio } from '../utils/juicyAudio';

interface Game2DTransitionPreviewProps {
  onBackToIntroHold: () => void;
  onReplayFullFlow: () => void;
}

export const Game2DTransitionPreview: React.FC<Game2DTransitionPreviewProps> = ({
  onBackToIntroHold,
  onReplayFullFlow,
}) => {
  const [entered, setEntered] = useState(false);
  const [mascotY, setMascotY] = useState(0);
  const [mascotScale, setMascotScale] = useState({ x: 1, y: 1 });
  const [isJumping, setIsJumping] = useState(false);
  const [coins, setCoins] = useState(12);
  const [gameStarted, setGameStarted] = useState(false);

  // Smooth Fade-In when entering the Main 2D Game Page ("Halaman Game Inti")
  useEffect(() => {
    const timer = requestAnimationFrame(() => {
      setEntered(true);
    });
    return () => cancelAnimationFrame(timer);
  }, []);

  const triggerMascotJump = () => {
    if (isJumping) return;
    setIsJumping(true);
    juicyAudio.playManualSquish(1.1);

    // Pre-jump cushion squash
    setMascotScale({ x: 1.32, y: 0.68 });

    setTimeout(() => {
      juicyAudio.playReleaseBoing(1.5);
      setMascotScale({ x: 0.82, y: 1.26 });
      setMascotY(-85);
    }, 85);

    setTimeout(() => {
      setMascotScale({ x: 1.04, y: 0.96 });
      setCoins((c) => c + 1);
      juicyAudio.playMascotWink();
    }, 260);

    setTimeout(() => {
      setMascotY(0);
      setMascotScale({ x: 1.28, y: 0.75 });
      juicyAudio.playSquishImpact(1, 0.7);
    }, 440);

    setTimeout(() => {
      setMascotScale({ x: 0.95, y: 1.06 });
    }, 560);

    setTimeout(() => {
      setMascotScale({ x: 1, y: 1 });
      setIsJumping(false);
    }, 680);
  };

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        e.preventDefault();
        triggerMascotJump();
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  });

  return (
    <div
      className={`relative w-full h-full flex flex-col items-center justify-between p-5 bg-[#151622] text-white overflow-hidden select-none transition-all duration-700 ease-out ${
        entered ? 'opacity-100 scale-100' : 'opacity-0 scale-[1.03]'
      }`}
    >
      {/* 2D Game Sky & Floating Clouds Background */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(circle at 50% 34%, #2B2E4A 0%, #191B2C 62%, #10111C 100%)',
        }}
      />

      {/* Decorative 2D Vector Stars & Hills optimized for 9:16 vertical screen */}
      <svg
        viewBox="0 0 540 960"
        preserveAspectRatio="xMidYMid slice"
        className="absolute inset-0 w-full h-full pointer-events-none opacity-55"
      >
        <circle cx="85" cy="140" r="4" fill="#FFFFFF" />
        <circle cx="440" cy="110" r="5.5" fill="#FF6B6B" />
        <circle cx="390" cy="220" r="4.5" fill="#FFFFFF" />
        <circle cx="110" cy="290" r="3.5" fill="#FFD166" />
        <circle cx="270" cy="95" r="3" fill="#FFFFFF" />
        {/* 2D Hills */}
        <path d="M -60 820 Q 150 610 380 820 Z" fill="#23263E" />
        <path d="M 180 820 Q 410 580 620 820 Z" fill="#1E2036" />
        {/* 2D Ground Platform */}
        <rect x="0" y="790" width="540" height="180" fill="#F11E1E" />
        <rect x="0" y="790" width="540" height="16" fill="#FF4747" />
      </svg>

      {/* Top Bar: Controls to Replay Intro Flow or Stay on Logo Page */}
      <div className="relative z-10 w-full flex flex-col items-center gap-2">
        <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/15 px-3.5 py-1.5 rounded-full">
          <span className="w-2 h-2 rounded-full bg-[#4ADE80] animate-pulse" />
          <span className="text-[10px] sm:text-[11px] font-semibold tracking-wide text-white/95 uppercase">
            HALAMAN GAME INTI 2D • SETELAH FADE-OUT INTRO
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={onReplayFullFlow}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#F11E1E] hover:bg-[#ff3333] text-white font-bold text-xs shadow-lg transition cursor-pointer active:scale-95"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Ulangi Intro (Fade-In → Out)
          </button>
          <button
            onClick={onBackToIntroHold}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/15 hover:bg-white/25 text-white font-semibold text-xs backdrop-blur-md border border-white/20 transition cursor-pointer active:scale-95"
          >
            <Sliders className="w-3.5 h-3.5" />
            Tahan di Logo
          </button>
        </div>
      </div>

      {/* Center 2D Game Title & Interactive Mascot Stage */}
      <div className="relative z-10 flex flex-col items-center text-center my-auto px-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#F11E1E]/25 border border-[#F11E1E]/50 text-[#FF8585] text-[10px] font-bold tracking-widest uppercase mb-2">
          <Gamepad2 className="w-3.5 h-3.5" />
          SANS STUDIO • OFFICIAL 2D GAME
        </div>

        <h1 className="font-studio text-4xl sm:text-5xl font-bold tracking-tight text-white drop-shadow-[0_5px_0_rgba(0,0,0,0.45)] leading-none">
          SANS <span className="text-[#F11E1E]">WORLD</span>
        </h1>
        <p className="text-white/70 text-xs mt-2 max-w-[260px]">
          Setelah intro logo <strong className="text-white">Fade-Out</strong>, pemain langsung masuk ke halaman utama game 2D ini.
        </p>

        {/* Interactive Bouncing Mascot Character */}
        <div
          onClick={triggerMascotJump}
          className="relative mt-5 mb-3 cursor-pointer group flex flex-col items-center"
          title="Ketuk untuk lompat!"
        >
          <div className="mb-2.5 px-3 py-1 rounded-full bg-[#FFD166]/20 border border-[#FFD166]/50 text-[#FFD166] font-mono-code text-[11px] font-bold flex items-center gap-1.5">
            <Sparkles className="w-3 h-3" />
            COINS: {coins}
          </div>

          <div
            style={{
              transform: `translateY(${mascotY}px) scale(${mascotScale.x}, ${mascotScale.y})`,
              transformOrigin: 'bottom center',
              transition: 'transform 90ms cubic-bezier(0.34, 1.56, 0.64, 1)',
            }}
          >
            {/* Mini App-Icon 'S' Mascot from Reference Artwork */}
            <svg width="112" height="112" viewBox="0 0 160 160" className="overflow-visible">
              <rect
                x="16"
                y="16"
                width="128"
                height="128"
                rx="36"
                fill="#F11E1E"
                stroke="#FFFFFF"
                strokeWidth="5"
              />
              <path
                d="M 102 52 C 88 42, 54 48, 54 72 C 54 92, 106 90, 104 114 C 102 134, 68 134, 52 122"
                fill="none"
                stroke="#FFFFFF"
                strokeWidth="36"
                strokeLinecap="round"
              />
              <path d="M 114 40 L 122 28" stroke="#FFFFFF" strokeWidth="7" strokeLinecap="round" />
              <path d="M 120 50 L 132 45" stroke="#FFFFFF" strokeWidth="7" strokeLinecap="round" />
              <path d="M 120 62 L 130 64" stroke="#FFFFFF" strokeWidth="6.5" strokeLinecap="round" />
              <ellipse cx="74" cy="70" rx="5" ry="10.5" fill="#F11E1E" transform="rotate(-8 74 70)" />
              <ellipse cx="92" cy="68" rx="5" ry="10.5" fill="#F11E1E" transform="rotate(-8 92 68)" />
              <path d="M 76 85 Q 84 88 92 84 C 93 96, 75 96, 76 85 Z" fill="#F11E1E" />
            </svg>
          </div>

          <div
            className="h-2.5 bg-black/45 rounded-full transition-all duration-150"
            style={{
              width: isJumping ? '46px' : '82px',
              opacity: isJumping ? 0.35 : 0.75,
            }}
          />

          <span className="mt-1.5 text-[11px] text-white/60 group-hover:text-white transition">
            Ketuk karakter untuk lompat!
          </span>
        </div>

        {/* Press Start Button */}
        <button
          onClick={() => {
            triggerMascotJump();
            setGameStarted(true);
          }}
          className="mt-1 px-8 py-3 rounded-2xl bg-[#F11E1E] hover:bg-[#ff2e2e] text-white font-studio text-lg tracking-wider shadow-[0_5px_0_#9E0B0B] active:translate-y-1 active:shadow-[0_2px_0_#9E0B0B] transition flex items-center gap-2.5 cursor-pointer"
        >
          <Play className="w-4 h-4 fill-white" />
          {gameStarted ? 'LEVEL 1 START!' : 'START GAME'}
        </button>
      </div>

      {/* Bottom Info Footer */}
      <div className="relative z-10 text-[11px] text-white/55 text-center px-2">
        Alur: <strong className="text-white/85">Fade-In Intro</strong> →{' '}
        <strong className="text-white/85">Neat Juicy Squeeze &amp; Wink</strong> →{' '}
        <strong className="text-white/85">Fade-Out</strong> →{' '}
        <strong className="text-white/85">Game Inti</strong>
      </div>
    </div>
  );
};
