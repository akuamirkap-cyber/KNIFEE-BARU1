// Procedural Web Audio API synthesizer for juicy 2D game splash sound effects

class JuicyAudioEngine {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  private getContext(): AudioContext | null {
    if (!this.enabled) return null;
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public unlock() {
    const ctx = this.getContext();
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
  }

  // Soft silky air drop whoosh
  public playDropWhoosh(index: number = 0) {
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    const startFreq = 580 + index * 65;
    const endFreq = 190 + index * 25;

    osc.type = 'sine';
    osc.frequency.setValueAtTime(startFreq, now);
    osc.frequency.exponentialRampToValueAtTime(endFreq, now + 0.16);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.08, now + 0.04);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.17);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.18);
  }

  // Deep juicy jelly squash impact + harmonic pop
  public playSquishImpact(index: number = 0, intensity: number = 1) {
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    // Harmonic pentatonic notes for S - A - N - S (F5, A5, C6, F6)
    const notes = [349.23, 440.0, 523.25, 698.46];
    const baseNote = notes[index % notes.length];

    // 1. Subby jelly thump / squish body
    const bodyOsc = ctx.createOscillator();
    const bodyGain = ctx.createGain();
    bodyOsc.type = 'triangle';
    bodyOsc.frequency.setValueAtTime(160 + index * 20, now);
    bodyOsc.frequency.exponentialRampToValueAtTime(58, now + 0.09);
    bodyOsc.frequency.exponentialRampToValueAtTime(195 + index * 30, now + 0.22);

    const vol = Math.min(0.28, 0.18 * intensity);
    bodyGain.gain.setValueAtTime(0.001, now);
    bodyGain.gain.linearRampToValueAtTime(vol, now + 0.015);
    bodyGain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);

    bodyOsc.connect(bodyGain);
    bodyGain.connect(ctx.destination);
    bodyOsc.start(now);
    bodyOsc.stop(now + 0.25);

    // 2. Liquid filter bubble harmonic
    const popOsc = ctx.createOscillator();
    const popGain = ctx.createGain();
    popOsc.type = 'sine';
    popOsc.frequency.setValueAtTime(baseNote * 0.65, now + 0.02);
    popOsc.frequency.exponentialRampToValueAtTime(baseNote * 1.35, now + 0.11);
    popOsc.frequency.exponentialRampToValueAtTime(baseNote, now + 0.22);

    popGain.gain.setValueAtTime(0.001, now + 0.02);
    popGain.gain.linearRampToValueAtTime(0.14 * intensity, now + 0.045);
    popGain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

    popOsc.connect(popGain);
    popGain.connect(ctx.destination);
    popOsc.start(now + 0.02);
    popOsc.stop(now + 0.26);
  }

  // Crisp water droplet burst when the 4 side marks pop out
  public playDropletBurst() {
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const freqs = [784, 987.77, 1174.66, 1567.98];

    freqs.forEach((f, i) => {
      const delay = i * 0.028;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(f * 0.55, now + delay);
      osc.frequency.exponentialRampToValueAtTime(f * 1.25, now + delay + 0.075);

      gain.gain.setValueAtTime(0.001, now + delay);
      gain.gain.linearRampToValueAtTime(0.11, now + delay + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.11);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + delay);
      osc.stop(now + delay + 0.12);
    });
  }

  // Subtle marimba-like tick for S - T - U - D - I - O wave
  public playStudioLetterTick(index: number) {
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const scale = [523.25, 587.33, 659.25, 783.99, 880.0, 1046.5];
    const freq = scale[index % scale.length];

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now);
    osc.frequency.exponentialRampToValueAtTime(freq * 1.04, now + 0.08);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.075, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.12);
  }

  // Cute mascot wink / happy chirp for letter 'A'
  public playMascotWink() {
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, now);
    osc.frequency.exponentialRampToValueAtTime(1318.5, now + 0.06);
    osc.frequency.exponentialRampToValueAtTime(1760, now + 0.13);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.11, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.17);
  }

  // Manual rubbery squish sound when user squeezes a letter or whole logo
  public playManualSquish(intensity: number = 1) {
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(140, now + 0.08);
    osc.frequency.exponentialRampToValueAtTime(240, now + 0.15);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.14 * Math.min(1.4, intensity), now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.17);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.18);
  }

  // Elastic release boing when letting go of a squeeze
  public playReleaseBoing(pitchOffset: number = 0) {
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    const base = 280 + pitchOffset * 55;
    osc.type = 'sine';
    osc.frequency.setValueAtTime(base * 0.6, now);
    osc.frequency.exponentialRampToValueAtTime(base * 1.85, now + 0.09);
    osc.frequency.exponentialRampToValueAtTime(base * 1.15, now + 0.18);
    osc.frequency.exponentialRampToValueAtTime(base * 1.45, now + 0.28);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.18, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.34);
  }

  // Warm studio resolve chord
  public playStudioResolveChord() {
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    // F major 9 warm indie game studio shimmer
    const chord = [349.23, 440.0, 523.25, 659.25, 783.99];
    chord.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.018);

      gain.gain.setValueAtTime(0.001, now + idx * 0.018);
      gain.gain.linearRampToValueAtTime(0.045, now + idx * 0.018 + 0.06);
      gain.gain.exponentialRampToValueAtTime(0.0008, now + 0.85);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + idx * 0.018);
      osc.stop(now + 0.9);
    });
  }
}

export const juicyAudio = new JuicyAudioEngine();
