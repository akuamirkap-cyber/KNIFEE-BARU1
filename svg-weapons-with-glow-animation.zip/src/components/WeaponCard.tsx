import { useCallback, useEffect, useRef, useState, type CSSProperties, type MouseEvent, type ReactNode } from "react";
import type { Rarity, WeaponDef } from "../weapons";

type Props = { def: WeaponDef; signal: { n: number; delay: number } };

const ONE_SHOT = ["dg-fire", "wb-fire", "pb-fire", "sl-fire", "mh-fire", "dg-spin", "sl-chomp", "pb-jiggle", "mh-whipA", "mh-whipB"];

function serialize(svg: SVGSVGElement) {
  const clone = svg.cloneNode(true) as SVGSVGElement;
  clone.querySelectorAll("[data-fx]").forEach((n) => n.remove());
  ONE_SHOT.forEach((c) => clone.querySelectorAll(`.${c}`).forEach((n) => n.classList.remove(c)));
  clone.removeAttribute("class");
  clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  clone.setAttribute("width", "512");
  clone.setAttribute("height", "512");
  return `<?xml version="1.0" encoding="UTF-8"?>\n${new XMLSerializer().serializeToString(clone)}`;
}

const Icon = ({ d, className = "h-3.5 w-3.5" }: { d: string; className?: string }) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden>
    <path d={d} />
  </svg>
);

const ICONS = {
  bolt: "M13.5 2 4 13.5h6.5L9.5 22 20 9.5h-6.6L13.5 2Z",
  flame: "M12 2s-5 5.2-5 10.2a5 5 0 0 0 10 0c0-2.2-1.1-3.8-2.1-4.8 0 1.6-.8 2.7-2.1 2.7.1-3.4-.8-5.7-.8-8.1Z",
  spark: "M12 1.5c.6 4.6 2.1 7.1 6.6 8.4.9.3.9 1.6 0 1.9-4.5 1.3-6 3.8-6.6 8.4-.1 1-1.6 1-1.7 0-.6-4.6-2.1-7.1-6.6-8.4-.9-.3-.9-1.6 0-1.9 4.5-1.3 6-3.8 6.6-8.4.1-1 1.6-1 1.7 0Z",
  gem: "M6.5 3h11l4.5 6.2L12 21.5 2 9.2 6.5 3Z",
  download: "M11 3h2v9.2l3.3-3.3 1.4 1.4L12 16l-5.7-5.7 1.4-1.4L11 12.2V3ZM4 18h16v2H4v-2Z",
  copy: "M8 3h11a2 2 0 0 1 2 2v11h-2V5H8V3Zm-3 4h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2Zm0 2v10h10V9H5Z",
  fire: "M12 2 9.5 8.5 3 9.3l4.9 4.5L6.6 21 12 17.6 17.4 21l-1.3-7.2L21 9.3l-6.5-.8L12 2Z",
};

const RARITY: Record<Rarity, { cls: string; icon: ReactNode }> = {
  MYTHIC: { cls: "from-cyan-300 to-blue-500 text-white", icon: <Icon d={ICONS.gem} className="h-3 w-3" /> },
  LEGEND: { cls: "from-amber-300 to-orange-500 text-[#3b1a00]", icon: <Icon d={ICONS.flame} className="h-3 w-3" /> },
  EPIC: { cls: "from-fuchsia-500 to-violet-600 text-white", icon: <Icon d={ICONS.bolt} className="h-3 w-3" /> },
  RARE: { cls: "from-pink-400 to-rose-500 text-white", icon: <Icon d={ICONS.spark} className="h-3 w-3" /> },
};

export default function WeaponCard({ def, signal }: Props) {
  const [tick, setTick] = useState(0);
  const [shots, setShots] = useState<number[]>([]);
  const [count, setCount] = useState(0);
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([]);
  const [toast, setToast] = useState<string | null>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const flashRef = useRef<HTMLDivElement>(null);
  const kickRef = useRef<HTMLDivElement>(null);
  const glowRef = useRef<HTMLDivElement>(null);
  const artRef = useRef<HTMLDivElement>(null);
  const seq = useRef(1);
  const Comp = def.Comp;
  const c = def.color;

  const fire = useCallback(() => {
    const id = seq.current++ * 7919 + Math.floor(Math.random() * 997);
    setTick((t) => t + 1);
    setCount((n) => n + 1);
    setShots((s) => [...s.slice(-6), id]);
    window.setTimeout(() => setShots((s) => s.filter((x) => x !== id)), 1800);
    def.sound();

    glowRef.current?.animate(
      [
        { filter: `drop-shadow(0 0 0px ${c}) drop-shadow(0 0 0px ${c}) brightness(1)` },
        { filter: `drop-shadow(0 0 14px ${c}) drop-shadow(0 0 34px ${c}) brightness(1.28)`, offset: 0.16 },
        { filter: `drop-shadow(0 0 9px ${c}) drop-shadow(0 0 18px ${c}) brightness(1.08)`, offset: 0.5 },
        { filter: `drop-shadow(0 0 0px ${c}) drop-shadow(0 0 0px ${c}) brightness(1)` },
      ],
      { duration: 1000, easing: "ease-out" }
    );
    const k = def.kick;
    kickRef.current?.animate(
      k.rot
        ? [
            { transform: "rotate(0deg)" },
            { transform: `rotate(${k.rot}deg)`, offset: 0.2 },
            { transform: `rotate(${-k.rot * 0.35}deg)`, offset: 0.55 },
            { transform: "rotate(0deg)" },
          ]
        : [
            { transform: "translate(0px,0px)" },
            { transform: `translate(${k.x}px,${k.y}px)`, offset: 0.12 },
            { transform: `translate(${-k.x * 0.18}px,${-k.y * 0.18}px)`, offset: 0.45 },
            { transform: "translate(0px,0px)" },
          ],
      { duration: k.rot ? 620 : 440, easing: "cubic-bezier(.2,.8,.2,1)" }
    );
    cardRef.current?.animate(
      [
        { boxShadow: `0 0 0 1px ${c}33, 0 0 0px ${c}00` },
        { boxShadow: `0 0 0 2px ${c}, 0 0 60px ${c}99`, offset: 0.18 },
        { boxShadow: `0 0 0 1px ${c}33, 0 0 0px ${c}00` },
      ],
      { duration: 900, easing: "ease-out" }
    );
    flashRef.current?.animate([{ opacity: 0 }, { opacity: 1, offset: 0.15 }, { opacity: 0 }], {
      duration: 850,
      easing: "ease-out",
    });
  }, [def, c]);

  useEffect(() => {
    if (!signal.n) return;
    window.setTimeout(fire, signal.delay);
  }, [signal, fire]);

  const onContext = (e: MouseEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    const rect = e.currentTarget.getBoundingClientRect();
    const rid = Date.now() + Math.random();
    setRipples((r) => [...r.slice(-4), { id: rid, x: e.clientX - rect.left, y: e.clientY - rect.top }]);
    window.setTimeout(() => setRipples((r) => r.filter((p) => p.id !== rid)), 700);
    fire();
  };

  const flashToast = (msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast(null), 1400);
  };

  const getSvg = () => {
    const svg = artRef.current?.querySelector("svg");
    return svg ? serialize(svg) : null;
  };

  const download = () => {
    const xml = getSvg();
    if (!xml) return;
    const url = URL.createObjectURL(new Blob([xml], { type: "image/svg+xml" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `${def.id}.svg`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1500);
    flashToast("SVG diunduh!");
  };

  const copy = async () => {
    const xml = getSvg();
    if (!xml) return;
    try {
      await navigator.clipboard.writeText(xml);
      flashToast("Kode SVG tersalin!");
    } catch {
      // fallback for non-secure contexts
      const ta = document.createElement("textarea");
      ta.value = xml;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      flashToast(ok ? "Kode SVG tersalin!" : "Gagal menyalin");
    }
  };

  const rar = RARITY[def.rarity];

  return (
    <div
      ref={cardRef}
      onContextMenu={onContext}
      className="weapon-card group relative select-none overflow-hidden rounded-[28px] border border-white/10 bg-[#170b30] shadow-2xl shadow-black/60 transition-transform duration-300 hover:-translate-y-1"
      style={{ "--c": c, "--c2": def.color2 } as CSSProperties}
    >
      {/* backdrop */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_42%,#4d2c8f_0%,#2b1659_42%,#140a2c_82%)]" />
      <div className="card-rays pointer-events-none absolute -inset-1/4" />
      <div
        className="breath pointer-events-none absolute left-1/2 top-[44%] h-[62%] w-[62%] -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl"
        style={{ background: `radial-gradient(circle, ${c}55 0%, transparent 70%)` }}
      />
      <div
        ref={flashRef}
        className="pointer-events-none absolute inset-0 opacity-0"
        style={{ background: `radial-gradient(circle at 50% 45%, ${c}66, transparent 68%)` }}
      />
      <div
        className="pointer-events-none absolute inset-0 rounded-[28px] opacity-0 transition-opacity duration-300 group-hover:opacity-100"
        style={{ boxShadow: `inset 0 0 0 1.5px ${c}77, inset 0 0 50px ${c}26` }}
      />

      {/* chips */}
      <div className="absolute left-4 top-4 z-20 flex items-center gap-2">
        <span className="grid h-8 w-8 place-items-center rounded-xl bg-black/35 font-display text-lg text-white/90 ring-1 ring-white/15">
          {def.no}
        </span>
      </div>
      <div className="absolute right-4 top-4 z-20 flex items-center gap-1.5 rounded-xl bg-black/35 px-2.5 py-1.5 text-[11px] font-extrabold uppercase tracking-wider text-white/80 ring-1 ring-white/15">
        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden>
          <rect x="5" y="2.5" width="14" height="19" rx="7" />
          <path d="M12 2.5v7" />
          <path d="M12 2.5h0a7 7 0 0 1 7 7H12Z" fill={c} stroke={c} />
        </svg>
        <span>{count > 0 ? `x${count}` : "Klik kanan"}</span>
      </div>

      {/* stage */}
      <div className="relative aspect-square w-full">
        <div className="floor-ring pointer-events-none absolute bottom-[5%] left-[17%] right-[17%] h-[9%] rounded-[50%]" />
        <div className="idle-float absolute inset-[7%]">
          <div ref={kickRef} className="h-full w-full" style={{ transformOrigin: def.kick.origin ?? "50% 50%" }}>
            <div ref={glowRef} className="h-full w-full">
              <div ref={artRef} className="h-full w-full">
                <Comp shots={shots} tick={tick} />
              </div>
            </div>
          </div>
        </div>
        {ripples.map((r) => (
          <span key={r.id} className="ripple" style={{ left: r.x, top: r.y }} />
        ))}
        {toast && (
          <div className="toast absolute left-1/2 top-14 z-30 -translate-x-1/2 rounded-full bg-black/70 px-3 py-1.5 text-xs font-bold text-white ring-1 ring-white/20">
            {toast}
          </div>
        )}
      </div>

      {/* banner */}
      <div className="relative z-20 mx-3 -mt-3 flex items-center gap-2">
        <div className="flex min-w-0 flex-1 items-center gap-2 rounded-2xl border border-amber-300/40 bg-[#1c1040]/90 px-3.5 py-2.5 shadow-[inset_0_1px_0_rgba(255,255,255,.08)]">
          <h3 className="gold-text min-w-0 truncate font-display text-[20px] leading-none tracking-wide">{def.name.toUpperCase()}</h3>
          <span
            className={`ml-auto inline-flex shrink-0 items-center gap-1 rounded-lg bg-gradient-to-b px-2 py-1 font-display text-[12px] leading-none tracking-wider shadow-md ring-1 ring-white/30 ${rar.cls}`}
          >
            {rar.icon}
            {def.rarity}
          </span>
        </div>
        <button
          type="button"
          onClick={download}
          title="Unduh file .svg"
          className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-b from-violet-500 to-violet-700 text-white shadow-lg ring-1 ring-white/25 transition hover:brightness-125 active:scale-95"
        >
          <Icon d={ICONS.download} className="h-5 w-5" />
        </button>
      </div>
      <div className="relative z-20 flex items-center gap-2 px-5 pb-4 pt-3 text-[12.5px] leading-snug text-violet-200/75">
        <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: c, boxShadow: `0 0 10px ${c}` }} />
        <span className="flex-1">{def.effect}</span>
        <button
          type="button"
          onClick={copy}
          title="Salin kode SVG"
          className="inline-flex shrink-0 items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-extrabold uppercase tracking-wider text-white/70 ring-1 ring-white/15 transition hover:bg-white/10 hover:text-white"
        >
          <Icon d={ICONS.copy} className="h-3.5 w-3.5" />
          SVG
        </button>
        <button
          type="button"
          onClick={fire}
          className="shrink-0 rounded-lg px-2 py-1 text-[11px] font-extrabold uppercase tracking-wider text-white/70 ring-1 ring-white/15 transition hover:bg-white/10 hover:text-white sm:hidden"
        >
          Tembak
        </button>
      </div>
    </div>
  );
}
