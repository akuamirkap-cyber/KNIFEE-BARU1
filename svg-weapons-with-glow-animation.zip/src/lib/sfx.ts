/* Tiny WebAudio synth – every weapon gets its own procedural sound. */

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let muted = false;
let noiseBuf: AudioBuffer | null = null;

export const setMuted = (m: boolean) => {
  muted = m;
};

function ac() {
  if (!ctx) {
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.3;
    const comp = ctx.createDynamicsCompressor();
    master.connect(comp).connect(ctx.destination);
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

type ToneOpts = {
  type?: OscillatorType;
  f0: number;
  f1?: number;
  dur: number;
  vol?: number;
  delay?: number;
};

function tone(o: ToneOpts) {
  const c = ac();
  const t = c.currentTime + (o.delay ?? 0);
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = o.type ?? "sine";
  osc.frequency.setValueAtTime(o.f0, t);
  if (o.f1) osc.frequency.exponentialRampToValueAtTime(o.f1, t + o.dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(o.vol ?? 0.4, t + 0.008);
  g.gain.exponentialRampToValueAtTime(0.0001, t + o.dur);
  osc.connect(g).connect(master!);
  osc.start(t);
  osc.stop(t + o.dur + 0.05);
}

type NoiseOpts = {
  dur: number;
  vol?: number;
  delay?: number;
  type?: BiquadFilterType;
  f0: number;
  f1?: number;
  q?: number;
};

function noise(o: NoiseOpts) {
  const c = ac();
  const t = c.currentTime + (o.delay ?? 0);
  if (!noiseBuf) {
    noiseBuf = c.createBuffer(1, c.sampleRate, c.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  }
  const src = c.createBufferSource();
  src.buffer = noiseBuf;
  const f = c.createBiquadFilter();
  f.type = o.type ?? "bandpass";
  f.Q.value = o.q ?? 1;
  f.frequency.setValueAtTime(o.f0, t);
  if (o.f1) f.frequency.exponentialRampToValueAtTime(o.f1, t + o.dur);
  const g = c.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(o.vol ?? 0.4, t + 0.005);
  g.gain.exponentialRampToValueAtTime(0.0001, t + o.dur);
  src.connect(f).connect(g).connect(master!);
  src.start(t, Math.random() * 0.4);
  src.stop(t + o.dur + 0.05);
}

const safe = (fn: () => void) => () => {
  if (muted) return;
  try {
    fn();
  } catch {
    /* audio not available */
  }
};

export const sfx = {
  /** crystal chime + shimmer */
  diamond: safe(() => {
    [1568, 2093, 2637, 3136, 4186].forEach((f, i) => tone({ f0: f, dur: 0.65 - i * 0.07, vol: 0.16, delay: i * 0.035 }));
    tone({ type: "triangle", f0: 900, f1: 2600, dur: 0.18, vol: 0.12 });
    noise({ dur: 0.4, vol: 0.1, type: "highpass", f0: 6500 });
  }),
  /** laser "pew" */
  wars: safe(() => {
    tone({ type: "square", f0: 1500, f1: 110, dur: 0.24, vol: 0.2 });
    tone({ type: "sawtooth", f0: 760, f1: 70, dur: 0.3, vol: 0.16 });
    noise({ dur: 0.16, vol: 0.3, type: "bandpass", f0: 2400, f1: 600, q: 0.8 });
  }),
  /** triple pop + splat */
  paintball: safe(() => {
    [0, 0.085, 0.17].forEach((d) => {
      noise({ dur: 0.07, vol: 0.5, type: "lowpass", f0: 1500, f1: 300, delay: d });
      tone({ f0: 220, f1: 60, dur: 0.09, vol: 0.38, delay: d });
    });
    noise({ dur: 0.2, vol: 0.25, type: "bandpass", f0: 900, f1: 260, q: 2, delay: 0.4 });
  }),
  /** chomp + water whoosh */
  shark: safe(() => {
    tone({ type: "square", f0: 260, f1: 55, dur: 0.14, vol: 0.26 });
    tone({ type: "square", f0: 200, f1: 50, dur: 0.12, vol: 0.2, delay: 0.13 });
    noise({ dur: 0.45, vol: 0.28, type: "bandpass", f0: 300, f1: 2200, q: 1.2, delay: 0.05 });
    tone({ f0: 500, f1: 1300, dur: 0.3, vol: 0.08, delay: 0.1 });
  }),
  /** electric heat-ray zap */
  martian: safe(() => {
    tone({ type: "sawtooth", f0: 120, f1: 1400, dur: 0.42, vol: 0.15 });
    tone({ type: "square", f0: 62, f1: 40, dur: 0.5, vol: 0.12 });
    for (let i = 0; i < 6; i++) noise({ dur: 0.04, vol: 0.28, type: "highpass", f0: 3000, delay: i * 0.06 + Math.random() * 0.03 });
    tone({ f0: 2200, f1: 600, dur: 0.5, vol: 0.08, delay: 0.12 });
  }),
};
