import { useCallback, useEffect, useState, type MouseEvent, type ReactNode } from "react";
import WeaponCard from "./components/WeaponCard";
import { setMuted } from "./lib/sfx";
import { WEAPONS } from "./weapons";

function Chip({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.06] px-3.5 py-1.5 text-[13px] font-semibold text-violet-100/90 backdrop-blur">
      {children}
    </span>
  );
}

const Mouse = () => (
  <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden>
    <rect x="5" y="2.5" width="14" height="19" rx="7" />
    <path d="M12 2.5v7" />
    <path d="M12 2.5a7 7 0 0 1 7 7h-7Z" fill="#c084fc" stroke="#c084fc" />
  </svg>
);

export default function App() {
  const [signals, setSignals] = useState(() => WEAPONS.map(() => ({ n: 0, delay: 0 })));
  const [muted, setMutedState] = useState(false);
  const [bgPulse, setBgPulse] = useState(0);

  const fireAll = useCallback(() => {
    setSignals((s) => s.map((x, i) => ({ n: x.n + 1, delay: i * 110 })));
    setBgPulse((p) => p + 1);
  }, []);

  const fireOne = useCallback((i: number) => {
    setSignals((s) => s.map((x, j) => (j === i ? { n: x.n + 1, delay: 0 } : x)));
  }, []);

  useEffect(() => {
    setMuted(muted);
  }, [muted]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return;
      const k = Number.parseInt(e.key, 10);
      if (k >= 1 && k <= WEAPONS.length) fireOne(k - 1);
      else if (e.key === "a" || e.key === "A") fireAll();
    };
    const block = (e: Event) => e.preventDefault();
    window.addEventListener("keydown", onKey);
    window.addEventListener("contextmenu", block);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("contextmenu", block);
    };
  }, [fireAll, fireOne]);

  const onBgContext = (e: MouseEvent) => {
    e.preventDefault();
    fireAll();
  };

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-[#0c0520] text-white" onContextMenu={onBgContext}>
      {/* backdrop */}
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_-10%,#3b1d7a_0%,#1a0b3b_45%,#0c0520_80%)]" />
        <div className="stars absolute inset-0 opacity-60" />
        <div className="absolute -left-40 top-1/3 h-[480px] w-[480px] rounded-full bg-fuchsia-600/15 blur-[120px]" />
        <div className="absolute -right-40 top-1/4 h-[520px] w-[520px] rounded-full bg-cyan-500/10 blur-[120px]" />
        <div key={bgPulse} className={bgPulse ? "bg-pulse absolute inset-0" : "hidden"} />
      </div>

      <header className="relative mx-auto max-w-5xl px-4 pb-8 pt-10 text-center sm:pt-14">
        <div className="inline-flex items-center gap-2 rounded-full border border-violet-400/30 bg-violet-500/10 px-3.5 py-1 text-[11px] font-extrabold uppercase tracking-[0.25em] text-violet-200">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-fuchsia-400" />
          SVG 2D • Animated Glow
        </div>
        <h1 className="gold-text mt-4 font-display text-5xl tracking-wide sm:text-7xl">WEAPON ARSENAL</h1>
        <p className="mx-auto mt-4 max-w-2xl text-[15px] leading-relaxed text-violet-200/80">
          5 senjata digambar ulang menjadi <b className="text-white">SVG 2D</b>. Setiap kali kamu{" "}
          <b className="text-white">klik kanan</b> pada senjata, ia akan menembak dengan animasi glow &amp; efek
          sesuai warnanya.
        </p>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-2.5">
          <Chip>
            <Mouse /> Klik kanan senjata = tembak
          </Chip>
          <Chip>
            <Mouse /> Klik kanan area kosong = tembak semua
          </Chip>
          <Chip>
            <kbd className="rounded bg-white/10 px-1.5 font-mono text-xs">1</kbd>–
            <kbd className="rounded bg-white/10 px-1.5 font-mono text-xs">5</kbd> /{" "}
            <kbd className="rounded bg-white/10 px-1.5 font-mono text-xs">A</kbd> keyboard
          </Chip>
          <button
            type="button"
            onClick={() => setMutedState((m) => !m)}
            className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.06] px-3.5 py-1.5 text-[13px] font-semibold text-violet-100/90 transition hover:bg-white/15"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor" aria-hidden>
              <path d="M4 9h4l5-4v14l-5-4H4V9Z" />
              {muted ? (
                <path d="m16 9 5 6m0-6-5 6" stroke="currentColor" strokeWidth={2} strokeLinecap="round" />
              ) : (
                <path d="M16 8.5a5 5 0 0 1 0 7M18.5 6a8.5 8.5 0 0 1 0 12" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" />
              )}
            </svg>
            {muted ? "Suara mati" : "Suara nyala"}
          </button>
        </div>
      </header>

      <main className="relative mx-auto flex max-w-[1260px] flex-wrap justify-center gap-6 px-4 pb-12">
        {WEAPONS.map((w, i) => (
          <div key={w.id} className="w-full max-w-[400px] sm:w-[calc(50%-12px)] lg:w-[calc(33.333%-16px)]">
            <WeaponCard def={w} signal={signals[i]} />
          </div>
        ))}
      </main>

      <footer className="relative pb-10 text-center text-xs text-violet-300/50">
        Semua senjata adalah SVG murni (vector) — tekan tombol unduh / salin pada kartu untuk mengambil file .svg-nya.
      </footer>
    </div>
  );
}
