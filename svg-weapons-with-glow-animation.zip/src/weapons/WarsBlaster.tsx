import { Bevel, Burst, pts, rng, vars, type P, type WeaponProps } from "./shared";

/* ------------------------------------------------------------------
   2. WARS BLASTER – gunmetal sci-fi blaster on ONE straight axis:
   bevelled receiver (dials, LCD, red energy cell), scope, coil,
   perforated barrel, flared bronze muzzle with a red-hot bore.
   Frame: x = back -> muzzle, y- = top. Rotated -40deg.
------------------------------------------------------------------- */

const A = -40;
const W_T = `translate(187 254) rotate(${A}) scale(1.08)`;
const RCV: P[] = [[-112, -38], [-98, -52], [34, -52], [46, -40], [46, 42], [34, 52], [-98, 52], [-112, 38]];
const METAL = ["#1b1f24", "#363c44", "#636a74", "#9aa2ac", "#dde2e8"];
const G_T = "translate(-70 48) rotate(50)";

const HOLES: P[] = [];
for (let i = 0; i < 9; i++) HOLES.push([110 + i * 12.5, -7], [116 + i * 12.5, 7]);

const r0 = rng(77);
const SPARKS = Array.from({ length: 30 }).map(() => {
  const t = r0();
  return {
    x: 210 + t * 280 + (r0() - 0.5) * 110,
    y: 300 - t * 280 + (r0() - 0.5) * 130,
    r: 0.7 + r0() * 1.7,
    c: ["#ff8a3a", "#ff3a2a", "#ffd36b", "#ff5f6d"][Math.floor(r0() * 4)],
    d: r0() * 2.2,
    s: 1.4 + r0() * 1.8,
  };
});

const star = (n: number, r1: number, r2: number) => {
  const p: number[][] = [];
  for (let i = 0; i < n * 2; i++) {
    const a = (Math.PI * i) / n;
    const r = i % 2 ? r2 : r1 * (0.75 + ((i * 37) % 10) / 40);
    p.push([Math.cos(a) * r, Math.sin(a) * r]);
  }
  return pts(p);
};

const CSS = `
.wb-cellglow{animation:wb-pulse 1.6s ease-in-out infinite}
@keyframes wb-pulse{0%,100%{opacity:.35}50%{opacity:.8}}
.wb-muzzle{animation:wb-flick .22s steps(2) infinite}
@keyframes wb-flick{0%{opacity:.8}50%{opacity:1}}
.wb-zap{animation:wb-zap 1.1s steps(1) infinite}
.wb-zap.z2{animation-delay:-.55s}
@keyframes wb-zap{0%,100%{opacity:0}8%{opacity:1}16%{opacity:.25}26%{opacity:.95}40%{opacity:0}}
.wb-spark{animation:wb-spark 2.2s ease-in-out infinite}
@keyframes wb-spark{0%,100%{opacity:.1}50%{opacity:1}}
.wb-lcd{animation:wb-lcd 2.4s steps(3) infinite}
@keyframes wb-lcd{0%{opacity:1}50%{opacity:.55}100%{opacity:1}}
.wb-led{animation:wb-led 1s steps(2) infinite}
@keyframes wb-led{0%{opacity:1}50%{opacity:.25}}
.wb-fire .wb-heat{animation:wb-heat 1s ease-out both}
@keyframes wb-heat{0%{opacity:0}15%{opacity:.85}100%{opacity:0}}
.wb-fire .wb-surge{animation:wb-surge 700ms ease-out both}
@keyframes wb-surge{0%{opacity:0}15%{opacity:1}100%{opacity:0}}
.wb-fire .wb-mflash{transform-box:fill-box;transform-origin:center;animation:wb-mflash 460ms ease-out both}
@keyframes wb-mflash{0%{opacity:0;transform:scale(.4)}20%{opacity:1;transform:scale(1.35)}100%{opacity:0;transform:scale(1)}}
.wb-star{transform-box:fill-box;transform-origin:center;animation:wb-star 280ms ease-out both}
@keyframes wb-star{0%{transform:scale(.2) rotate(0deg);opacity:0}5%{opacity:1}40%{transform:scale(1.25) rotate(14deg);opacity:1}100%{transform:scale(.6) rotate(24deg);opacity:0}}
`;

function Screw({ x, y, r = 2.8 }: { x: number; y: number; r?: number }) {
  return (
    <g>
      <circle cx={x} cy={y} r={r} fill="url(#wb-knob)" stroke="#16191d" strokeWidth={0.8} />
      <line x1={x - r * 0.6} y1={y - r * 0.2} x2={x + r * 0.6} y2={y + r * 0.2} stroke="#2a2f35" strokeWidth={0.9} />
    </g>
  );
}

export default function WarsBlaster({ shots, tick }: WeaponProps) {
  return (
    <svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" className="weapon-svg" overflow="visible">
      <style>{CSS}</style>
      <defs>
        <linearGradient id="wb-face" x1="0" y1="-52" x2="0" y2="52" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#7b828c" />
          <stop offset="0.5" stopColor="#555c65" />
          <stop offset="1" stopColor="#3a4047" />
        </linearGradient>
        <linearGradient id="wb-panel" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#5d646e" />
          <stop offset="1" stopColor="#353a41" />
        </linearGradient>
        <linearGradient id="wb-steel" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#e4e8ec" />
          <stop offset="0.45" stopColor="#959ca6" />
          <stop offset="1" stopColor="#353a41" />
        </linearGradient>
        <linearGradient id="wb-rib" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#2a2e34" />
          <stop offset="0.22" stopColor="#c3c9d1" />
          <stop offset="0.55" stopColor="#636a73" />
          <stop offset="1" stopColor="#121417" />
        </linearGradient>
        <linearGradient id="wb-barrel" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#80868f" />
          <stop offset="0.3" stopColor="#3a3f46" />
          <stop offset="0.78" stopColor="#17191c" />
          <stop offset="1" stopColor="#0b0c0e" />
        </linearGradient>
        <linearGradient id="wb-bronze" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f0bb90" />
          <stop offset="0.28" stopColor="#b06b3e" />
          <stop offset="0.7" stopColor="#62341a" />
          <stop offset="1" stopColor="#2c1509" />
        </linearGradient>
        <radialGradient id="wb-hot" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.25" stopColor="#ffd2c4" />
          <stop offset="0.55" stopColor="#ff3d24" />
          <stop offset="1" stopColor="#9a0008" />
        </radialGradient>
        <radialGradient id="wb-flash" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.3" stopColor="#ffd48a" />
          <stop offset="0.65" stopColor="#ff4a1a" />
          <stop offset="1" stopColor="#ff1a1a" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="wb-cell" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffc6c6" />
          <stop offset="0.3" stopColor="#ff3838" />
          <stop offset="0.72" stopColor="#c80000" />
          <stop offset="1" stopColor="#5e0000" />
        </linearGradient>
        <linearGradient id="wb-rubber" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#14161a" />
          <stop offset="0.5" stopColor="#2c2f35" />
          <stop offset="1" stopColor="#101114" />
        </linearGradient>
        <linearGradient id="wb-scope" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#a2a9b3" />
          <stop offset="0.4" stopColor="#454b53" />
          <stop offset="1" stopColor="#15171a" />
        </linearGradient>
        <radialGradient id="wb-lens" cx="0.4" cy="0.35" r="0.7">
          <stop offset="0" stopColor="#ffb3a6" />
          <stop offset="0.35" stopColor="#b3121a" />
          <stop offset="1" stopColor="#1a0505" />
        </radialGradient>
        <radialGradient id="wb-knob" cx="0.35" cy="0.3" r="0.8">
          <stop offset="0" stopColor="#e6e9ee" />
          <stop offset="0.5" stopColor="#848b95" />
          <stop offset="1" stopColor="#2d3137" />
        </radialGradient>
        <linearGradient id="wb-beam" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.12" stopColor="#ff6a4a" />
          <stop offset="0.6" stopColor="#ff1a1a" stopOpacity="0.85" />
          <stop offset="1" stopColor="#ff0000" stopOpacity="0" />
        </linearGradient>
        <pattern id="wb-stipple" width="5" height="5" patternUnits="userSpaceOnUse">
          <circle cx="1.5" cy="1.5" r="0.8" fill="#474b52" />
          <circle cx="4" cy="4" r="0.6" fill="#363940" />
        </pattern>
        <filter id="wb-glow" x="-60%" y="-120%" width="220%" height="340%">
          <feGaussianBlur stdDeviation="6" />
        </filter>
        <filter id="wb-glow-s" x="-50%" y="-200%" width="200%" height="500%">
          <feGaussianBlur stdDeviation="2.4" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* ambient sparks */}
      {SPARKS.map((s, i) => (
        <circle
          key={i}
          className="wb-spark"
          cx={s.x.toFixed(1)}
          cy={s.y.toFixed(1)}
          r={s.r.toFixed(2)}
          fill={s.c}
          style={{ animationDelay: `${s.d.toFixed(2)}s`, animationDuration: `${s.s.toFixed(2)}s` }}
        />
      ))}

      <g transform={W_T}>
        {/* ---------- cables (behind) ---------- */}
        <g fill="none" strokeLinecap="round">
          <path d="M -114 -16 C -158 -22, -204 40, -182 106" stroke="#0e0f11" strokeWidth={9} />
          <path d="M -114 -16 C -158 -22, -204 40, -182 106" stroke="#5a6069" strokeWidth={1.6} transform="translate(-1.6 -1.6)" />
          <path d="M -114 4 C -146 2, -182 52, -168 102" stroke="#6e0909" strokeWidth={5.5} />
          <path d="M -114 4 C -146 2, -182 52, -168 102" stroke="#ee5a5a" strokeWidth={1.4} transform="translate(-1 -1)" />
        </g>

        {/* ---------- grip ---------- */}
        <g transform={G_T}>
          <path
            d="M -24 -8 L 24 -8 L 26 10 C 33 18, 27 28, 32 38 C 37 48, 29 58, 34 68 C 39 78, 31 90, 34 100 L 35 114 L -22 120 C -28 90, -30 50, -26 10 Z"
            fill="url(#wb-rubber)"
            stroke="#060708"
            strokeWidth={2}
            strokeLinejoin="round"
          />
          <path d="M -19 4 L 20 4 L 24 104 L -17 110 C -21 80, -23 40, -19 4 Z" fill="url(#wb-stipple)" />
          <path d="M -23 -2 C -27 34, -27 80, -20 116" fill="none" stroke="#5a5f67" strokeWidth={1.8} opacity={0.7} />
          <path d="M -26 112 L 37 106 L 41 120 C 41 128, 35 132, 27 133 L -18 137 C -26 137, -28 130, -26 122 Z" fill="url(#wb-steel)" stroke="#0e0f11" strokeWidth={1.4} strokeLinejoin="round" />
          <circle cx={6} cy={124} r={3} fill="#2a2d32" stroke="#a9b0ba" strokeWidth={0.8} />
          <rect x={-24} y={124} width={9} height={8} rx={2} fill="#1d2024" stroke="#5a6069" strokeWidth={0.8} />
        </g>

        {/* ---------- trigger guard + trigger ---------- */}
        <path d="M -16 50 L -16 76 Q -16 88 -30 88 L -76 86" fill="none" stroke="#202328" strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" />
        <path d="M -16 50 L -16 76 Q -16 88 -30 88 L -76 86" fill="none" stroke="#7d848e" strokeWidth={1.5} strokeLinecap="round" transform="translate(-1.4 -1.4)" />
        <path d="M -38 52 C -36 62, -40 72, -48 80 L -53 76 C -46 69, -44 61, -46 52 Z" fill="#1a1c20" stroke="#5a6069" strokeWidth={1} />

        {/* ---------- coil + barrel + muzzle ---------- */}
        <rect x={44} y={-22} width={48} height={44} fill="#16181b" />
        {Array.from({ length: 9 }).map((_, i) => (
          <rect key={i} x={46 + i * 5} y={-22} width={3.4} height={44} rx={1.4} fill="url(#wb-rib)" />
        ))}
        <rect x={90} y={-25} width={11} height={50} rx={2} fill="url(#wb-steel)" stroke="#111" />
        <rect x={100} y={-16} width={124} height={32} fill="url(#wb-barrel)" stroke="#090a0b" strokeWidth={1.2} />
        <rect x={100} y={-13} width={124} height={2.6} fill="#ffffff" opacity={0.22} />
        {HOLES.map(([x, y], i) => (
          <g key={i}>
            <circle cx={x} cy={y + 0.7} r={3.3} fill="#8a919b" opacity={0.5} />
            <circle cx={x} cy={y} r={3.2} fill="#040405" />
          </g>
        ))}
        <rect x={132} y={16} width={52} height={6} rx={2} fill="#2b2f35" stroke="#0d0e10" />
        <rect x={222} y={-20} width={11} height={40} rx={2} fill="url(#wb-steel)" stroke="#111" />
        <path d="M 232 -14 L 270 -28 L 270 28 L 232 14 Z" fill="url(#wb-bronze)" stroke="#2a1408" strokeWidth={1.2} strokeLinejoin="round" />
        <path d="M 245 -18.8 L 245 18.8 M 258 -23.6 L 258 23.6" stroke="#3a1d0e" strokeWidth={1.6} opacity={0.7} />
        <path d="M 236 -10 L 268 -22" stroke="#ffd9bb" strokeWidth={1.4} opacity={0.6} />
        <ellipse cx={270} cy={0} rx={7.5} ry={28} fill="#2a140c" stroke="#8a5530" strokeWidth={2} />
        <ellipse className="wb-muzzle" cx={271} cy={0} rx={5.6} ry={21} fill="url(#wb-hot)" filter="url(#wb-glow-s)" />
        <ellipse cx={271.5} cy={0} rx={2.2} ry={8} fill="#ffffff" />

        {/* idle red zaps */}
        <g fill="none" strokeLinecap="round" strokeLinejoin="round" filter="url(#wb-glow-s)">
          <path className="wb-zap" d="M 278 0 L 306 -7 L 326 4 L 352 -9 L 378 1 L 412 -12" stroke="#ff3a2a" strokeWidth={2.2} />
          <path className="wb-zap z2" d="M 278 2 L 302 9 L 324 -2 L 348 8 L 372 -3 L 404 6" stroke="#ff5a3a" strokeWidth={1.8} />
        </g>

        {/* ---------- receiver ---------- */}
        <polygon points={pts(RCV.map(([x, y]) => [x - 1, y + 9]))} fill="#24282d" stroke="#0f1113" strokeWidth={1.4} strokeLinejoin="round" />
        <Bevel poly={RCV} d={7} angle={A} stops={METAL} face="url(#wb-face)" outline="#0f1113" />

        {/* upper panel with dials */}
        <rect x={-100} y={-42} width={92} height={48} rx={5} fill="url(#wb-panel)" stroke="#1c1f23" strokeWidth={1.4} />
        <line x1={-97} y1={-40.6} x2={-11} y2={-40.6} stroke="#a7aeb8" strokeWidth={1} opacity={0.55} />
        <Screw x={-94} y={-36} r={2.4} />
        <Screw x={-14} y={-36} r={2.4} />
        <Screw x={-94} y={0} r={2.4} />
        <Screw x={-14} y={0} r={2.4} />
        <circle cx={-68} cy={-18} r={14} fill="#1f2226" />
        <circle cx={-68} cy={-18} r={11} fill="url(#wb-knob)" stroke="#16181b" strokeWidth={0.8} />
        {Array.from({ length: 12 }).map((_, i) => {
          const a = (i * Math.PI) / 6;
          return <line key={i} x1={-68 + Math.cos(a) * 11} y1={-18 + Math.sin(a) * 11} x2={-68 + Math.cos(a) * 9} y2={-18 + Math.sin(a) * 9} stroke="#3a3f46" strokeWidth={1} />;
        })}
        <line x1={-68} y1={-18} x2={-68} y2={-27} stroke="#15171a" strokeWidth={2.2} strokeLinecap="round" />
        <circle cx={-38} cy={-26} r={8} fill="#1f2226" />
        <circle cx={-38} cy={-26} r={6} fill="url(#wb-knob)" />
        <line x1={-38} y1={-26} x2={-34} y2={-30} stroke="#15171a" strokeWidth={1.6} strokeLinecap="round" />
        <rect x={-46} y={-11} width={7} height={12} rx={1.5} fill="#1b1e22" />
        <rect x={-44.5} y={-13} width={4} height={7} rx={1} fill="#d5dae1" />
        <rect x={-32} y={-11} width={7} height={12} rx={1.5} fill="#1b1e22" />
        <rect x={-30.5} y={-5} width={4} height={7} rx={1} fill="#ff4a3a" />
        <circle className="wb-led" cx={-20} cy={-24} r={2.4} fill="#ff3a2a" filter="url(#wb-glow-s)" />

        {/* LCD */}
        <rect x={-2} y={-44} width={44} height={30} rx={3} fill="#2a2e35" stroke="#121417" strokeWidth={1.4} />
        <rect x={3} y={-39} width={34} height={20} rx={2} fill="#05192e" />
        <g className="wb-lcd" filter="url(#wb-glow-s)">
          <rect x={6} y={-35} width={18} height={2.6} fill="#5fd0ff" />
          <rect x={6} y={-30} width={27} height={2.6} fill="#5fd0ff" opacity={0.8} />
          <rect x={6} y={-25} width={11} height={2.6} fill="#5fd0ff" opacity={0.7} />
          <rect x={21} y={-25} width={9} height={2.6} fill="#a6f2ff" />
        </g>
        <Screw x={6} y={-6} r={2.2} />
        <Screw x={34} y={-6} r={2.2} />

        {/* lower-left vent panel */}
        <rect x={-100} y={14} width={86} height={30} rx={3} fill="#33383f" stroke="#1b1e22" strokeWidth={1.2} />
        {Array.from({ length: 6 }).map((_, i) => (
          <rect key={i} x={-64 + i * 8} y={19} width={4} height={20} rx={2} fill="#101215" />
        ))}
        <path d="M -94 22 L -74 22 M -94 28 L -80 28 M -94 34 L -76 34" stroke="#6a717b" strokeWidth={1.2} />

        {/* energy cell window */}
        <rect x={-8} y={16} width={52} height={30} rx={5} fill="#16181b" stroke="#0c0d0f" strokeWidth={1.2} />
        <ellipse className="wb-cellglow" cx={18} cy={31} rx={28} ry={14} fill="#ff2020" filter="url(#wb-glow)" />
        <rect x={-4} y={20} width={44} height={22} rx={11} fill="url(#wb-cell)" />
        <rect x={0} y={27.5} width={36} height={3.6} rx={1.8} fill="#ffeaea" opacity={0.95} />
        <rect x={6} y={16} width={6} height={30} rx={1.5} fill="url(#wb-steel)" stroke="#111" />
        <rect x={26} y={16} width={6} height={30} rx={1.5} fill="url(#wb-steel)" stroke="#111" />

        {/* cable ports + rear details */}
        <rect x={-120} y={-22} width={10} height={12} rx={2} fill="#2a2d32" stroke="#0e0f11" />
        <rect x={-120} y={-2} width={10} height={11} rx={2} fill="#5a1010" stroke="#0e0f11" />
        {[-90, -50, -10, 30].map((x) => (
          <circle key={x} cx={x} cy={48} r={1.8} fill="#aeb4bd" />
        ))}

        {/* scope */}
        <rect x={0} y={-62} width={10} height={12} fill="#2c3036" stroke="#121417" />
        <rect x={26} y={-62} width={10} height={12} fill="#2c3036" stroke="#121417" />
        <rect x={-16} y={-84} width={62} height={22} rx={11} fill="url(#wb-scope)" stroke="#0d0e10" strokeWidth={1.2} />
        <path d="M 44 -86 L 60 -90 L 60 -56 L 44 -60 Z" fill="url(#wb-scope)" stroke="#0d0e10" strokeLinejoin="round" />
        <ellipse cx={60} cy={-73} rx={5} ry={17} fill="url(#wb-lens)" stroke="#0d0e10" strokeWidth={1.4} />
        <ellipse cx={61} cy={-78} rx={1.6} ry={5} fill="#ffd8cf" opacity={0.75} />
        <ellipse cx={-16} cy={-73} rx={3.5} ry={10} fill="#16181b" />
        <rect x={10} y={-92} width={12} height={9} rx={1.5} fill="#4a5058" stroke="#15171a" />
        <line x1={-10} y1={-80} x2={42} y2={-80} stroke="#d0d5dc" strokeWidth={1.2} opacity={0.6} />

        {/* ---------- right-click overlays ---------- */}
        <g key={`r${tick}`} className={tick ? "wb-fire" : undefined}>
          <rect className="wb-heat" x={44} y={-22} width={48} height={44} fill="#ff6a2a" opacity={0} />
          <rect className="wb-surge" x={-4} y={20} width={44} height={22} rx={11} fill="#ffffff" opacity={0} />
          <ellipse className="wb-surge" cx={18} cy={31} rx={42} ry={20} fill="#ff2a2a" filter="url(#wb-glow)" opacity={0} />
          <ellipse className="wb-mflash" cx={276} cy={0} rx={34} ry={44} fill="url(#wb-flash)" opacity={0} />
        </g>

        {/* ============ SHOT FX ============ */}
        {shots.map((id) => (
          <g key={id} data-fx="">
            <rect className="fx-beam" x={280} y={-7} width={560} height={14} rx={7} fill="url(#wb-beam)" style={vars({ "--t": "430ms" })} />
            <rect className="fx-beam" x={280} y={-1.8} width={500} height={3.6} rx={1.8} fill="#ffffff" style={vars({ "--t": "330ms" })} />
            <g transform="translate(282 0)">
              <g className="wb-star">
                <polygon points={star(12, 46, 14)} fill="url(#wb-flash)" />
              </g>
              <circle className="fx-ring" r={14} fill="none" stroke="#ff9a6a" strokeWidth={3} vectorEffect="non-scaling-stroke" style={vars({ "--s": 5, "--t": "480ms" })} />
              <Burst seed={id} count={20} colors={["#fff4c4", "#ffb347", "#ff6a2a", "#ff2a2a"]} spread={110} dist={[50, 150]} size={[2, 4.5]} dur={[350, 650]} shape="streak" />
              <g className="fx-fly" style={vars({ "--dx": "480px", "--dy": "0px", "--t": "380ms" })}>
                <ellipse rx={30} ry={7} fill="#ff2a1a" filter="url(#wb-glow-s)" />
                <ellipse rx={20} ry={3} fill="#ffffff" />
              </g>
            </g>
          </g>
        ))}
      </g>
    </svg>
  );
}
