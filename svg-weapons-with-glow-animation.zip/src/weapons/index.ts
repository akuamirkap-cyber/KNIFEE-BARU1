import type { ComponentType } from "react";
import { sfx } from "../lib/sfx";
import DiamondGun from "./DiamondGun";
import MartianHeatray from "./MartianHeatray";
import PaintballGun from "./PaintballGun";
import SharkLauncher from "./SharkLauncher";
import WarsBlaster from "./WarsBlaster";
import type { WeaponProps } from "./shared";

export type Rarity = "MYTHIC" | "LEGEND" | "EPIC" | "RARE";

export type WeaponDef = {
  id: string;
  no: number;
  name: string;
  rarity: Rarity;
  /** main glow colour */
  color: string;
  /** secondary colour (gradients / accents) */
  color2: string;
  effect: string;
  /** recoil / swing applied to the weapon on fire */
  kick: { x: number; y: number; rot?: number; origin?: string };
  Comp: ComponentType<WeaponProps>;
  sound: () => void;
};

export const WEAPONS: WeaponDef[] = [
  {
    id: "diamond-gun",
    no: 1,
    name: "Diamond Gun",
    rarity: "MYTHIC",
    color: "#5ad1ff",
    color2: "#c9f3ff",
    effect: "Kristal & berlian bersinar, kilau emas & peluru berlian es",
    kick: { x: -11, y: 11 },
    Comp: DiamondGun,
    sound: sfx.diamond,
  },
  {
    id: "wars-blaster",
    no: 2,
    name: "Wars Blaster",
    rarity: "EPIC",
    color: "#ff3b30",
    color2: "#ffb347",
    effect: "Laser merah, muzzle flash, percikan api & sel energi menyala",
    kick: { x: -12, y: 10 },
    Comp: WarsBlaster,
    sound: sfx.wars,
  },
  {
    id: "paintball-gun",
    no: 3,
    name: "Paintball Gun",
    rarity: "RARE",
    color: "#ff4fb0",
    color2: "#ffd23f",
    effect: "Bola cat warna-warni, cipratan cat & neon pink berkedip",
    kick: { x: -9, y: 9 },
    Comp: PaintballGun,
    sound: sfx.paintball,
  },
  {
    id: "shark-launcher",
    no: 4,
    name: "Shark Launcher",
    rarity: "EPIC",
    color: "#38d6ff",
    color2: "#ffb03a",
    effect: "Rahang menggigit, mata menyala, jet biru & bola energi",
    kick: { x: -14, y: 6 },
    Comp: SharkLauncher,
    sound: sfx.shark,
  },
  {
    id: "martian-heatray",
    no: 5,
    name: "Martian Heatray",
    rarity: "LEGEND",
    color: "#7dff3a",
    color2: "#d8ff9a",
    effect: "Ekor manik hijau hidup & meliuk, petir hijau & sinar panas alien",
    kick: { x: 0, y: 0, rot: -9, origin: "23% 88%" },
    Comp: MartianHeatray,
    sound: sfx.martian,
  },
];
