import type { ReactNode } from "react";
import { Burst, rng, vars, type WeaponProps } from "./shared";

/* ------------------------------------------------------------------
   5. MARTIAN HEATRAY – symmetric alien steel pick-head (two mirrored
   crescent blades + centre spike + green core orb) on a LIVING tail:
   a braided column of glowing beads built from nested segments that
   sway like a real tail, wrapped in green lightning.
   Local frame: origin = socket, -y = spike, +y = tail. Rotated 35.5deg.
------------------------------------------------------------------- */

const ANG = 35.5;
const M_T = `translate(290 192) rotate(${ANG}) scale(1.05)`;

/* ---------- head (right half; left half is mirrored) ---------- */
const BLADE = "M 20 -62 C 70 -94, 150 -62, 148 56 C 132 2, 96 -24, 28 -10 Z";
const BLADE_TOP = "M 20 -62 C 70 -94, 150 -62, 148 56 L 147 40 C 140 -46, 80 -76, 30 -52 Z";
const BLADE_EDGE = "M 103.5 -59.3 C 129.5 -40.5, 149 -3, 148 56";
const BLADE_INNER = "M 148 56 C 132 2, 96 -24, 28 -10";
const SPIKE_HALF = "M 0 -178 C 12 -142, 24 -102, 24 -62 L 0 -50 Z";
const SPIKE = "M 0 -178 C 12 -142, 24 -102, 24 -62 L 0 -50 L -24 -62 C -24 -102, -12 -142, 0 -178 Z";
const HUB = "M 0 -76 C 24 -72, 36 -48, 32 -26 C 28 -8, 14 4, 0 6 C -14 4, -28 -8, -32 -26 C -36 -48, -24 -72, 0 -76 Z";
const ORB_Y = -34;

/* ---------- living tail ---------- */
const N = 12;
const SEG = 24;
const LEN = N * SEG;
const R0 = 12.4;
const R1 = 7.2;
const PER = 16;
const AMP = Array.from({ length: N }, (_, k) => 0.7 + k * 0.34);

type Bead = { x: number; y: number; r: number; z: number; id: number; k: number };
const BEADS: Bead[] = [];
for (let s = 0; s < 2; s++) {
  for (let i = 0; i < PER; i++) {
    const t = Math.min(1, (i + 0.5 * s + 0.3) / PER);
    const ph = i * 0.95 + s * Math.PI;
    const yy = t * (LEN - 6);
    const k = Math.min(N - 1, Math.floor(yy / SEG));
    BEADS.push({
      x: 5.6 * Math.sin(ph),
      y: yy - k * SEG,
      r: (R0 - (R0 - R1) * t) * (Math.cos(ph) < 0 ? 0.93 : 1),
      z: Math.cos(ph),
      id: i * 2 + s,
      k,
    });
  }
}
const SEG_BEADS = Array.from({ length: N }, (_, k) => BEADS.filter((b) => b.k === k).sort((a, b) => a.z - b.z));

/** lightning spiral split into per-segment front/back pieces (local coords) */
function spiral(seed: number, turns: number, phase: number, extra: number, jitter: number) {
  const r = rng(seed);
  const steps = 96;
  const P: { x: number; y: number; f: boolean }[] = [];
  for (let j = 0; j <= steps; j++) {
    const t = j / steps;
    const ang = Math.PI * 2 * turns * t + phase;
    const rad = R0 - (R0 - R1) * t + extra;
    P.push({ x: rad * Math.sin(ang) + (r() - 0.5) * jitter, y: t * (LEN - 4), f: Math.cos(ang) > -0.1 });
  }
  const front: string[] = Array(N).fill("");
  const back: string[] = Array(N).fill("");
  for (let j = 0; j < steps; j++) {
    const a = P[j];
    const b = P[j + 1];
    const k = Math.min(N - 1, Math.floor((a.y + b.y) / 2 / SEG));
    const o = k * SEG;
    const d = `M${a.x.toFixed(1)} ${(a.y - o).toFixed(1)}L${b.x.toFixed(1)} ${(b.y - o).toFixed(1)}`;
    if (a.f) front[k] += d;
    else back[k] += d;
  }
  return { front, back };
}
const ARCS = [spiral(1, 4.2, 0, 5, 9), spiral(2, 3.6, 2.2, 7, 10), spiral(3, 4.2, 1.1, 6, 9), spiral(4, 3.8, 3.6, 5, 10)];

function zap(seed: number, cx: number, cy: number, len: number, ang: number) {
  const r = rng(seed);
  const n = 7;
  const p: string[] = [`${cx} ${cy}`];
  for (let i = 1; i <= n; i++) {
    const d = (len * i) / n;
    const a = ang + (r() - 0.5) * 0.7;
    p.push(`${(cx + Math.cos(a) * d).toFixed(1)} ${(cy + Math.sin(a) * d).toFixed(1)}`);
  }
  return "M " + p.join(" L ");
}

/** nested segment chain – every level rotates around its joint, giving a travelling tail wave */
function Chain({ k, render }: { k: number; render: (k: number) => ReactNode }): ReactNode {
  return (
    <g transform={k ? `translate(0 ${SEG})` : undefined}>
      <g className="mh-seg" style={vars({ "--a": AMP[k].toFixed(2), animationDelay: `${(-k * 0.17).toFixed(2)}s` })}>
        {render(k)}
        {k < N - 1 && <Chain k={k + 1} render={render} />}
      </g>
    </g>
  );
}

const CSS = `
.mh-seg{transform-origin:0 0;animation:mh-sway 2.6s ease-in-out infinite}
@keyframes mh-sway{0%,100%{transform:rotate(calc(var(--a) * -1deg))}50%{transform:rotate(calc(var(--a) * 1deg))}}
.mh-fin{transform-origin:0 0;animation:mh-fin 1.3s ease-in-out infinite alternate}
@keyframes mh-fin{0%{transform:rotate(-14deg)}100%{transform:rotate(14deg)}}
.mh-whipA{transform-origin:0 0;animation:mh-whipA 950ms cubic-bezier(.3,.6,.3,1) both}
.mh-whipB{transform-origin:0 0;animation:mh-whipB 950ms cubic-bezier(.3,.6,.3,1) both}
@keyframes mh-whipA{0%{transform:rotate(0)}16%{transform:rotate(10deg)}40%{transform:rotate(-7deg)}64%{transform:rotate(3deg)}100%{transform:rotate(0)}}
@keyframes mh-whipB{0%{transform:rotate(0)}16%{transform:rotate(10deg)}40%{transform:rotate(-7deg)}64%{transform:rotate(3deg)}100%{transform:rotate(0)}}
.mh-arc{animation:mh-arc .5s steps(1) infinite}
.mh-arc.b{animation-delay:-.25s}
@keyframes mh-arc{0%{opacity:1}30%{opacity:.3}45%{opacity:.95}50%,100%{opacity:0}}
.mh-orb{animation:mh-orb 1.6s ease-in-out infinite}
@keyframes mh-orb{0%,100%{opacity:.55}50%{opacity:1}}
.mh-wave{animation:mh-wave 2.2s ease-in-out infinite}
@keyframes mh-wave{0%,100%{opacity:0}45%{opacity:.7}}
.mh-rim{animation:mh-rim 1.8s ease-in-out infinite}
@keyframes mh-rim{0%,100%{opacity:.7}50%{opacity:1}}
.mh-fire .mh-bflash{animation:mh-bflash 520ms ease-out var(--dl,0ms) both}
@keyframes mh-bflash{0%{opacity:0}30%{opacity:.95}100%{opacity:0}}
.mh-fire .mh-flash{animation:mh-flash 760ms ease-out both}
@keyframes mh-flash{0%{opacity:0}20%{opacity:1}100%{opacity:0}}
.mh-fire .mh-orbburst{transform-box:fill-box;transform-origin:center;animation:mh-ob 640ms ease-out both}
@keyframes mh-ob{0%{opacity:0;transform:scale(.6)}25%{opacity:1;transform:scale(2)}100%{opacity:0;transform:scale(1.2)}}
.mh-zap{animation:mh-zap 480ms steps(1) var(--dl,0ms) both}
@keyframes mh-zap{0%{opacity:1}20%{opacity:.1}35%{opacity:1}55%{opacity:.3}70%{opacity:.9}100%{opacity:0}}
`;

function BladeHalf({ side }: { side: "L" | "R" }) {
  return (
    <g>
      <path d={SPIKE_HALF} fill={`url(#mh-spk${side})`} />
      <path d={BLADE} fill={`url(#mh-low${side})`} />
      <path d={BLADE_TOP} fill={`url(#mh-top${side})`} />
      {/* seam + bevel lines */}
      <path d="M 49 -73 L 56 -18" stroke="#4a5563" strokeWidth={1.3} />
      <path d="M 51 -73 L 58 -19" stroke="#ffffff" strokeWidth={0.8} opacity={0.5} />
      <path d="M 30 -52 C 80 -76, 140 -46, 147 40" fill="none" stroke="#56616f" strokeWidth={1.1} opacity={0.8} />
      <path d="M 24 -64 C 72 -92, 146 -62, 146 44" fill="none" stroke="#ffffff" strokeWidth={1.3} opacity={side === "L" ? 0.9 : 0.55} />
      <path d={BLADE} fill="none" stroke="#27303b" strokeWidth={2.2} strokeLinejoin="round" />
      <path d={SPIKE_HALF} fill="none" stroke="#27303b" strokeWidth={2.2} strokeLinejoin="round" />
      {/* green energy edge + vents */}
      <g className="mh-rim" filter="url(#mh-glow)">
        <path d={BLADE_EDGE} fill="none" stroke="#b6ff5a" strokeWidth={3.4} strokeLinecap="round" />
        <path d="M 148 54 C 146 30, 142 10, 136 -6" fill="none" stroke="#9dff4a" strokeWidth={1.8} strokeLinecap="round" opacity={0.8} />
        <rect x={69} y={-61} width={15} height={4.4} rx={2.2} fill="#c4ff6a" transform="rotate(9.6 76 -59)" />
        <rect x={98} y={-49.5} width={13} height={4} rx={2} fill="#c4ff6a" transform="rotate(34.6 105 -47.5)" />
        <circle cx={40} cy={-30} r={2.8} fill="#c4ff6a" />
        <circle cx={66} cy={-30} r={2.2} fill="#c4ff6a" />
      </g>
    </g>
  );
}

export default function MartianHeatray({ shots, tick }: WeaponProps) {
  const whip = tick ? (tick % 2 ? "mh-whipA" : "mh-whipB") : undefined;
  return (
    <svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" className="weapon-svg" overflow="visible">
      <style>{CSS}</style>
      <defs>
        <linearGradient id="mh-topL" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="1" stopColor="#d3dae3" />
        </linearGradient>
        <linearGradient id="mh-topR" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#eef2f6" />
          <stop offset="1" stopColor="#a5b0bd" />
        </linearGradient>
        <linearGradient id="mh-lowL" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#b3bdc8" />
          <stop offset="1" stopColor="#737f8d" />
        </linearGradient>
        <linearGradient id="mh-lowR" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#8b97a5" />
          <stop offset="1" stopColor="#4a5461" />
        </linearGradient>
        <linearGradient id="mh-spkL" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="1" stopColor="#c6cfd9" />
        </linearGradient>
        <linearGradient id="mh-spkR" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#a9b4c0" />
          <stop offset="1" stopColor="#616d7b" />
        </linearGradient>
        <linearGradient id="mh-hub" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.45" stopColor="#b4bfcb" />
          <stop offset="1" stopColor="#56616f" />
        </linearGradient>
        <radialGradient id="mh-bead" cx="0.36" cy="0.3" r="0.72">
          <stop offset="0" stopColor="#f7ffe0" />
          <stop offset="0.1" stopColor="#d6ff82" />
          <stop offset="0.42" stopColor="#82ee2c" />
          <stop offset="0.8" stopColor="#36b814" />
          <stop offset="1" stopColor="#146a08" />
        </radialGradient>
        <radialGradient id="mh-bead-d" cx="0.36" cy="0.3" r="0.72">
          <stop offset="0" stopColor="#c8f590" />
          <stop offset="0.35" stopColor="#5cc72a" />
          <stop offset="0.8" stopColor="#23860d" />
          <stop offset="1" stopColor="#0c4a06" />
        </radialGradient>
        <radialGradient id="mh-orb" cx="0.42" cy="0.38" r="0.65">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.22" stopColor="#eaffc0" />
          <stop offset="0.5" stopColor="#8dff3a" />
          <stop offset="0.82" stopColor="#2fbf12" />
          <stop offset="1" stopColor="#0d5a06" />
        </radialGradient>
        <linearGradient id="mh-beam" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.1" stopColor="#d4ff8a" />
          <stop offset="0.5" stopColor="#6dff3a" stopOpacity="0.85" />
          <stop offset="1" stopColor="#3aff3a" stopOpacity="0" />
        </linearGradient>
        <radialGradient id="mh-flare" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.3" stopColor="#d8ff9a" />
          <stop offset="0.7" stopColor="#6dff3a" stopOpacity="0.6" />
          <stop offset="1" stopColor="#6dff3a" stopOpacity="0" />
        </radialGradient>
        <filter id="mh-glow" x="-60%" y="-60%" width="220%" height="220%">
          <feGaussianBlur stdDeviation="2.6" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <filter id="mh-blur" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="9" />
        </filter>
        <filter id="mh-halo" x="-60%" y="-20%" width="220%" height="140%">
          <feGaussianBlur stdDeviation="5" />
        </filter>
        <filter id="mh-soft" x="-60%" y="-20%" width="220%" height="140%">
          <feGaussianBlur stdDeviation="1.8" />
        </filter>
      </defs>

      <g transform={M_T}>
        {/* ================= LIVING TAIL ================= */}
        <g className={whip}>
          {/* back layer: glow halo + back lightning (one filter pass for the whole chain) */}
          <g filter="url(#mh-halo)" opacity={0.85}>
            <Chain
              k={0}
              render={(k) =>
                SEG_BEADS[k].map((b) => <circle key={b.id} cx={b.x.toFixed(1)} cy={b.y.toFixed(1)} r={(b.r + 5).toFixed(1)} fill="#5dff2a" opacity={0.5} />)
              }
            />
          </g>
          <g filter="url(#mh-soft)" opacity={0.75}>
            <Chain
              k={0}
              render={(k) => (
                <g fill="none" stroke="#7dff3a" strokeWidth={2.6} strokeLinecap="round">
                  {ARCS.map((a, i) => (a.back[k] ? <path key={i} className={i % 2 ? "mh-arc b" : "mh-arc"} d={a.back[k]} /> : null))}
                </g>
              )}
            />
          </g>
          {/* beads (back strand first, then front strand) */}
          <Chain
            k={0}
            render={(k) => (
              <g>
                {SEG_BEADS[k].map((b) => (
                  <g key={b.id}>
                    <circle cx={b.x.toFixed(1)} cy={b.y.toFixed(1)} r={b.r.toFixed(1)} fill={b.z < 0 ? "url(#mh-bead-d)" : "url(#mh-bead)"} stroke="#17700a" strokeWidth={0.9} />
                    <circle className="mh-wave" cx={b.x.toFixed(1)} cy={b.y.toFixed(1)} r={(b.r * 0.85).toFixed(1)} fill="#e6ffb8" opacity={0} style={{ animationDelay: `${(b.id * 0.07).toFixed(2)}s` }} />
                  </g>
                ))}
                <g key={`f${tick}`} className={tick ? "mh-fire" : undefined}>
                  {SEG_BEADS[k].map((b) => (
                    <circle
                      key={b.id}
                      className="mh-bflash"
                      cx={b.x.toFixed(1)}
                      cy={b.y.toFixed(1)}
                      r={(b.r * 1.15).toFixed(1)}
                      fill="#f4ffd6"
                      opacity={0}
                      style={vars({ "--dl": `${((2 * PER - 1 - b.id) * 14).toFixed(0)}ms` })}
                    />
                  ))}
                </g>
                {k === N - 1 && (
                  <g transform="translate(0 20)">
                    <g className="mh-fin">
                      <g filter="url(#mh-glow)">
                        <path d="M -6.5 -4 C -8 10, -15 22, -26 31 C -17 31, -11 36, -12 46 C 0 35, 7 19, 6.5 -4 Z" fill="#8dff3a" />
                        <path d="M 0 0 C -2 12, -8 23, -17 31" fill="none" stroke="#eaffc4" strokeWidth={2} strokeLinecap="round" />
                      </g>
                    </g>
                  </g>
                )}
              </g>
            )}
          />
          {/* front lightning */}
          <g filter="url(#mh-soft)">
            <Chain
              k={0}
              render={(k) => (
                <g fill="none" strokeLinecap="round" stroke="#7dff3a" strokeWidth={4.6} opacity={0.8}>
                  {ARCS.map((a, i) => (a.front[k] ? <path key={i} className={i % 2 ? "mh-arc b" : "mh-arc"} d={a.front[k]} /> : null))}
                </g>
              )}
            />
          </g>
          <Chain
            k={0}
            render={(k) => (
              <g fill="none" strokeLinecap="round" stroke="#f4ffdc" strokeWidth={1.6}>
                {ARCS.map((a, i) => (a.front[k] ? <path key={i} className={i % 2 ? "mh-arc b" : "mh-arc"} d={a.front[k]} /> : null))}
              </g>
            )}
          />
        </g>

        {/* ================= HEAD (symmetric) ================= */}
        <ellipse cx={0} cy={-40} rx={70} ry={66} fill="#7dff3a" opacity={0.18} filter="url(#mh-blur)" />
        {/* socket collar */}
        <rect x={-14} y={-8} width={28} height={20} rx={4} fill="url(#mh-hub)" stroke="#27303b" strokeWidth={1.6} />
        <rect className="mh-rim" x={-14} y={3} width={28} height={3} fill="#a6ff4f" filter="url(#mh-glow)" />

        <g transform="scale(-1 1)">
          <BladeHalf side="L" />
        </g>
        <BladeHalf side="R" />
        <path d="M 0 -176 L 0 -60" stroke="#6b7684" strokeWidth={1.2} />

        {/* hub */}
        <path d={HUB} fill="url(#mh-hub)" stroke="#27303b" strokeWidth={2} strokeLinejoin="round" />
        <path d="M -26 -50 C -22 -66, -12 -72, 0 -73" fill="none" stroke="#ffffff" strokeWidth={1.4} opacity={0.85} strokeLinecap="round" />
        <ellipse cx={0} cy={ORB_Y} rx={19} ry={27} fill="#25303b" stroke="#1b232c" strokeWidth={1.2} />
        <ellipse className="mh-orb" cx={0} cy={ORB_Y} rx={22} ry={30} fill="#8dff3a" filter="url(#mh-blur)" />
        <ellipse cx={0} cy={ORB_Y} rx={14} ry={21} fill="url(#mh-orb)" stroke="#1a6b0a" strokeWidth={1} />
        <ellipse cx={-4.5} cy={ORB_Y - 8} rx={3.5} ry={6} fill="#ffffff" opacity={0.85} />
        <g fill="#c4ff6a" filter="url(#mh-glow)">
          <circle cx={-22} cy={-8} r={2.4} />
          <circle cx={22} cy={-8} r={2.4} />
          <circle cx={0} cy={-66} r={2.2} />
        </g>

        {/* right-click overlays */}
        <g key={`h${tick}`} className={tick ? "mh-fire" : undefined}>
          <g className="mh-flash" opacity={0} fill="none" strokeLinecap="round" filter="url(#mh-glow)">
            <path d={BLADE} stroke="#b6ff5a" strokeWidth={3} />
            <path d={BLADE} stroke="#b6ff5a" strokeWidth={3} transform="scale(-1 1)" />
            <path d={SPIKE} stroke="#b6ff5a" strokeWidth={3} />
            <path d={BLADE_EDGE} stroke="#ffffff" strokeWidth={5} />
            <path d={BLADE_EDGE} stroke="#ffffff" strokeWidth={5} transform="scale(-1 1)" />
            <path d={BLADE_INNER} stroke="#d8ff9a" strokeWidth={2} />
            <path d={BLADE_INNER} stroke="#d8ff9a" strokeWidth={2} transform="scale(-1 1)" />
          </g>
          <ellipse className="mh-orbburst" cx={0} cy={ORB_Y} rx={26} ry={32} fill="url(#mh-flare)" opacity={0} />
        </g>

        {/* ============ SHOT FX ============ */}
        {shots.map((id) => {
          const r = rng(id);
          return (
            <g key={id} data-fx="">
              <g transform="translate(0 -180) rotate(-90)">
                <rect className="fx-beam" x={0} y={-12} width={560} height={24} rx={12} fill="url(#mh-beam)" style={vars({ "--t": "560ms", "--dl": "140ms" })} />
                <rect className="fx-beam" x={0} y={-2.6} width={520} height={5.2} rx={2.6} fill="#ffffff" style={vars({ "--t": "440ms", "--dl": "140ms" })} />
                {[50, 110, 170].map((x, i) => (
                  <ellipse key={x} className="fx-ring" cx={x} cy={0} rx={5} ry={13} fill="none" stroke="#c8ff7a" strokeWidth={2} vectorEffect="non-scaling-stroke" style={vars({ "--s": 3, "--t": "520ms", "--dl": `${160 + i * 60}ms` })} />
                ))}
                <circle className="fx-pop" r={30} fill="url(#mh-flare)" style={vars({ "--t": "420ms", "--dl": "120ms" })} />
                <Burst seed={id} count={16} colors={["#f2ffd8", "#b6ff5a", "#6dff3a", "#2fd80f"]} spread={80} dist={[40, 130]} size={[2, 4]} dur={[400, 700]} shape="streak" delay={140} />
              </g>
              <g transform={`translate(0 ${ORB_Y})`}>
                <circle className="fx-ring" r={16} fill="none" stroke="#b6ff5a" strokeWidth={3} vectorEffect="non-scaling-stroke" style={vars({ "--s": 6, "--t": "640ms" })} />
                <Burst seed={id + 3} count={14} colors={["#f2ffd8", "#9dff4a", "#4fd41e"]} dist={[40, 120]} size={[2, 4]} />
              </g>
              <g fill="none" strokeLinecap="round" strokeLinejoin="round" filter="url(#mh-glow)">
                {Array.from({ length: 6 }).map((_, i) => {
                  const ang = r() * Math.PI * 2;
                  const d = zap(id + i * 17, 0, ORB_Y, 70 + r() * 90, ang);
                  return <path key={i} className="mh-zap" d={d} stroke="#eaffc8" strokeWidth={1.6} style={vars({ "--dl": `${(r() * 120).toFixed(0)}ms` })} />;
                })}
              </g>
            </g>
          );
        })}
      </g>
    </svg>
  );
}
