import { Burst, rng, vars, type WeaponProps } from "./shared";

/* ------------------------------------------------------------------
   3. PAINTBALL GUN – pink polka-dot body, perforated black barrel,
   gumball-globe hopper, mini side globe, pink/black grip + gauge.
   Everything is built in ONE body frame (rotated -45deg) so the
   hopper neck, grip, trigger guard, tank and side feed line up neatly.
------------------------------------------------------------------- */

const P_T = "translate(212 298) rotate(-45)";
/** whole gun slightly smaller so it breathes inside the card */
const W_T = "translate(256 262) scale(0.92) translate(-256 -262)";

const BALL = [
  ["#ff9090", "#e8262e", "#7a0a0e"],
  ["#93b8ff", "#2563eb", "#0b2a7a"],
  ["#93f0ad", "#22b14c", "#0a5a22"],
  ["#fff3a6", "#ffc21a", "#a86a00"],
];
export const BALL_COLORS = BALL.map((b) => b[1]);

function pack(R: number, r: number, topY: number, seed: number, offset = 0) {
  const out: [number, number, number][] = [];
  const rand = rng(seed);
  const dy = r * 1.72;
  let row = 0;
  for (let y = R - r - 1 - offset * 0.6; y > topY; y -= dy, row++) {
    const off = ((row + (offset ? 1 : 0)) % 2) * r;
    for (let x = -R + r + off; x <= R - r + 0.1; x += 2 * r) {
      const jx = x + (rand() - 0.5) * 2.4;
      const jy = y + (rand() - 0.5) * 2.4;
      if (Math.hypot(jx, jy) + r <= R + 0.5) out.push([jx, jy, Math.floor(rand() * 4)]);
    }
  }
  return out;
}

const BIG_BACK = pack(62, 10.5, -46, 11, 1);
const BIG_FRONT = pack(62, 10.5, -44, 7);
const SMALL_BACK = pack(34, 8.4, -22, 5, 1);
const SMALL_FRONT = pack(34, 8.4, -20, 3);

const DOTS: { x: number; y: number; ry: number }[] = [];
[-37, -19, -1, 17, 35].forEach((y, j) => {
  for (let x = -104 + (j % 2) * 13; x <= 112; x += 26) {
    DOTS.push({ x, y, ry: 6.6 * Math.sqrt(Math.max(0.05, 1 - (y / 50) ** 2)) });
  }
});

const HOLES = [160, 186, 212, 238, 264, 290, 316];
const RINGS = [-212, -190, -168];

function Balls({ list, r, dim }: { list: [number, number, number][]; r: number; dim?: boolean }) {
  return (
    <g opacity={dim ? 0.7 : 1}>
      {list.map(([x, y, c], i) => (
        <circle key={i} cx={x.toFixed(1)} cy={y.toFixed(1)} r={r * 1.04} fill={`url(#pb-b${c})`} stroke="#00000055" strokeWidth={0.6} />
      ))}
    </g>
  );
}

function Globe({ R, back, front, r, tick }: { R: number; back: [number, number, number][]; front: [number, number, number][]; r: number; tick: number }) {
  const id = `pb-gc${R}`;
  return (
    <g>
      <clipPath id={id}>
        <circle r={R - 2} />
      </clipPath>
      <circle r={R} fill="#1a0f2e" opacity={0.55} />
      <g clipPath={`url(#${id})`}>
        <g key={tick} className={tick ? "pb-jiggle" : undefined}>
          <Balls list={back} r={r} dim />
          <Balls list={front} r={r} />
        </g>
      </g>
      <circle r={R} fill="url(#pb-glass)" stroke="#ffffff" strokeOpacity={0.6} strokeWidth={2} />
      <path
        className="pb-glint"
        d={`M ${-R * 0.72} ${-R * 0.42} A ${R * 0.82} ${R * 0.82} 0 0 1 ${-R * 0.18} ${-R * 0.82}`}
        fill="none"
        stroke="#ffffff"
        strokeWidth={R * 0.07}
        strokeLinecap="round"
        opacity={0.75}
      />
      <ellipse cx={-R * 0.46} cy={-R * 0.62} rx={R * 0.1} ry={R * 0.05} transform={`rotate(-40 ${-R * 0.46} ${-R * 0.62})`} fill="#ffffff" opacity={0.9} />
      <path d={`M ${R * 0.62} ${R * 0.55} A ${R * 0.84} ${R * 0.84} 0 0 0 ${R * 0.86} ${-R * 0.1}`} fill="none" stroke="#d6b8ff" strokeWidth={R * 0.05} strokeLinecap="round" opacity={0.55} />
    </g>
  );
}

const CSS = `
.pb-neon{animation:pb-neon 1.8s ease-in-out infinite}
@keyframes pb-neon{0%,100%{opacity:.7}50%{opacity:1}}
.pb-glint{animation:pb-glint 3.6s ease-in-out infinite}
@keyframes pb-glint{0%,100%{opacity:.35}50%{opacity:.9}}
.pb-jiggle{animation:pb-jig 560ms ease-out both}
@keyframes pb-jig{0%{transform:translate(0,0)}15%{transform:translate(-3px,-6px)}30%{transform:translate(3px,2px)}45%{transform:translate(-2px,-4px)}60%{transform:translate(2px,1px)}80%{transform:translate(-1px,-1px)}100%{transform:translate(0,0)}}
.pb-fire .pb-flash{animation:pb-flash 620ms ease-out both}
@keyframes pb-flash{0%{opacity:0}20%{opacity:1}100%{opacity:0}}
.pb-fire .pb-puff{transform-box:fill-box;transform-origin:center;animation:pb-puff 760ms ease-out both}
@keyframes pb-puff{0%{opacity:0;transform:scale(.3)}20%{opacity:.85}100%{opacity:0;transform:scale(2.6)}}
.pb-splat{transform-box:fill-box;transform-origin:center;animation:pb-splat 1400ms cubic-bezier(.2,1.4,.4,1) var(--dl,0ms) both}
@keyframes pb-splat{0%{transform:scale(0);opacity:0}12%{transform:scale(1.18);opacity:1}25%{transform:scale(1)}72%{opacity:1}100%{opacity:0;transform:scale(1)}}
`;

function Splat({ seed, color }: { seed: number; color: string }) {
  const r = rng(seed);
  const blobs = Array.from({ length: 9 }).map(() => {
    const a = r() * Math.PI * 2;
    const d = 10 + r() * 14;
    return [Math.cos(a) * d, Math.sin(a) * d, 2.5 + r() * 5];
  });
  return (
    <g>
      <circle r={15} fill={color} />
      {blobs.map(([x, y, s], i) => (
        <circle key={i} cx={x.toFixed(1)} cy={y.toFixed(1)} r={s.toFixed(1)} fill={color} />
      ))}
      <path d="M -4 12 Q -3 26 -6 32 Q -2 34 0 30 Q 1 22 3 12 Z" fill={color} />
      <ellipse cx={-5} cy={-6} rx={5} ry={3} fill="#ffffff" opacity={0.45} />
    </g>
  );
}

export default function PaintballGun({ shots, tick }: WeaponProps) {
  return (
    <svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" className="weapon-svg" overflow="visible">
      <style>{CSS}</style>
      <defs>
        {BALL.map(([l, b, d], i) => (
          <radialGradient key={i} id={`pb-b${i}`} cx="0.36" cy="0.3" r="0.72">
            <stop offset="0" stopColor="#ffffff" stopOpacity="0.95" />
            <stop offset="0.16" stopColor={l} />
            <stop offset="0.6" stopColor={b} />
            <stop offset="1" stopColor={d} />
          </radialGradient>
        ))}
        <linearGradient id="pb-body" x1="0" y1="-46" x2="0" y2="46" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#ffa6d4" />
          <stop offset="0.22" stopColor="#ff5cb0" />
          <stop offset="0.55" stopColor="#ef2f8b" />
          <stop offset="0.85" stopColor="#b8146a" />
          <stop offset="1" stopColor="#7e0c49" />
        </linearGradient>
        <linearGradient id="pb-pinkv" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffa3d3" />
          <stop offset="0.4" stopColor="#ff4fa8" />
          <stop offset="0.75" stopColor="#d61c7a" />
          <stop offset="1" stopColor="#8a0e50" />
        </linearGradient>
        <linearGradient id="pb-pinkm" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#a8125f" />
          <stop offset="0.35" stopColor="#ff4fa8" />
          <stop offset="0.6" stopColor="#ff8cc8" />
          <stop offset="1" stopColor="#c21872" />
        </linearGradient>
        <linearGradient id="pb-black" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#5a5a66" />
          <stop offset="0.3" stopColor="#202026" />
          <stop offset="0.75" stopColor="#0a0a0d" />
          <stop offset="1" stopColor="#2a2a32" />
        </linearGradient>
        <linearGradient id="pb-barrel" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#62626e" />
          <stop offset="0.38" stopColor="#1a1a20" />
          <stop offset="1" stopColor="#040405" />
        </linearGradient>
        <linearGradient id="pb-silver" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.35" stopColor="#d7dce4" />
          <stop offset="0.8" stopColor="#8e96a3" />
          <stop offset="1" stopColor="#5b626e" />
        </linearGradient>
        <linearGradient id="pb-chrome" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f4f6f9" />
          <stop offset="0.5" stopColor="#9aa1ab" />
          <stop offset="1" stopColor="#474c55" />
        </linearGradient>
        <radialGradient id="pb-cap" cx="0.35" cy="0.35" r="0.8">
          <stop offset="0" stopColor="#4a4a55" />
          <stop offset="1" stopColor="#0a0a0c" />
        </radialGradient>
        <linearGradient id="pb-lid" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#0b0b0e" />
          <stop offset="0.28" stopColor="#44444f" />
          <stop offset="0.55" stopColor="#141418" />
          <stop offset="0.82" stopColor="#30303a" />
          <stop offset="1" stopColor="#09090b" />
        </linearGradient>
        <radialGradient id="pb-glass" cx="0.45" cy="0.4" r="0.6">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.04" />
          <stop offset="0.8" stopColor="#e6d8ff" stopOpacity="0.12" />
          <stop offset="1" stopColor="#ffffff" stopOpacity="0.38" />
        </radialGradient>
        <radialGradient id="pb-red" cx="0.35" cy="0.3" r="0.75">
          <stop offset="0" stopColor="#ffb0b0" />
          <stop offset="0.35" stopColor="#ff2a35" />
          <stop offset="1" stopColor="#7a0008" />
        </radialGradient>
        <pattern id="pb-carbon" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <rect width="6" height="6" fill="#111115" />
          <rect width="3" height="3" fill="#26262e" />
          <rect x="3" y="3" width="3" height="3" fill="#26262e" />
        </pattern>
        <filter id="pb-neon" x="-100%" y="-30%" width="300%" height="160%">
          <feGaussianBlur stdDeviation="2.6" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <filter id="pb-soft" x="-20%" y="-100%" width="140%" height="300%">
          <feGaussianBlur stdDeviation="3" />
        </filter>
        <clipPath id="pb-bodyclip">
          <path d="M -112 -46 L 106 -46 Q 120 -46 120 0 Q 120 46 106 46 L -112 46 Z" />
        </clipPath>
      </defs>

      <g transform={W_T}>
      {/* main frame */}
      <g transform={P_T}>
        {/* ---------- grip assembly (behind the body) ---------- */}
        {/* trigger guard: front bar (raked like the handle) + bottom bar that flows into the handle */}
        <path d="M 92 40 L 78 72 Q 72 86 58 86 L 4 86" fill="none" stroke="#7a0c46" strokeWidth={11} strokeLinecap="round" strokeLinejoin="round" />
        <path d="M 92 40 L 78 72 Q 72 86 58 86 L 4 86" fill="none" stroke="#ec3a92" strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" />
        <path d="M 89 42 L 75.5 71 Q 70 83 58 83 L 8 83" fill="none" stroke="#ffb8dc" strokeWidth={1.2} strokeLinecap="round" opacity={0.8} />
        {/* trigger */}
        <path d="M 60 44 C 62 56, 58 68, 48 76 L 43 72 C 51 65, 54 56, 52 44 Z" fill="#141418" stroke="#4a4a55" strokeWidth={0.9} />

        {/* handle: straight, rounded, raked 30deg, ribbed rubber panel */}
        <g transform="translate(30 46) rotate(30)">
          <path d="M 0 -26 L 0 104 Q 0 114 -10 114 L -32 114 Q -42 114 -42 104 L -42 -26 Z" fill="url(#pb-pinkm)" stroke="#7a0c46" strokeWidth={1.6} strokeLinejoin="round" />
          <rect x={-35} y={6} width={27} height={92} rx={6} fill="url(#pb-carbon)" stroke="#000" strokeWidth={1} />
          {[18, 30, 42, 54, 66, 78, 90].map((y) => (
            <g key={y}>
              <line x1={-31} y1={y} x2={-12} y2={y} stroke="#000" strokeWidth={2.4} opacity={0.65} strokeLinecap="round" />
              <line x1={-31} y1={y + 1.7} x2={-12} y2={y + 1.7} stroke="#62626e" strokeWidth={0.8} opacity={0.75} strokeLinecap="round" />
            </g>
          ))}
          <path d="M -31 10 L -31 94" stroke="#ffffff" strokeOpacity={0.14} strokeWidth={3} />
          <path d="M -2.6 -20 L -2.6 106" stroke="#ffb8dc" strokeWidth={1.2} opacity={0.75} />
          <path d="M -39.6 -20 L -39.6 106" stroke="#7a0c46" strokeWidth={1} opacity={0.5} />
        </g>

        {/* air tank + foot block – both parallel to the body */}
        <rect x={-146} y={121} width={86} height={24} rx={7} fill="url(#pb-black)" stroke="#000" />
        <rect x={-146} y={125} width={86} height={3} rx={1.5} fill="#ffffff" opacity={0.18} />
        <rect className="pb-neon" x={-110} y={121} width={4.5} height={24} fill="#ff4fb0" filter="url(#pb-neon)" />
        <rect className="pb-neon" x={-96} y={121} width={4.5} height={24} fill="#ff4fb0" filter="url(#pb-neon)" />
        <ellipse cx={-146} cy={133} rx={6.5} ry={12} fill="url(#pb-cap)" stroke="#4a4a55" strokeWidth={1.5} />
        <ellipse cx={-147} cy={133} rx={3} ry={5.6} fill="#050506" />
        <rect x={-67} y={119} width={8} height={28} rx={2} fill="url(#pb-chrome)" stroke="#33333b" strokeWidth={0.8} />
        <rect x={-60} y={116} width={66} height={31} rx={9} fill="url(#pb-pinkv)" stroke="#7a0c46" strokeWidth={1.5} />
        <rect x={-55} y={119.5} width={56} height={4} rx={2} fill="#ffffff" opacity={0.38} />
        <circle cx={-48} cy={138} r={2.2} fill="#7a0c46" opacity={0.7} />
        <circle cx={-6} cy={138} r={2.2} fill="#7a0c46" opacity={0.7} />

        {/* pressure gauge on the front of the foot */}
        <rect x={4} y={127.5} width={9} height={9} fill="url(#pb-chrome)" stroke="#33333b" strokeWidth={0.6} />
        <g transform="translate(24 132)">
          <circle r={12.5} fill="url(#pb-chrome)" stroke="#24242a" strokeWidth={1.5} />
          <circle r={9.4} fill="#f7f7f7" />
          <path d="M 3.4 -8.7 A 9.4 9.4 0 0 1 9 -2.4 L 6.5 -1.8 A 6.8 6.8 0 0 0 2.6 -6.3 Z" fill="#e01b24" />
          {Array.from({ length: 9 }).map((_, i) => {
            const a = ((-210 + i * 30) * Math.PI) / 180;
            return <line key={i} x1={Math.cos(a) * 6.7} y1={Math.sin(a) * 6.7} x2={Math.cos(a) * 8.5} y2={Math.sin(a) * 8.5} stroke="#222" strokeWidth={0.8} />;
          })}
          <line x1={0} y1={0} x2={4.6} y2={-5.8} stroke="#e01b24" strokeWidth={1.7} strokeLinecap="round" />
          <circle r={1.6} fill="#222" />
          <ellipse cx={-3.4} cy={-4.8} rx={3.4} ry={1.7} fill="#ffffff" opacity={0.7} />
        </g>

        {/* barrel */}
        <rect x={112} y={-34} width={18} height={44} rx={4} fill="url(#pb-black)" stroke="#000" />
        <rect x={128} y={-27} width={214} height={30} fill="url(#pb-barrel)" stroke="#000" strokeWidth={1} />
        <rect x={128} y={-24} width={214} height={3} fill="#ffffff" opacity={0.22} />
        {HOLES.map((x) => (
          <g key={x}>
            <circle cx={x} cy={-12} r={5.8} fill="#000" stroke="#c4c4d0" strokeWidth={1.4} />
            <circle cx={x - 1.6} cy={-13.8} r={1.5} fill="#ffffff" opacity={0.45} />
          </g>
        ))}
        <rect x={338} y={-31} width={26} height={38} rx={3} fill="url(#pb-chrome)" stroke="#55555f" />
        <rect x={340} y={-28} width={22} height={3} fill="#ffffff" opacity={0.7} />
        <ellipse cx={364} cy={-12} rx={5} ry={19} fill="#d9dde3" stroke="#55555f" />
        <ellipse cx={365} cy={-12} rx={3} ry={11} fill="#0a0a0c" />

        {/* front stock */}
        <rect x={-234} y={-26} width={126} height={60} fill="url(#pb-black)" />
        <rect x={-234} y={-21} width={126} height={4} fill="#ffffff" opacity={0.14} />
        {RINGS.map((x) => (
          <g key={x} className="pb-neon">
            <path d={`M ${x} -26 Q ${x + 5} 4 ${x} 34`} stroke="#ff4fb0" strokeWidth={5} fill="none" filter="url(#pb-neon)" />
            <path d={`M ${x} -26 Q ${x + 5} 4 ${x} 34`} stroke="#ffd0ea" strokeWidth={1.6} fill="none" />
          </g>
        ))}
        <ellipse cx={-234} cy={4} rx={12} ry={30} fill="url(#pb-cap)" stroke="#45454f" strokeWidth={2} />
        <ellipse cx={-236} cy={4} rx={6} ry={18} fill="#08080a" />

        {/* body */}
        <path d="M -112 -46 L 106 -46 Q 120 -46 120 0 Q 120 46 106 46 L -112 46 Z" fill="url(#pb-body)" stroke="#6e0a40" strokeWidth={1.5} />
        <g clipPath="url(#pb-bodyclip)">
          {DOTS.map((d, i) => (
            <ellipse key={i} cx={d.x} cy={d.y} rx={6.6} ry={d.ry.toFixed(2)} fill="#ffffff" opacity={d.y > 20 ? 0.82 : 0.96} />
          ))}
          <rect x={-108} y={-38} width={214} height={8} rx={4} fill="#ffffff" opacity={0.4} filter="url(#pb-soft)" />
          <rect x={-112} y={30} width={232} height={18} fill="#4a0429" opacity={0.3} filter="url(#pb-soft)" />
        </g>
        <path d="M 106 -46 Q 120 -46 120 0 Q 120 46 106 46" fill="none" stroke="#ff9ccd" strokeWidth={2} opacity={0.8} />
        <rect x={-114} y={-30} width={10} height={68} rx={3} fill="#24242a" stroke="#000" />
        <circle cx={-60} cy={-8} r={11.5} fill="#2a0a18" />
        <circle cx={-60} cy={-8} r={9.5} fill="url(#pb-red)" />
        <ellipse cx={-63} cy={-11.5} rx={3.2} ry={2} fill="#ffffff" opacity={0.85} />

        {/* silver tube */}
        <rect x={-160} y={-67} width={186} height={22} rx={11} fill="url(#pb-silver)" stroke="#5d6470" strokeWidth={1} />
        <rect x={-136} y={-68} width={5} height={24} rx={1} fill="#7b8390" />
        <rect x={-6} y={-69} width={24} height={26} rx={4} fill="url(#pb-pinkm)" stroke="#8a0e50" />
        <ellipse cx={-158} cy={-56} rx={4} ry={10} fill="#eef1f5" />


        {/* hopper neck – exactly perpendicular to the body */}
        <rect x={30} y={-60} width={40} height={16} rx={4} fill="url(#pb-lid)" stroke="#000" />
        <rect x={37} y={-124} width={26} height={66} fill="url(#pb-lid)" stroke="#000" />
        <rect x={33} y={-88} width={34} height={9} rx={2} fill="url(#pb-lid)" stroke="#000" />
        <rect x={33} y={-108} width={34} height={8} rx={2} fill="url(#pb-lid)" stroke="#000" />
        <rect x={27} y={-132} width={46} height={12} rx={3} fill="url(#pb-lid)" stroke="#000" />
        <circle cx={28} cy={-97} r={6.5} fill="#26262c" stroke="#4a4a54" strokeWidth={1.5} />
        <circle cx={28} cy={-97} r={2.8} fill="#7a7a86" />

        {/* side feed elbow + mini globe */}
        <rect x={102} y={19} width={28} height={22} rx={4} fill="url(#pb-lid)" stroke="#000" />
        <rect x={108} y={16} width={6} height={28} rx={2} fill="#3a3a44" stroke="#000" strokeWidth={0.8} />
        <g transform="translate(156 30) rotate(45)">
          <Globe R={34} back={SMALL_BACK} front={SMALL_FRONT} r={8.4} tick={tick} />
        </g>
        <g transform="translate(156 30)">
          <rect x={31} y={-10} width={13} height={20} rx={3} fill="url(#pb-lid)" stroke="#000" />
          <ellipse cx={44} cy={0} rx={3.4} ry={10} fill="#4a4a55" />
        </g>

        {/* hopper globe (balls settle to the screen bottom) */}
        <g transform="translate(50 -192) rotate(45)">
          <Globe R={64} back={BIG_BACK} front={BIG_FRONT} r={10.5} tick={tick} />
        </g>
        {/* hopper lid on the same axis */}
        <g transform="translate(50 -192)">
          <rect x={-30} y={-68} width={60} height={9} rx={2} fill="#141418" />
          <rect x={-32} y={-92} width={64} height={26} fill="url(#pb-lid)" stroke="#000" />
          {[-86, -81, -76, -71].map((y) => (
            <line key={y} x1={-32} y1={y} x2={32} y2={y} stroke="#5d5d69" strokeWidth={1} />
          ))}
          <ellipse cx={0} cy={-92} rx={32} ry={8} fill="#2d2d35" stroke="#a5a5b2" strokeWidth={1.8} />
          <ellipse cx={0} cy={-92} rx={23} ry={5.2} fill="#18181d" />
          <ellipse cx={-10} cy={-94} rx={8} ry={1.6} fill="#ffffff" opacity={0.35} />
        </g>

        <g key={`p${tick}`} className={tick ? "pb-fire" : undefined}>
          {RINGS.map((x) => (
            <path key={x} className="pb-flash" d={`M ${x} -26 Q ${x + 5} 4 ${x} 34`} stroke="#ffffff" strokeWidth={6} fill="none" filter="url(#pb-neon)" opacity={0} />
          ))}
          <circle className="pb-puff" cx={378} cy={-12} r={16} fill="#ffd6ef" opacity={0} filter="url(#pb-soft)" />
        </g>
      </g>

      {/* ============ SHOT FX ============ */}
      {shots.map((id) => {
        const r = rng(id);
        return (
          <g key={id} data-fx="">
            <g transform={P_T}>
              <g transform="translate(370 -12)">
                {[0, 1, 2].map((i) => {
                  const c = Math.floor(r() * 4);
                  return (
                    <g key={i} className="fx-fly" style={vars({ "--dx": "340px", "--dy": `${((r() - 0.5) * 50).toFixed(0)}px`, "--t": "520ms", "--dl": `${i * 85}ms` })}>
                      <circle r={10} fill={`url(#pb-b${c})`} />
                    </g>
                  );
                })}
                <Burst seed={id} count={22} colors={BALL_COLORS.concat(["#ff4fb0", "#ffffff"])} spread={90} dist={[40, 130]} size={[2, 4.5]} />
                <circle className="fx-ring" r={12} fill="none" stroke="#ff8cc8" strokeWidth={3} vectorEffect="non-scaling-stroke" style={vars({ "--s": 5, "--t": "520ms" })} />
              </g>
            </g>
            {[0, 1, 2].map((i) => {
              const x = 330 + r() * 170;
              const y = -20 + r() * 170;
              const c = BALL_COLORS[Math.floor(r() * 4)];
              return (
                <g key={i} transform={`translate(${x.toFixed(0)} ${y.toFixed(0)}) rotate(${(r() * 360).toFixed(0)}) scale(${(0.7 + r() * 0.6).toFixed(2)})`}>
                  <g className="pb-splat" style={vars({ "--dl": `${300 + i * 90}ms` })}>
                    <Splat seed={id + i * 13} color={c} />
                  </g>
                </g>
              );
            })}
          </g>
        );
      })}
      </g>
    </svg>
  );
}
