import { Burst, rng, vars, type WeaponProps } from "./shared";

/* ------------------------------------------------------------------
   4. SHARK LAUNCHER – sleek armored robo-shark with a torpedo body,
   wide open jaws + glowing throat, glowing cyber eye under an
   armored brow, curved neon gill slits, swept fins, rear thruster.
   Local frame: head at -x, tail at +x (rotated -22deg).
   The lower jaw hinges at (-122, 50).
------------------------------------------------------------------- */

const S_T = "translate(250 226) rotate(-22) scale(0.94)";
type Pt = [number, number];

function bez(p: Pt[], t: number): Pt {
  const u = 1 - t;
  const a = u * u * u;
  const b = 3 * u * u * t;
  const c = 3 * u * t * t;
  const d = t * t * t;
  return [a * p[0][0] + b * p[1][0] + c * p[2][0] + d * p[3][0], a * p[0][1] + b * p[1][1] + c * p[2][1] + d * p[3][1]];
}

/** curved shark fangs standing on a cubic curve */
function fangs(curve: Pt[], n: number, from: number, to: number, h0: number, h1: number, w0: number, w1: number, side: 1 | -1, lean: number) {
  const out: string[] = [];
  const f = (p: Pt) => `${p[0].toFixed(1)} ${p[1].toFixed(1)}`;
  for (let i = 0; i < n; i++) {
    const k = n === 1 ? 0 : i / (n - 1);
    const t = from + (to - from) * k;
    const a = bez(curve, Math.max(0, t - 0.015));
    const b = bez(curve, Math.min(1, t + 0.015));
    const c = bez(curve, t);
    const L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
    const ux = (b[0] - a[0]) / L;
    const uy = (b[1] - a[1]) / L;
    const nx = -uy * side;
    const ny = ux * side;
    const h = h0 + (h1 - h0) * k;
    const w = w0 + (w1 - w0) * k;
    const b1: Pt = [c[0] - (ux * w) / 2, c[1] - (uy * w) / 2];
    const b2: Pt = [c[0] + (ux * w) / 2, c[1] + (uy * w) / 2];
    const tip: Pt = [c[0] + nx * h + ux * lean * h, c[1] + ny * h + uy * lean * h];
    const q1: Pt = [b1[0] + nx * h * 0.62 + ux * lean * h * 0.15, b1[1] + ny * h * 0.62 + uy * lean * h * 0.15];
    const q2: Pt = [b2[0] + nx * h * 0.42 + ux * lean * h * 0.75, b2[1] + ny * h * 0.42 + uy * lean * h * 0.75];
    out.push(`M ${f(b1)} Q ${f(q1)} ${f(tip)} Q ${f(q2)} ${f(b2)} Z`);
  }
  return out;
}

/* ---------- shapes ---------- */
const BODY =
  "M -252 2 C -240 -10, -218 -28, -184 -38 C -150 -47, -104 -50, -60 -49 C 0 -48, 90 -43, 160 -35 C 192 -31, 214 -28, 228 -26 L 230 22 C 208 26, 172 36, 132 46 C 84 58, 24 68, -36 70 C -70 71, -96 73, -110 72 C -118 66, -121 58, -122 50 C -164 44, -206 31, -238 17 Q -250 12 -252 2 Z";
const UPPER_GUM: Pt[] = [[-122, 50], [-164, 44], [-206, 31], [-238, 17]];
const LOWER_GUM: Pt[] = [[6, -2], [-30, 10], [-68, 26], [-104, 44]]; // relative to hinge
const UPPER_TEETH = fangs(UPPER_GUM, 8, 0.07, 0.95, 13, 22, 10, 13, -1, -0.2);
const UPPER_BACK = fangs(UPPER_GUM, 7, 0.13, 0.89, 8, 12, 8, 9, -1, -0.12);
const LOWER_TEETH = fangs(LOWER_GUM, 7, 0.1, 0.94, 12, 19, 10, 12.5, 1, -0.2);
const LOWER_BACK = fangs(LOWER_GUM, 6, 0.17, 0.88, 8, 11, 8, 9, 1, -0.12);
const LIP = "M -252 2 Q -250 12 -238 17 C -206 31, -164 44, -122 50 L -118 36 C -160 30, -204 17, -236 5 Q -246 2 -252 2 Z";
const JAW = "M 6 -4 C -30 8, -68 24, -106 42 C -112 46, -111 54, -103 55 C -78 56, -46 50, -18 39 C -2 33, 10 20, 10 6 Z";
const BELLY = "M -116 50 C -70 50, 0 44, 100 26 C 150 18, 200 10, 240 8 L 240 130 L -116 130 Z";
const BELLY_LINE = "M -116 50 C -70 50, 0 44, 100 26 C 150 18, 200 10, 232 8";
const BACK_BAND =
  "M -236 -8 C -218 -26, -192 -36, -160 -43 C -110 -50, -40 -48, 20 -46 C 90 -43, 150 -37, 228 -26 L 228 -16 C 150 -24, 80 -30, 10 -32 C -60 -34, -130 -32, -180 -24 C -206 -18, -224 -10, -236 -8 Z";
const DORSAL = "M -26 -48 C 2 -68, 36 -106, 78 -140 C 62 -104, 58 -74, 70 -46 Z";
const DORSAL2 = "M 148 -36 C 158 -44, 172 -58, 194 -70 C 186 -56, 182 -44, 184 -32 Z";
const TAIL_UP = "M 190 -30 C 210 -52, 236 -82, 270 -108 C 262 -74, 250 -40, 238 -18 Z";
const TAIL_LO = "M 200 22 C 214 38, 230 58, 250 76 C 250 52, 244 32, 236 16 Z";
const PECTORAL = "M -66 62 C -38 84, 0 114, 42 134 C 30 108, 18 86, 6 66 Z";
const PELVIC = "M 110 48 C 122 58, 136 70, 154 78 C 150 62, 146 50, 144 42 Z";
const GILLS = [0, 1, 2, 3, 4].map((i) => {
  const x = -102 + i * 12;
  const e = Math.abs(i - 2) * 4;
  return `M ${x} ${-16 + e} Q ${x + 9} ${14} ${x - 1} ${44 - e}`;
});
const GILL_AREA = "M -110 -18 Q -60 -24 -40 -10 L -40 46 Q -70 54 -112 50 Z";
const EYE: Pt = [-164, -8];
const BROW = "M -30 -4 L 22 -26 L 28 -17 L -24 4 Z";
const SOCKET = "M -22 4 Q -12 -12 12 -10 Q 19 -2 13 7 Q -4 13 -22 4 Z";

const r0 = rng(31);
const JET_BUBBLES = Array.from({ length: 7 }).map((_, i) => ({ y: (r0() - 0.5) * 18, r: 1.2 + r0() * 2, d: i * 0.23 }));

const CSS = `
.sl-jet{transform-box:fill-box;transform-origin:0% 50%;animation:sl-jet .14s ease-in-out infinite alternate}
@keyframes sl-jet{0%{transform:scaleX(.84) scaleY(.92);opacity:.85}100%{transform:scaleX(1.12) scaleY(1.05);opacity:1}}
.sl-eye{animation:sl-eye 1.8s ease-in-out infinite}
@keyframes sl-eye{0%,100%{opacity:.5}50%{opacity:1}}
.sl-flare{transform-box:fill-box;transform-origin:center;animation:sl-flare 1.8s ease-in-out infinite}
@keyframes sl-flare{0%,100%{transform:scaleX(.6);opacity:.55}50%{transform:scaleX(1.15);opacity:1}}
.sl-mist{transform-box:fill-box;transform-origin:center;animation:sl-mist 3s ease-in-out infinite}
@keyframes sl-mist{0%,100%{transform:translateX(0) scale(1);opacity:.45}50%{transform:translateX(10px) scale(1.12);opacity:.9}}
.sl-strip{animation:sl-strip 1.8s ease-in-out infinite}
@keyframes sl-strip{0%,100%{opacity:.6}50%{opacity:1}}
.sl-mg{animation:sl-mg 1.4s ease-in-out infinite}
@keyframes sl-mg{0%,100%{opacity:.45}50%{opacity:.95}}
.sl-bub{animation:sl-bub 1.6s linear infinite}
@keyframes sl-bub{0%{transform:translate(0,0);opacity:0}15%{opacity:1}100%{transform:translate(80px,-4px);opacity:0}}
.sl-chomp{animation:sl-chomp 600ms cubic-bezier(.3,.7,.3,1) both}
@keyframes sl-chomp{0%{transform:rotate(0)}22%{transform:rotate(42deg)}46%{transform:rotate(-12deg)}72%{transform:rotate(4deg)}100%{transform:rotate(0)}}
.sl-fire .sl-flash{animation:sl-flash 650ms ease-out both}
@keyframes sl-flash{0%{opacity:0}20%{opacity:1}100%{opacity:0}}
.sl-fire .sl-boost{transform-box:fill-box;transform-origin:0% 50%;animation:sl-boost 760ms ease-out both}
@keyframes sl-boost{0%{transform:scaleX(.6);opacity:0}20%{transform:scaleX(2.4) scaleY(1.4);opacity:1}100%{transform:scaleX(1);opacity:0}}
`;

export default function SharkLauncher({ shots, tick }: WeaponProps) {
  const chomp = tick ? "sl-chomp" : undefined;
  return (
    <svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" className="weapon-svg" overflow="visible">
      <style>{CSS}</style>
      <defs>
        <linearGradient id="sl-body" x1="0" y1="-50" x2="0" y2="72" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#b4e2ff" />
          <stop offset="0.12" stopColor="#5eaaf2" />
          <stop offset="0.36" stopColor="#2f78cf" />
          <stop offset="0.62" stopColor="#1d58a4" />
          <stop offset="1" stopColor="#113770" />
        </linearGradient>
        <linearGradient id="sl-silver" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f5f9fc" />
          <stop offset="0.45" stopColor="#c6d3e1" />
          <stop offset="1" stopColor="#7d8fa7" />
        </linearGradient>
        <linearGradient id="sl-belly" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#e6eef6" />
          <stop offset="0.5" stopColor="#aebfd2" />
          <stop offset="1" stopColor="#6c819e" />
        </linearGradient>
        <linearGradient id="sl-fin" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#8ccaff" />
          <stop offset="0.45" stopColor="#2f7ad4" />
          <stop offset="1" stopColor="#143a76" />
        </linearGradient>
        <linearGradient id="sl-finsilver" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#eef4fa" />
          <stop offset="0.5" stopColor="#a9bccf" />
          <stop offset="1" stopColor="#5d7390" />
        </linearGradient>
        <linearGradient id="sl-steel" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#e6edf5" />
          <stop offset="0.5" stopColor="#8696aa" />
          <stop offset="1" stopColor="#3a4658" />
        </linearGradient>
        <radialGradient id="sl-eye" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.24" stopColor="#eafdff" />
          <stop offset="0.5" stopColor="#6ff0ff" />
          <stop offset="0.78" stopColor="#1b8cff" />
          <stop offset="1" stopColor="#0b3a8a" />
        </radialGradient>
        <radialGradient id="sl-mouth" cx="0.3" cy="0.62" r="0.75">
          <stop offset="0" stopColor="#ffe788" />
          <stop offset="0.28" stopColor="#ffa22a" />
          <stop offset="0.58" stopColor="#ea381c" />
          <stop offset="0.85" stopColor="#9a100c" />
          <stop offset="1" stopColor="#4a0606" />
        </radialGradient>
        <linearGradient id="sl-tooth" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="1" stopColor="#cfd3d8" />
        </linearGradient>
        <linearGradient id="sl-jet" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.25" stopColor="#a8f9ff" />
          <stop offset="0.65" stopColor="#2fb6ff" stopOpacity="0.8" />
          <stop offset="1" stopColor="#2f7bff" stopOpacity="0" />
        </linearGradient>
        <radialGradient id="sl-mist" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#b0fcff" stopOpacity="0.85" />
          <stop offset="0.45" stopColor="#4fd8ff" stopOpacity="0.35" />
          <stop offset="1" stopColor="#4fd8ff" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="sl-grip" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#434b57" />
          <stop offset="0.5" stopColor="#1c2027" />
          <stop offset="1" stopColor="#0b0d10" />
        </linearGradient>
        <radialGradient id="sl-orb" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.3" stopColor="#c4faff" />
          <stop offset="0.65" stopColor="#3ad0ff" stopOpacity="0.8" />
          <stop offset="1" stopColor="#2a7bff" stopOpacity="0" />
        </radialGradient>
        <filter id="sl-glow" x="-80%" y="-80%" width="260%" height="260%">
          <feGaussianBlur stdDeviation="2.4" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <filter id="sl-blur" x="-60%" y="-60%" width="220%" height="220%">
          <feGaussianBlur stdDeviation="6" />
        </filter>
        <filter id="sl-soft" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="2" />
        </filter>
        <clipPath id="sl-clip">
          <path d={BODY} />
        </clipPath>
        <clipPath id="sl-mouthclip">
          <path d="M -262 2 L -238 17 C -206 31, -164 44, -122 50 L -96 60 L -96 170 L -262 170 Z" />
        </clipPath>
      </defs>

      <g transform={S_T}>
        {/* ---------- thruster jet ---------- */}
        <g transform="translate(256 0)">
          <g className="sl-jet">
            <path d="M 0 -16 C 30 -15, 62 -8, 94 0 C 62 8, 30 15, 0 16 Z" fill="url(#sl-jet)" filter="url(#sl-soft)" />
            <path d="M 0 -8 C 20 -7, 38 -4, 56 0 C 38 4, 20 7, 0 8 Z" fill="#effeff" />
          </g>
          {JET_BUBBLES.map((b, i) => (
            <circle key={i} className="sl-bub" cx={8} cy={b.y.toFixed(1)} r={b.r.toFixed(1)} fill="#bff9ff" style={{ animationDelay: `${b.d}s` }} />
          ))}
          <g key={`j${tick}`} className={tick ? "sl-fire" : undefined}>
            <path className="sl-boost" d="M 0 -18 C 40 -16, 80 -8, 120 0 C 80 8, 40 16, 0 18 Z" fill="url(#sl-jet)" opacity={0} />
          </g>
        </g>

        {/* ---------- fins behind the body ---------- */}
        <path d={TAIL_UP} fill="url(#sl-fin)" stroke="#0c2a55" strokeWidth={1.5} strokeLinejoin="round" />
        <path d="M 196 -34 C 214 -54, 238 -82, 266 -104" stroke="#d2f0ff" strokeWidth={2} fill="none" opacity={0.8} strokeLinecap="round" />
        <path d={TAIL_LO} fill="url(#sl-fin)" stroke="#0c2a55" strokeWidth={1.5} strokeLinejoin="round" />
        <path d={PELVIC} fill="url(#sl-fin)" stroke="#0c2a55" strokeWidth={1.3} strokeLinejoin="round" />
        <path d={DORSAL} fill="url(#sl-fin)" stroke="#0c2a55" strokeWidth={1.6} strokeLinejoin="round" />
        <path d="M -20 -52 C 6 -70, 38 -104, 75 -136" stroke="#e2f5ff" strokeWidth={2.6} fill="none" opacity={0.9} strokeLinecap="round" />
        <path className="sl-strip" d="M 8 -54 C 26 -70, 44 -92, 62 -112" stroke="#74f5ff" strokeWidth={2.2} fill="none" strokeLinecap="round" filter="url(#sl-glow)" />
        <path d={DORSAL2} fill="url(#sl-fin)" stroke="#0c2a55" strokeWidth={1.4} strokeLinejoin="round" />

        {/* ---------- grip (behind the body) ---------- */}
        <g transform="translate(84 50) rotate(16)">
          <path d="M -14 -8 L 18 -8 L 20 18 C 24 28, 18 36, 22 46 C 25 54, 20 60, 22 68 L 16 78 L -12 76 C -17 50, -17 22, -14 -8 Z" fill="url(#sl-grip)" stroke="#06070a" strokeWidth={1.5} />
          <path d="M -8 8 L 12 8 M -9 20 L 13 20 M -9 32 L 14 32 M -9 44 L 14 44 M -9 56 L 13 56 M -8 68 L 12 68" stroke="#3a424e" strokeWidth={1.4} />
          <path d="M -14 4 L -30 6 Q -39 8 -37 19 L -33 32 L -14 32" fill="none" stroke="#2c3644" strokeWidth={4} strokeLinejoin="round" />
          <path d="M -19 10 Q -28 19 -24 30 L -20 29 Q -22 20 -15 13 Z" fill="#cfdbe8" stroke="#45556a" strokeWidth={0.8} />
        </g>

        {/* ---------- body ---------- */}
        <path d={BODY} fill="url(#sl-body)" stroke="#0a2349" strokeWidth={2} strokeLinejoin="round" />
        <g clipPath="url(#sl-clip)">
          <path d={BACK_BAND} fill="#9ad4ff" opacity={0.32} />
          <path d={BELLY} fill="url(#sl-belly)" />
          <path d={BELLY_LINE} fill="none" stroke="#0e3360" strokeWidth={1.6} />
          <path d="M -116 52 C -70 52, 0 46, 100 28 C 150 20, 200 12, 232 10" fill="none" stroke="#ffffff" strokeWidth={0.9} opacity={0.6} />
          {/* side armor line */}
          <path d="M -36 8 C 30 4, 110 -4, 228 -12" fill="none" stroke="#123d73" strokeWidth={1.3} opacity={0.8} />
          <path d="M -36 10 C 30 6, 110 -2, 228 -10" fill="none" stroke="#8fcbff" strokeWidth={0.8} opacity={0.5} />
          {/* tail rings */}
          <rect x={194} y={-40} width={8} height={90} fill="url(#sl-steel)" />
          <rect x={214} y={-40} width={5} height={90} fill="url(#sl-steel)" />
          {/* segment seams */}
          <g fill="none" stroke="#0b2b55" strokeWidth={1.6}>
            <path d="M -130 -50 C -132 -20, -128 10, -118 36" />
            <path d="M -38 -50 C -42 0, -44 40, -48 72" />
            <path d="M 66 -46 C 66 -10, 64 20, 60 60" />
            <path d="M 150 -38 C 149 -10, 148 10, 144 44" />
          </g>
          <g fill="none" stroke="#a6d8ff" strokeWidth={0.9} opacity={0.6}>
            <path d="M -128 -50 C -130 -20, -126 10, -116 36" />
            <path d="M -36 -50 C -40 0, -42 40, -46 72" />
            <path d="M 68 -46 C 68 -10, 66 20, 62 60" />
            <path d="M 152 -38 C 151 -10, 150 10, 146 44" />
          </g>
          {/* snout sheen */}
          <path d="M -244 -4 C -228 -20, -204 -32, -170 -40 L -176 -30 C -204 -24, -226 -12, -238 2 Z" fill="#ffffff" opacity={0.22} />
        </g>

        {/* emblem */}
        <path
          d="M 12 10 C 18 6, 26 5, 34 7 L 38 1 L 39 7 C 43 8, 46 10, 48 12 L 52 9 L 51 13 L 52 17 L 48 14 C 42 16, 32 17, 22 15 L 18 19 L 18 14 C 15 13, 13 12, 12 10 Z"
          fill="#ffffff"
          opacity={0.92}
          transform="translate(-20 -36)"
        />
        {/* control panel */}
        <rect x={100} y={4} width={34} height={15} rx={3} fill="#0f2a48" stroke="#061629" />
        <rect x={104} y={8} width={6} height={4} rx={1} fill="#74f5ff" />
        <rect x={113} y={8} width={6} height={4} rx={1} fill="#ffcf4a" />
        <rect x={122} y={8} width={8} height={4} rx={1} fill="#ff5a5a" />
        <rect x={104} y={14} width={26} height={2} fill="#74f5ff" opacity={0.6} />
        {/* cyan light strips */}
        <g className="sl-strip" filter="url(#sl-glow)" strokeLinecap="round" fill="none" stroke="#74f5ff">
          <path d="M -26 28 L 52 18" strokeWidth={3.6} />
          <path d="M 82 -12 L 172 -20" strokeWidth={3} />
          <path d="M 152 14 L 200 7" strokeWidth={2.4} />
        </g>
        {/* rivets */}
        <g fill="#d6ecff">
          {[[-36, -30], [-40, 0], [-44, 32], [70, -30], [68, 0], [66, 30], [154, -24], [152, 0], [150, 24]].map(([x, y], i) => (
            <circle key={i} cx={x} cy={y} r={1.4} />
          ))}
        </g>
        {/* back highlight */}
        <path d="M -238 -6 C -220 -22, -196 -33, -160 -42 C -110 -49, -50 -47, 20 -45 C 90 -42, 150 -36, 210 -29" stroke="#d2ecff" strokeWidth={2.2} fill="none" opacity={0.8} strokeLinecap="round" />

        {/* gills: curved neon slits */}
        <ellipse className="sl-mist" cx={-70} cy={16} rx={44} ry={30} fill="url(#sl-mist)" />
        {GILLS.map((d, i) => (
          <g key={i}>
            <path d={d} fill="none" stroke="#041a2c" strokeWidth={6.5} strokeLinecap="round" />
            <path d={d} fill="none" stroke="#8fd3ff" strokeWidth={1} strokeLinecap="round" opacity={0.6} transform="translate(2.6 0)" />
            <path className="sl-strip" d={d} fill="none" stroke="#7ff7ff" strokeWidth={2.2} strokeLinecap="round" filter="url(#sl-glow)" style={{ animationDelay: `${i * 0.15}s` }} />
          </g>
        ))}

        {/* ---------- head ---------- */}
        {/* mouth interior (rotates with jaw, clipped under the upper gum) */}
        <g clipPath="url(#sl-mouthclip)">
          <g transform="translate(-122 50)">
            <g key={`m${tick}`} className={chomp}>
              <path d="M 12 -4 C -30 10, -68 26, -104 44 L -130 -40 L -60 -76 L 26 -76 Z" fill="url(#sl-mouth)" />
              <ellipse cx={-4} cy={12} rx={18} ry={14} fill="#3a0505" opacity={0.7} filter="url(#sl-soft)" />
              <ellipse className="sl-mg" cx={-62} cy={10} rx={36} ry={18} fill="#ffd36b" filter="url(#sl-blur)" />
            </g>
          </g>
        </g>
        {/* upper jaw: back row, fangs, gum, lip band, nostril */}
        {UPPER_BACK.map((d, i) => (
          <path key={`ub${i}`} d={d} fill="#b8c0ca" stroke="#7d8794" strokeWidth={0.6} strokeLinejoin="round" />
        ))}
        {UPPER_TEETH.map((d, i) => (
          <path key={`u${i}`} d={d} fill="url(#sl-tooth)" stroke="#8a939e" strokeWidth={0.7} strokeLinejoin="round" />
        ))}
        <path d="M -122 50 C -164 44, -206 31, -238 17" fill="none" stroke="#a30d16" strokeWidth={7} strokeLinecap="round" />
        <path d="M -122 47 C -164 41, -206 28, -236 14" fill="none" stroke="#ff6b6b" strokeWidth={1.4} strokeLinecap="round" opacity={0.7} />
        <path d={LIP} fill="url(#sl-silver)" stroke="#3d4e66" strokeWidth={1.3} strokeLinejoin="round" />
        <path d="M -246 4 C -230 6, -206 14, -186 20 C -166 26, -146 32, -124 37" fill="none" stroke="#ffffff" strokeWidth={1.2} opacity={0.75} />
        <path d="M -200 18 L -204 34" stroke="#5f7491" strokeWidth={1.3} />
        <path d="M -236 -7 Q -229 -11 -220 -10" fill="none" stroke="#0b2647" strokeWidth={2.6} strokeLinecap="round" />

        {/* lower jaw */}
        <g transform="translate(-122 50)">
          <g key={`l${tick}`} className={chomp}>
            {LOWER_BACK.map((d, i) => (
              <path key={`lb${i}`} d={d} fill="#b8c0ca" stroke="#7d8794" strokeWidth={0.6} strokeLinejoin="round" />
            ))}
            {LOWER_TEETH.map((d, i) => (
              <path key={`l${i}`} d={d} fill="url(#sl-tooth)" stroke="#8a939e" strokeWidth={0.7} strokeLinejoin="round" />
            ))}
            <path d="M 6 -2 C -30 10, -68 26, -104 44" fill="none" stroke="#a30d16" strokeWidth={7} strokeLinecap="round" />
            <path d={JAW} fill="url(#sl-silver)" stroke="#2c3d55" strokeWidth={1.6} strokeLinejoin="round" />
            <path d="M 4 1 C -30 12, -66 28, -100 46" fill="none" stroke="#ffffff" strokeWidth={1.2} opacity={0.7} />
            <path d="M -100 53 C -76 54, -46 48, -18 37 C -4 32, 6 22, 8 10" fill="none" stroke="#5f7491" strokeWidth={1.2} opacity={0.7} />
            <path className="sl-strip" d="M -88 46 C -70 48, -46 45, -26 38" fill="none" stroke="#74f5ff" strokeWidth={2.2} strokeLinecap="round" filter="url(#sl-glow)" />
            <path d="M -56 30 L -53 50" stroke="#5f7491" strokeWidth={1.2} />
            <circle cx={-12} cy={26} r={1.6} fill="#e6f2ff" />
            <circle cx={-28} cy={33} r={1.6} fill="#e6f2ff" />
          </g>
        </g>

        {/* ---------- glowing cyber eye ---------- */}
        <g transform={`translate(${EYE[0]} ${EYE[1]}) scale(1.16)`}>
          <circle className="sl-eye" r={24} fill="#3fd2ff" opacity={0.85} filter="url(#sl-blur)" />
          <path d={SOCKET} fill="#061424" stroke="#02070d" strokeWidth={1.2} strokeLinejoin="round" />
          <path d={SOCKET} fill="none" stroke="#9fb6cf" strokeWidth={1.2} strokeLinejoin="round" transform="translate(0.6 1.2)" opacity={0.6} />
          <circle r={8.6} fill="url(#sl-eye)" />
          <circle r={5.8} fill="none" stroke="#e8ffff" strokeWidth={0.9} opacity={0.75} />
          <circle r={3.2} fill="#ffffff" filter="url(#sl-glow)" />
          <g className="sl-flare" filter="url(#sl-glow)">
            <path d="M -20 0 L 0 -1.4 L 22 0 L 0 1.4 Z" fill="#c8fbff" />
            <path d="M 0 -9 L 1 0 L 0 9 L -1 0 Z" fill="#c8fbff" opacity={0.8} />
          </g>
          <circle cx={-3} cy={-3} r={1.4} fill="#ffffff" />
          {/* armored brow */}
          <path d={BROW} fill="#173f72" stroke="#0a2347" strokeWidth={1.3} strokeLinejoin="round" />
          <path d="M -29 -4.5 L 21.5 -25.5" stroke="#9fd4ff" strokeWidth={1.2} opacity={0.8} />
          <path d="M -23 3.5 L 27 -16.5" stroke="#0a2347" strokeWidth={1} opacity={0.8} />
        </g>

        {/* pectoral fin (front) */}
        <path d={PECTORAL} fill="url(#sl-finsilver)" stroke="#2c3d55" strokeWidth={1.5} strokeLinejoin="round" />
        <path d="M -60 64 C -34 84, 2 112, 38 130" stroke="#ffffff" strokeWidth={1.4} fill="none" opacity={0.75} />
        <path className="sl-strip" d="M -46 72 C -22 88, 6 108, 30 122" stroke="#74f5ff" strokeWidth={2} fill="none" filter="url(#sl-glow)" />

        {/* thruster nozzle */}
        <rect x={220} y={-30} width={10} height={56} rx={3} fill="url(#sl-steel)" stroke="#1f2b3b" strokeWidth={1.2} />
        <path d="M 228 -22 L 254 -27 L 254 27 L 228 21 Z" fill="url(#sl-steel)" stroke="#1f2b3b" strokeWidth={1.4} strokeLinejoin="round" />
        <ellipse cx={254} cy={0} rx={5} ry={26} fill="#0b2a3f" stroke="#a9dcff" strokeWidth={1.4} />
        <ellipse cx={254.5} cy={0} rx={3.4} ry={18} fill="#c4fbff" filter="url(#sl-glow)" />

        {/* right-click overlays */}
        <g key={`f${tick}`} className={tick ? "sl-fire" : undefined}>
          <circle className="sl-flash" cx={EYE[0]} cy={EYE[1]} r={30} fill="#d8fbff" filter="url(#sl-blur)" opacity={0} />
          <path className="sl-flash" d={GILL_AREA} fill="#c8fdff" filter="url(#sl-soft)" opacity={0} />
          <g className="sl-flash" opacity={0} filter="url(#sl-glow)" stroke="#ffffff" strokeLinecap="round" fill="none">
            <path d="M -26 28 L 52 18" strokeWidth={4} />
            <path d="M 82 -12 L 172 -20" strokeWidth={3.4} />
            {GILLS.map((d, i) => (
              <path key={i} d={d} strokeWidth={2.6} />
            ))}
          </g>
        </g>
      </g>

      {/* ============ SHOT FX ============ */}
      {shots.map((id) => (
        <g key={id} data-fx="">
          <g transform={S_T}>
            <g transform="translate(-204 50)">
              <circle className="fx-ring" r={14} fill="none" stroke="#9ff6ff" strokeWidth={3} vectorEffect="non-scaling-stroke" style={vars({ "--s": 5, "--t": "560ms" })} />
              <circle className="fx-ring" r={14} fill="none" stroke="#ffb35a" strokeWidth={2} vectorEffect="non-scaling-stroke" style={vars({ "--s": 7, "--t": "760ms", "--dl": "80ms" })} />
              <Burst seed={id} count={16} colors={["#bff9ff", "#74f5ff", "#3ab8ff", "#ffffff"]} angle={160} spread={90} dist={[50, 140]} size={[2.5, 6]} dur={[500, 900]} shape="bubble" />
              <Burst seed={id + 7} count={12} colors={["#ffe27a", "#ff9a2a", "#ff4a2a"]} angle={160} spread={70} dist={[40, 110]} size={[2, 4]} dur={[350, 600]} shape="streak" />
              <g className="fx-fly" style={vars({ "--dx": "-330px", "--dy": "130px", "--t": "620ms" })}>
                <circle r={30} fill="url(#sl-orb)" />
                <circle r={12} fill="#ffffff" opacity={0.9} />
                <circle r={20} fill="none" stroke="#bff9ff" strokeWidth={2} strokeDasharray="6 5" />
              </g>
            </g>
          </g>
        </g>
      ))}
    </svg>
  );
}
