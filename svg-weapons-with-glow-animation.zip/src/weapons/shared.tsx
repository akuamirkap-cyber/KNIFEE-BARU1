import type { CSSProperties, ReactNode } from "react";

export type WeaponProps = {
  /** ids of active shots – every id renders its own one-shot effect layer */
  shots: number[];
  /** increments on every right-click – used as a React key to restart CSS animations */
  tick: number;
};

/** deterministic pseudo random generator (mulberry32) */
export function rng(seed: number) {
  let a = seed >>> 0 || 1;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** helper to pass CSS custom properties through the style prop */
export const vars = (o: Record<string, string | number>) => o as CSSProperties;

export const SPARKLE =
  "M0 -10 Q1.6 -1.6 10 0 Q1.6 1.6 0 10 Q-1.6 1.6 -10 0 Q-1.6 -1.6 0 -10 Z";

export const pts = (a: number[][]) => a.map((p) => `${+p[0].toFixed(2)},${+p[1].toFixed(2)}`).join(" ");

/* ------------------------------------------------------------------
   Geometry + lighting helpers used to build clean, bevelled shapes
------------------------------------------------------------------- */
export type P = [number, number];

/** light direction in screen space (towards the light: top / slightly left) */
export const LIGHT: P = [-0.42, -0.91];

export const area = (poly: P[]) => {
  let a = 0;
  for (let i = 0; i < poly.length; i++) {
    const [x1, y1] = poly[i];
    const [x2, y2] = poly[(i + 1) % poly.length];
    a += x1 * y2 - x2 * y1;
  }
  return a / 2;
};

export const rot = ([x, y]: P, deg: number): P => {
  const a = (deg * Math.PI) / 180;
  return [x * Math.cos(a) - y * Math.sin(a), x * Math.sin(a) + y * Math.cos(a)];
};

function intersect(p1: P, d1: P, p2: P, d2: P): P {
  const c = d1[0] * d2[1] - d1[1] * d2[0];
  if (Math.abs(c) < 1e-9) return p2;
  const t = ((p2[0] - p1[0]) * d2[1] - (p2[1] - p1[1]) * d2[0]) / c;
  return [p1[0] + d1[0] * t, p1[1] + d1[1] * t];
}

/** inset (shrink) a convex polygon by distance d */
export function inset(poly: P[], d: number): P[] {
  const n = poly.length;
  const s = area(poly) > 0 ? 1 : -1;
  const lines = poly.map((p, i) => {
    const q = poly[(i + 1) % n];
    const dx = q[0] - p[0];
    const dy = q[1] - p[1];
    const L = Math.hypot(dx, dy) || 1;
    const nx = (s * -dy) / L;
    const ny = (s * dx) / L;
    return { p: [p[0] + nx * d, p[1] + ny * d] as P, d: [dx, dy] as P };
  });
  return poly.map((_, i) => {
    const a = lines[(i - 1 + n) % n];
    const b = lines[i];
    return intersect(a.p, a.d, b.p, b.d);
  });
}

const hex = (h: string) => {
  const v = h.replace("#", "");
  return [0, 2, 4].map((i) => parseInt(v.slice(i, i + 2), 16));
};
export function mix(a: string, b: string, t: number) {
  const A = hex(a);
  const B = hex(b);
  return (
    "#" +
    A.map((v, i) =>
      Math.round(v + (B[i] - v) * Math.min(1, Math.max(0, t)))
        .toString(16)
        .padStart(2, "0")
    ).join("")
  );
}
/** sample a multi-stop colour ramp, t in [0,1] */
export function ramp(stops: string[], t: number) {
  const x = Math.min(0.9999, Math.max(0, t)) * (stops.length - 1);
  const i = Math.floor(x);
  return mix(stops[i], stops[i + 1], x - i);
}
/** brightness (0..1) of a surface whose outward normal is n (local), rotated by deg into screen space */
export function lit(n: P, deg: number, light: P = LIGHT) {
  const L = Math.hypot(n[0], n[1]) || 1;
  const [x, y] = rot([n[0] / L, n[1] / L], deg);
  return (x * light[0] + y * light[1] + 1) / 2;
}

type BevelProps = {
  poly: P[];
  d: number;
  /** rotation of the parent frame (deg) so lighting stays in screen space */
  angle?: number;
  stops: string[];
  face: string;
  outline?: string;
  trim?: string;
  trimW?: number;
};

/** convex polygon with a lit bevel ring + flat face */
export function Bevel({ poly, d, angle = 0, stops, face, outline, trim, trimW = 1.2 }: BevelProps) {
  const inner = inset(poly, d);
  const s = area(poly) > 0 ? 1 : -1;
  const n = poly.length;
  return (
    <g>
      {poly.map((p, i) => {
        const q = poly[(i + 1) % n];
        const nrm: P = [s * (q[1] - p[1]), -s * (q[0] - p[0])];
        const fill = ramp(stops, lit(nrm, angle));
        return (
          <polygon
            key={i}
            points={pts([p, q, inner[(i + 1) % n], inner[i]])}
            fill={fill}
            stroke={fill}
            strokeWidth={0.6}
            strokeLinejoin="round"
          />
        );
      })}
      <polygon points={pts(inner)} fill={face} />
      {trim && <polygon points={pts(inner)} fill="none" stroke={trim} strokeWidth={trimW} strokeLinejoin="round" />}
      {outline && <polygon points={pts(poly)} fill="none" stroke={outline} strokeWidth={1.3} strokeLinejoin="round" />}
    </g>
  );
}

/** faceted crystal: triangles fanning from a centre point, each lit by its edge normal */
export function Facets({ poly, c, angle = 0, stops, table = 0.42, tableFill, edge = "#ffffff" }: {
  poly: P[];
  c: P;
  angle?: number;
  stops: string[];
  table?: number;
  tableFill?: string;
  edge?: string;
}) {
  const n = poly.length;
  const s = area(poly) > 0 ? 1 : -1;
  const T = poly.map(([x, y]) => [c[0] + (x - c[0]) * table, c[1] + (y - c[1]) * table] as P);
  return (
    <g>
      {poly.map((p, i) => {
        const q = poly[(i + 1) % n];
        const nrm: P = [s * (q[1] - p[1]), -s * (q[0] - p[0])];
        const fill = ramp(stops, lit(nrm, angle));
        return (
          <polygon key={i} points={pts([p, q, T[(i + 1) % n], T[i]])} fill={fill} stroke={fill} strokeWidth={0.5} strokeLinejoin="round" />
        );
      })}
      <polygon points={pts(T)} fill={tableFill ?? stops[stops.length - 2]} />
      <g stroke={edge} strokeOpacity={0.55} strokeWidth={0.7}>
        {poly.map((p, i) => (
          <line key={i} x1={p[0]} y1={p[1]} x2={T[i][0]} y2={T[i][1]} />
        ))}
      </g>
      <polygon points={pts(poly)} fill="none" stroke={edge} strokeOpacity={0.7} strokeWidth={0.9} strokeLinejoin="round" />
    </g>
  );
}

type BurstProps = {
  seed: number;
  count: number;
  colors: string[];
  /** main direction in degrees (0 = +x) */
  angle?: number;
  /** cone spread in degrees */
  spread?: number;
  dist?: [number, number];
  size?: [number, number];
  dur?: [number, number];
  shape?: "circle" | "streak" | "sparkle" | "rhombus" | "bubble";
  delay?: number;
};

/** radial particle burst – rendered once, animates via CSS (fx-p / fx-streak) */
export function Burst({
  seed,
  count,
  colors,
  angle = 0,
  spread = 360,
  dist = [30, 90],
  size = [2, 4],
  dur = [450, 800],
  shape = "circle",
  delay = 0,
}: BurstProps) {
  const r = rng(seed);
  const items: ReactNode[] = [];
  for (let i = 0; i < count; i++) {
    const deg = angle + (r() - 0.5) * spread;
    const a = (deg * Math.PI) / 180;
    const d = dist[0] + r() * (dist[1] - dist[0]);
    const s = size[0] + r() * (size[1] - size[0]);
    const t = dur[0] + r() * (dur[1] - dur[0]);
    const c = colors[Math.floor(r() * colors.length)];
    const dl = delay + r() * 70;
    const style = vars({
      "--dx": `${(Math.cos(a) * d).toFixed(1)}px`,
      "--dy": `${(Math.sin(a) * d).toFixed(1)}px`,
      "--t": `${t.toFixed(0)}ms`,
      "--dl": `${dl.toFixed(0)}ms`,
    });
    if (shape === "streak") {
      items.push(
        <g key={i} transform={`rotate(${deg.toFixed(1)})`}>
          <line
            className="fx-streak"
            x1={0}
            y1={0}
            x2={s * 4}
            y2={0}
            stroke={c}
            strokeWidth={Math.max(1, s * 0.55)}
            strokeLinecap="round"
            style={vars({ "--d": `${d.toFixed(1)}px`, "--t": `${t.toFixed(0)}ms`, "--dl": `${dl.toFixed(0)}ms` })}
          />
        </g>
      );
    } else if (shape === "sparkle") {
      items.push(
        <g key={i} className="fx-p" style={style}>
          <path d={SPARKLE} fill={c} transform={`scale(${(s / 10).toFixed(2)})`} />
        </g>
      );
    } else if (shape === "rhombus") {
      items.push(
        <g key={i} className="fx-p" style={style}>
          <polygon points={pts([[0, -s], [s * 0.62, 0], [0, s], [-s * 0.62, 0]])} fill={c} stroke="#ffffff" strokeOpacity={0.6} strokeWidth={0.5} />
        </g>
      );
    } else if (shape === "bubble") {
      items.push(
        <circle key={i} className="fx-p" r={s} fill={c} fillOpacity={0.25} stroke={c} strokeWidth={1.2} style={style} />
      );
    } else {
      items.push(<circle key={i} className="fx-p" r={s} fill={c} style={style} />);
    }
  }
  return <g>{items}</g>;
}
