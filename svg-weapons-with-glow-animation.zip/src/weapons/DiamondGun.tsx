import { Bevel, Burst, Facets, SPARKLE, inset, pts, rng, rot, vars, type P, type WeaponProps } from "./shared";

/* ------------------------------------------------------------------
   1. DIAMOND GUN – elegant white-marble crystal rifle: sculpted stock,
   pistol grip, receiver with crystal sight, tapered forend, gold
   filigree, blue diamonds and a big faceted muzzle crystal.
   Gun frame: x = stock -> muzzle, y- = top edge. Rotated -45deg.
------------------------------------------------------------------- */

const A = -45;
const T = `translate(238 270) rotate(${A}) scale(0.87)`;

type Cmd = P | ["C", number, number, number, number, number, number];
/** polygon from points + sampled cubic curves */
function shape(cmds: Cmd[], seg = 7): P[] {
  const out: P[] = [];
  let cur: P = [0, 0];
  for (const c of cmds) {
    if (c[0] === "C") {
      const [, x1, y1, x2, y2, x, y] = c as ["C", number, number, number, number, number, number];
      for (let i = 1; i <= seg; i++) {
        const t = i / seg;
        const u = 1 - t;
        out.push([
          u * u * u * cur[0] + 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t * x,
          u * u * u * cur[1] + 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t * y,
        ]);
      }
      cur = [x, y];
    } else {
      cur = c as P;
      out.push(cur);
    }
  }
  return out;
}

const STOCK = shape([[-110, -40], [-232, -40], ["C", -246, -40, -258, -34, -262, -24], [-266, 50], ["C", -265, 58, -260, 62, -252, 62], ["C", -212, 60, -170, 46, -134, 38], [-110, 36]]);
const GRIP = shape([[-112, 30], [-70, 28], ["C", -70, 58, -90, 94, -112, 120], ["C", -116, 128, -122, 133, -130, 133], ["C", -137, 133, -142, 127, -140, 118], ["C", -130, 92, -120, 64, -112, 40]]);
const RECV = shape([[-114, -38], ["C", -112, -48, -104, -55, -92, -55], [38, -55], ["C", 52, -55, 62, -48, 65, -36], [65, 28], ["C", 64, 38, 58, 44, 48, 46], [-98, 46], ["C", -108, 46, -114, 40, -114, 32]]);
const FORE = shape([[58, -40], [218, -33], ["C", 230, -33, 240, -26, 240, -16], [240, 8], ["C", 240, 17, 231, 23, 218, 23], [58, 30]]);
const PLATES = [STOCK, FORE, RECV];
const BEV = 8.5;
const EX = rot([4, 9], -A);
const MARBLE = ["#6f7a9b", "#a3adc7", "#dde3ee", "#f5f7fb", "#ffffff"];
const ICE = ["#0b2f96", "#1b52d6", "#3a8cf6", "#8fd0ff", "#dcf5ff", "#ffffff"];

const VEINS: string[][] = [
  [
    "M -250 -16 C -232 -8, -220 -26, -200 -19 C -184 -13, -172 -30, -150 -25 C -136 -22, -126 -31, -114 -28",
    "M -246 40 C -228 34, -214 46, -196 41 C -176 36, -160 44, -140 38",
    "M -252 8 C -244 14, -246 24, -238 30",
  ],
  [
    "M 82 -30 C 100 -22, 118 -33, 138 -27 C 158 -21, 176 -32, 198 -26 C 212 -22, 224 -29, 234 -23",
    "M 90 20 C 110 13, 126 22, 148 17 C 168 12, 184 21, 204 15 C 218 11, 228 16, 234 11",
  ],
  [
    "M -102 -42 C -86 -33, -74 -49, -56 -41 C -40 -34, -30 -49, -10 -44 C 8 -39, 22 -49, 40 -44 C 50 -41, 56 -45, 60 -40",
    "M -102 36 C -86 27, -72 41, -54 34 C -40 28, -28 40, -8 36 C 10 32, 22 41, 40 36 C 50 33, 56 36, 60 32",
  ],
];
const GRIP_VEINS = ["M -102 40 C -96 56, -110 70, -104 84 C -100 98, -116 106, -120 122", "M -84 38 C -90 48, -84 58, -92 68"];

/* lighter / darker crystal planes (subtle 3D) */
const PLANES: [string, string, number][] = [
  ["-260,-40 -176,-40 -212,50 -266,50", "#ffffff", 0.55],
  ["-150,-40 -110,-40 -110,44 -124,44", "#b7c0d6", 0.24],
  ["-124,-56 -36,-56 -70,50 -124,50", "#ffffff", 0.5],
  ["18,-56 82,-56 82,50 -6,50", "#b7c0d6", 0.26],
  ["78,-42 166,-40 134,30 78,30", "#ffffff", 0.45],
  ["192,-40 248,-40 248,30 172,30", "#b7c0d6", 0.26],
];

const rh = (w: number, h: number) => pts([[0, -h / 2], [w / 2, 0], [0, h / 2], [-w / 2, 0]]);
const FACET = ["#bdeeff", "#6fb9ff", "#2459d8", "#3a83f4", "#1640b4", "#4c95fa", "#d2f0ff", "#f4fcff"];

export function Gem({ w, h }: { w: number; h: number }) {
  const hw = w / 2;
  const hh = h / 2;
  const V = [[0, -hh], [hw, 0], [0, hh], [-hw, 0]];
  const ring: number[][] = [];
  for (let i = 0; i < 4; i++) {
    const a = V[i];
    const b = V[(i + 1) % 4];
    ring.push(a, [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]);
  }
  const k = 0.44;
  return (
    <g>
      {ring.map((p, i) => {
        const q = ring[(i + 1) % 8];
        return <polygon key={i} points={pts([p, q, [0, 0]])} fill={FACET[i]} stroke={FACET[i]} strokeWidth={0.4} />;
      })}
      <polygon points={pts(V.map(([x, y]) => [x * k, y * k]))} fill="url(#dg-table)" />
      <g stroke="#ffffff" strokeOpacity={0.55} strokeWidth={0.6}>
        {V.map(([x, y], i) => (
          <line key={i} x1={x * k} y1={y * k} x2={x} y2={y} />
        ))}
      </g>
      <polygon points={pts(V)} fill="none" stroke="#0a2470" strokeWidth={1} strokeLinejoin="round" />
      <path
        d={SPARKLE}
        fill="#ffffff"
        transform={`translate(${(-hw * 0.22).toFixed(1)} ${(-hh * 0.26).toFixed(1)}) scale(${(Math.min(w, h) / 60).toFixed(2)})`}
      />
    </g>
  );
}

function Setting({ w, h }: { w: number; h: number }) {
  return (
    <g>
      <polygon points={rh(w * 1.36, h * 1.3)} fill="url(#dg-gold)" stroke="#86621d" strokeWidth={1} strokeLinejoin="round" />
      <polygon points={rh(w * 1.36, h * 1.3)} fill="none" stroke="#fff3c4" strokeWidth={0.8} strokeOpacity={0.7} transform="translate(-0.6 -0.6)" />
      <polygon points={rh(w * 1.14, h * 1.11)} fill="#2a3358" />
    </g>
  );
}

/** symmetric gold filigree ornament */
function Flourish({ x, y, s = 1 }: { x: number; y: number; s?: number }) {
  const curl = "M 4 0 C 8 -7, 16 -10, 22 -5 C 26 -1, 23 5, 18 4 C 15 3, 16 -1, 19 -1";
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <g fill="none" strokeLinecap="round" strokeLinejoin="round">
        {["", "scale(-1 1)", "scale(1 -1)", "scale(-1 -1)"].map((t, i) => (
          <g key={i} transform={t || undefined}>
            <path d={curl} stroke="#8a6420" strokeWidth={2.6} opacity={0.25} transform="translate(0.5 0.8)" />
            <path d={curl} stroke="#d9b257" strokeWidth={1.7} />
          </g>
        ))}
      </g>
      <polygon points="0,-6 4,0 0,6 -4,0" fill="url(#dg-gold)" stroke="#8a6420" strokeWidth={0.6} />
      <circle cx={-0.8} cy={-1.6} r={0.9} fill="#fffbe6" />
    </g>
  );
}

/* gem placements: x, y, w, h, uprightOnScreen */
const GEMS: [number, number, number, number, boolean][] = [
  [-188, 9, 80, 46, false],
  [-22, -4, 46, 60, true],
  [150, -5, 32, 44, true],
];

const CRYSTAL: P[] = [[244, -33], [304, -48], [364, -7], [304, 34], [244, 21]];
const SIGHT: P[] = [[-32, -60], [-37, -84], [-21, -114], [-5, -84], [-10, -60]];

const TWINKLES = [
  [440, 30, 1.3, 0],
  [470, 120, 0.8, 0.7],
  [300, 60, 1, 1.3],
  [398, 250, 0.8, 0.4],
  [150, 330, 0.9, 1.8],
  [70, 440, 0.8, 1.1],
  [210, 130, 0.7, 2.1],
];

const CSS = `
.dg-bob{animation:dg-bob 3.2s ease-in-out infinite}
.dg-bob.b2{animation-duration:3.8s;animation-delay:-1.7s}
@keyframes dg-bob{0%,100%{transform:translateY(-4px)}50%{transform:translateY(5px)}}
.dg-aura{animation:dg-aura 2.6s ease-in-out infinite}
@keyframes dg-aura{0%,100%{opacity:.25}50%{opacity:.6}}
.dg-twinkle{transform-box:fill-box;transform-origin:center;animation:dg-tw 2.4s ease-in-out infinite}
@keyframes dg-tw{0%,100%{transform:scale(.2) rotate(0deg);opacity:0}50%{transform:scale(1) rotate(45deg);opacity:1}}
.dg-gemglow{animation:dg-gemglow 2.2s ease-in-out infinite}
@keyframes dg-gemglow{0%,100%{opacity:.35}50%{opacity:.95}}
.dg-shimmer{animation:dg-shimmer 4.6s ease-in-out infinite}
@keyframes dg-shimmer{0%{transform:translateX(-330px)}55%,100%{transform:translateX(380px)}}
.dg-fire .dg-flash{animation:dg-flash 560ms ease-out both}
@keyframes dg-flash{0%{opacity:0}18%{opacity:1}100%{opacity:0}}
.dg-fire .dg-sheen{animation:dg-sheen 620ms ease-out both}
@keyframes dg-sheen{0%{transform:translateX(-300px);opacity:1}100%{transform:translateX(380px);opacity:.9}}
.dg-spin{transform-box:fill-box;transform-origin:center;animation:dg-spin 760ms cubic-bezier(.2,.8,.2,1) both}
@keyframes dg-spin{0%{transform:scale(1) rotate(0)}35%{transform:scale(1.6) rotate(200deg)}100%{transform:scale(1) rotate(360deg)}}
`;

function FloatGem({ x, y, tick, cls }: { x: number; y: number; tick: number; cls: string }) {
  return (
    <g transform={`translate(${x} ${y}) rotate(${-A})`}>
      <g className={cls}>
        <g key={tick} className={tick ? "dg-spin" : undefined}>
          <polygon className="dg-gemglow" points={rh(48, 62)} fill="#6fd3ff" filter="url(#dg-blur)" />
          <Gem w={30} h={40} />
        </g>
      </g>
    </g>
  );
}

function Studs({ list }: { list: number[][] }) {
  return (
    <g>
      {list.map(([x, y], i) => (
        <g key={i}>
          <circle cx={x} cy={y} r={3.2} fill="url(#dg-gold)" stroke="#86621d" strokeWidth={0.7} />
          <circle cx={x - 0.9} cy={y - 0.9} r={1} fill="#fffbe6" />
        </g>
      ))}
    </g>
  );
}

export default function DiamondGun({ shots, tick }: WeaponProps) {
  return (
    <svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" className="weapon-svg" overflow="visible">
      <style>{CSS}</style>
      <defs>
        <linearGradient id="dg-face" x1="0" y1="-56" x2="0" y2="50" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.55" stopColor="#f3f5fa" />
          <stop offset="1" stopColor="#d5dbe8" />
        </linearGradient>
        <linearGradient id="dg-face-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.6" stopColor="#eef1f7" />
          <stop offset="1" stopColor="#cdd4e3" />
        </linearGradient>
        <linearGradient id="dg-side" x1="0" y1="20" x2="0" y2="62" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#8f99b6" />
          <stop offset="1" stopColor="#4f5878" />
        </linearGradient>
        <linearGradient id="dg-gold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#fff2bd" />
          <stop offset="0.45" stopColor="#e4bd5e" />
          <stop offset="1" stopColor="#9c7022" />
        </linearGradient>
        <linearGradient id="dg-silver" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.5" stopColor="#d3d9e6" />
          <stop offset="1" stopColor="#8a93ad" />
        </linearGradient>
        <radialGradient id="dg-table" cx="0.4" cy="0.35" r="0.75">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.45" stopColor="#d9f3ff" />
          <stop offset="1" stopColor="#5aa8ff" />
        </radialGradient>
        <radialGradient id="dg-refl" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#7fd2ff" stopOpacity="0.55" />
          <stop offset="0.6" stopColor="#9fdcff" stopOpacity="0.18" />
          <stop offset="1" stopColor="#bfe8ff" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="dg-pearl" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffd6f4" />
          <stop offset="0.3" stopColor="#bfe9ff" />
          <stop offset="0.6" stopColor="#fff2c9" />
          <stop offset="1" stopColor="#c8d4ff" />
        </linearGradient>
        <linearGradient id="dg-sheen-g" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0" />
          <stop offset="0.5" stopColor="#ffffff" stopOpacity="0.95" />
          <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="dg-shim-g" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#bfefff" stopOpacity="0" />
          <stop offset="0.5" stopColor="#e9fbff" stopOpacity="0.8" />
          <stop offset="1" stopColor="#bfefff" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="dg-trail" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#5fd0ff" stopOpacity="0" />
          <stop offset="1" stopColor="#e6fbff" stopOpacity="0.95" />
        </linearGradient>
        <radialGradient id="dg-burst" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.35" stopColor="#bdefff" stopOpacity="0.9" />
          <stop offset="1" stopColor="#3aa8ff" stopOpacity="0" />
        </radialGradient>
        <filter id="dg-blur" x="-80%" y="-80%" width="260%" height="260%">
          <feGaussianBlur stdDeviation="6" />
        </filter>
        <filter id="dg-blur-l" x="-30%" y="-60%" width="160%" height="220%">
          <feGaussianBlur stdDeviation="12" />
        </filter>
        <clipPath id="dg-clip">
          {PLATES.map((p, i) => (
            <polygon key={i} points={pts(p)} />
          ))}
          <polygon points={pts(GRIP)} />
        </clipPath>
        {PLATES.map((p, i) => (
          <clipPath key={i} id={`dg-face${i}`}>
            <polygon points={pts(inset(p, BEV))} />
          </clipPath>
        ))}
        <clipPath id="dg-facegrip">
          <polygon points={pts(inset(GRIP, BEV))} />
        </clipPath>
      </defs>

      {/* ============ ART ============ */}
      <g transform={T}>
        {/* aura */}
        <g className="dg-aura" filter="url(#dg-blur-l)">
          {PLATES.map((p, i) => (
            <polygon key={i} points={pts(p)} fill="#7fdcff" />
          ))}
          <polygon points={pts(GRIP)} fill="#7fdcff" />
        </g>

        {/* ---------- pistol grip (behind) ---------- */}
        <polygon points={pts(GRIP.map(([x, y]) => [x + EX[0], y + EX[1]]))} fill="url(#dg-side)" stroke="#434b69" strokeWidth={1.2} strokeLinejoin="round" />
        <Bevel poly={GRIP} d={BEV} angle={A} stops={MARBLE} face="url(#dg-face-g)" outline="#6c7591" trim="#d4ae58" />
        <g clipPath="url(#dg-facegrip)">
          <polygon points="-146,28 -104,28 -124,138 -150,138" fill="#ffffff" opacity={0.5} />
          <g fill="none" strokeLinecap="round">
            {GRIP_VEINS.map((d, i) => (
              <path key={i} d={d} stroke="#d9b257" strokeWidth={1.8} />
            ))}
          </g>
        </g>
        {/* grip cap gem */}
        <g transform={`translate(-121 112) rotate(${-A})`}>
          <polygon points={rh(18, 24)} fill="url(#dg-gold)" stroke="#86621d" strokeWidth={0.8} />
          <Gem w={12} h={16} />
        </g>

        {/* ---------- trigger guard + trigger ---------- */}
        <path d="M 2 42 L 2 70 Q 2 88 -16 88 L -90 88" fill="none" stroke="#6b7491" strokeWidth={10} strokeLinecap="round" strokeLinejoin="round" />
        <path d="M 2 42 L 2 70 Q 2 88 -16 88 L -90 88" fill="none" stroke="url(#dg-silver)" strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" />
        <path d="M -0.5 46 L -0.5 70 Q -0.5 85 -16 85 L -86 85" fill="none" stroke="#ffffff" strokeWidth={1.2} opacity={0.8} />

        {/* ---------- plates (stock, fore, receiver) ---------- */}
        {PLATES.map((p, i) => (
          <g key={i}>
            <polygon points={pts(p.map(([x, y]) => [x + EX[0], y + EX[1]]))} fill="url(#dg-side)" stroke="#434b69" strokeWidth={1.2} strokeLinejoin="round" />
            <Bevel poly={p} d={BEV} angle={A} stops={MARBLE} face="url(#dg-face)" outline="#6c7591" trim="#d4ae58" />
            <g clipPath={`url(#dg-face${i})`}>
              {PLANES.map(([pp, c, o], j) => (
                <polygon key={j} points={pp} fill={c} opacity={o} />
              ))}
              <g fill="none" strokeLinecap="round" strokeLinejoin="round">
                {VEINS[i].map((d, j) => (
                  <path key={`s${j}`} d={d} stroke="#8a6420" strokeWidth={3} opacity={0.22} transform="translate(0.7 1.1)" />
                ))}
                {VEINS[i].map((d, j) => (
                  <path key={j} d={d} stroke="#d9b257" strokeWidth={1.8} />
                ))}
                {VEINS[i].map((d, j) => (
                  <path key={`h${j}`} d={d} stroke="#fff4c8" strokeWidth={0.6} opacity={0.8} transform="translate(-0.4 -0.5)" />
                ))}
              </g>
            </g>
          </g>
        ))}

        {/* trigger (in front of the receiver side) */}
        <path d="M -30 52 C -28 63, -33 73, -44 80 L -49 75 C -40 68, -37 61, -39 52 Z" fill="url(#dg-silver)" stroke="#6b7491" strokeWidth={1} />

        {/* gold butt plate */}
        <polygon points="-262,-24 -266,50 -275,47 -271,-21" fill="url(#dg-gold)" stroke="#86621d" strokeWidth={1} strokeLinejoin="round" />

        {/* gem light reflected on the marble + pearl sheen */}
        <g clipPath="url(#dg-clip)">
          {GEMS.map(([x, y, w, h], i) => (
            <ellipse key={i} className="dg-gemglow" cx={x} cy={y} rx={w * 1.25} ry={h * 1.05} fill="url(#dg-refl)" />
          ))}
          <polygon points="-280,-60 370,-60 370,140 -280,140" fill="url(#dg-pearl)" opacity={0.15} />
          <g transform="skewX(-25)">
            <rect className="dg-shimmer" x={-40} y={-70} width={60} height={220} fill="url(#dg-shim-g)" />
          </g>
        </g>

        {/* filigree ornaments + studs */}
        <Flourish x={100} y={-5} s={1.15} />
        <Flourish x={206} y={-5} s={0.95} />
        <Flourish x={-128} y={2} s={0.8} />
        <Studs list={[[-238, -31], [-250, 52], [-100, -45], [42, -45], [-100, 37], [50, 36], [214, -25], [214, 15], [72, -31], [72, 22]]} />

        {/* inset gems */}
        {GEMS.map(([x, y, w, h, up], i) => (
          <g key={i} transform={`translate(${x} ${y}) rotate(${up ? -A : 0})`}>
            <Setting w={w} h={h} />
            <polygon className="dg-gemglow" points={rh(w * 1.1, h * 1.1)} fill="#4fb6ff" filter="url(#dg-blur)" opacity={0.7} />
            <Gem w={w} h={h} />
          </g>
        ))}

        {/* crystal sight cluster */}
        <ellipse className="dg-gemglow" cx={-21} cy={-86} rx={26} ry={32} fill="#6fd3ff" filter="url(#dg-blur)" />
        <Facets poly={SIGHT} c={[-21, -84]} angle={A} stops={ICE} table={0.38} tableFill="url(#dg-table)" />
        <path d={SPARKLE} fill="#ffffff" transform="translate(-25 -94) scale(0.85)" />
        <polygon points="-44,-55 -38,-63 -4,-63 2,-55" fill="url(#dg-gold)" stroke="#86621d" strokeWidth={1} strokeLinejoin="round" />
        <line x1={-39} y1={-61.5} x2={-3} y2={-61.5} stroke="#fff3c4" strokeWidth={1} opacity={0.8} />

        {/* muzzle crystal */}
        <ellipse className="dg-gemglow" cx={304} cy={-7} rx={80} ry={52} fill="#5fd0ff" filter="url(#dg-blur-l)" />
        <ellipse cx={304} cy={-7} rx={58} ry={40} fill="#9fe6ff" opacity={0.35} filter="url(#dg-blur)" />
        <polygon points="236,-36 252,-38 252,26 236,24" fill="url(#dg-gold)" stroke="#86621d" strokeWidth={1} strokeLinejoin="round" />
        <line x1={240} y1={-35} x2={240} y2={23} stroke="#fff3c4" strokeWidth={1} opacity={0.7} />
        <Facets poly={CRYSTAL} c={[300, -7]} angle={A} stops={ICE} table={0.42} tableFill="url(#dg-table)" />
        <polygon points="262,-30 300,-40 286,-16" fill="#ffffff" opacity={0.55} />
        <path d={SPARKLE} fill="#ffffff" transform="translate(286 -20) scale(1.5)" />
        <path d={SPARKLE} fill="#ffffff" transform="translate(338 -4) scale(0.7)" opacity={0.9} />

        {/* floating diamonds */}
        <FloatGem x={196} y={-82} tick={tick} cls="dg-bob" />
        <FloatGem x={124} y={76} tick={tick} cls="dg-bob b2" />

        {/* ---- right-click overlays (restart with tick) ---- */}
        <g key={`f${tick}`} className={tick ? "dg-fire" : undefined}>
          <g clipPath="url(#dg-clip)">
            <g transform="skewX(-25)">
              <rect className="dg-sheen" x={-30} y={-70} width={70} height={220} fill="url(#dg-sheen-g)" opacity={0} />
            </g>
          </g>
          {GEMS.map(([x, y, w, h, up], i) => (
            <g key={i} transform={`translate(${x} ${y}) rotate(${up ? -A : 0})`}>
              <polygon className="dg-flash" points={rh(w * 1.5, h * 1.5)} fill="#ffffff" filter="url(#dg-blur)" opacity={0} />
            </g>
          ))}
          <ellipse className="dg-flash" cx={-21} cy={-80} rx={30} ry={30} fill="url(#dg-burst)" opacity={0} />
          <ellipse className="dg-flash" cx={304} cy={-7} rx={100} ry={66} fill="url(#dg-burst)" opacity={0} />
        </g>
      </g>

      {/* twinkles */}
      {TWINKLES.map(([x, y, s, d], i) => (
        <g key={i} transform={`translate(${x} ${y}) scale(${s})`}>
          <path className="dg-twinkle" d={SPARKLE} fill="#ffffff" style={{ animationDelay: `${d}s` }} />
        </g>
      ))}

      {/* ============ SHOT FX ============ */}
      {shots.map((id) => {
        const r = rng(id);
        return (
          <g key={id} data-fx="">
            <g transform={T}>
              <g transform="translate(366 -7)">
                <circle className="fx-ring" r={12} fill="none" stroke="#c8f3ff" strokeWidth={3} vectorEffect="non-scaling-stroke" style={vars({ "--s": 7, "--t": "620ms" })} />
                <circle className="fx-ring" r={12} fill="none" stroke="#5fc8ff" strokeWidth={2} vectorEffect="non-scaling-stroke" style={vars({ "--s": 10, "--t": "820ms", "--dl": "90ms" })} />
                <Burst seed={id} count={18} colors={["#ffffff", "#c6efff", "#62c9ff", "#3a7bff"]} spread={120} dist={[50, 150]} size={[3, 7]} shape="rhombus" />
                <g className="fx-fly" style={vars({ "--dx": "300px", "--dy": "0px", "--t": "700ms" })}>
                  <rect x={-90} y={-5} width={90} height={10} rx={5} fill="url(#dg-trail)" />
                  <ellipse rx={30} ry={18} fill="#8fe0ff" filter="url(#dg-blur)" opacity={0.8} />
                  <Gem w={44} h={22} />
                </g>
              </g>
            </g>
            {Array.from({ length: 7 }).map((_, i) => {
              const x = 60 + r() * 400;
              const y = 30 + r() * 440;
              return (
                <g key={i} transform={`translate(${x.toFixed(0)} ${y.toFixed(0)}) scale(${(0.8 + r() * 1.2).toFixed(2)})`}>
                  <g className="fx-pop" style={vars({ "--t": "760ms", "--dl": `${(r() * 220).toFixed(0)}ms` })}>
                    <path d={SPARKLE} fill={i % 2 ? "#ffffff" : "#aee9ff"} />
                  </g>
                </g>
              );
            })}
          </g>
        );
      })}
    </svg>
  );
}
