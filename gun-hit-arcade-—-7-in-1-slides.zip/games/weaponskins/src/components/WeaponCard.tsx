import { useEffect, useRef } from 'react';
import { startPreview, type Weapon } from '../engine';

interface Props {
  weapon: Weapon;
  index: number;
  active: boolean;
  onSelect: () => void;
}

export default function WeaponCard({ weapon, index, active, onSelect }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!ref.current) return;
    return startPreview(ref.current, weapon);
  }, [weapon]);

  const acc = weapon.accent;
  return (
    <button
      type="button"
      onClick={(e) => {
        onSelect();
        e.currentTarget.blur();
      }}
      aria-pressed={active}
      aria-label={weapon.name}
      className="group relative w-[128px] shrink-0 rounded-2xl border p-1.5 text-left transition duration-300 md:w-[156px]"
      style={{
        borderColor: active ? acc : 'rgba(255,255,255,0.1)',
        background: active ? `linear-gradient(160deg, ${acc}22, rgba(255,255,255,0.03))` : 'rgba(255,255,255,0.03)',
        boxShadow: active ? `0 0 28px ${acc}44, inset 0 0 22px ${acc}18` : 'none',
        transform: active ? 'translateY(-3px)' : 'none',
        opacity: active ? 1 : 0.78,
      }}
    >
      <div
        className="relative h-[60px] overflow-hidden rounded-xl md:h-[80px]"
        style={{ background: `linear-gradient(180deg, ${weapon.theme.top}, ${weapon.theme.bottom})` }}
      >
        <canvas ref={ref} className="absolute inset-0 h-full w-full" />
      </div>
      <div className="mt-1.5 flex items-center justify-between gap-0.5 px-1 pb-0.5">
        <span
          className="truncate text-[10.5px] font-semibold leading-tight tracking-tight md:text-[11.5px]"
          style={{ color: active ? acc : '#e5e7eb' }}
        >
          {weapon.name}
        </span>
        <kbd className="hidden shrink-0 rounded border border-white/15 px-1 text-[9px] leading-[14px] text-white/50 md:block">
          {index + 1}
        </kbd>
      </div>
    </button>
  );
}
