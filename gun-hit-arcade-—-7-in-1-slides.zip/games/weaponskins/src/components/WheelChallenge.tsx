import { useEffect, useRef, useState } from 'react';
import { WheelGame, type WheelStats } from '../engine/wheelgame';

export default function WheelChallenge() {
  const wrap = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const game = useRef<WheelGame | null>(null);
  const [stats, setStats] = useState<WheelStats | null>(null);

  useEffect(() => {
    const el = wrap.current!;
    const g = new WheelGame(canvas.current!);
    game.current = g;
    g.onChange = () => setStats(g.stats);
    setStats(g.stats);
    const fit = () => {
      const r = el.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) g.resize(r.width, r.height);
    };
    const ro = new ResizeObserver(fit);
    ro.observe(el);
    fit();
    g.start();
    return () => {
      ro.disconnect();
      g.destroy();
      game.current = null;
    };
  }, []);

  const acc = stats?.skin.accent ?? '#ffc95c';
  const done = stats ? stats.state : 'playing';

  return (
    <div className="absolute inset-0">
      <div ref={wrap} className="absolute inset-0">
        <canvas
          ref={canvas}
          className="block touch-none select-none"
          style={{ cursor: done === 'playing' ? 'pointer' : 'default' }}
          onPointerDown={(e) => {
            if (e.target === canvas.current) return;
          }}
        />
      </div>

      {/* ===== HUD atas ===== */}
      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-3 p-3 md:p-5">
        <div
          className="rounded-2xl border border-white/10 bg-black/40 px-4 py-2.5 backdrop-blur-md"
          style={{ boxShadow: `inset 0 1px 0 ${acc}33` }}
        >
          <p className="text-[10px] uppercase tracking-[0.28em] text-white/50">
            Level {stats?.level ?? 1} · {stats?.skin.name ?? '—'}
          </p>
          <p className="mt-0.5 max-w-[19rem] text-xs leading-snug text-white/80 md:text-sm">{stats?.challenge}</p>
          <div className="mt-1.5 flex items-center gap-1.5">
            <span
              className="rounded-full px-2 py-0.5 text-[10px] font-semibold"
              style={{ background: `${acc}26`, color: acc }}
            >
              {stats?.pattern}
            </span>
            {!!stats?.apples && (
              <span className="rounded-full bg-red-500/20 px-2 py-0.5 text-[10px] font-semibold text-red-200">
                🍎 {stats.apples} bonus
              </span>
            )}
          </div>
        </div>

        <div className="flex flex-col items-end gap-1.5">
          <div className="rounded-2xl border border-white/10 bg-black/40 px-4 py-2 text-right backdrop-blur-md">
            <p className="text-[10px] uppercase tracking-[0.24em] text-white/50">Skor</p>
            <p className="text-2xl font-extrabold leading-none" style={{ color: acc }}>
              {stats?.score ?? 0}
            </p>
          </div>
          <div className="rounded-xl border border-white/10 bg-black/30 px-3 py-1 text-right backdrop-blur-md">
            <p className="text-[10px] uppercase tracking-[0.24em] text-white/45">Terbaik</p>
            <p className="text-sm font-bold leading-none text-white/85">{stats?.best ?? 0}</p>
          </div>
        </div>
      </div>

      {/* ===== HUD bawah ===== */}
      <div className="absolute inset-x-0 bottom-0 flex flex-col items-center gap-2 p-4 md:p-6">
        <div className="flex items-center gap-1.5">
          {Array.from({ length: stats?.left ?? 0 }).map((_, i) => (
            <span
              key={i}
              className="h-1.5 w-8 rounded-full"
              style={{ background: acc, opacity: 0.35 + 0.55 * (1 - i / Math.max(1, stats?.left ?? 1)) }}
            />
          ))}

        </div>
        <p className="text-[11px] text-white/55">
          {stats?.left ?? 0} pisau tersisa · klik arena atau tekan <b className="text-white/80">SPASI</b> untuk melempar
        </p>
        <button
          type="button"
          onClick={(e) => {
            game.current?.throwKnife();
            e.currentTarget.blur();
          }}
          className="rounded-full px-9 py-3.5 text-sm font-extrabold uppercase tracking-[0.22em] text-black transition active:scale-95"
          style={{
            background: `linear-gradient(135deg, #ffffff 0%, ${acc} 60%, ${stats?.skin.bg[1] ?? '#333'} 130%)`,
            boxShadow: `0 0 32px ${acc}66, 0 10px 26px rgba(0,0,0,0.5)`,
          }}
        >
          Lempar Pisau
        </button>
      </div>

      {/* ===== Overlay ===== */}
      {stats && stats.state !== 'playing' && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/55 backdrop-blur-sm">
          <div
            className="mx-4 w-full max-w-sm rounded-3xl border p-7 text-center"
            style={{ borderColor: `${acc}55`, background: 'rgba(16,12,24,0.92)', boxShadow: `0 0 60px ${acc}33` }}
          >
            <p
              className="text-[11px] uppercase tracking-[0.34em]"
              style={{ color: stats.state === 'gameover' ? '#ff8080' : acc }}
            >
              {stats.state === 'gameover' ? 'Pisau Bertabrakan' : 'Tantangan Selesai'}
            </p>
            <h2
              className="mt-1 text-4xl font-extrabold tracking-tight"
              style={{ color: stats.state === 'gameover' ? '#ff6b6b' : acc }}
            >
              {stats.state === 'gameover' ? 'GAGAL' : 'LEVEL SELESAI'}
            </h2>
            <p className="mt-2 text-sm text-white/70">
              {stats.state === 'gameover'
                ? `Skormu ${stats.score} — rekor terbaik ${stats.best}.`
                : `Roda ${stats.skin.name} takluk! Skor ${stats.score}.`}
            </p>
            <div className="mt-5 flex flex-col gap-2">
              {stats.state === 'clear' && (
                <button
                  type="button"
                  onClick={(e) => {
                    game.current?.nextLevel();
                    e.currentTarget.blur();
                  }}
                  className="rounded-full px-7 py-3 text-sm font-extrabold uppercase tracking-[0.2em] text-black transition active:scale-95"
                  style={{ background: `linear-gradient(135deg, #ffffff, ${acc})`, boxShadow: `0 0 26px ${acc}66` }}
                >
                  Level Berikutnya
                </button>
              )}
              <button
                type="button"
                onClick={(e) => {
                  game.current?.retry();
                  e.currentTarget.blur();
                }}
                className="rounded-full border border-white/15 bg-white/5 px-7 py-3 text-sm font-semibold uppercase tracking-[0.2em] text-white/85 transition hover:bg-white/10"
              >
                {stats.state === 'gameover' ? 'Coba Lagi' : 'Main Lagi'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
