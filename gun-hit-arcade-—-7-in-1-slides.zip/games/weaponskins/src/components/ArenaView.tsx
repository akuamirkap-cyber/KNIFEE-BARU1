import { useEffect, useRef } from 'react';
import { Arena, createWeapons } from '../engine';

interface Props {
  index: number;
  auto: boolean;
  onReady: (a: Arena | null) => void;
}

/** Kanvas arena utama (senjata + target + efek) */
export default function ArenaView({ index, auto, onReady }: Props) {
  const wrap = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const arena = useRef<Arena | null>(null);
  const initial = useRef({ index, auto });

  useEffect(() => {
    const el = wrap.current!;
    const a = new Arena(canvas.current!, createWeapons(), initial.current.index);
    a.auto = initial.current.auto;
    arena.current = a;
    onReady(a);
    const fit = () => {
      const r = el.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) a.resize(r.width, r.height);
    };
    const ro = new ResizeObserver(fit);
    ro.observe(el);
    fit();
    a.start();
    return () => {
      ro.disconnect();
      a.destroy();
      arena.current = null;
      onReady(null);
    };
  }, [onReady]);

  useEffect(() => {
    arena.current?.setWeapon(index);
  }, [index]);

  useEffect(() => {
    if (arena.current) arena.current.auto = auto;
  }, [auto]);

  return (
    <div ref={wrap} className="absolute inset-0">
      <canvas ref={canvas} className="block touch-none select-none" style={{ cursor: 'crosshair' }} />
    </div>
  );
}
