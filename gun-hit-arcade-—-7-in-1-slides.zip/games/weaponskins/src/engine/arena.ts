import { glow } from './gfx';
import { Particles } from './particles';
import { Target } from './target';
import type { Entity, World } from './types';
import { clamp, easeInCubic, easeOutBack, hexRgb, mixRgb, rgbStr, TAU, type Vec } from './util';
import type { Weapon } from './weapon';

interface Dust {
  x: number;
  y: number;
  vx: number;
  vy: number;
  z: number;
  ph: number;
}

type RGB = [number, number, number];

export class Arena implements World {
  readonly canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  dpr = 1;
  width = 0;
  height = 0;
  scale = 1;
  time = 0;
  muzzle: Vec = { x: 0, y: 0 };
  aim = 0;
  target = new Target();
  fx = new Particles();
  weapons: Weapon[];
  index = 0;
  auto = false;
  onSwap?: (i: number) => void;

  private entities: Entity[] = [];
  private incoming: Entity[] = [];
  private dust: Dust[] = [];
  private shakeAmt = 0;
  private pose = { x: 0, y: 0, rot: 0, s: 1 };
  private pending: number | null = null;
  private swap = 1; // 1 = tampil penuh
  private autoT = 0;
  private raf = 0;
  private last = 0;
  private running = false;
  private bg: { top: RGB; bottom: RGB; glow: RGB };
  private dragging = false;
  private dragMoved = false;
  private dragStart: Vec = { x: 0, y: 0 };
  private portrait = false;
  private ready = false;

  constructor(canvas: HTMLCanvasElement, weapons: Weapon[], index = 0) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.weapons = weapons;
    this.index = index;
    const th = weapons[index].theme;
    this.bg = { top: hexRgb(th.top), bottom: hexRgb(th.bottom), glow: hexRgb(th.glow) };
    for (let i = 0; i < 80; i++) {
      this.dust.push({
        x: Math.random(),
        y: Math.random(),
        vx: (Math.random() - 0.5) * 6,
        vy: -2 - Math.random() * 8,
        z: 0.3 + Math.random() * 0.7,
        ph: Math.random() * TAU,
      });
    }
    canvas.addEventListener('pointerdown', this.onDown);
    canvas.addEventListener('pointermove', this.onMove);
    canvas.addEventListener('pointerup', this.onUp);
    canvas.addEventListener('pointercancel', this.onUp);
  }

  get weapon() {
    return this.weapons[this.index];
  }

  /* ------------------------------ World API ------------------------------ */

  add(e: Entity) {
    this.incoming.push(e);
  }
  shake(a: number) {
    this.shakeAmt = Math.min(10, this.shakeAmt + a);
  }
  toWorld(lx: number, ly: number): Vec {
    const c = this.weapon.center;
    const sh = this.weapon.recoilShift();
    const s = this.pose.s;
    const x = (lx + sh - c.x) * s;
    const y = (ly - c.y) * s;
    const cr = Math.cos(this.pose.rot);
    const sr = Math.sin(this.pose.rot);
    return { x: this.pose.x + x * cr - y * sr, y: this.pose.y + x * sr + y * cr };
  }
  attract(x: number, y: number, radius: number, strength: number, dt: number) {
    for (const d of this.dust) {
      const px = d.x * this.width;
      const py = d.y * this.height;
      const dx = x - px;
      const dy = y - py;
      const dist = Math.hypot(dx, dy);
      if (dist < radius && dist > 2) {
        const f = (1 - dist / radius) * strength * dt;
        d.vx += (dx / dist) * f;
        d.vy += (dy / dist) * f;
      }
    }
  }

  /* ------------------------------ kontrol ------------------------------ */

  setWeapon(i: number) {
    if (i === this.index && this.pending === null) return;
    if (i === this.pending) return;
    this.pending = i;
  }

  fire(): boolean {
    if (this.swap < 0.9 || this.pending !== null) return false;
    return this.weapon.trigger(this);
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.last = performance.now();
    const loop = (now: number) => {
      if (!this.running) return;
      const dt = Math.min(0.05, (now - this.last) / 1000);
      this.last = now;
      if (this.width > 0) {
        this.update(dt);
        this.draw();
      }
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  destroy() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    this.canvas.removeEventListener('pointerdown', this.onDown);
    this.canvas.removeEventListener('pointermove', this.onMove);
    this.canvas.removeEventListener('pointerup', this.onUp);
    this.canvas.removeEventListener('pointercancel', this.onUp);
  }

  resize(w: number, h: number) {
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    this.width = w;
    this.height = h;
    this.canvas.width = Math.round(w * this.dpr);
    this.canvas.height = Math.round(h * this.dpr);
    this.canvas.style.width = `${w}px`;
    this.canvas.style.height = `${h}px`;
    this.portrait = h > w * 1.05;
    this.target.r = clamp(Math.min(w, h) * 0.085, 32, 56);
    this.layout();
    if (!this.ready) {
      if (this.portrait) this.target.setHome(w * 0.62, h * 0.28, true);
      else this.target.setHome(w * 0.74, h * 0.46, true);
      this.ready = true;
    } else {
      this.target.setHome((this.target.home.x / this.lastW) * w, (this.target.home.y / this.lastH) * h, true);
    }
    this.clampHome();
    this.lastW = w;
    this.lastH = h;
  }
  private lastW = 1;
  private lastH = 1;

  /* ------------------------------ layout ------------------------------ */

  private layout() {
    const W = this.width;
    const H = this.height;
    const nomW = 450;
    const nomH = 200;
    let s: number;
    let cx: number;
    let cy: number;
    if (this.portrait) {
      s = clamp((W * 0.88) / nomW, 0.4, 1.2);
      cx = W / 2;
      cy = H * 0.69;
    } else {
      s = clamp(Math.min((W * 0.46) / nomW, (H * 0.52) / nomH), 0.45, 1.5);
      cx = W * 0.03 + (nomW / 2) * s + 10;
      cy = H * 0.57;
    }
    this.scale = s;
    this.pose.s = s;
    this.pose.x = cx;
    this.pose.y = cy;
  }

  private clampHome() {
    const r = this.target.r;
    const W = this.width;
    const H = this.height;
    let minX: number;
    let maxX = W - r * 1.5;
    let minY = r * 1.5 + 28;
    let maxY = H - r * 1.5 - 10;
    if (this.portrait) {
      minX = r * 1.5;
      maxY = Math.min(maxY, this.pose.y - 130 * this.pose.s - r * 1.3);
    } else {
      minX = this.pose.x + 235 * this.pose.s + r * 1.2 + 20;
    }
    if (maxX < minX) maxX = minX;
    if (maxY < minY) maxY = minY;
    this.target.home.x = clamp(this.target.home.x, minX, maxX);
    this.target.home.y = clamp(this.target.home.y, minY, maxY);
  }

  /* ------------------------------ input ------------------------------ */

  private local(e: PointerEvent): Vec {
    const r = this.canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }
  private onDown = (e: PointerEvent) => {
    const p = this.local(e);
    this.canvas.setPointerCapture(e.pointerId);
    const d = Math.hypot(p.x - this.target.x, p.y - this.target.y);
    if (d < this.target.r * 1.45) {
      this.dragging = true;
      this.dragMoved = false;
      this.dragStart = p;
      this.canvas.style.cursor = 'grabbing';
    } else {
      this.target.setHome(p.x, p.y);
      this.clampHome();
      this.fire();
    }
  };
  private onMove = (e: PointerEvent) => {
    const p = this.local(e);
    if (this.dragging) {
      if (Math.hypot(p.x - this.dragStart.x, p.y - this.dragStart.y) > 6) this.dragMoved = true;
      if (this.dragMoved) {
        this.target.setHome(p.x, p.y);
        this.clampHome();
      }
    } else {
      const d = Math.hypot(p.x - this.target.x, p.y - this.target.y);
      this.canvas.style.cursor = d < this.target.r * 1.45 ? 'grab' : 'crosshair';
    }
  };
  private onUp = () => {
    if (this.dragging && !this.dragMoved) this.fire();
    this.dragging = false;
    this.canvas.style.cursor = 'crosshair';
  };

  /* ------------------------------ update ------------------------------ */

  private update(dt: number) {
    this.time += dt;
    this.layout();
    this.clampHome();

    // pergantian senjata
    if (this.pending !== null) {
      this.swap = Math.max(0, this.swap - dt / 0.16);
      if (this.swap <= 0) {
        this.index = this.pending;
        this.pending = null;
        this.onSwap?.(this.index);
        this.target.accent = this.weapon.accent;
        this.weapon.since = 99;
        this.weapon.cd = 0;
      }
    } else if (this.swap < 1) {
      this.swap = Math.min(1, this.swap + dt / 0.34);
    }

    const wp = this.weapon;
    this.target.accent = wp.accent;

    // tema latar
    const th = wp.theme;
    const k = 1 - Math.exp(-dt * 4);
    this.bg.top = mixRgb(this.bg.top, hexRgb(th.top), k);
    this.bg.bottom = mixRgb(this.bg.bottom, hexRgb(th.bottom), k);
    this.bg.glow = mixRgb(this.bg.glow, hexRgb(th.glow), k);

    // bidik target
    const dx = this.target.x - this.pose.x;
    const dy = this.target.y - this.pose.y;
    const lim = this.portrait ? 1.05 : 0.55;
    const desired = clamp(Math.atan2(dy, dx), -lim, lim);
    this.aim += (desired - this.aim) * (1 - Math.exp(-dt * 9));
    this.pose.rot = this.aim + wp.recoilTilt();

    wp.update(dt, this);
    const m = this.toWorld(wp.muzzle.x, wp.muzzle.y);
    this.muzzle.x = m.x;
    this.muzzle.y = m.y;

    this.target.update(dt);

    if (this.auto) {
      this.autoT -= dt;
      if (this.autoT <= 0 && wp.canFire() && this.swap >= 0.95) {
        this.fire();
        this.autoT = 0.12;
      }
    }

    // entitas
    for (let i = 0; i < this.entities.length; i++) this.entities[i].update(dt, this);
    this.fx.update(dt);
    if (this.incoming.length) {
      this.entities.push(...this.incoming);
      this.incoming.length = 0;
    }
    this.entities = this.entities.filter((e) => !e.dead);

    // debu
    for (const d of this.dust) {
      d.ph += dt;
      d.x += ((d.vx + Math.sin(d.ph * 0.7) * 4) * d.z * dt) / this.width;
      d.y += (d.vy * d.z * dt) / this.height;
      d.vx *= Math.exp(-dt * 0.4);
      d.vy += (-4 - d.vy) * (1 - Math.exp(-dt * 0.5)) * 0.2;
      if (d.x < -0.02) d.x = 1.02;
      if (d.x > 1.02) d.x = -0.02;
      if (d.y < -0.02) d.y = 1.02;
      if (d.y > 1.02) d.y = -0.02;
    }

    this.shakeAmt *= Math.exp(-dt * 9);
  }

  /* ------------------------------ draw ------------------------------ */

  private drawBackground() {
    const ctx = this.ctx;
    const W = this.width;
    const H = this.height;
    const { top, bottom, glow: gc } = this.bg;
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, rgbStr(top));
    g.addColorStop(1, rgbStr(bottom));
    ctx.fillStyle = g;
    ctx.fillRect(-20, -20, W + 40, H + 40);

    const gcs = rgbStr(gc);
    // cahaya di belakang senjata & target
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const rg = ctx.createRadialGradient(this.pose.x, this.pose.y, 0, this.pose.x, this.pose.y, Math.max(W, H) * 0.55);
    rg.addColorStop(0, rgbStr(gc, 0.2));
    rg.addColorStop(1, rgbStr(gc, 0));
    ctx.fillStyle = rg;
    ctx.fillRect(0, 0, W, H);
    ctx.restore();
    glow(ctx, this.target.home.x, this.target.home.y, this.target.r * 4.5, gcs, 0.09);

    // lantai perspektif
    const hy = this.portrait ? H * 0.8 : H * 0.76;
    ctx.save();
    ctx.lineWidth = 1;
    ctx.strokeStyle = rgbStr(gc, 0.1);
    for (let i = 1; i <= 9; i++) {
      const y = hy + Math.pow(i / 9, 1.8) * (H - hy);
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(W, y);
      ctx.stroke();
    }
    for (let i = -12; i <= 12; i++) {
      ctx.beginPath();
      ctx.moveTo(W / 2 + i * W * 0.02, hy);
      ctx.lineTo(W / 2 + i * W * 0.16, H);
      ctx.stroke();
    }
    const hg = ctx.createLinearGradient(0, 0, W, 0);
    hg.addColorStop(0, rgbStr(gc, 0));
    hg.addColorStop(0.5, rgbStr(gc, 0.45));
    hg.addColorStop(1, rgbStr(gc, 0));
    ctx.strokeStyle = hg;
    ctx.beginPath();
    ctx.moveTo(0, hy);
    ctx.lineTo(W, hy);
    ctx.stroke();
    const fade = ctx.createLinearGradient(0, hy, 0, H);
    fade.addColorStop(0, rgbStr(gc, 0.07));
    fade.addColorStop(1, rgbStr(gc, 0));
    ctx.fillStyle = fade;
    ctx.fillRect(0, hy, W, H - hy);
    ctx.restore();

    // debu / bintang
    for (const d of this.dust) {
      const a = (0.25 + 0.35 * (0.5 + 0.5 * Math.sin(d.ph * 1.7))) * d.z;
      glow(ctx, d.x * W, d.y * H, 3 + d.z * 5, gcs, a * 0.6);
      ctx.fillStyle = `rgba(255,255,255,${a * 0.5})`;
      ctx.fillRect(d.x * W, d.y * H, d.z * 1.4, d.z * 1.4);
    }
  }

  private draw() {
    const ctx = this.ctx;
    const dpr = this.dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
    ctx.clearRect(0, 0, this.width, this.height);

    ctx.save();
    const sk = this.shakeAmt;
    if (sk > 0.05) ctx.translate((Math.random() - 0.5) * sk, (Math.random() - 0.5) * sk);

    this.drawBackground();

    // bayangan lantai di bawah senjata
    const wp = this.weapon;
    const sw = this.swap;
    const sScale = this.pending !== null ? 1 - easeInCubic(1 - sw) : easeOutBack(sw);
    {
      const ps = this.pose;
      ctx.save();
      ctx.translate(ps.x, ps.y + 118 * ps.s);
      ctx.scale(1, 0.1);
      glow(ctx, 0, 0, 240 * ps.s, '#000000', 0.5 * sw);
      ctx.restore();
    }

    this.target.draw(ctx);

    for (const e of this.entities) if (e.layer === 0) e.draw(ctx, this);

    // senjata
    {
      const ps = this.pose;
      const c = wp.center;
      const bob = Math.sin(this.time * 1.4) * 4 * ps.s;
      const s = ps.s * Math.max(0.001, sScale);
      ctx.save();
      ctx.translate(ps.x, ps.y + bob);
      ctx.rotate(ps.rot + (1 - sw) * -0.15);
      ctx.scale(s, s);
      ctx.translate(-c.x + wp.recoilShift(), -c.y);
      wp.drawBody(ctx, this);
      ctx.restore();
    }

    for (const e of this.entities) if (e.layer === 1) e.draw(ctx, this);
    this.fx.draw(ctx);

    ctx.restore();

    // vinyet
    const vg = ctx.createRadialGradient(
      this.width / 2,
      this.height / 2,
      Math.min(this.width, this.height) * 0.45,
      this.width / 2,
      this.height / 2,
      Math.max(this.width, this.height) * 0.8,
    );
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, 'rgba(0,0,0,0.55)');
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, this.width, this.height);
  }
}
