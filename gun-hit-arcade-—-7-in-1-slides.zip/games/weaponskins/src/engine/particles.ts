import { glow, star4 } from './gfx';
import type { Ctx, Entity, World } from './types';
import { TAU, clamp, easeOutCubic } from './util';

export type Kind = 'dot' | 'glow' | 'streak' | 'star' | 'shard' | 'smoke' | 'rect';

export interface P {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  size1?: number;
  color: string;
  kind: Kind;
  rot: number;
  vr: number;
  drag: number;
  g: number;
  add: boolean;
  fade: number;
  len: number;
  delay: number;
  step?: (p: P, dt: number) => void;
  tag?: Record<string, number>;
}

export type PInit = Partial<P> & { x: number; y: number; color: string; life: number };

export class Particles implements Entity {
  dead = false;
  layer: 0 | 1 = 1;
  list: P[] = [];

  emit(i: PInit) {
    if (this.list.length > 1400) return;
    this.list.push({
      vx: 0,
      vy: 0,
      size: 3,
      kind: 'glow',
      rot: 0,
      vr: 0,
      drag: 0,
      g: 0,
      add: true,
      fade: 1,
      len: 0.04,
      delay: 0,
      max: i.life,
      ...i,
    });
  }

  update(dt: number) {
    const l = this.list;
    for (let n = l.length - 1; n >= 0; n--) {
      const p = l[n];
      if (p.delay > 0) {
        p.delay -= dt;
        continue;
      }
      p.life -= dt;
      if (p.life <= 0) {
        l[n] = l[l.length - 1];
        l.pop();
        continue;
      }
      p.step?.(p, dt);
      if (p.drag) {
        const k = Math.exp(-p.drag * dt);
        p.vx *= k;
        p.vy *= k;
      }
      p.vy += p.g * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
    }
  }

  draw(ctx: Ctx) {
    ctx.save();
    for (const p of this.list) {
      if (p.delay > 0) continue;
      const k = clamp(p.life / p.max, 0, 1);
      const a = Math.pow(k, p.fade);
      const s1 = p.size1 ?? p.size;
      const size = s1 + (p.size - s1) * k;
      ctx.globalCompositeOperation = p.add ? 'lighter' : 'source-over';
      switch (p.kind) {
        case 'glow':
          glow(ctx, p.x, p.y, size, p.color, a);
          break;
        case 'dot':
          ctx.globalAlpha = a;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, Math.max(0.2, size), 0, TAU);
          ctx.fill();
          break;
        case 'streak':
          ctx.globalAlpha = a;
          ctx.strokeStyle = p.color;
          ctx.lineWidth = Math.max(0.4, size);
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(p.x - p.vx * p.len, p.y - p.vy * p.len);
          ctx.lineTo(p.x, p.y);
          ctx.stroke();
          break;
        case 'star':
          star4(ctx, p.x, p.y, size, p.rot, p.color, a);
          break;
        case 'rect': {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.globalAlpha = a * 0.95;
          ctx.fillStyle = p.color;
          ctx.fillRect(-size, -size * 0.55, size * 2, size * 1.1);
          ctx.globalAlpha = a * 0.5;
          ctx.fillStyle = 'rgba(255,255,255,0.8)';
          ctx.fillRect(-size, -size * 0.55, size * 2, size * 0.3);
          ctx.restore();
          break;
        }
        case 'smoke': {
          const rr2 = Math.max(1, size);
          const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, rr2);
          const m = p.color.match(/rgba?\(([^)]+)\)/);
          const [cr, cg, cb] = m ? m[1].split(',').map(Number) : [40, 24, 16];
          g.addColorStop(0, `rgba(${cr},${cg},${cb},${0.75 * a})`);
          g.addColorStop(0.55, `rgba(${cr},${cg},${cb},${0.32 * a})`);
          g.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
          ctx.globalCompositeOperation = 'source-over';
          ctx.globalAlpha = 1;
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.arc(p.x, p.y, rr2, 0, TAU);
          ctx.fill();
          break;
        }
        case 'shard': {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.globalAlpha = a * 0.9;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.moveTo(size, 0);
          ctx.lineTo(0, size * 0.42);
          ctx.lineTo(-size * 0.75, 0);
          ctx.lineTo(0, -size * 0.42);
          ctx.closePath();
          ctx.fill();
          ctx.globalAlpha = a;
          ctx.strokeStyle = 'rgba(255,255,255,0.85)';
          ctx.lineWidth = 0.9;
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(size, 0);
          ctx.lineTo(-size * 0.2, 0);
          ctx.strokeStyle = 'rgba(255,255,255,0.5)';
          ctx.stroke();
          ctx.restore();
          break;
        }
      }
    }
    ctx.restore();
  }
}

/** Efek berdurasi sekali pakai dengan fungsi gambar bebas */
export class Timed implements Entity {
  dead = false;
  age = 0;
  constructor(
    public dur: number,
    private drawFn: (ctx: Ctx, t: number, age: number, w: World) => void,
    private updFn?: (dt: number, age: number, w: World) => void,
    public layer: 0 | 1 = 1,
  ) {}
  update(dt: number, w: World) {
    this.age += dt;
    this.updFn?.(dt, this.age, w);
    if (this.age >= this.dur) this.dead = true;
  }
  draw(ctx: Ctx, w: World) {
    ctx.save();
    this.drawFn(ctx, clamp(this.age / this.dur, 0, 1), this.age, w);
    ctx.restore();
  }
}

/** Lingkaran gelombang yang melebar */
export function addRing(
  w: World,
  x: number,
  y: number,
  r0: number,
  r1: number,
  dur: number,
  color: string,
  lw0 = 2,
  lw1 = 0.3,
  alpha = 1,
  ease: (t: number) => number = easeOutCubic,
  additive = true,
  delay = 0,
) {
  w.add(
    new Timed(dur + delay, (ctx, _t, age) => {
      const t = clamp((age - delay) / dur, 0, 1);
      if (age < delay) return;
      const e = ease(t);
      ctx.globalCompositeOperation = additive ? 'lighter' : 'source-over';
      ctx.globalAlpha = alpha * (1 - t) ** 1.2;
      ctx.strokeStyle = color;
      ctx.lineWidth = Math.max(0.2, lw0 + (lw1 - lw0) * e);
      ctx.beginPath();
      ctx.arc(x, y, r0 + (r1 - r0) * e, 0, TAU);
      ctx.stroke();
    }),
  );
}

/** Kilatan cahaya radial singkat */
export function addFlash(w: World, x: number, y: number, r0: number, r1: number, dur: number, color: string, alpha = 1) {
  w.add(
    new Timed(dur, (ctx, t) => {
      const e = easeOutCubic(t);
      glow(ctx, x, y, r0 + (r1 - r0) * e, color, alpha * (1 - t) ** 1.5);
    }),
  );
}
