import { glow } from './gfx';
import type { Ctx, TargetLike } from './types';
import { TAU, clamp, easeOutBack, rgba } from './util';

/** Lingkaran target neon yang bisa ditarik, terguncang, dan menyala saat terkena */
export class Target implements TargetLike {
  home = { x: 0, y: 0 };
  pos = { x: 0, y: 0 };
  off = { x: 0, y: 0 };
  vel = { x: 0, y: 0 };
  r = 48;
  rot = 0;
  rotVel = 0.35;
  flash = 0;
  flashColor = '#ffffff';
  spawn = 0;
  t = 0;
  accent = '#ffffff';
  private pullX = 0;
  private pullY = 0;

  get x() {
    return this.pos.x + this.off.x;
  }
  get y() {
    return this.pos.y + this.off.y + Math.sin(this.t * 1.3) * 3;
  }

  setHome(x: number, y: number, snap = false) {
    this.home.x = x;
    this.home.y = y;
    if (snap) {
      this.pos.x = x;
      this.pos.y = y;
    }
  }

  pull(x: number, y: number, amount: number) {
    const dx = x - this.pos.x;
    const dy = y - this.pos.y;
    const d = Math.hypot(dx, dy);
    if (d < 1) return;
    this.pullX += (dx / d) * amount;
    this.pullY += (dy / d) * amount;
  }
  impulse(dx: number, dy: number) {
    this.vel.x += dx;
    this.vel.y += dy;
  }
  hit(color: string) {
    this.flash = 1;
    this.flashColor = color;
  }
  spin(v: number) {
    this.rotVel += v;
  }

  update(dt: number) {
    this.t += dt;
    const k = 1 - Math.exp(-dt * 9);
    this.pos.x += (this.home.x - this.pos.x) * k;
    this.pos.y += (this.home.y - this.pos.y) * k;
    const ax = 120 * (this.pullX - this.off.x) - 9.5 * this.vel.x;
    const ay = 120 * (this.pullY - this.off.y) - 9.5 * this.vel.y;
    this.vel.x += ax * dt;
    this.vel.y += ay * dt;
    this.off.x += this.vel.x * dt;
    this.off.y += this.vel.y * dt;
    this.pullX = 0;
    this.pullY = 0;
    this.flash = Math.max(0, this.flash - dt * 2.8);
    this.rotVel += (0.35 - this.rotVel) * (1 - Math.exp(-dt * 1.6));
    this.rot += this.rotVel * dt;
    this.spawn = Math.min(1, this.spawn + dt * 1.6);
  }

  draw(ctx: Ctx) {
    const r = this.r;
    const x = this.x;
    const y = this.y;
    const acc = this.accent;
    ctx.save();
    ctx.translate(x, y);
    const d = Math.hypot(this.off.x, this.off.y);
    if (d > 1) {
      const a = Math.atan2(this.off.y, this.off.x);
      ctx.rotate(a);
      ctx.scale(1 + clamp(d / 110, 0, 0.3), 1 - clamp(d / 240, 0, 0.12));
      ctx.rotate(-a);
    }
    const sp = easeOutBack(this.spawn);
    ctx.scale(sp, sp);

    glow(ctx, 0, 0, r * 2, acc, 0.16);
    // piringan tipis
    const g = ctx.createRadialGradient(0, 0, 0, 0, 0, r);
    g.addColorStop(0, rgba('#ffffff', 0.07));
    g.addColorStop(0.7, rgba('#ffffff', 0.025));
    g.addColorStop(1, rgba('#ffffff', 0.08));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, TAU);
    ctx.fill();

    ctx.lineCap = 'round';
    ctx.strokeStyle = acc;
    ctx.globalAlpha = 0.75;
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, TAU);
    ctx.stroke();
    ctx.globalAlpha = 0.45;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.66, 0, TAU);
    ctx.stroke();
    ctx.globalAlpha = 0.35;
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.33, 0, TAU);
    ctx.stroke();

    // tanda putar
    ctx.save();
    ctx.rotate(this.rot);
    ctx.globalAlpha = 0.55;
    ctx.lineWidth = 1.4;
    for (let i = 0; i < 24; i++) {
      const a = (i / 24) * TAU;
      const l = i % 6 === 0 ? 0.2 : 0.09;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * r * 1.07, Math.sin(a) * r * 1.07);
      ctx.lineTo(Math.cos(a) * r * (1.07 + l), Math.sin(a) * r * (1.07 + l));
      ctx.stroke();
    }
    ctx.restore();
    ctx.save();
    ctx.rotate(-this.rot * 0.7);
    ctx.globalAlpha = 0.5;
    ctx.lineWidth = 2;
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.arc(0, 0, r * 1.42, i * (TAU / 4) + 0.2, i * (TAU / 4) + 0.2 + 0.7);
      ctx.stroke();
    }
    ctx.restore();

    // titik tengah + garis bidik
    ctx.globalAlpha = 0.9;
    ctx.fillStyle = acc;
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.07, 0, TAU);
    ctx.fill();
    glow(ctx, 0, 0, r * 0.35, acc, 0.5);
    ctx.globalAlpha = 0.4;
    ctx.lineWidth = 1;
    for (let i = 0; i < 4; i++) {
      const a = (i * TAU) / 4;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * r * 0.14, Math.sin(a) * r * 0.14);
      ctx.lineTo(Math.cos(a) * r * 0.26, Math.sin(a) * r * 0.26);
      ctx.stroke();
    }

    if (this.flash > 0.01) {
      const f = this.flash;
      glow(ctx, 0, 0, r * (2.3 + (1 - f) * 0.6), this.flashColor, f * 0.7);
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = f;
      ctx.strokeStyle = this.flashColor;
      ctx.lineWidth = 3 * f + 1;
      ctx.beginPath();
      ctx.arc(0, 0, r * (1 + (1 - f) * 0.22), 0, TAU);
      ctx.stroke();
    }
    ctx.restore();
  }
}
