import { glow, lens, star4 } from '../gfx';
import { addFlash, addRing, Timed } from '../particles';
import type { Ctx, Entity, World } from '../types';
import { clamp, easeOutCubic, pick, rr, TAU } from '../util';
import { Flight, Weapon, type Bounds, type Features, type Theme } from '../weapon';

const MX = 250;
const FIRE = ['#fff3c0', '#ffd23a', '#ff8a1e', '#ff4d16', '#a8140a'];

/* ----------------------------- detail kecil ----------------------------- */

function rivet(ctx: Ctx, x: number, y: number, r = 3.2) {
  const g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r);
  g.addColorStop(0, '#8c96a2');
  g.addColorStop(0.6, '#3b434c');
  g.addColorStop(1, '#14181d');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, TAU);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.16)';
  ctx.lineWidth = 0.8;
  ctx.stroke();
}

function hazard(ctx: Ctx, x: number, y: number, w: number, h: number) {
  ctx.save();
  ctx.beginPath();
  ctx.rect(x, y, w, h);
  ctx.clip();
  ctx.fillStyle = '#d9a92c';
  ctx.fillRect(x, y, w, h);
  ctx.fillStyle = '#181b21';
  for (let i = -3; i < 14; i++) {
    ctx.save();
    ctx.translate(x + i * 15, y);
    ctx.transform(1, 0, -0.5, 1, 0, 0);
    ctx.fillRect(0, 0, 8, h);
    ctx.restore();
  }
  const sh = ctx.createLinearGradient(0, y, 0, y + h);
  sh.addColorStop(0, 'rgba(255,255,255,0.28)');
  sh.addColorStop(0.5, 'rgba(255,255,255,0)');
  sh.addColorStop(1, 'rgba(0,0,0,0.35)');
  ctx.fillStyle = sh;
  ctx.fillRect(x, y, w, h);
  ctx.restore();
}

/** Pelat baja dengan gradasi, garis panel, dan bayangan sisi */
function plate(ctx: Ctx, path: () => void, l0: string, l1: string, x0: number, y0: number, x1: number, y1: number) {
  path();
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  g.addColorStop(0, l0);
  g.addColorStop(1, l1);
  ctx.fillStyle = g;
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.14)';
  ctx.lineWidth = 1.1;
  ctx.stroke();
}

/* ------------------------------- SENJATA ------------------------------- */

export class ObliteratorGun extends Weapon {
  readonly id = 'obliterator';
  readonly name = 'Obliterator Gun';
  readonly tagline = 'Meriam plasma berat — baja neraka, inti tak terkendali';
  readonly accent = '#ff7a2a';
  readonly theme: Theme = { top: '#0d0507', bottom: '#2c1006', glow: '#ff5a1e' };
  readonly features: Features = {
    body: 'Baja gunmetal berat, sel energi plasma yang berputar, tiga koil akselerator dan ventilasi panas menyala.',
    bullet: 'Bol plasma lebur yang dikurung cincin giroskop, dengan kerucut kejut dan jejak bara.',
    impact: 'Bola api berlapis, gelombang kejut, petir plasma, dan puing logam cair beterbangan.',
    idle: 'Inti berdenyut, koil berputar, asap panas mengepul, dan percik api menetes dari ventilasi.',
  };
  readonly bounds: Bounds = { x0: -200, x1: 266, y0: -100, y1: 138 };
  kick = 27;
  cooldown = 0.52;
  heat = 0;
  spin = 1.2;
  private embers: { x: number; y: number; vx: number; vy: number; life: number; max: number; s: number }[] = [];
  private acc = 0;

  constructor() {
    super();
    this.muzzle = { x: MX, y: 0 };
  }

  update(dt: number, w: World) {
    super.update(dt, w);
    this.heat = Math.max(0, this.heat - dt * 0.42);
    const target = 1.1 + 13 * this.flare(2.2);
    this.spin += (target - this.spin) * (1 - Math.exp(-dt * 6));

    this.acc += dt * (4 + 22 * this.heat);
    while (this.acc > 1) {
      this.acc -= 1;
      const vx = rr(150, 240);
      this.embers.push({
        x: rr(70, 210),
        y: rr(-54, -38),
        vx,
        vy: -rr(30, 110),
        life: 0,
        max: rr(0.5, 1.2),
        s: rr(1.2, 3),
      });
    }
    for (let i = this.embers.length - 1; i >= 0; i--) {
      const e = this.embers[i];
      e.life += dt;
      if (e.life > e.max) {
        this.embers.splice(i, 1);
        continue;
      }
      e.vy += 210 * dt;
      e.x += e.vx * dt;
      e.y += e.vy * dt;
      e.vx *= Math.exp(-dt * 1.4);
    }
  }

  protected fire(w: World) {
    w.add(new OblitBolt(w));
    this.heat = 1;
    w.shake(5);
    for (let i = 0; i < 30; i++) {
      const a = w.aim + rr(-0.55, 0.55);
      const sp = rr(180, 620);
      w.fx.emit({
        x: w.muzzle.x,
        y: w.muzzle.y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.25, 0.6),
        size: rr(1.2, 2.8),
        kind: 'streak',
        color: pick(FIRE),
        drag: 3.2,
        g: 220,
      });
    }
    for (let i = 0; i < 10; i++) {
      w.fx.emit({
        x: w.muzzle.x + rr(-8, 8),
        y: w.muzzle.y + rr(-10, 10),
        vx: rr(60, 260),
        vy: rr(-60, 60),
        life: rr(0.5, 1.1),
        size: rr(12, 26),
        size1: 3,
        kind: 'glow',
        color: pick(['#ff6a1e', '#ffb347']),
        drag: 2.4,
      });
    }
    // asap tebal dari moncong
    for (let i = 0; i < 8; i++) {
      w.fx.emit({
        x: w.muzzle.x + rr(0, 30),
        y: w.muzzle.y + rr(-8, 8),
        vx: rr(60, 190),
        vy: rr(-40, 10),
        life: rr(0.9, 1.8),
        size: rr(16, 28),
        size1: 46,
        kind: 'smoke',
        color: 'rgba(44,25,15,1)',
        add: false,
        drag: 1.4,
      });
    }
    // kerucut kejut
    w.add(
      new Timed(
        0.34,
        (ctx, t, _age, world) => {
          const e = easeOutCubic(t);
          const m = world.muzzle;
          const a = world.aim;
          const L = 210 * e;
          const R = 74 * (0.5 + e);
          ctx.save();
          ctx.translate(m.x, m.y);
          ctx.rotate(a);
          ctx.globalCompositeOperation = 'lighter';
          const g = ctx.createLinearGradient(0, 0, L, 0);
          g.addColorStop(0, `rgba(255,240,200,${0.85 * (1 - t)})`);
          g.addColorStop(0.35, `rgba(255,140,40,${0.5 * (1 - t)})`);
          g.addColorStop(1, 'rgba(255,90,20,0)');
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.moveTo(0, -R * 0.34);
          ctx.lineTo(L, -R);
          ctx.lineTo(L, R);
          ctx.lineTo(0, R * 0.34);
          ctx.closePath();
          ctx.fill();
          ctx.restore();
        },
      ),
    );
  }

  drawBody(ctx: Ctx, _w: World) {
    const t = this.time;
    const fl = this.flare(3);
    const heat = this.heat;
    const pulse = 0.5 + 0.5 * Math.sin(t * 2.6);
    const breathe = 0.5 + 0.5 * Math.sin(t * 1.25);

    /* ---------- pendar neraka di belakang senjata ---------- */
    ctx.save();
    ctx.translate(30, -6);
    ctx.scale(1, 0.5);
    glow(ctx, 0, 0, 300, '#ff5a1e', 0.1 + 0.06 * pulse + 0.22 * fl + 0.12 * heat);
    glow(ctx, 150, 0, 190, '#ffb347', 0.06 + 0.05 * heat + 0.18 * fl);
    ctx.restore();

    /* ================= GAGANG ================= */
    ctx.beginPath();
    ctx.moveTo(-132, 24);
    ctx.lineTo(-72, 32);
    ctx.lineTo(-44, 114);
    ctx.quadraticCurveTo(-45, 132, -64, 133);
    ctx.lineTo(-100, 132);
    ctx.quadraticCurveTo(-116, 129, -113, 111);
    ctx.lineTo(-132, 44);
    ctx.closePath();
    plate(ctx, () => {}, '#2b323a', '#0d1014', -132, 24, -60, 132);
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(-132, 24);
    ctx.lineTo(-72, 32);
    ctx.lineTo(-44, 114);
    ctx.quadraticCurveTo(-45, 132, -64, 133);
    ctx.lineTo(-100, 132);
    ctx.quadraticCurveTo(-116, 129, -113, 111);
    ctx.lineTo(-132, 44);
    ctx.closePath();
    ctx.clip();
    for (let i = 0; i < 6; i++) {
      const y = 52 + i * 13;
      ctx.strokeStyle = 'rgba(0,0,0,0.55)';
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(-134, y);
      ctx.lineTo(-56, y + 7);
      ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,0.12)';
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(-134, y - 3);
      ctx.lineTo(-56, y + 4);
      ctx.stroke();
    }
    const gsg = ctx.createLinearGradient(-132, 24, -60, 60);
    gsg.addColorStop(0, 'rgba(255,140,60,0.22)');
    gsg.addColorStop(1, 'rgba(255,140,60,0)');
    ctx.fillStyle = gsg;
    ctx.fillRect(-134, 20, 96, 40);
    ctx.restore();
    rivet(ctx, -122, 36, 3.4);
    rivet(ctx, -60, 40, 3.4);
    rivet(ctx, -104, 122, 3);

    // pelindung picu
    ctx.save();
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#0f1216';
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.moveTo(-88, 36);
    ctx.bezierCurveTo(-82, 82, -34, 82, -26, 36);
    ctx.stroke();
    ctx.strokeStyle = '#4a535d';
    ctx.lineWidth = 5.5;
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.fillStyle = '#c2481a';
    ctx.beginPath();
    ctx.roundRect(-58, 38, 11, 26, 4);
    ctx.fill();
    ctx.strokeStyle = '#ffb066';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.restore();

    /* ================= BADAN TENGAH ================= */
    const mid = () => {
      ctx.beginPath();
      ctx.moveTo(-128, -54);
      ctx.lineTo(-108, -68);
      ctx.lineTo(64, -68);
      ctx.lineTo(84, -50);
      ctx.lineTo(84, 46);
      ctx.lineTo(58, 60);
      ctx.lineTo(-108, 58);
      ctx.lineTo(-128, 42);
      ctx.closePath();
    };
    plate(ctx, mid, '#4a525c', '#12161b', -128, -68, 84, 60);
    ctx.save();
    mid();
    ctx.clip();
    const hi = ctx.createLinearGradient(0, -68, 0, -12);
    hi.addColorStop(0, 'rgba(255,255,255,0.22)');
    hi.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = hi;
    ctx.fillRect(-130, -70, 220, 62);
    const lo = ctx.createLinearGradient(0, 20, 0, 62);
    lo.addColorStop(0, 'rgba(0,0,0,0)');
    lo.addColorStop(1, 'rgba(0,0,0,0.5)');
    ctx.fillStyle = lo;
    ctx.fillRect(-130, 20, 220, 44);
    // garis panel
    ctx.strokeStyle = 'rgba(0,0,0,0.5)';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(-108, -68);
    ctx.lineTo(-108, 58);
    ctx.moveTo(36, -68);
    ctx.lineTo(36, 60);
    ctx.moveTo(-108, 22);
    ctx.lineTo(36, 22);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.12)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-108, -62);
    ctx.lineTo(-108, 52);
    ctx.moveTo(36, -62);
    ctx.lineTo(36, 54);
    ctx.stroke();
    // ventilasi samping
    for (let i = 0; i < 5; i++) {
      const x = -96 + i * 13;
      const g = ctx.createLinearGradient(x, 26, x, 50);
      const hv = clamp(0.35 + heat * 0.9 + 0.12 * Math.sin(t * 3 + i), 0, 1.2);
      g.addColorStop(0, `rgba(255,90,20,${0.15 * hv})`);
      g.addColorStop(0.5, `rgba(255,150,50,${0.75 * hv})`);
      g.addColorStop(1, `rgba(255,60,10,${0.2 * hv})`);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.roundRect(x, 26, 7, 26, 2);
      ctx.fill();
      glow(ctx, x + 3.5, 39, 12 * hv, '#ff6a1e', 0.5 * hv);
    }
    hazard(ctx, -130, -70, 22, 132);
    ctx.restore();
    mid();
    ctx.strokeStyle = 'rgba(255,255,255,0.16)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    [-118, -100, 26, 70].forEach((x, i) => rivet(ctx, x, i < 2 ? -52 : -48, 3.2));
    [-118, -100, 26, 70].forEach((x, i) => rivet(ctx, x, i < 2 ? 44 : 46, 3.2));

    // pelat nama terukir
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(-96, -42, 134, 30, 5);
    const pg = ctx.createLinearGradient(0, -42, 0, -12);
    pg.addColorStop(0, '#2c333b');
    pg.addColorStop(1, '#171c22');
    ctx.fillStyle = pg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.12)';
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,150,70,0.72)';
    ctx.font = 'bold 13px ui-sans-serif, system-ui, sans-serif';
    ctx.fillText('OBLITERATOR', -84, -26);
    ctx.fillStyle = 'rgba(255,255,255,0.32)';
    ctx.font = 'bold 8.5px ui-sans-serif, system-ui, sans-serif';
    ctx.fillText('MK-VII · ARGENT', -84, -16);
    ctx.restore();

    /* ================= INTI PLASMA ================= */
    const cx = 52;
    const cy = -6;
    const coreR = 30;
    ctx.save();
    glow(ctx, cx, cy, 70 + 26 * pulse + 60 * fl, '#ff5a1e', 0.5 + 0.22 * pulse + 0.3 * fl + 0.2 * heat);
    // cincin luar
    ctx.beginPath();
    ctx.arc(cx, cy, coreR + 6, 0, TAU);
    const ring = ctx.createLinearGradient(cx, cy - coreR, cx, cy + coreR);
    ring.addColorStop(0, '#59626c');
    ring.addColorStop(0.5, '#20262c');
    ring.addColorStop(1, '#4b535c');
    ctx.fillStyle = ring;
    ctx.fill();
    // plasma berputar
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, coreR, 0, TAU);
    ctx.clip();
    const pc = ctx.createConicGradient(t * 1.35, cx, cy);
    for (let i = 0; i <= 10; i++) {
      const u = i / 10;
      pc.addColorStop(u, i % 2 ? 'rgba(255,220,150,0.95)' : 'rgba(255,90,25,0.85)');
    }
    ctx.fillStyle = pc;
    ctx.fillRect(cx - coreR, cy - coreR, coreR * 2, coreR * 2);
    const pg2 = ctx.createRadialGradient(cx, cy, 2, cx, cy, coreR);
    pg2.addColorStop(0, 'rgba(255,255,235,0.98)');
    pg2.addColorStop(0.42, 'rgba(255,170,70,0.6)');
    pg2.addColorStop(1, 'rgba(120,20,0,0.15)');
    ctx.fillStyle = pg2;
    ctx.fillRect(cx - coreR, cy - coreR, coreR * 2, coreR * 2);
    ctx.restore();
    // kaca inti
    ctx.beginPath();
    ctx.arc(cx, cy, coreR, 0, TAU);
    ctx.strokeStyle = 'rgba(255,220,180,0.75)';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx, cy, coreR + 6, 0, TAU);
    ctx.strokeStyle = 'rgba(255,255,255,0.16)';
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.beginPath();
    ctx.arc(cx, cy, coreR * 0.82, -2.5, -1.1);
    ctx.strokeStyle = 'rgba(255,255,255,0.8)';
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.restore();
    ctx.restore();
    // baut cincin inti
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU + t * 0.25;
      rivet(ctx, cx + Math.cos(a) * (coreR + 6), cy + Math.sin(a) * (coreR + 6), 2.6);
    }

    /* ================= RUANG SEL ENERGI (ATAS) ================= */
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(-70, -100, 132, 36, 15);
    const dg = ctx.createLinearGradient(0, -100, 0, -64);
    dg.addColorStop(0, '#59626c');
    dg.addColorStop(0.45, '#2a3138');
    dg.addColorStop(1, '#12161b');
    ctx.fillStyle = dg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.16)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.clip();
    for (let i = 0; i < 4; i++) {
      const x = -52 + i * 28;
      const b = clamp(0.35 + 0.65 * (0.5 + 0.5 * Math.sin(t * 3.2 - i * 0.8)) + heat * 0.5, 0, 1.1);
      const g = ctx.createLinearGradient(x, -100, x, -64);
      g.addColorStop(0, `rgba(255,120,30,${0.15 * b})`);
      g.addColorStop(0.5, `rgba(255,170,60,${0.85 * b})`);
      g.addColorStop(1, `rgba(255,90,20,${0.2 * b})`);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.roundRect(x, -96, 16, 28, 5);
      ctx.fill();
      glow(ctx, x + 8, -82, 16 * b, '#ff8a2a', 0.5 * b);
    }
    // sorot
    const dh = ctx.createLinearGradient(0, -100, 0, -86);
    dh.addColorStop(0, 'rgba(255,255,255,0.22)');
    dh.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = dh;
    ctx.fillRect(-72, -100, 140, 16);
    ctx.restore();
    rivet(ctx, -66, -82, 3);
    rivet(ctx, 58, -82, 3);

    /* ================= PERISAI LARAS ================= */
    const shroud = () => {
      ctx.beginPath();
      ctx.moveTo(72, -58);
      ctx.lineTo(214, -50);
      ctx.lineTo(214, 42);
      ctx.lineTo(72, 50);
      ctx.closePath();
    };
    plate(ctx, shroud, '#3c444d', '#0f1317', 72, -58, 214, 50);
    ctx.save();
    shroud();
    ctx.clip();
    for (let i = 0; i < 6; i++) {
      const x = 84 + i * 21;
      const hv = clamp(0.3 + heat * 1.05 + 0.12 * Math.sin(t * 4 + i * 0.7), 0, 1.3);
      const g = ctx.createLinearGradient(x, -58, x, -34);
      g.addColorStop(0, `rgba(255,70,10,${0.75 * hv})`);
      g.addColorStop(1, `rgba(255,180,70,${0.15 * hv})`);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.roundRect(x, -58, 13, 24, 3);
      ctx.fill();
      glow(ctx, x + 6, -48, 13 * hv, '#ff5a1e', 0.55 * hv);
    }
    const sh2 = ctx.createLinearGradient(0, -58, 0, -20);
    sh2.addColorStop(0, 'rgba(255,255,255,0.16)');
    sh2.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = sh2;
    ctx.fillRect(70, -58, 150, 40);
    ctx.restore();

    /* ================= KOIL AKSELERATOR ================= */
    const coils = [
      { x: 96, ry: 42 },
      { x: 142, ry: 38 },
      { x: 186, ry: 34 },
    ];
    for (const c of coils) {
      ctx.save();
      ctx.translate(c.x, 0);
      ctx.beginPath();
      ctx.ellipse(0, 0, 8, c.ry, 0, 0, TAU);
      const cg = ctx.createLinearGradient(0, -c.ry, 0, c.ry);
      cg.addColorStop(0, '#6a737d');
      cg.addColorStop(0.42, '#22282e');
      cg.addColorStop(1, '#454d56');
      ctx.fillStyle = cg;
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.18)';
      ctx.lineWidth = 1.1;
      ctx.stroke();
      // pita berputar
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(0, 0, 9, c.ry + 1.5, 0, 0, TAU);
      ctx.setLineDash([20, 11]);
      ctx.lineDashOffset = -t * 60 * this.spin;
      ctx.strokeStyle = `rgba(255,150,60,${0.5 + 0.42 * fl + 0.22 * heat})`;
      ctx.lineWidth = 2.6;
      ctx.stroke();
      ctx.setLineDash([9, 22]);
      ctx.lineDashOffset = t * 34 * this.spin;
      ctx.strokeStyle = 'rgba(255,220,170,0.55)';
      ctx.lineWidth = 1.6;
      ctx.stroke();
      ctx.restore();
      glow(ctx, 0, 0, c.ry * 1.1, '#ff6a1e', 0.06 + 0.1 * fl + 0.05 * heat);
      ctx.restore();
    }

    /* ================= REM LARAS (MUZZLE BRAKE) ================= */
    const brake = () => {
      ctx.beginPath();
      ctx.moveTo(210, -46);
      ctx.lineTo(252, -38);
      ctx.lineTo(252, 34);
      ctx.lineTo(210, 42);
      ctx.closePath();
    };
    plate(ctx, brake, '#525b66', '#12171c', 210, -46, 252, 42);
    ctx.save();
    brake();
    ctx.clip();
    for (let i = 0; i < 3; i++) {
      const x = 218 + i * 12;
      const hv = clamp(0.4 + heat + fl, 0, 1.4);
      const g = ctx.createLinearGradient(x, -40, x, 36);
      g.addColorStop(0, `rgba(255,80,15,${0.7 * hv})`);
      g.addColorStop(0.5, `rgba(255,190,90,${0.35 * hv})`);
      g.addColorStop(1, `rgba(255,80,15,${0.7 * hv})`);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.roundRect(x, -40, 7, 76, 2);
      ctx.fill();
    }
    const bh = ctx.createLinearGradient(0, -46, 0, -22);
    bh.addColorStop(0, 'rgba(255,255,255,0.2)');
    bh.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = bh;
    ctx.fillRect(208, -46, 48, 26);
    ctx.restore();
    // mulut laras
    ctx.beginPath();
    ctx.roundRect(244, -26, 10, 48, 3);
    const mg = ctx.createLinearGradient(244, 0, 254, 0);
    mg.addColorStop(0, '#1a1f25');
    mg.addColorStop(1, '#05070a');
    ctx.fillStyle = mg;
    ctx.fill();
    const inner = 0.5 + 0.5 * pulse + heat * 0.5 + fl;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = `rgba(255,140,50,${clamp(0.25 + 0.4 * inner, 0, 1)})`;
    ctx.fillRect(246, -20, 7, 36);
    ctx.restore();

    /* ================= UAP PANAS ================= */
    if (heat > 0.22) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.lineWidth = 1.4;
      for (let k = 0; k < 3; k++) {
        ctx.beginPath();
        for (let i = 0; i <= 22; i++) {
          const x = 80 + i * 7;
          const y = -74 - k * 9 - Math.sin(t * 2.4 + i * 0.55 + k * 1.7) * 4 * (0.4 + heat);
          i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
        }
        ctx.strokeStyle = `rgba(255,160,80,${0.16 * heat})`;
        ctx.stroke();
      }
      ctx.restore();
    }

    /* ================= BARA JATUH ================= */
    for (const e of this.embers) {
      const k = 1 - e.life / e.max;
      glow(ctx, e.x, e.y, e.s * 4.5, '#ff6a1e', k * 0.85);
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.strokeStyle = `rgba(255,170,70,${k * 0.9})`;
      ctx.lineWidth = e.s * 0.85;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(e.x, e.y);
      ctx.lineTo(e.x - e.vx * 0.035, e.y - e.vy * 0.035);
      ctx.stroke();
      ctx.restore();
    }

    /* ================= KILATAN MONCONG ================= */
    const mx = this.muzzle.x;
    const my = this.muzzle.y;
    if (fl > 0.02) {
      glow(ctx, mx, my, 60 + 120 * fl, '#ff5a1e', 1.1 * fl);
      glow(ctx, mx, my, 28 + 40 * fl, '#fff3c0', fl);
      star4(ctx, mx, my, 26 + 90 * fl, t * 2.4, '#fff3c0', fl, 0.09);
      star4(ctx, mx, my, 18 + 50 * fl, t * 2.4 + 0.78, '#ff8a1e', fl * 0.9, 0.11);
    } else {
      glow(ctx, mx - 4, my, 16 + 6 * breathe, '#ff6a1e', 0.32 + 0.16 * breathe + 0.2 * heat);
    }

  }
}

/* ================================ PELURU ================================ */

class OblitBolt extends Flight {
  constructor(w: World) {
    super(w, 1250, 0.1, 0.45, 0.2);
    this.trailMax = 14;
  }
  onMove(_dt: number, w: World) {
    const a = this.heading;
    for (let i = 0; i < 3; i++) {
      const sp = rr(40, 180);
      const off = rr(-0.7, 0.7);
      w.fx.emit({
        x: this.pos.x + rr(-4, 4),
        y: this.pos.y + rr(-4, 4),
        vx: -Math.cos(a + off) * sp,
        vy: -Math.sin(a + off) * sp,
        life: rr(0.25, 0.6),
        size: rr(8, 18),
        size1: 1.5,
        kind: 'glow',
        color: pick(FIRE),
        drag: 2.6,
      });
    }
    if (Math.random() < 0.9) {
      const sp = rr(80, 260);
      const off = rr(-1, 1);
      w.fx.emit({
        x: this.pos.x,
        y: this.pos.y,
        vx: -Math.cos(a + off) * sp,
        vy: -Math.sin(a + off) * sp,
        life: rr(0.35, 0.8),
        size: rr(1.2, 2.6),
        kind: 'streak',
        color: pick(FIRE),
        drag: 2,
        g: 260,
      });
    }
    if (Math.random() < 0.35)
      w.fx.emit({
        x: this.pos.x + rr(-10, 10),
        y: this.pos.y + rr(-10, 10),
        vx: rr(-30, 30),
        vy: rr(-10, 60),
        life: rr(0.7, 1.4),
        size: rr(12, 22),
        size1: 38,
        kind: 'smoke',
        color: 'rgba(40,22,13,1)',
        add: false,
        drag: 1.2,
      });
  }
  onHit(w: World, x: number, y: number) {
    w.add(new OblitBlast(x, y, w));
    w.target.hit('#ff8a1e');
    w.target.impulse(Math.cos(this.heading) * 320, Math.sin(this.heading) * 320);
    w.target.spin(2.2);
    w.shake(7);
  }
  draw(ctx: Ctx) {
    const { x, y } = this.pos;
    const n = this.trail.length;
    const ca = Math.cos(this.heading);
    const sa = Math.sin(this.heading);

    // kerucut kejut di depan peluru
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const L = 96;
    const g = ctx.createLinearGradient(x, y, x + ca * L, y + sa * L);
    g.addColorStop(0, 'rgba(255,240,205,0.55)');
    g.addColorStop(1, 'rgba(255,110,30,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(x + ca * 14 - sa * 12, y + sa * 14 + ca * 12);
    ctx.lineTo(x + ca * L, y + sa * L);
    ctx.lineTo(x + ca * 14 + sa * 12, y + sa * 14 - ca * 12);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // jejak api
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round';
    for (let i = 1; i < n; i++) {
      const k = i / n;
      const a = this.trail[i - 1];
      const b = this.trail[i];
      const g2 = ctx.createLinearGradient(a.x, a.y, b.x, b.y);
      g2.addColorStop(0, `rgba(255,90,20,${0.32 * k})`);
      g2.addColorStop(1, `rgba(255,190,90,${0.5 * k})`);
      ctx.strokeStyle = g2;
      ctx.lineWidth = 2 + 17 * k;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
    ctx.restore();

    lens(ctx, x, y, 34, 1.45, this.age * 3);
    glow(ctx, x, y, 52, '#ff5a1e', 0.95);
    glow(ctx, x, y, 26, '#ffb347', 0.9);

    // inti bola api
    const fg = ctx.createRadialGradient(x - 5, y - 6, 1, x, y, 20);
    fg.addColorStop(0, '#fffdf2');
    fg.addColorStop(0.32, '#ffd23a');
    fg.addColorStop(0.68, '#ff6a1e');
    fg.addColorStop(1, 'rgba(150,25,5,0.2)');
    ctx.fillStyle = fg;
    ctx.beginPath();
    ctx.arc(x, y, 19, 0, TAU);
    ctx.fill();

    // kurung giroskop logam
    for (let k = 0; k < 2; k++) {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(this.age * (k ? -16 : 13) + k * 1.1);
      ctx.scale(1, k ? 0.42 : 0.28);
      ctx.beginPath();
      ctx.arc(0, 0, 25 + k * 3, 0, TAU);
      ctx.strokeStyle = k ? 'rgba(255,210,150,0.95)' : 'rgba(120,130,140,0.9)';
      ctx.lineWidth = k ? 3 : 4.5;
      ctx.stroke();
      ctx.setLineDash([14, 10]);
      ctx.lineDashOffset = -this.age * 120;
      ctx.strokeStyle = 'rgba(255,240,210,0.85)';
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.restore();
    }
    star4(ctx, x, y, 12 + 10 * Math.abs(Math.sin(this.age * 22)), this.age * 3, '#ffffff', 0.85, 0.12);
  }
}

/* ================================ TUMBUKAN ================================ */

interface Debris {
  x: number;
  y: number;
  vx: number;
  vy: number;
  rot: number;
  vr: number;
  s: number;
  life: number;
  max: number;
  hot: number;
}

class OblitBlast implements Entity {
  dead = false;
  layer: 0 | 1 = 1;
  age = 0;
  debris: Debris[] = [];
  private emitAcc = 0;

  constructor(
    private x: number,
    private y: number,
    w: World,
  ) {
    for (let i = 0; i < 26; i++) {
      const a = rr(0, TAU);
      const sp = rr(120, 520);
      this.debris.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 90,
        rot: rr(0, TAU),
        vr: rr(-16, 16),
        s: rr(4, 11),
        life: 0,
        max: rr(0.8, 1.7),
        hot: 1,
      });
    }
    // gelombang kejut
    addRing(w, x, y, 12, 300, 0.62, '#ffd23a', 12, 0.6, 1);
    addRing(w, x, y, 12, 380, 0.82, '#ff6a1e', 5, 0.3, 0.85, easeOutCubic, true, 0.06);
    addRing(w, x, y, 12, 220, 0.42, '#fff3c0', 16, 1.2, 1);
    addFlash(w, x, y, 30, 260, 0.55, '#ff8a1e', 1);
    addFlash(w, x, y, 18, 120, 0.3, '#fff8e0', 1);
    // api susulan
    for (let i = 0; i < 44; i++) {
      const a = rr(0, TAU);
      const sp = rr(60, 420);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.35, 0.9),
        size: rr(18, 44),
        size1: 3,
        kind: 'glow',
        color: pick(FIRE),
        drag: 3.4,
      });
    }
    for (let i = 0; i < 40; i++) {
      const a = rr(0, TAU);
      const sp = rr(160, 620);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.4, 1.0),
        size: rr(1.2, 2.6),
        kind: 'streak',
        color: pick(FIRE),
        drag: 2.6,
        g: 320,
        len: 0.05,
      });
    }
    for (let i = 0; i < 14; i++) {
      w.fx.emit({
        x: x + rr(-30, 30),
        y: y + rr(-30, 30),
        vx: rr(-70, 70),
        vy: rr(-60, 30),
        life: rr(1.2, 2.4),
        size: rr(20, 36),
        size1: 78,
        kind: 'smoke',
        color: 'rgba(32,18,11,1)',
        add: false,
        drag: 1.1,
        g: -70,
      });
    }
  }

  update(dt: number, w: World) {
    this.age += dt;
    for (let i = this.debris.length - 1; i >= 0; i--) {
      const d = this.debris[i];
      d.life += dt;
      if (d.life > d.max) {
        this.debris.splice(i, 1);
        continue;
      }
      d.vy += 620 * dt;
      d.vx *= Math.exp(-dt * 1.1);
      d.vy *= Math.exp(-dt * 0.5);
      d.x += d.vx * dt;
      d.y += d.vy * dt;
      d.rot += d.vr * dt;
      d.hot = Math.max(0, d.hot - dt * 0.9);
    }
    if (this.age < 0.35) {
      w.attract(this.x, this.y, 260, 120, dt);
    }
    this.emitAcc += dt * 26;
    while (this.emitAcc > 1 && this.age < 0.5) {
      this.emitAcc -= 1;
      const a = rr(0, TAU);
      const sp = rr(20, 120);
      w.fx.emit({
        x: this.x + Math.cos(a) * rr(10, 60),
        y: this.y + Math.sin(a) * rr(10, 60),
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 40,
        life: rr(0.5, 1.1),
        size: rr(8, 20),
        size1: 2,
        kind: 'glow',
        color: pick(FIRE),
        drag: 2.2,
      });
    }
    if (this.age > 1.7) this.dead = true;
  }

  private lightning(ctx: Ctx, a: number, r: number, alpha: number, seed: number) {
    const seg = 7;
    ctx.beginPath();
    let px = this.x;
    let py = this.y;
    ctx.moveTo(px, py);
    for (let i = 1; i <= seg; i++) {
      const u = i / seg;
      const wob = (Math.sin(seed * 7 + i * 2.3) * 0.36 + Math.sin(seed * 3.1 + i * 5.1) * 0.2) * r * 0.28 * (1 - u * 0.4);
      const ang = a + wob / r;
      px = this.x + Math.cos(ang) * r * u;
      py = this.y + Math.sin(ang) * r * u;
      ctx.lineTo(px, py);
    }
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = `rgba(255,150,50,${alpha * 0.55})`;
    ctx.lineWidth = 6.5;
    ctx.stroke();
    ctx.strokeStyle = `rgba(255,242,214,${alpha})`;
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  draw(ctx: Ctx) {
    const x = this.x;
    const y = this.y;
    const a = this.age;

    // bola api berlapis
    if (a < 0.62) {
      const e = easeOutCubic(a / 0.62);
      const R = 16 + 168 * e;
      const fade = Math.pow(1 - a / 0.62, 1.25);
      glow(ctx, x, y, R * 1.45, '#ff4d16', 0.75 * fade);
      const g = ctx.createRadialGradient(x, y, 0, x, y, R);
      g.addColorStop(0, `rgba(255,255,240,${0.98 * fade})`);
      g.addColorStop(0.22, `rgba(255,214,120,${0.92 * fade})`);
      g.addColorStop(0.52, `rgba(255,110,30,${0.8 * fade})`);
      g.addColorStop(0.82, `rgba(170,26,6,${0.45 * fade})`);
      g.addColorStop(1, 'rgba(60,10,2,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(x, y, R, 0, TAU);
      ctx.fill();
      // kerak gelap di tepi
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.setLineDash([26, 16]);
      ctx.lineDashOffset = -a * 220;
      ctx.beginPath();
      ctx.arc(x, y, R * 0.86, 0, TAU);
      ctx.strokeStyle = `rgba(255,190,110,${0.35 * fade})`;
      ctx.lineWidth = 6;
      ctx.stroke();
      ctx.restore();
    } else {
      const t2 = (a - 0.62) / 1.05;
      const R = 184 * (1 + t2 * 0.5);
      glow(ctx, x, y, R * 0.8, '#7a2a12', 0.22 * (1 - t2));
    }

    // distorsi panas
    if (a < 0.75) {
      const e = easeOutCubic(a / 0.75);
      lens(ctx, x, y, 40 + 210 * e, 1.7, a * 2.2, 1 - e * 0.9);
    }

    // petir plasma
    if (a < 0.34) {
      const k = 1 - a / 0.34;
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      for (let i = 0; i < 6; i++) {
        this.lightning(ctx, (i / 6) * TAU + a * 2.2, 120 + 150 * k, 0.85 * k, i + a * 6);
      }
      glow(ctx, x, y, 90 * (0.5 + k), '#ffb347', 0.5 * k);
      ctx.restore();
    }

    // puing logam cair
    for (const d of this.debris) {
      const k = 1 - d.life / d.max;
      const hot = d.hot;
      glow(ctx, d.x, d.y, d.s * (2 + 4 * hot), '#ff5a1e', k * (0.35 + 0.65 * hot));
      ctx.save();
      ctx.translate(d.x, d.y);
      ctx.rotate(d.rot);
      const g = ctx.createLinearGradient(-d.s, -d.s, d.s, d.s);
      g.addColorStop(0, `rgba(255,${Math.round(120 + 120 * hot)},${Math.round(40 + 90 * hot)},${0.55 + 0.45 * k})`);
      g.addColorStop(1, `rgba(${Math.round(60 + 60 * hot)},26,12,${0.6 + 0.4 * k})`);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(d.s, 0);
      ctx.lineTo(d.s * 0.1, d.s * 0.72);
      ctx.lineTo(-d.s * 0.85, d.s * 0.2);
      ctx.lineTo(-d.s * 0.5, -d.s * 0.7);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = `rgba(255,220,170,${0.5 * k})`;
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.restore();
    }
  }
}
