import { glow, lens, star4 } from '../gfx';
import { addFlash, addRing, Timed } from '../particles';
import type { Ctx, Entity, World } from '../types';
import { clamp, easeOutCubic, hsl, hsla, pick, rr, TAU } from '../util';
import { Flight, Weapon, type Bounds, type Features, type Theme } from '../weapon';

const MX = 238;

/** Gradasi pelangi konis */
function rainbow(ctx: Ctx, cx: number, cy: number, rot: number, light = 62) {
  const g = ctx.createConicGradient(rot, cx, cy);
  for (let i = 0; i <= 12; i++) g.addColorStop(i / 12, hsl((i / 12) * 360, 92, light));
  return g;
}

function ring(
  ctx: Ctx,
  x: number,
  y: number,
  rx: number,
  ry: number,
  rot: number,
  lw: number,
  alpha: number,
  spin: number,
  dash?: [number, number],
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.beginPath();
  ctx.ellipse(0, 0, rx, ry, 0, 0, TAU);
  if (dash) {
    ctx.setLineDash(dash);
    ctx.lineDashOffset = -spin * 55;
  }
  ctx.globalAlpha = clamp(alpha, 0, 1);
  ctx.lineWidth = lw;
  ctx.strokeStyle = rainbow(ctx, 0, 0, spin, 62);
  ctx.stroke();
  ctx.restore();
}

interface Mote {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  hue: number;
  s: number;
}

export class RainbowGun extends Weapon {
  readonly id = 'rainbow';
  readonly name = 'Rainbow Gun';
  readonly tagline = 'Prisma hidup — tujuh warna jadi satu ledakan';
  readonly accent = '#ff6fc8';
  readonly theme: Theme = { top: '#1b0a2c', bottom: '#3a1252', glow: '#ff5fc8' };
  readonly features: Features = {
    body: 'Badan krom holografik dengan kaca prisma berputar, sirip tembus cahaya, dan tiga cincin aura pelangi.',
    bullet: 'Bola prisma berpusing dengan cincin konis berputar dan jejak tiga helai warna.',
    impact: 'Cincin pelangi berputar melebar, kilatan bintang, dan pusaran pita warna.',
    idle: 'Kilau krom menyapu badan, halo berputar, dan mote cahaya berganti warna.',
  };
  readonly bounds: Bounds = { x0: -192, x1: 252, y0: -116, y1: 130 };
  kick = 13;
  cooldown = 0.3;
  private motes: Mote[] = [];
  private acc = 0;

  constructor() {
    super();
    this.muzzle = { x: MX, y: 0 };
  }

  update(dt: number, w: World) {
    super.update(dt, w);
    this.acc += dt * 7;
    while (this.acc > 1) {
      this.acc -= 1;
      this.motes.push({
        x: rr(-150, 190),
        y: rr(-70, 70),
        vx: rr(-16, 16),
        vy: -rr(12, 34),
        life: 0,
        max: rr(1.4, 2.6),
        hue: rr(0, 360),
        s: rr(1.4, 3.2),
      });
    }
    for (let i = this.motes.length - 1; i >= 0; i--) {
      const m = this.motes[i];
      m.life += dt;
      if (m.life > m.max) {
        this.motes.splice(i, 1);
        continue;
      }
      m.x += (m.vx + Math.sin(this.time * 1.6 + m.hue) * 8) * dt;
      m.y += m.vy * dt;
    }
  }

  protected fire(w: World) {
    w.add(new RainbowBolt(w));
    w.shake(2);
    for (let i = 0; i < 16; i++) {
      const a = w.aim + rr(-0.55, 0.55);
      const sp = rr(140, 420);
      w.fx.emit({
        x: w.muzzle.x,
        y: w.muzzle.y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.3, 0.7),
        size: rr(3, 6),
        kind: 'star',
        rot: rr(0, 3),
        vr: rr(-5, 5),
        color: hsl(rr(0, 360), 95, 72),
        drag: 3,
      });
    }
  }

  drawBody(ctx: Ctx, _w: World) {
    const t = this.time;
    const fl = this.flare(5);
    const pulse = 0.5 + 0.5 * Math.sin(t * 2.1);

    /* ---------- pendar ---------- */
    ctx.save();
    ctx.translate(30, 0);
    ctx.scale(1, 0.5);
    glow(ctx, 0, 0, 300, '#ff5fc8', 0.1 + 0.05 * pulse + 0.2 * fl);
    glow(ctx, -60, 0, 220, '#5fe8ff', 0.08 + 0.05 * pulse + 0.16 * fl);
    ctx.restore();

    /* ---------- halo pelangi berputar ---------- */
    for (let k = 0; k < 3; k++) {
      ring(
        ctx,
        40,
        0,
        128 + k * 28,
        (128 + k * 28) * 0.42,
        Math.sin(t * 0.36 + k) * 0.3,
        2.2,
        0.16 + 0.1 * Math.sin(t * 1.5 + k) + 0.3 * fl,
        t * (k % 2 ? -0.42 : 0.34) + k,
        [24, 18],
      );
    }

    /* ================= BADAN KROM ================= */
    const body = () => {
      ctx.beginPath();
      ctx.moveTo(-172, -20);
      ctx.quadraticCurveTo(-168, -42, -134, -48);
      ctx.lineTo(18, -56);
      ctx.quadraticCurveTo(118, -52, 166, -30);
      ctx.quadraticCurveTo(180, 0, 166, 30);
      ctx.quadraticCurveTo(118, 52, 18, 56);
      ctx.lineTo(-134, 48);
      ctx.quadraticCurveTo(-168, 42, -172, 20);
      ctx.quadraticCurveTo(-178, 0, -172, -20);
      ctx.closePath();
    };
    ctx.save();
    ctx.shadowColor = 'rgba(255,120,220,0.5)';
    ctx.shadowBlur = 20;
    body();
    const bg = ctx.createLinearGradient(0, -56, 0, 56);
    bg.addColorStop(0, '#ffffff');
    bg.addColorStop(0.3, '#e2f6ff');
    bg.addColorStop(0.55, '#9fdcf4');
    bg.addColorStop(0.8, '#5aa8d8');
    bg.addColorStop(1, '#2b5f9c');
    ctx.fillStyle = bg;
    ctx.fill();
    ctx.restore();

    ctx.save();
    body();
    ctx.clip();
    // lapisan krom holografik
    const rg = ctx.createLinearGradient(-180, -60, 180, 60);
    for (let i = 0; i <= 10; i++) rg.addColorStop(i / 10, hsla(i * 36, 92, 62, 0.3));
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = rg;
    ctx.fillRect(-190, -70, 380, 140);
    // kilau menyapu
    const sw = ((t * 0.32) % 1) * 460 - 230;
    const sg = ctx.createLinearGradient(sw - 70, -60, sw + 70, 60);
    sg.addColorStop(0, 'rgba(255,255,255,0)');
    sg.addColorStop(0.5, 'rgba(255,255,255,0.5)');
    sg.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = sg;
    ctx.fillRect(-190, -70, 380, 140);
    ctx.globalCompositeOperation = 'source-over';
    // pita warna melintang
    for (let i = 0; i < 5; i++) {
      const x = -120 + i * 62;
      ctx.fillStyle = hsla(i * 62 + t * 22, 92, 60, 0.16);
      ctx.beginPath();
      ctx.moveTo(x, -58);
      ctx.lineTo(x + 26, -58);
      ctx.lineTo(x + 2, 58);
      ctx.lineTo(x - 24, 58);
      ctx.closePath();
      ctx.fill();
    }
    // garis panel
    ctx.strokeStyle = 'rgba(255,255,255,0.45)';
    ctx.lineWidth = 1.1;
    ctx.beginPath();
    ctx.moveTo(-134, -48);
    ctx.lineTo(-134, 48);
    ctx.moveTo(-70, -54);
    ctx.lineTo(-70, 54);
    ctx.moveTo(96, -52);
    ctx.lineTo(96, 52);
    ctx.stroke();
    // sorot atas & bayangan bawah
    const hi = ctx.createLinearGradient(0, -56, 0, -10);
    hi.addColorStop(0, 'rgba(255,255,255,0.85)');
    hi.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = hi;
    ctx.fillRect(-180, -58, 370, 50);
    const lo = ctx.createLinearGradient(0, 18, 0, 58);
    lo.addColorStop(0, 'rgba(20,40,80,0)');
    lo.addColorStop(1, 'rgba(20,40,80,0.32)');
    ctx.fillStyle = lo;
    ctx.fillRect(-180, 18, 370, 42);
    ctx.restore();
    body();
    ctx.strokeStyle = 'rgba(255,255,255,0.75)';
    ctx.lineWidth = 1.3;
    ctx.stroke();

    /* ================= SIRIP PELANGI ================= */
    const fin = (pts: [number, number][], alpha: number) => {
      ctx.beginPath();
      ctx.moveTo(...pts[0]);
      for (let i = 1; i < pts.length; i++) ctx.lineTo(...pts[i]);
      ctx.closePath();
      const g = ctx.createLinearGradient(pts[0][0], pts[0][1], pts[pts.length - 1][0], pts[pts.length - 1][1]);
      for (let i = 0; i <= 6; i++) g.addColorStop(i / 6, hsla(i * 60 + t * 30, 92, 62, alpha));
      ctx.fillStyle = g;
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.55)';
      ctx.lineWidth = 1;
      ctx.stroke();
    };
    fin(
      [
        [-70, -52],
        [10, -96],
        [86, -54],
      ],
      0.55,
    );
    fin(
      [
        [-80, 50],
        [-6, 92],
        [70, 52],
      ],
      0.45,
    );

    /* ================= PRISMA TENGAH ================= */
    const cx = 16;
    const cy = 0;
    ctx.save();
    glow(ctx, cx, cy, 76 + 22 * pulse + 40 * fl, '#b98cff', 0.32 + 0.14 * pulse + 0.3 * fl);
    // dudukan heksagon
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * TAU + Math.PI / 6;
      const px = cx + Math.cos(a) * 44;
      const py = cy + Math.sin(a) * 44;
      i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
    }
    ctx.closePath();
    const hg = ctx.createLinearGradient(cx - 44, cy - 44, cx + 44, cy + 44);
    hg.addColorStop(0, '#f2fbff');
    hg.addColorStop(0.5, '#9fd0ea');
    hg.addColorStop(1, '#3d6fa8');
    ctx.fillStyle = hg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.7)';
    ctx.lineWidth = 1.4;
    ctx.stroke();
    // kaca prisma berputar
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, 32, 0, TAU);
    ctx.clip();
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = rainbow(ctx, cx, cy, t * 0.9, 58);
    ctx.fillRect(cx - 34, cy - 34, 68, 68);
    const pg = ctx.createRadialGradient(cx - 8, cy - 10, 2, cx, cy, 32);
    pg.addColorStop(0, 'rgba(255,255,255,0.95)');
    pg.addColorStop(0.55, 'rgba(255,255,255,0.18)');
    pg.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = pg;
    ctx.fillRect(cx - 34, cy - 34, 68, 68);
    ctx.restore();
    ctx.beginPath();
    ctx.arc(cx, cy, 32, 0, TAU);
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.lineWidth = 2.2;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx, cy, 32, -2.6, -1.2);
    ctx.strokeStyle = 'rgba(255,255,255,0.95)';
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.restore();

    /* ================= GAGANG ================= */
    ctx.beginPath();
    ctx.moveTo(-122, 26);
    ctx.lineTo(-72, 32);
    ctx.lineTo(-52, 112);
    ctx.quadraticCurveTo(-54, 128, -72, 128);
    ctx.lineTo(-102, 128);
    ctx.quadraticCurveTo(-118, 126, -116, 110);
    ctx.lineTo(-122, 44);
    ctx.closePath();
    const gg = ctx.createLinearGradient(-118, 26, -56, 128);
    gg.addColorStop(0, '#f7fdff');
    gg.addColorStop(0.45, '#a8dcf2');
    gg.addColorStop(1, '#3f7cb8');
    ctx.fillStyle = gg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.6)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(-122, 26);
    ctx.lineTo(-72, 32);
    ctx.lineTo(-52, 112);
    ctx.quadraticCurveTo(-54, 128, -72, 128);
    ctx.lineTo(-102, 128);
    ctx.quadraticCurveTo(-118, 126, -116, 110);
    ctx.lineTo(-122, 44);
    ctx.closePath();
    ctx.clip();
    for (let i = 0; i < 6; i++) {
      const y = 54 + i * 12;
      ctx.strokeStyle = hsla(i * 55, 92, 60, 0.4);
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(-124, y);
      ctx.lineTo(-56, y + 5);
      ctx.stroke();
    }
    ctx.restore();

    // pelindung picu
    ctx.save();
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#2c5f9c';
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.moveTo(-84, 36);
    ctx.bezierCurveTo(-80, 80, -30, 80, -22, 34);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.7)';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = hsl(t * 120, 95, 62);
    ctx.beginPath();
    ctx.roundRect(-56, 36, 10, 24, 4);
    ctx.fill();
    ctx.restore();

    /* ================= MONCONG: CINCIN PRISMA ================= */
    ctx.beginPath();
    ctx.moveTo(150, -32);
    ctx.lineTo(206, -22);
    ctx.lineTo(206, 22);
    ctx.lineTo(150, 32);
    ctx.closePath();
    const ng = ctx.createLinearGradient(150, -32, 206, 22);
    ng.addColorStop(0, '#eaf8ff');
    ng.addColorStop(0.5, '#7fc4e8');
    ng.addColorStop(1, '#2f63a0');
    ctx.fillStyle = ng;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.6)';
    ctx.lineWidth = 1.1;
    ctx.stroke();

    for (let k = 0; k < 3; k++) {
      const x = 176 + k * 26;
      const ry = 40 - k * 6;
      ring(ctx, x, 0, 7, ry, 0, 4 - k * 0.6, 0.9, t * (k % 2 ? -1.6 : 1.6) + k, [22, 12]);
      glow(ctx, x, 0, ry * 1.1, hsl(t * 90 + k * 90, 95, 62), 0.1 + 0.12 * fl);
    }

    // inti moncong
    const mx = this.muzzle.x;
    const my = this.muzzle.y;
    glow(ctx, mx, my, 26 + 8 * pulse, '#ffd6f2', 0.4 + 0.2 * pulse);
    if (fl > 0.02) {
      glow(ctx, mx, my, 60 + 110 * fl, hsl(t * 220, 95, 62), 1.1 * fl);
      glow(ctx, mx, my, 26 + 30 * fl, '#ffffff', fl);
      star4(ctx, mx, my, 22 + 80 * fl, t * 2, '#ffffff', fl, 0.1);
      star4(ctx, mx, my, 16 + 44 * fl, t * 2 + 0.78, hsl(t * 260, 95, 72), fl * 0.9, 0.12);
    }

    /* ================= MOTE CAHAYA ================= */
    for (const m of this.motes) {
      const a = Math.sin((m.life / m.max) * Math.PI);
      glow(ctx, m.x, m.y, m.s * 4.2, hsl(m.hue + t * 40, 95, 65), a * 0.85);
    }
  }
}

/* ================================ PELURU ================================ */

class RainbowBolt extends Flight {
  constructor(w: World) {
    super(w, 1320, 0.1, 0.5, 0.17);
    this.trailMax = 18;
  }
  onMove(_dt: number, w: World) {
    for (let i = 0; i < 2; i++) {
      w.fx.emit({
        x: this.pos.x + rr(-5, 5),
        y: this.pos.y + rr(-5, 5),
        vx: rr(-40, 40),
        vy: rr(-40, 40),
        life: rr(0.3, 0.65),
        size: rr(4, 9),
        size1: 1,
        kind: 'glow',
        color: hsl(rr(0, 360), 95, 66),
        drag: 2.4,
      });
    }
    if (Math.random() < 0.45)
      w.fx.emit({
        x: this.pos.x,
        y: this.pos.y,
        vx: rr(-60, 60),
        vy: rr(-60, 60),
        life: rr(0.4, 0.8),
        size: rr(3, 7),
        kind: 'star',
        rot: rr(0, 3),
        vr: rr(-5, 5),
        color: hsl(rr(0, 360), 95, 85),
        drag: 2,
      });
  }
  onHit(w: World, x: number, y: number) {
    w.add(new RainbowBurst(x, y, w));
    w.target.hit('#ff8ad0');
    w.target.impulse(Math.cos(this.heading) * 150, Math.sin(this.heading) * 150);
    w.target.spin(1.8);
    w.shake(2.6);
  }
  draw(ctx: Ctx) {
    const { x, y } = this.pos;
    const n = this.trail.length;
    const nx = -Math.sin(this.heading);
    const ny = Math.cos(this.heading);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round';
    for (let s = 0; s < 3; s++) {
      ctx.beginPath();
      for (let i = 0; i < n; i++) {
        const p = this.trail[i];
        const k = i / Math.max(1, n - 1);
        const off = Math.sin(this.age * 18 + i * 0.55 + s * 2.1) * 7 * k;
        const px = p.x + nx * off;
        const py = p.y + ny * off;
        i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
      }
      ctx.strokeStyle = hsla(this.age * 240 + s * 120, 95, 62, 0.55);
      ctx.lineWidth = 1.5 + 3.5 * (s === 1 ? 1 : 0.6);
      ctx.stroke();
    }
    ctx.restore();

    lens(ctx, x, y, 28, 1.35, this.age * 3);
    glow(ctx, x, y, 44, hsl(this.age * 240, 95, 62), 0.85);
    const g = ctx.createRadialGradient(x - 4, y - 5, 1, x, y, 19);
    g.addColorStop(0, '#ffffff');
    g.addColorStop(0.45, hsl(this.age * 240, 95, 70));
    g.addColorStop(1, hsla(this.age * 240 + 120, 95, 50, 0.22));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, 19, 0, TAU);
    ctx.fill();
    for (let k = 0; k < 2; k++) {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(this.age * (k ? -9 : 11) + k);
      ctx.scale(1, k ? 0.42 : 0.28);
      ctx.beginPath();
      ctx.arc(0, 0, 25 + k * 3, 0, TAU);
      ctx.lineWidth = 3;
      ctx.strokeStyle = rainbow(ctx, 0, 0, this.age * 2 + k, 64);
      ctx.globalAlpha = 0.95;
      ctx.stroke();
      ctx.restore();
    }
    star4(ctx, x, y, 10 + 6 * Math.abs(Math.sin(this.age * 24)), this.age * 4, '#ffffff', 0.85);
  }
}

/* ================================ TUMBUKAN ================================ */

class RainbowBurst implements Entity {
  dead = false;
  layer: 0 | 1 = 1;
  age = 0;
  constructor(
    private x: number,
    private y: number,
    w: World,
  ) {
    for (let i = 0; i < 30; i++) {
      const a = rr(0, TAU);
      const sp = rr(120, 480);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.5, 1.0),
        size: rr(5, 11),
        kind: 'shard',
        rot: rr(0, TAU),
        vr: rr(-12, 12),
        color: hsla(i * 12 + rr(-8, 8), 95, 70, 0.85),
        drag: 2.2,
        g: 200,
        add: false,
        fade: 0.7,
      });
    }
    for (let i = 0; i < 34; i++) {
      const a = rr(0, TAU);
      const sp = rr(150, 560);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.35, 0.8),
        size: rr(1.2, 2.6),
        kind: 'streak',
        color: hsl(i * 10.5, 95, 68),
        drag: 2.8,
        len: 0.05,
      });
    }
    for (let i = 0; i < 12; i++) {
      w.fx.emit({
        x,
        y,
        vx: rr(-140, 140),
        vy: rr(-140, 140),
        life: rr(0.5, 0.9),
        size: rr(6, 12),
        kind: 'star',
        rot: rr(0, 3),
        vr: rr(-4, 4),
        color: hsl(i * 30, 95, 88),
        drag: 2.2,
      });
    }
    addFlash(w, x, y, 22, 180, 0.55, '#ffffff', 1);
    addRing(w, x, y, 10, 230, 0.75, '#ffffff', 3, 0.3, 0.95);
    for (let k = 0; k < 4; k++) {
      w.add(
        new Timed(0.9 + k * 0.12, (ctx, t, age) => {
          const e = easeOutCubic(t);
          const R = 18 + (150 + k * 55) * e;
          ctx.globalCompositeOperation = 'lighter';
          ctx.save();
          ctx.translate(x, y);
          ctx.rotate(age * (k % 2 ? -2.2 : 1.8) + k);
          ctx.beginPath();
          ctx.arc(0, 0, R, 0, TAU);
          ctx.setLineDash([30 + k * 8, 16]);
          ctx.lineDashOffset = -age * (120 + k * 40);
          ctx.lineWidth = (7 - k) * (1 - t * 0.6);
          ctx.globalAlpha = (1 - t) * 0.95;
          ctx.strokeStyle = rainbow(ctx, 0, 0, age * 1.5 + k * 0.7, 62);
          ctx.stroke();
          ctx.restore();
        }),
      );
    }
  }
  update(dt: number) {
    this.age += dt;
    if (this.age > 1.15) this.dead = true;
  }
  draw(ctx: Ctx) {
    const a = this.age;
    const { x, y } = this;
    if (a < 0.42) {
      const k = 1 - a / 0.42;
      glow(ctx, x, y, 70 + 190 * (1 - k), hsl(a * 420, 95, 68), k);
      lens(ctx, x, y, 30 + 150 * (1 - k), 1.5, a * 3, k);
    }
    // pusaran pita warna
    const u = clamp(a / 1.0, 0, 1);
    const fade = Math.pow(1 - u, 1.3);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round';
    for (let s = 0; s < 5; s++) {
      const dir = s % 2 ? -1 : 1;
      const rad = 24 + 130 * u * (1 + s * 0.12);
      ctx.beginPath();
      for (let i = 0; i <= 18; i++) {
        const ang = a * 3.4 * dir + (i / 18) * 2.4 + (s * TAU) / 5;
        const r = rad * (0.35 + (i / 18) * 0.75);
        const px = x + Math.cos(ang) * r;
        const py = y + Math.sin(ang) * r * 0.82;
        i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
      }
      ctx.strokeStyle = hsla(a * 300 + s * 70, 95, 66, 0.7 * fade);
      ctx.lineWidth = 6 * (1 - u) + 1;
      ctx.stroke();
    }
    ctx.restore();
    for (let k = 0; k < 2; k++) {
      star4(ctx, x, y, 60 * (1 - u) * (k ? 0.6 : 1), a * 2 + k, '#ffffff', fade * 0.5, 0.12);
    }
    void pick;
  }
}
