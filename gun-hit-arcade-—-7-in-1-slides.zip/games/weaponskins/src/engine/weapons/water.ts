import { glow, lens, star4 } from '../gfx';
import { addFlash, addRing } from '../particles';
import type { Ctx, Entity, World } from '../types';
import { clamp, easeOutCubic, rr, smooth, TAU } from '../util';
import { Flight, Weapon, type Bounds, type Features, type Theme } from '../weapon';

const MX = 234;

function droplet(ctx: Ctx, x: number, y: number, r: number, color: string, alpha = 1) {
  ctx.save();
  ctx.globalAlpha = clamp(alpha, 0, 1);
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(x, y - r * 1.7);
  ctx.quadraticCurveTo(x + r, y - r * 0.25, x, y + r);
  ctx.quadraticCurveTo(x - r, y - r * 0.25, x, y - r * 1.7);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

interface Bubble {
  x: number;
  y: number;
  r: number;
  sp: number;
  ph: number;
}

export class WaterGun extends Weapon {
  readonly id = 'water';
  readonly name = 'Water Gun';
  readonly tagline = 'Meriam air laut dalam — jernih, deras, mematikan';
  readonly accent = '#2fdbe8';
  readonly theme: Theme = { top: '#04222e', bottom: '#0a4258', glow: '#2fdbe8' };
  readonly features: Features = {
    body: 'Badan plastik cyan tembus pandang dengan tangki air, gelembung naik, pompa bergerigi, dan moncong chrome.',
    bullet: 'Bola air bening berpusar dengan jejak tetesan dan kabut halus.',
    impact: 'Cincin air, mahkota percikan yang melengkung, kabut, dan kubah air yang mengembang.',
    idle: 'Gelembung naik di tangki, kilau kausal menyapu, tetesan menetes dari moncong.',
  };
  readonly bounds: Bounds = { x0: -192, x1: 252, y0: -112, y1: 130 };
  kick = 11;
  cooldown = 0.26;
  private bubbles: Bubble[] = [];
  private drip = 0;

  constructor() {
    super();
    this.muzzle = { x: MX, y: 0 };
    for (let i = 0; i < 16; i++) {
      this.bubbles.push({
        x: rr(-96, 30),
        y: rr(-84, -38),
        r: rr(1.8, 5),
        sp: rr(9, 26),
        ph: rr(0, TAU),
      });
    }
  }

  update(dt: number, w: World) {
    super.update(dt, w);
    for (const b of this.bubbles) {
      b.y -= b.sp * dt;
      b.x += Math.sin(this.time * 2 + b.ph) * 9 * dt;
      if (b.y < -92) {
        b.y = -36;
        b.x = rr(-96, 30);
      }
    }
    this.drip += dt;
    if (this.drip > 0.55) {
      this.drip = 0;
      w.fx.emit({
        x: MX - 4,
        y: 12,
        vx: rr(-6, 6),
        vy: 30,
        life: 0.8,
        size: 3,
        kind: 'dot',
        color: 'rgba(180,240,255,0.75)',
        add: false,
        g: 220,
      });
    }
  }

  protected fire(w: World) {
    w.add(new WaterBlob(w));
    w.shake(1.8);
    for (let i = 0; i < 14; i++) {
      const a = w.aim + rr(-0.6, 0.6);
      const sp = rr(120, 380);
      w.fx.emit({
        x: w.muzzle.x,
        y: w.muzzle.y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.3, 0.7),
        size: rr(2.5, 5),
        kind: 'dot',
        color: 'rgba(190,245,255,0.8)',
        add: false,
        g: 260,
        drag: 2,
      });
    }
    for (let i = 0; i < 6; i++) {
      w.fx.emit({
        x: w.muzzle.x + rr(0, 20),
        y: w.muzzle.y + rr(-10, 10),
        vx: rr(70, 200),
        vy: rr(-30, 20),
        life: rr(0.5, 1.0),
        size: rr(12, 22),
        size1: 40,
        kind: 'smoke',
        color: 'rgba(190,235,250,1)',
        add: false,
        drag: 1.6,
      });
    }
  }

  drawBody(ctx: Ctx, _w: World) {
    const t = this.time;
    const fl = this.flare(5);
    const pulse = 0.5 + 0.5 * Math.sin(t * 1.9);

    /* ---------- pendar air ---------- */
    ctx.save();
    ctx.translate(30, 0);
    ctx.scale(1, 0.5);
    glow(ctx, 0, 0, 290, '#2fdbe8', 0.11 + 0.05 * pulse + 0.22 * fl);
    glow(ctx, -70, -20, 190, '#7ef0ff', 0.07 + 0.05 * pulse + 0.14 * fl);
    ctx.restore();

    /* ================= TANGKI AIR ================= */
    ctx.save();
    const tank = () => {
      ctx.beginPath();
      ctx.moveTo(-108, -84);
      ctx.quadraticCurveTo(-112, -100, -86, -102);
      ctx.lineTo(6, -102);
      ctx.quadraticCurveTo(32, -100, 32, -84);
      ctx.lineTo(32, -34);
      ctx.quadraticCurveTo(32, -22, 12, -22);
      ctx.lineTo(-88, -22);
      ctx.quadraticCurveTo(-108, -22, -108, -34);
      ctx.closePath();
    };
    tank();
    const tg = ctx.createLinearGradient(-110, -102, 34, -22);
    tg.addColorStop(0, 'rgba(210,250,255,0.9)');
    tg.addColorStop(0.5, 'rgba(120,215,240,0.65)');
    tg.addColorStop(1, 'rgba(30,110,150,0.8)');
    ctx.fillStyle = tg;
    ctx.fill();
    tank();
    ctx.clip();
    // permukaan air beriak
    const level = -62 + Math.sin(t * 1.4) * 2;
    const wg = ctx.createLinearGradient(0, level, 0, -22);
    wg.addColorStop(0, 'rgba(80,220,245,0.75)');
    wg.addColorStop(1, 'rgba(12,90,130,0.9)');
    ctx.fillStyle = wg;
    ctx.beginPath();
    ctx.moveTo(-120, level);
    for (let x = -120; x <= 44; x += 4) {
      ctx.lineTo(x, level + Math.sin(x * 0.08 + t * 2.4) * 2.4);
    }
    ctx.lineTo(44, -10);
    ctx.lineTo(-120, -10);
    ctx.closePath();
    ctx.fill();
    // gelembung naik
    for (const b of this.bubbles) {
      if (b.y > level) continue;
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.r, 0, TAU);
      ctx.strokeStyle = 'rgba(235,255,255,0.75)';
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.fillStyle = 'rgba(235,255,255,0.22)';
      ctx.fill();
    }
    // kilau kausal
    ctx.globalCompositeOperation = 'lighter';
    const cs = ((t * 0.3) % 1) * 260 - 140;
    const cg = ctx.createLinearGradient(cs - 40, -110, cs + 40, -10);
    cg.addColorStop(0, 'rgba(180,245,255,0)');
    cg.addColorStop(0.5, 'rgba(180,245,255,0.4)');
    cg.addColorStop(1, 'rgba(180,245,255,0)');
    ctx.fillStyle = cg;
    ctx.fillRect(-120, -110, 260, 110);
    ctx.restore();

    // tutup tangki
    ctx.beginPath();
    ctx.roundRect(-84, -112, 78, 14, 6);
    const cg2 = ctx.createLinearGradient(0, -112, 0, -98);
    cg2.addColorStop(0, '#eafcff');
    cg2.addColorStop(1, '#2c89ad');
    ctx.fillStyle = cg2;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.5)';
    ctx.lineWidth = 1;
    ctx.stroke();

    /* ================= BADAN ================= */
    const body = () => {
      ctx.beginPath();
      ctx.moveTo(-152, -30);
      ctx.quadraticCurveTo(-150, -44, -124, -46);
      ctx.lineTo(60, -50);
      ctx.quadraticCurveTo(128, -46, 158, -28);
      ctx.quadraticCurveTo(172, 0, 158, 28);
      ctx.quadraticCurveTo(128, 46, 60, 50);
      ctx.lineTo(-124, 46);
      ctx.quadraticCurveTo(-150, 44, -152, 30);
      ctx.quadraticCurveTo(-158, 0, -152, -30);
      ctx.closePath();
    };
    body();
    const bg = ctx.createLinearGradient(0, -50, 0, 50);
    bg.addColorStop(0, 'rgba(226,252,255,0.95)');
    bg.addColorStop(0.42, 'rgba(110,215,238,0.82)');
    bg.addColorStop(1, 'rgba(16,92,128,0.92)');
    ctx.fillStyle = bg;
    ctx.fill();
    ctx.save();
    body();
    ctx.clip();
    // aliran air dalam badan
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      for (let x = -160; x <= 170; x += 6) {
        const y = -14 + i * 16 + Math.sin(x * 0.03 + t * (1.4 + i * 0.3)) * 6;
        x === -160 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      ctx.strokeStyle = 'rgba(220,252,255,0.35)';
      ctx.lineWidth = 4 - i;
      ctx.stroke();
    }
    const hi = ctx.createLinearGradient(0, -50, 0, -6);
    hi.addColorStop(0, 'rgba(255,255,255,0.7)');
    hi.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = hi;
    ctx.fillRect(-160, -52, 330, 48);
    const lo = ctx.createLinearGradient(0, 16, 0, 52);
    lo.addColorStop(0, 'rgba(6,50,74,0)');
    lo.addColorStop(1, 'rgba(6,50,74,0.35)');
    ctx.fillStyle = lo;
    ctx.fillRect(-160, 16, 330, 40);
    // pelat logo
    ctx.fillStyle = 'rgba(255,255,255,0.22)';
    ctx.beginPath();
    ctx.roundRect(-118, -12, 74, 26, 6);
    ctx.fill();
    ctx.fillStyle = 'rgba(240,255,255,0.9)';
    ctx.font = 'bold 12px ui-sans-serif, system-ui, sans-serif';
    ctx.fillText('AQUA-9', -108, 6);
    ctx.restore();
    body();
    ctx.strokeStyle = 'rgba(255,255,255,0.65)';
    ctx.lineWidth = 1.3;
    ctx.stroke();

    /* ================= POMPA ================= */
    ctx.beginPath();
    ctx.roundRect(58, 16, 92, 34, 12);
    const pg = ctx.createLinearGradient(0, 16, 0, 50);
    pg.addColorStop(0, '#9df0fb');
    pg.addColorStop(1, '#136486');
    ctx.fillStyle = pg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.45)';
    ctx.lineWidth = 1;
    ctx.stroke();
    for (let i = 0; i < 7; i++) {
      const x = 66 + i * 12;
      ctx.strokeStyle = 'rgba(6,50,74,0.45)';
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(x, 20);
      ctx.lineTo(x, 46);
      ctx.stroke();
    }

    /* ================= GAGANG ================= */
    ctx.beginPath();
    ctx.moveTo(-116, 24);
    ctx.lineTo(-68, 30);
    ctx.lineTo(-48, 110);
    ctx.quadraticCurveTo(-50, 126, -68, 126);
    ctx.lineTo(-98, 126);
    ctx.quadraticCurveTo(-114, 124, -112, 108);
    ctx.lineTo(-116, 42);
    ctx.closePath();
    const gg = ctx.createLinearGradient(-112, 24, -52, 126);
    gg.addColorStop(0, '#b7f2fc');
    gg.addColorStop(0.5, '#3fa9c9');
    gg.addColorStop(1, '#0d4f6b');
    ctx.fillStyle = gg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.5)';
    ctx.lineWidth = 1.1;
    ctx.stroke();
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(-116, 24);
    ctx.lineTo(-68, 30);
    ctx.lineTo(-48, 110);
    ctx.quadraticCurveTo(-50, 126, -68, 126);
    ctx.lineTo(-98, 126);
    ctx.quadraticCurveTo(-114, 124, -112, 108);
    ctx.lineTo(-116, 42);
    ctx.closePath();
    ctx.clip();
    for (let i = 0; i < 5; i++) {
      ctx.strokeStyle = 'rgba(255,255,255,0.28)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-118, 52 + i * 14);
      ctx.lineTo(-52, 57 + i * 14);
      ctx.stroke();
    }
    ctx.restore();
    // pelindung picu
    ctx.save();
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#0d4f6b';
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.moveTo(-80, 34);
    ctx.bezierCurveTo(-76, 78, -26, 78, -18, 32);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(220,252,255,0.6)';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();

    /* ================= MONCONG ================= */
    for (let k = 0; k < 3; k++) {
      const x = 168 + k * 18;
      const ry = 30 - k * 3;
      ctx.beginPath();
      ctx.ellipse(x, 0, 6, ry, 0, 0, TAU);
      const ng = ctx.createLinearGradient(x, -ry, x, ry);
      ng.addColorStop(0, '#eafcff');
      ng.addColorStop(0.5, '#63c3dd');
      ng.addColorStop(1, '#12587a');
      ctx.fillStyle = ng;
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.55)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    // kepala semprot
    ctx.beginPath();
    ctx.roundRect(214, -18, 24, 36, 5);
    const sg = ctx.createLinearGradient(214, 0, 238, 0);
    sg.addColorStop(0, '#8fe6f7');
    sg.addColorStop(1, '#0c4c68');
    ctx.fillStyle = sg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.5)';
    ctx.lineWidth = 1;
    ctx.stroke();
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.arc(238, -11 + i * 7.4, 1.9, 0, TAU);
      ctx.fillStyle = 'rgba(225,252,255,0.9)';
      ctx.fill();
    }
    const mx = this.muzzle.x;
    const my = this.muzzle.y;
    glow(ctx, mx, my, 22 + 6 * pulse, '#8ff0ff', 0.45 + 0.2 * pulse);
    if (fl > 0.02) {
      glow(ctx, mx, my, 52 + 90 * fl, '#7fe8ff', 1.05 * fl);
      glow(ctx, mx, my, 22 + 26 * fl, '#ffffff', fl);
      star4(ctx, mx, my, 18 + 56 * fl, t * 2, '#ffffff', fl, 0.12);
    }

    /* ================= TETESAN & GELEMBUNG ================= */
    for (let i = 0; i < 3; i++) {
      const x = 226 + i * 3;
      const ph = (t * 1.4 + i * 0.37) % 1;
      if (ph < 0.8) {
        droplet(ctx, x, 16 + ph * 22, 2.6, 'rgba(190,240,255,0.7)', 0.8 * (1 - ph));
      }
    }
    for (let i = 0; i < 5; i++) {
      const ph = (t * 0.5 + i * 0.21) % 1;
      const bx = -120 + i * 62 + Math.sin(t * 1.2 + i) * 6;
      const by = 74 - ph * 46;
      ctx.beginPath();
      ctx.arc(bx, by, 2 + i % 2, 0, TAU);
      ctx.strokeStyle = 'rgba(210,250,255,0.5)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    glow(ctx, 40, -60, 120 + 20 * pulse, '#7fe8ff', 0.06 + 0.05 * pulse + 0.2 * fl);
    void smooth;
  }
}

/* ================================ PELURU ================================ */

class WaterBlob extends Flight {
  constructor(w: World) {
    super(w, 1180, 0.1, 0.5, 0.2);
    this.trailMax = 16;
  }
  onMove(_dt: number, w: World) {
    for (let i = 0; i < 2; i++) {
      w.fx.emit({
        x: this.pos.x + rr(-8, 8),
        y: this.pos.y + rr(-8, 8),
        vx: rr(-30, 30),
        vy: rr(-30, 30),
        life: rr(0.35, 0.8),
        size: rr(2.5, 5.5),
        kind: 'dot',
        color: 'rgba(190,240,255,0.75)',
        add: false,
        g: 120,
        drag: 2,
      });
    }
    if (Math.random() < 0.5)
      w.fx.emit({
        x: this.pos.x,
        y: this.pos.y,
        life: 0.5,
        size: 16,
        size1: 30,
        kind: 'smoke',
        color: 'rgba(185,235,252,1)',
        add: false,
        drag: 2,
      });
  }
  onHit(w: World, x: number, y: number) {
    w.add(new SplashBurst(x, y, w));
    w.target.hit('#7fe8ff');
    w.target.impulse(Math.cos(this.heading) * 120, Math.sin(this.heading) * 120);
    w.shake(2.2);
  }
  draw(ctx: Ctx) {
    const { x, y } = this.pos;
    const n = this.trail.length;
    ctx.save();
    ctx.lineCap = 'round';
    for (let i = 1; i < n; i++) {
      const k = i / n;
      const a = this.trail[i - 1];
      const b = this.trail[i];
      ctx.strokeStyle = `rgba(150,225,250,${0.3 * k})`;
      ctx.lineWidth = 2 + 12 * k;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
    ctx.restore();
    lens(ctx, x, y, 32, 1.35, this.age * 2);
    glow(ctx, x, y, 40, '#2fdbe8', 0.6);
    const g = ctx.createRadialGradient(x - 6, y - 7, 2, x, y, 21);
    g.addColorStop(0, 'rgba(255,255,255,0.95)');
    g.addColorStop(0.32, 'rgba(175,238,252,0.85)');
    g.addColorStop(0.72, 'rgba(45,190,220,0.6)');
    g.addColorStop(1, 'rgba(20,110,150,0.12)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, 21, 0, TAU);
    ctx.fill();
    // pusaran dalam
    for (let k = 0; k < 2; k++) {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(this.age * (k ? -6 : 8));
      ctx.beginPath();
      ctx.arc(0, 0, 12 - k * 4, 0.3, 2.2);
      ctx.strokeStyle = 'rgba(255,255,255,0.85)';
      ctx.lineWidth = 2.2;
      ctx.stroke();
      ctx.restore();
    }
    // sorot
    ctx.beginPath();
    ctx.arc(x - 7, y - 8, 5.5, 0, TAU);
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.fill();
    star4(ctx, x - 6, y - 7, 9, 0.6, '#ffffff', 0.7);
  }
}

/* ================================ TUMBUKAN ================================ */

class SplashBurst implements Entity {
  dead = false;
  layer: 0 | 1 = 1;
  age = 0;
  constructor(
    private x: number,
    private y: number,
    w: World,
  ) {
    // mahkota percikan
    for (let i = 0; i < 34; i++) {
      const a = rr(0, TAU);
      const sp = rr(120, 420);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 120,
        life: rr(0.5, 1.1),
        size: rr(2.5, 6),
        kind: 'dot',
        color: 'rgba(205,248,255,0.85)',
        add: false,
        g: 620,
        drag: 1.1,
      });
    }
    for (let i = 0; i < 12; i++) {
      const a = rr(0, TAU);
      const sp = rr(60, 220);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.7, 1.4),
        size: rr(18, 34),
        size1: 62,
        kind: 'smoke',
        color: 'rgba(195,238,252,1)',
        add: false,
        drag: 1.4,
        g: -40,
      });
    }
    for (let i = 0; i < 10; i++) {
      const a = rr(0, TAU);
      const sp = rr(40, 180);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.5, 1.0),
        size: rr(3, 7),
        kind: 'glow',
        color: '#7fe8ff',
        drag: 2.4,
      });
    }
    addFlash(w, x, y, 22, 150, 0.42, '#9ff0ff', 1);
    addRing(w, x, y, 10, 210, 0.7, '#d8f9ff', 4, 0.3, 0.95);
    addRing(w, x, y, 10, 160, 0.5, '#ffffff', 2, 0.2, 0.9, easeOutCubic, true, 0.08);
  }
  update(dt: number) {
    this.age += dt;
    if (this.age > 1.1) this.dead = true;
  }
  draw(ctx: Ctx) {
    const { x, y } = this;
    const a = this.age;
    if (a < 0.55) {
      const e = easeOutCubic(a / 0.55);
      const R = 22 + 130 * e;
      const k = 1 - a / 0.55;
      // kubah air
      const g = ctx.createRadialGradient(x, y, 0, x, y, R);
      g.addColorStop(0, `rgba(240,253,255,${0.5 * k})`);
      g.addColorStop(0.7, `rgba(120,215,240,${0.22 * k})`);
      g.addColorStop(1, 'rgba(120,215,240,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(x, y, R, 0, TAU);
      ctx.fill();
      // riak
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      for (let i = 0; i < 3; i++) {
        const e2 = clamp((a - i * 0.06) / 0.55, 0, 1);
        ctx.beginPath();
        ctx.ellipse(x, y, R * (0.6 + i * 0.28) * e2 * 1.3, R * (0.22 + i * 0.07), 0, 0, TAU);
        ctx.strokeStyle = `rgba(225,252,255,${0.5 * (1 - e2)})`;
        ctx.lineWidth = 3 - i * 0.6;
        ctx.stroke();
      }
      ctx.restore();
      glow(ctx, x, y, 60 + 120 * e, '#7fe8ff', 0.5 * k);
    }
  }
}
