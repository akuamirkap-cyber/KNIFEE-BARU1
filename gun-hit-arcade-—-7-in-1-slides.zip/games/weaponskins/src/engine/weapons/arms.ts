import { glow, lens, star4 } from '../gfx';
import { addFlash, addRing, Timed } from '../particles';
import type { Ctx, Entity, World } from '../types';
import { clamp, easeOutCubic, pick, rr, TAU } from '../util';
import { Flight, Weapon, type Bounds, type Features, type Theme } from '../weapon';

/* ============================ DETAIL BERSAMA ============================ */

function metal(ctx: Ctx, _x0: number, y0: number, _x1: number, y1: number, light: string, dark: string) {
  const g = ctx.createLinearGradient(0, y0, 0, y1);
  g.addColorStop(0, light);
  g.addColorStop(0.42, dark);
  g.addColorStop(1, light);
  return g;
}

function wood(ctx: Ctx, x0: number, y0: number, x1: number, y1: number) {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  g.addColorStop(0, '#c97b32');
  g.addColorStop(0.45, '#8f4c16');
  g.addColorStop(1, '#4b2408');
  return g;
}

function grain(ctx: Ctx, x0: number, x1: number, y0: number, y1: number, n: number, alpha = 0.22) {
  ctx.save();
  ctx.strokeStyle = `rgba(255,190,120,${alpha})`;
  ctx.lineWidth = 1.2;
  for (let i = 0; i < n; i++) {
    const u = i / n;
    const y = y0 + (y1 - y0) * u;
    ctx.beginPath();
    ctx.moveTo(x0, y);
    ctx.quadraticCurveTo((x0 + x1) / 2, y + 4, x1, y - 2);
    ctx.stroke();
  }
  ctx.restore();
}

function rivet(ctx: Ctx, x: number, y: number, r = 2.6, light = '#b9c3cd', dark = '#22272e') {
  const g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r);
  g.addColorStop(0, light);
  g.addColorStop(1, dark);
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, TAU);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.16)';
  ctx.lineWidth = 0.7;
  ctx.stroke();
}

function serrations(ctx: Ctx, x0: number, x1: number, y0: number, y1: number, n: number) {
  const step = (x1 - x0) / n;
  for (let i = 0; i < n; i++) {
    const x = x0 + i * step;
    const g = ctx.createLinearGradient(x, 0, x + step * 0.55, 0);
    g.addColorStop(0, 'rgba(255,255,255,0.22)');
    g.addColorStop(1, 'rgba(0,0,0,0.32)');
    ctx.fillStyle = g;
    ctx.fillRect(x, y0, step * 0.55, y1 - y0);
  }
}

/** Selongsong kuningan yang terpelanting */
class Casing implements Entity {
  dead = false;
  layer: 0 | 1 = 1;
  rot = rr(0, TAU);
  age = 0;
  constructor(
    public x: number,
    public y: number,
    public vx: number,
    public vy: number,
    public vr: number,
    public len: number,
    public r: number,
  ) {}
  update(dt: number, w: World) {
    this.age += dt;
    this.vy += 1500 * dt;
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    this.rot += this.vr * dt;
    if (this.y > w.height + 60 || this.age > 3) this.dead = true;
  }
  draw(ctx: Ctx) {
    const cs = Math.abs(Math.cos(this.rot));
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(Math.sin(this.rot * 0.6) * 0.8);
    const L = this.len;
    const R = this.r * (0.35 + 0.65 * cs);
    const g = ctx.createLinearGradient(0, -R, 0, R);
    g.addColorStop(0, '#ffe9a8');
    g.addColorStop(0.35, '#d5a12c');
    g.addColorStop(0.7, '#8d5f12');
    g.addColorStop(1, '#e8c25c');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.roundRect(-L / 2, -R, L, R * 2, R * 0.5);
    ctx.fill();
    ctx.fillStyle = '#f2d176';
    ctx.fillRect(-L / 2 - 1.6, -R * 1.12, 3.2, R * 2.24);
    ctx.strokeStyle = 'rgba(120,80,10,0.5)';
    ctx.lineWidth = 0.8;
    ctx.stroke();
    ctx.restore();
  }
}

type ImpactFn = (w: World, x: number, y: number, heading: number) => void;

/** Peluru dengan jejak panas */
class Round extends Flight {
  constructor(
    w: World,
    private o: {
      speed: number;
      size: number;
      core: string;
      trail: string;
      len: number;
      impact: ImpactFn;
      trailMax?: number;
    },
  ) {
    super(w, o.speed, 0.12, 0.5, 0.13);
    this.trailMax = o.trailMax ?? 12;
  }
  onMove(_dt: number, w: World) {
    w.fx.emit({
      x: this.pos.x,
      y: this.pos.y,
      life: 0.22,
      size: this.o.size * 2.6,
      size1: 1,
      kind: 'glow',
      color: this.o.trail,
    });
    if (Math.random() < 0.5)
      w.fx.emit({
        x: this.pos.x,
        y: this.pos.y,
        vx: rr(-40, 40),
        vy: rr(-40, 40),
        life: rr(0.2, 0.45),
        size: rr(1, 2.2),
        kind: 'streak',
        color: this.o.trail,
        drag: 3,
      });
  }
  onHit(w: World, x: number, y: number) {
    this.o.impact(w, x, y, this.heading);
  }
  draw(ctx: Ctx) {
    const { x, y } = this.pos;
    const n = this.trail.length;
    const ca = Math.cos(this.heading);
    const sa = Math.sin(this.heading);
    if (n > 1) {
      const t0 = this.trail[Math.max(0, n - 9)];
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.lineCap = 'round';
      const g = ctx.createLinearGradient(t0.x, t0.y, x, y);
      g.addColorStop(0, 'rgba(255,180,90,0)');
      g.addColorStop(1, this.o.core);
      ctx.strokeStyle = g;
      ctx.lineWidth = this.o.size * 1.15;
      ctx.beginPath();
      ctx.moveTo(t0.x, t0.y);
      ctx.lineTo(x, y);
      ctx.stroke();
      ctx.restore();
    }
    glow(ctx, x, y, this.o.size * 7, this.o.trail, 0.75);
    // badan peluru
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(this.heading);
    const L = this.o.len;
    const R = this.o.size;
    const g2 = ctx.createLinearGradient(0, -R, 0, R);
    g2.addColorStop(0, '#fff4d6');
    g2.addColorStop(0.4, '#e8a24a');
    g2.addColorStop(1, '#7d4212');
    ctx.fillStyle = g2;
    ctx.beginPath();
    ctx.moveTo(L * 0.5, 0);
    ctx.quadraticCurveTo(L * 0.16, -R, -L * 0.5, -R * 0.82);
    ctx.lineTo(-L * 0.5, R * 0.82);
    ctx.quadraticCurveTo(L * 0.16, R, L * 0.5, 0);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,235,190,0.8)';
    ctx.lineWidth = 0.9;
    ctx.stroke();
    // alur putaran
    ctx.strokeStyle = 'rgba(255,255,255,0.35)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 3; i++) {
      const px = -L * 0.32 + i * L * 0.22;
      ctx.beginPath();
      ctx.moveTo(px, -R * 0.9);
      ctx.lineTo(px + R * 0.6, R * 0.9);
      ctx.stroke();
    }
    ctx.restore();
    star4(ctx, x + ca * this.o.len * 0.35, y + sa * this.o.len * 0.35, this.o.size * 1.6, this.heading, '#ffffff', 0.7);
    void lens;
  }
}

/* ============================== EFEK TUMBUKAN ============================== */

function pistolImpact(w: World, x: number, y: number, heading: number) {
  for (let i = 0; i < 22; i++) {
    const a = heading + Math.PI + rr(-1.1, 1.1);
    const sp = rr(160, 560);
    w.fx.emit({
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp,
      life: rr(0.18, 0.45),
      size: rr(1, 2.2),
      kind: 'streak',
      color: pick(['#fff3c0', '#ffb347', '#ff7a2a']),
      drag: 4,
      len: 0.05,
    });
  }
  for (let i = 0; i < 6; i++) {
    w.fx.emit({
      x,
      y,
      vx: rr(-120, 120),
      vy: rr(-120, 120),
      life: rr(0.25, 0.5),
      size: rr(5, 10),
      kind: 'star',
      rot: rr(0, 3),
      vr: rr(-5, 5),
      color: '#ffffff',
      drag: 3,
    });
  }
  for (let i = 0; i < 4; i++) {
    w.fx.emit({
      x: x + rr(-6, 6),
      y: y + rr(-6, 6),
      vx: rr(-40, 40),
      vy: rr(-30, 30),
      life: rr(0.6, 1.1),
      size: rr(12, 20),
      size1: 38,
      kind: 'smoke',
      color: 'rgba(150,150,158,1)',
      add: false,
      drag: 1.6,
    });
  }
  addFlash(w, x, y, 8, 62, 0.24, '#ffe6b0', 1);
  addRing(w, x, y, 4, 54, 0.34, '#ffe6b0', 1.8, 0.2, 0.9);
  w.target.hit('#cfe9ff');
  w.target.impulse(Math.cos(heading) * 70, Math.sin(heading) * 70);
  w.shake(1.1);
}

function akImpact(w: World, x: number, y: number, heading: number) {
  for (let i = 0; i < 30; i++) {
    const a = heading + Math.PI + rr(-1.35, 1.35);
    const sp = rr(140, 620);
    w.fx.emit({
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp - 80,
      life: rr(0.3, 0.7),
      size: rr(1.1, 2.6),
      kind: 'streak',
      color: pick(['#fff3c0', '#ffb347', '#ff7a2a', '#ffd98a']),
      drag: 3,
      g: 320,
      len: 0.05,
    });
  }
  for (let i = 0; i < 16; i++) {
    const a = rr(0, TAU);
    const sp = rr(90, 340);
    w.fx.emit({
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp - 120,
      life: rr(0.5, 1.1),
      size: rr(2.5, 5.5),
      kind: 'dot',
      color: 'rgba(120,86,58,0.9)',
      add: false,
      g: 720,
    });
  }
  for (let i = 0; i < 8; i++) {
    w.fx.emit({
      x: x + rr(-10, 10),
      y: y + rr(-10, 10),
      vx: rr(-60, 60),
      vy: rr(-70, 20),
      life: rr(0.8, 1.5),
      size: rr(14, 26),
      size1: 52,
      kind: 'smoke',
      color: 'rgba(122,98,78,1)',
      add: false,
      drag: 1.5,
      g: -40,
    });
  }
  addFlash(w, x, y, 12, 90, 0.3, '#ffce8a', 1);
  addRing(w, x, y, 6, 96, 0.45, '#ffce8a', 2.6, 0.25, 0.9);
  addRing(w, x, y, 6, 70, 0.3, '#ffffff', 1.6, 0.2, 0.8, easeOutCubic, true, 0.05);
  w.target.hit('#ffb066');
  w.target.impulse(Math.cos(heading) * 120, Math.sin(heading) * 120);
  w.shake(1.7);
}

function revImpact(w: World, x: number, y: number, heading: number) {
  for (let i = 0; i < 28; i++) {
    const a = rr(0, TAU);
    const sp = rr(140, 560);
    w.fx.emit({
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp,
      life: rr(0.3, 0.75),
      size: rr(1.2, 2.8),
      kind: 'streak',
      color: pick(['#fff6d6', '#ffc966', '#ff8f3a']),
      drag: 3.2,
      len: 0.05,
    });
  }
  for (let i = 0; i < 10; i++) {
    w.fx.emit({
      x,
      y,
      vx: rr(-180, 180),
      vy: rr(-180, 180),
      life: rr(0.35, 0.7),
      size: rr(6, 12),
      kind: 'star',
      rot: rr(0, 3),
      vr: rr(-4, 4),
      color: '#ffffff',
      drag: 2.6,
    });
  }
  for (let i = 0; i < 7; i++) {
    w.fx.emit({
      x: x + rr(-8, 8),
      y: y + rr(-8, 8),
      vx: rr(-70, 70),
      vy: rr(-60, 30),
      life: rr(1.0, 1.8),
      size: rr(16, 30),
      size1: 58,
      kind: 'smoke',
      color: 'rgba(168,158,150,1)',
      add: false,
      drag: 1.3,
      g: -50,
    });
  }
  addFlash(w, x, y, 16, 130, 0.4, '#ffd9a0', 1);
  addRing(w, x, y, 8, 130, 0.55, '#ffe3b0', 3.4, 0.25, 0.95);
  addRing(w, x, y, 8, 90, 0.34, '#ffffff', 2, 0.2, 0.9, easeOutCubic, true, 0.06);
  w.add(
    new Timed(0.36, (ctx, t) => {
      const e = easeOutCubic(t);
      lens(ctx, x, y, 20 + 110 * e, 1.5, t * 2, 1 - t);
    }),
  );
  w.target.hit('#ffd9a0');
  w.target.impulse(Math.cos(heading) * 200, Math.sin(heading) * 200);
  w.target.spin(1.4);
  w.shake(2.6);
}

/* ============================== KILATAN MONCONG ============================== */

function muzzleFlash(ctx: Ctx, x: number, y: number, s: number, t: number, warm: string) {
  if (s <= 0.02) return;
  glow(ctx, x, y, 34 * s + 26, warm, s);
  glow(ctx, x, y, 14 * s + 12, '#fff6dd', s);
  star4(ctx, x, y, 22 * s + 14, t * 2, '#fff6dd', s, 0.12);
  star4(ctx, x, y, 14 * s + 10, t * 2 + 0.78, warm, s * 0.9, 0.14);
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const g = ctx.createLinearGradient(x, y, x + 70 * s, y);
  g.addColorStop(0, `rgba(255,246,214,${0.75 * s})`);
  g.addColorStop(1, 'rgba(255,150,50,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(x, -13 * s);
  ctx.lineTo(x + 70 * s, -30 * s);
  ctx.lineTo(x + 70 * s, 30 * s);
  ctx.lineTo(x, 13 * s);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

/* ================================= PISTOL ================================= */

export class PistolGun extends Weapon {
  readonly id = 'pistol';
  readonly name = 'Pistol';
  readonly tagline = 'Presisi baja dingin — cepat, ringkas, mematikan';
  readonly accent = '#5ad2ff';
  readonly theme: Theme = { top: '#08111c', bottom: '#132a40', glow: '#4aa8ff' };
  readonly features: Features = {
    body: 'Seluncuran baja biru bergerigi, rel aksesori, grip polimer bertekstur, dan bidik besi.',
    bullet: 'Peluru tracer kecil berinti panas dengan jejak tipis yang tajam.',
    impact: 'Percikan bintang tajam, cincin tipis, dan asap tipis yang cepat hilang.',
    idle: 'Seluncuran bergeser saat menembak, peluru kuningan terpelanting dari lubang ejeksi.',
  };
  readonly bounds: Bounds = { x0: -128, x1: 240, y0: -72, y1: 132 };
  kick = 9;
  cooldown = 0.17;

  constructor() {
    super();
    this.muzzle = { x: 210, y: -8 };
  }

  protected fire(w: World) {
    w.add(
      new Round(w, {
        speed: 1900,
        size: 3.6,
        core: 'rgba(255,225,170,0.95)',
        trail: '#ffd9a0',
        len: 16,
        impact: pistolImpact,
      }),
    );
    w.add(new Casing(w.muzzle.x - 96, w.muzzle.y - 22, rr(190, 260), rr(-330, -220), rr(14, 26), 11, 3));
    w.shake(1.4);
    for (let i = 0; i < 8; i++) {
      w.fx.emit({
        x: w.muzzle.x,
        y: w.muzzle.y,
        vx: rr(120, 380),
        vy: rr(-70, 70),
        life: rr(0.16, 0.32),
        size: rr(1, 2.2),
        kind: 'streak',
        color: pick(['#ffe6b0', '#ffb347']),
        drag: 4,
      });
    }
    for (let i = 0; i < 3; i++) {
      w.fx.emit({
        x: w.muzzle.x + rr(0, 24),
        y: w.muzzle.y + rr(-8, 8),
        vx: rr(60, 190),
        vy: rr(-20, 20),
        life: rr(0.5, 1.0),
        size: rr(10, 18),
        size1: 34,
        kind: 'smoke',
        color: 'rgba(140,142,150,1)',
        add: false,
        drag: 1.7,
      });
    }
  }

  drawBody(ctx: Ctx, _w: World) {
    const t = this.time;
    const fl = this.flare(7);
    const slide = 26 * Math.exp(-this.since * 26);
    const trig = 1 - Math.min(1, this.since * 6);
    const pulse = 0.5 + 0.5 * Math.sin(t * 1.6);

    ctx.save();
    ctx.translate(40, -6);
    ctx.scale(1, 0.5);
    glow(ctx, 0, 0, 220, '#4aa8ff', 0.09 + 0.05 * pulse + 0.16 * fl);
    ctx.restore();

    /* ---- grip polimer ---- */
    ctx.beginPath();
    ctx.moveTo(-84, 16);
    ctx.lineTo(-18, 22);
    ctx.lineTo(-6, 108);
    ctx.quadraticCurveTo(-8, 122, -26, 123);
    ctx.lineTo(-72, 120);
    ctx.quadraticCurveTo(-88, 118, -86, 102);
    ctx.closePath();
    const gg = ctx.createLinearGradient(-88, 16, -6, 122);
    gg.addColorStop(0, '#2c3540');
    gg.addColorStop(0.5, '#1a2129');
    gg.addColorStop(1, '#0c1014');
    ctx.fillStyle = gg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.14)';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(-84, 16);
    ctx.lineTo(-18, 22);
    ctx.lineTo(-6, 108);
    ctx.quadraticCurveTo(-8, 122, -26, 123);
    ctx.lineTo(-72, 120);
    ctx.quadraticCurveTo(-88, 118, -86, 102);
    ctx.closePath();
    ctx.clip();
    for (let i = 0; i < 9; i++) {
      for (let k = 0; k < 7; k++) {
        ctx.fillStyle = 'rgba(255,255,255,0.07)';
        ctx.beginPath();
        ctx.arc(-84 + i * 10 + (k % 2) * 5, 24 + k * 13, 2.2, 0, TAU);
        ctx.fill();
      }
    }
    ctx.restore();
    // alas magasin
    ctx.beginPath();
    ctx.roundRect(-74, 110, 68, 14, 5);
    ctx.fillStyle = '#11161b';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.16)';
    ctx.stroke();

    /* ---- rangka + rel ---- */
    ctx.beginPath();
    ctx.moveTo(-92, 6);
    ctx.lineTo(150, 6);
    ctx.lineTo(150, 30);
    ctx.lineTo(96, 30);
    ctx.lineTo(88, 40);
    ctx.lineTo(-16, 40);
    ctx.lineTo(-24, 30);
    ctx.lineTo(-92, 30);
    ctx.closePath();
    const fg = ctx.createLinearGradient(0, 6, 0, 40);
    fg.addColorStop(0, '#48525e');
    fg.addColorStop(1, '#141a20');
    ctx.fillStyle = fg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.16)';
    ctx.lineWidth = 1;
    ctx.stroke();
    for (let i = 0; i < 5; i++) {
      const x = 104 + i * 9;
      ctx.fillStyle = 'rgba(0,0,0,0.5)';
      ctx.fillRect(x, 12, 5, 16);
    }

    /* ---- pelindung picu + picu ---- */
    ctx.save();
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#1a2129';
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.moveTo(-8, 38);
    ctx.bezierCurveTo(-2, 82, 62, 82, 70, 34);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.16)';
    ctx.lineWidth = 1.6;
    ctx.stroke();
    ctx.restore();
    ctx.save();
    ctx.translate(22, 38);
    ctx.rotate(trig * 0.34);
    ctx.beginPath();
    ctx.roundRect(-6, 0, 11, 34, 5);
    const tg = ctx.createLinearGradient(-6, 0, 5, 34);
    tg.addColorStop(0, '#5a6672');
    tg.addColorStop(1, '#161c22');
    ctx.fillStyle = tg;
    ctx.fill();
    ctx.restore();

    /* ---- seluncuran ---- */
    ctx.save();
    ctx.translate(-slide, 0);
    const sd = () => {
      ctx.beginPath();
      ctx.moveTo(-96, -38);
      ctx.lineTo(176, -38);
      ctx.quadraticCurveTo(196, -38, 196, -20);
      ctx.lineTo(196, 8);
      ctx.quadraticCurveTo(196, 16, 182, 16);
      ctx.lineTo(-96, 16);
      ctx.closePath();
    };
    sd();
    const sg = metal(ctx, 0, -38, 0, 16, '#9fb0c2', '#242c35');
    ctx.fillStyle = sg;
    ctx.fill();
    ctx.save();
    sd();
    ctx.clip();
    // sorot atas
    const hi = ctx.createLinearGradient(0, -38, 0, -10);
    hi.addColorStop(0, 'rgba(255,255,255,0.4)');
    hi.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = hi;
    ctx.fillRect(-100, -38, 300, 30);
    // gerigi
    serrations(ctx, -88, -30, -32, 12, 8);
    // port ejeksi
    ctx.beginPath();
    ctx.roundRect(48, -34, 62, 26, 4);
    const eg = ctx.createLinearGradient(48, -34, 110, -8);
    eg.addColorStop(0, '#0a0d11');
    eg.addColorStop(1, '#2b333c');
    ctx.fillStyle = eg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.18)';
    ctx.lineWidth = 1;
    ctx.stroke();
    // pelat nama
    ctx.fillStyle = 'rgba(220,235,255,0.28)';
    ctx.fillRect(-24, -12, 62, 3);
    ctx.fillRect(-24, -4, 44, 3);
    // kilau menyapu
    const sw = ((t * 0.28) % 1) * 420 - 220;
    ctx.globalCompositeOperation = 'lighter';
    const sgr = ctx.createLinearGradient(sw - 40, -40, sw + 40, 20);
    sgr.addColorStop(0, 'rgba(210,235,255,0)');
    sgr.addColorStop(0.5, 'rgba(210,235,255,0.32)');
    sgr.addColorStop(1, 'rgba(210,235,255,0)');
    ctx.fillStyle = sgr;
    ctx.fillRect(-100, -40, 300, 60);
    ctx.restore();
    sd();
    ctx.strokeStyle = 'rgba(255,255,255,0.3)';
    ctx.lineWidth = 1.1;
    ctx.stroke();
    // bidik
    ctx.beginPath();
    ctx.roundRect(150, -50, 12, 13, 2);
    ctx.fillStyle = '#20272f';
    ctx.fill();
    ctx.beginPath();
    ctx.roundRect(-72, -52, 32, 15, 3);
    ctx.fillStyle = '#20272f';
    ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,0.9)';
    ctx.fillRect(-62, -52, 12, 10);
    ctx.restore();

    /* ---- moncong ---- */
    const mx = this.muzzle.x;
    const my = this.muzzle.y;
    ctx.beginPath();
    ctx.ellipse(190, -8, 5, 12, 0, 0, TAU);
    ctx.fillStyle = '#05080b';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.25)';
    ctx.lineWidth = 1;
    ctx.stroke();
    muzzleFlash(ctx, mx, my, fl, t, '#ffb347');
  }
}

/* ================================== AK-47 ================================== */

export class Ak47Gun extends Weapon {
  readonly id = 'ak47';
  readonly name = 'AK-47';
  readonly tagline = 'Kayu panas, baja perkasa — tak pernah berhenti';
  readonly accent = '#ff8a2e';
  readonly theme: Theme = { top: '#170b05', bottom: '#3b1c07', glow: '#ff7a1e' };
  readonly features: Features = {
    body: 'Popor dan handguard kayu oranye, magasin melengkung bergerigi, gas tube berlubang, dan moncong miring.',
    bullet: 'Peluru runcing berjaket tembaga dengan jejak panas dan alur putaran.',
    impact: 'Semprotan tanah, percikan bara, dan awan debu yang naik perlahan.',
    idle: 'Bolt bergeser saat menembak, selongsong kuningan beterbangan, uap panas dari gas block.',
  };
  readonly bounds: Bounds = { x0: -212, x1: 268, y0: -86, y1: 132 };
  kick = 7;
  cooldown = 0.105;
  private heat = 0;

  constructor() {
    super();
    this.muzzle = { x: 252, y: -6 };
  }

  update(dt: number, w: World) {
    super.update(dt, w);
    this.heat = clamp(this.heat - dt * 0.5 + (this.since < 0.12 ? dt * 6 : 0), 0, 1);
  }

  protected fire(w: World) {
    w.add(
      new Round(w, {
        speed: 2100,
        size: 4.2,
        core: 'rgba(255,215,150,0.95)',
        trail: '#ffab52',
        len: 22,
        impact: akImpact,
        trailMax: 14,
      }),
    );
    w.add(new Casing(w.muzzle.x - 190, w.muzzle.y - 30, rr(230, 320), rr(-380, -260), rr(16, 28), 12, 3.2));
    w.shake(1.2);
    for (let i = 0; i < 10; i++) {
      w.fx.emit({
        x: w.muzzle.x,
        y: w.muzzle.y,
        vx: rr(180, 520),
        vy: rr(-90, 90),
        life: rr(0.16, 0.36),
        size: rr(1, 2.4),
        kind: 'streak',
        color: pick(['#ffe6b0', '#ffb347', '#ff7a2a']),
        drag: 4,
      });
    }
    for (let i = 0; i < 3; i++) {
      w.fx.emit({
        x: w.muzzle.x + rr(0, 30),
        y: w.muzzle.y + rr(-10, 10),
        vx: rr(80, 240),
        vy: rr(-24, 24),
        life: rr(0.5, 1.1),
        size: rr(12, 22),
        size1: 42,
        kind: 'smoke',
        color: 'rgba(128,110,92,1)',
        add: false,
        drag: 1.5,
      });
    }
  }

  drawBody(ctx: Ctx, _w: World) {
    const t = this.time;
    const fl = this.flare(9);
    const bolt = 20 * Math.exp(-this.since * 24);
    const pulse = 0.5 + 0.5 * Math.sin(t * 1.5);
    const heat = this.heat;

    ctx.save();
    ctx.translate(30, -6);
    ctx.scale(1, 0.5);
    glow(ctx, 0, 0, 280, '#ff7a1e', 0.1 + 0.05 * pulse + 0.18 * fl + 0.12 * heat);
    ctx.restore();

    /* ---- popor kayu ---- */
    ctx.beginPath();
    ctx.moveTo(-112, -14);
    ctx.lineTo(-206, -30);
    ctx.quadraticCurveTo(-214, -28, -214, -14);
    ctx.lineTo(-214, 22);
    ctx.quadraticCurveTo(-214, 32, -204, 30);
    ctx.lineTo(-112, 24);
    ctx.closePath();
    ctx.fillStyle = wood(ctx, -214, -30, -112, 30);
    ctx.fill();
    grain(ctx, -212, -116, -22, 22, 6, 0.28);
    ctx.strokeStyle = 'rgba(255,200,140,0.32)';
    ctx.lineWidth = 1.1;
    ctx.stroke();
    // pelat bahu
    ctx.beginPath();
    ctx.roundRect(-216, -30, 12, 62, 5);
    const bp = metal(ctx, 0, -30, 0, 32, '#8b95a0', '#22272d');
    ctx.fillStyle = bp;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.2)';
    ctx.stroke();

    /* ---- penerima ---- */
    const recv = () => {
      ctx.beginPath();
      ctx.moveTo(-118, -34);
      ctx.lineTo(52, -38);
      ctx.quadraticCurveTo(64, -38, 64, -24);
      ctx.lineTo(64, 30);
      ctx.quadraticCurveTo(64, 40, 52, 40);
      ctx.lineTo(-118, 36);
      ctx.closePath();
    };
    recv();
    ctx.fillStyle = metal(ctx, 0, -38, 0, 40, '#7b858f', '#1a1f24');
    ctx.fill();
    ctx.save();
    recv();
    ctx.clip();
    // tutup debu bergerigi
    const hi = ctx.createLinearGradient(0, -38, 0, -14);
    hi.addColorStop(0, 'rgba(255,255,255,0.32)');
    hi.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = hi;
    ctx.fillRect(-120, -38, 190, 26);
    for (let i = 0; i < 12; i++) {
      ctx.strokeStyle = 'rgba(0,0,0,0.35)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-110 + i * 13, -38);
      ctx.lineTo(-110 + i * 13, -18);
      ctx.stroke();
    }
    // tuas pemilih
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.fillRect(-120, 6, 190, 4);
    ctx.restore();
    recv();
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    ctx.lineWidth = 1.1;
    ctx.stroke();
    for (const [rx, ry] of [
      [-104, -22],
      [-104, 24],
      [-16, -26],
      [40, -26],
      [40, 26],
    ] as [number, number][])
      rivet(ctx, rx, ry);

    /* ---- tuas tarik (bolt) ---- */
    ctx.save();
    ctx.translate(-bolt, 0);
    ctx.beginPath();
    ctx.roundRect(6, -22, 30, 12, 4);
    ctx.fillStyle = '#39424b';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.25)';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.beginPath();
    ctx.roundRect(30, -22, 12, 26, 3);
    ctx.fillStyle = '#2b3239';
    ctx.fill();
    ctx.restore();

    /* ---- gas tube + handguard kayu ---- */
    ctx.beginPath();
    ctx.roundRect(-8, -58, 122, 22, 6);
    ctx.fillStyle = metal(ctx, 0, -58, 0, -36, '#7b858f', '#20262b');
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.2)';
    ctx.stroke();
    for (let i = 0; i < 6; i++) {
      ctx.beginPath();
      ctx.arc(6 + i * 18, -50, 2.6, 0, TAU);
      ctx.fillStyle = 'rgba(10,12,15,0.75)';
      ctx.fill();
    }
    ctx.beginPath();
    ctx.roundRect(-14, -34, 132, 62, 12);
    ctx.fillStyle = wood(ctx, -14, -34, 118, 28);
    ctx.fill();
    grain(ctx, -10, 114, -22, 18, 7, 0.3);
    ctx.strokeStyle = 'rgba(255,200,140,0.3)';
    ctx.lineWidth = 1.1;
    ctx.stroke();
    for (let i = 0; i < 4; i++) {
      ctx.strokeStyle = 'rgba(60,26,6,0.55)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(14 + i * 22, -32);
      ctx.lineTo(14 + i * 22, 26);
      ctx.stroke();
    }

    /* ---- laras + bidik depan + moncong ---- */
    ctx.beginPath();
    ctx.roundRect(116, -12, 92, 22, 6);
    ctx.fillStyle = metal(ctx, 0, -12, 0, 10, '#6f7983', '#191d22');
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.18)';
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(156, -46);
    ctx.lineTo(178, -46);
    ctx.lineTo(182, -12);
    ctx.lineTo(152, -12);
    ctx.closePath();
    ctx.fillStyle = metal(ctx, 0, -46, 0, -12, '#77818b', '#1d2228');
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.roundRect(163, -62, 6, 18, 2);
    ctx.fillStyle = '#12161a';
    ctx.fill();
    // moncong miring
    ctx.beginPath();
    ctx.moveTo(204, -18);
    ctx.lineTo(248, -14);
    ctx.lineTo(248, 8);
    ctx.lineTo(204, 12);
    ctx.closePath();
    ctx.fillStyle = metal(ctx, 0, -18, 0, 12, '#7d8791', '#1c2127');
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(226, -16);
    ctx.lineTo(232, -15);
    ctx.lineTo(232, 10);
    ctx.lineTo(226, 11);
    ctx.closePath();
    ctx.fillStyle = 'rgba(8,10,12,0.8)';
    ctx.fill();

    /* ---- magasin melengkung ---- */
    ctx.beginPath();
    ctx.moveTo(-22, 34);
    ctx.quadraticCurveTo(-4, 78, 34, 104);
    ctx.quadraticCurveTo(52, 116, 66, 100);
    ctx.quadraticCurveTo(34, 74, 18, 34);
    ctx.closePath();
    const mg = ctx.createLinearGradient(-22, 34, 66, 110);
    mg.addColorStop(0, '#4c555e');
    mg.addColorStop(1, '#191e23');
    ctx.fillStyle = mg;
    ctx.fill();
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(-22, 34);
    ctx.quadraticCurveTo(-4, 78, 34, 104);
    ctx.quadraticCurveTo(52, 116, 66, 100);
    ctx.quadraticCurveTo(34, 74, 18, 34);
    ctx.closePath();
    ctx.clip();
    for (let i = 0; i < 6; i++) {
      ctx.strokeStyle = 'rgba(255,255,255,0.14)';
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(-18 + i * 14, 32);
      ctx.quadraticCurveTo(4 + i * 14, 74, 36 + i * 14, 102);
      ctx.stroke();
    }
    ctx.restore();
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    ctx.lineWidth = 1.1;
    ctx.stroke();

    /* ---- grip kayu ---- */
    ctx.beginPath();
    ctx.moveTo(-104, 34);
    ctx.lineTo(-58, 38);
    ctx.lineTo(-46, 108);
    ctx.quadraticCurveTo(-48, 122, -66, 122);
    ctx.lineTo(-96, 118);
    ctx.quadraticCurveTo(-110, 116, -108, 100);
    ctx.closePath();
    ctx.fillStyle = wood(ctx, -110, 34, -46, 122);
    ctx.fill();
    grain(ctx, -108, -50, 46, 112, 5, 0.3);
    ctx.strokeStyle = 'rgba(255,200,140,0.3)';
    ctx.lineWidth = 1.1;
    ctx.stroke();

    /* ---- pelindung picu ---- */
    ctx.save();
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#20262b';
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.moveTo(-62, 38);
    ctx.bezierCurveTo(-58, 78, -8, 78, 0, 34);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.18)';
    ctx.lineWidth = 1.6;
    ctx.stroke();
    ctx.restore();

    /* ---- uap panas ---- */
    if (heat > 0.25) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.lineWidth = 1.4;
      for (let k = 0; k < 3; k++) {
        ctx.beginPath();
        for (let i = 0; i <= 16; i++) {
          const x = 20 + i * 9;
          const y = -66 - k * 8 - Math.sin(t * 2.2 + i * 0.6 + k) * 3 * (0.5 + heat);
          i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
        }
        ctx.strokeStyle = `rgba(255,170,90,${0.16 * heat})`;
        ctx.stroke();
      }
      ctx.restore();
    }

    const mx = this.muzzle.x;
    const my = this.muzzle.y;
    muzzleFlash(ctx, mx, my, fl, t, '#ff8a2e');
  }
}

/* ================================= REVOLVER ================================= */

export class RevolverGun extends Weapon {
  readonly id = 'revolver';
  readonly name = 'Revolver';
  readonly tagline = 'Magnum klasik — satu tembakan, satu keputusan';
  readonly accent = '#ffc25c';
  readonly theme: Theme = { top: '#0c0b14', bottom: '#241a2c', glow: '#ffb347' };
  readonly features: Features = {
    body: 'Baja biru gelap, silinder enam lubang yang berputar, rel berventilasi, dan grip kayu berukir.',
    bullet: 'Peluru timah besar berpita tembaga dengan alur putaran dan jejak panas tebal.',
    impact: 'Kilatan besar, cincin asap tebal, percikan bintang, dan distorsi udara sesaat.',
    idle: 'Silinder berputar setiap tembakan, palu turun, kilau menyapu baja biru.',
  };
  readonly bounds: Bounds = { x0: -168, x1: 252, y0: -78, y1: 132 };
  kick = 16;
  cooldown = 0.52;
  private shots = 0;
  private cyl = 0;

  constructor() {
    super();
    this.muzzle = { x: 228, y: -10 };
  }

  update(dt: number, w: World) {
    super.update(dt, w);
    const target = (this.shots * Math.PI) / 3 + 0.12 * Math.exp(-this.since * 8);
    this.cyl += (target - this.cyl) * (1 - Math.exp(-dt * 14));
  }

  protected fire(w: World) {
    this.shots++;
    w.add(
      new Round(w, {
        speed: 1650,
        size: 5.2,
        core: 'rgba(255,232,180,0.95)',
        trail: '#ffbe72',
        len: 24,
        impact: revImpact,
        trailMax: 13,
      }),
    );
    w.shake(2.4);
    for (let i = 0; i < 12; i++) {
      w.fx.emit({
        x: w.muzzle.x,
        y: w.muzzle.y,
        vx: rr(160, 520),
        vy: rr(-110, 110),
        life: rr(0.18, 0.4),
        size: rr(1.1, 2.6),
        kind: 'streak',
        color: pick(['#fff0c8', '#ffb347', '#ff8a2e']),
        drag: 3.6,
      });
    }
    for (let i = 0; i < 4; i++) {
      w.fx.emit({
        x: w.muzzle.x + rr(0, 30),
        y: w.muzzle.y + rr(-12, 12),
        vx: rr(70, 220),
        vy: rr(-30, 30),
        life: rr(0.7, 1.3),
        size: rr(14, 26),
        size1: 48,
        kind: 'smoke',
        color: 'rgba(150,140,132,1)',
        add: false,
        drag: 1.4,
      });
    }
  }

  drawBody(ctx: Ctx, _w: World) {
    const t = this.time;
    const fl = this.flare(5);
    const hammer = 1 - Math.min(1, this.since * 5.5);
    const pulse = 0.5 + 0.5 * Math.sin(t * 1.5);

    ctx.save();
    ctx.translate(30, -6);
    ctx.scale(1, 0.5);
    glow(ctx, 0, 0, 250, '#ffb347', 0.1 + 0.05 * pulse + 0.2 * fl);
    ctx.restore();

    /* ---- grip kayu ---- */
    const gripPath = () => {
      ctx.beginPath();
      ctx.moveTo(-122, 12);
      ctx.lineTo(-40, 24);
      ctx.lineTo(-32, 86);
      ctx.quadraticCurveTo(-30, 112, -62, 118);
      ctx.lineTo(-100, 114);
      ctx.quadraticCurveTo(-126, 106, -126, 72);
      ctx.closePath();
    };
    gripPath();
    ctx.fillStyle = wood(ctx, -126, 12, -32, 118);
    ctx.fill();
    ctx.save();
    gripPath();
    ctx.clip();
    // anyaman belah ketupat
    for (let i = -6; i < 12; i++) {
      ctx.strokeStyle = 'rgba(255,222,176,0.16)';
      ctx.lineWidth = 1.1;
      ctx.beginPath();
      ctx.moveTo(-130 + i * 15, 8);
      ctx.lineTo(-110 + i * 15, 122);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-130 + i * 15, 122);
      ctx.lineTo(-110 + i * 15, 8);
      ctx.stroke();
    }
    const ghl = ctx.createLinearGradient(-126, 12, -60, 118);
    ghl.addColorStop(0, 'rgba(255,235,190,0.35)');
    ghl.addColorStop(0.5, 'rgba(255,235,190,0)');
    ghl.addColorStop(1, 'rgba(60,26,4,0.35)');
    ctx.fillStyle = ghl;
    ctx.fillRect(-130, 8, 110, 118);
    ctx.restore();
    gripPath();
    ctx.strokeStyle = 'rgba(255,205,150,0.4)';
    ctx.lineWidth = 1.3;
    ctx.stroke();
    // baut grip
    rivet(ctx, -84, 74, 3.6, '#ffd98a', '#7a4c12');

    /* ---- kerangka ---- */
    ctx.beginPath();
    ctx.moveTo(-116, -34);
    ctx.lineTo(-16, -38);
    ctx.lineTo(-6, -22);
    ctx.lineTo(-6, 30);
    ctx.lineTo(-116, 34);
    ctx.closePath();
    ctx.fillStyle = metal(ctx, 0, -38, 0, 34, '#7a838f', '#151a21');
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    ctx.lineWidth = 1.1;
    ctx.stroke();

    /* ---- palu ---- */
    ctx.save();
    ctx.translate(-114, -32);
    ctx.rotate(-hammer * 0.6);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(-14, -12, -8, -30);
    ctx.lineTo(4, -34);
    ctx.quadraticCurveTo(10, -16, 12, -2);
    ctx.closePath();
    const hg = ctx.createLinearGradient(-14, -34, 12, 0);
    hg.addColorStop(0, '#9aa4af');
    hg.addColorStop(1, '#1c2229');
    ctx.fillStyle = hg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    ctx.stroke();
    ctx.restore();

    /* ---- silinder ---- */
    const cx = -62;
    const cy = -2;
    ctx.beginPath();
    ctx.roundRect(cx - 40, cy - 34, 80, 68, 16);
    const cg = ctx.createLinearGradient(0, cy - 34, 0, cy + 34);
    cg.addColorStop(0, '#8d97a3');
    cg.addColorStop(0.45, '#2a323b');
    cg.addColorStop(1, '#0f141a');
    ctx.fillStyle = cg;
    ctx.fill();
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(cx - 40, cy - 34, 80, 68, 16);
    ctx.clip();
    // alur antar ruang
    for (let i = 0; i < 6; i++) {
      const a = this.cyl + (i * TAU) / 6 + TAU / 12;
      const yy = cy + Math.sin(a) * 19;
      const depth = (Math.cos(a) + 1) / 2;
      ctx.save();
      ctx.globalAlpha = 0.25 + 0.3 * depth;
      const fg = ctx.createLinearGradient(cx - 20, yy - 9, cx + 20, yy + 9);
      fg.addColorStop(0, 'rgba(255,255,255,0)');
      fg.addColorStop(0.5, 'rgba(0,0,0,0.5)');
      fg.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = fg;
      ctx.fillRect(cx - 34, yy - 5, 68, 10);
      ctx.restore();
    }
    // lubang peluru
    for (let i = 0; i < 6; i++) {
      const a = this.cyl + (i * TAU) / 6;
      const yy = cy + Math.sin(a) * 19;
      const depth = (Math.cos(a) + 1) / 2;
      const r = 8.6 * (0.78 + 0.22 * depth);
      ctx.beginPath();
      ctx.arc(cx, yy, r, 0, TAU);
      const g2 = ctx.createRadialGradient(cx, yy - r * 0.35, r * 0.1, cx, yy, r);
      g2.addColorStop(0, `rgba(${Math.round(40 + 120 * depth)},${Math.round(48 + 124 * depth)},${Math.round(58 + 128 * depth)},1)`);
      g2.addColorStop(0.7, 'rgba(14,19,25,1)');
      g2.addColorStop(1, 'rgba(6,9,12,1)');
      ctx.fillStyle = g2;
      ctx.fill();
      ctx.beginPath();
      ctx.arc(cx, yy, r, Math.PI * 1.08, Math.PI * 1.92);
      ctx.strokeStyle = `rgba(226,240,255,${0.35 + 0.35 * depth})`;
      ctx.lineWidth = 1.4;
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx, yy, r * 0.55, 0, TAU);
      ctx.strokeStyle = 'rgba(255,255,255,0.12)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    const sg = ctx.createLinearGradient(cx - 40, cy - 34, cx + 20, cy + 20);
    sg.addColorStop(0, 'rgba(210,235,255,0.28)');
    sg.addColorStop(1, 'rgba(210,235,255,0)');
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = sg;
    ctx.fillRect(cx - 42, cy - 36, 84, 72);
    ctx.restore();
    ctx.beginPath();
    ctx.roundRect(cx - 40, cy - 34, 80, 68, 16);
    ctx.strokeStyle = 'rgba(255,255,255,0.3)';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    /* ---- rel berventilasi + laras ---- */
    ctx.beginPath();
    ctx.moveTo(-14, -44);
    ctx.lineTo(206, -40);
    ctx.lineTo(206, -26);
    ctx.lineTo(-14, -28);
    ctx.closePath();
    ctx.fillStyle = metal(ctx, 0, -44, 0, -26, '#8b95a1', '#222a32');
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    ctx.stroke();
    for (let i = 0; i < 9; i++) {
      const x = -2 + i * 23;
      ctx.fillStyle = 'rgba(8,11,15,0.85)';
      ctx.beginPath();
      ctx.roundRect(x, -42, 12, 13, 3);
      ctx.fill();
    }
    ctx.beginPath();
    ctx.moveTo(-14, -24);
    ctx.lineTo(214, -22);
    ctx.lineTo(214, 12);
    ctx.lineTo(-14, 22);
    ctx.closePath();
    ctx.fillStyle = metal(ctx, 0, -24, 0, 22, '#7e8792', '#181d23');
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    ctx.lineWidth = 1.1;
    ctx.stroke();
    // rel bawah (under-lug)
    ctx.beginPath();
    ctx.roundRect(-8, 8, 116, 18, 5);
    ctx.fillStyle = metal(ctx, 0, 8, 0, 26, '#5d6873', '#0d1216');
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.16)';
    ctx.stroke();
    ctx.beginPath();
    ctx.roundRect(20, 22, 66, 10, 4);
    ctx.fillStyle = '#141a20';
    ctx.fill();
    // pelat ukir
    ctx.fillStyle = 'rgba(255,215,150,0.55)';
    ctx.font = 'bold 11px ui-sans-serif, system-ui, sans-serif';
    ctx.fillText('.357', 120, 4);
    // bidik
    ctx.beginPath();
    ctx.roundRect(198, -52, 14, 12, 2);
    ctx.fillStyle = '#1b2027';
    ctx.fill();
    ctx.beginPath();
    ctx.roundRect(-22, -54, 22, 12, 3);
    ctx.fillStyle = '#1b2027';
    ctx.fill();

    /* ---- moncong ---- */
    const mx = this.muzzle.x;
    const my = this.muzzle.y;
    ctx.beginPath();
    ctx.ellipse(212, -6, 5, 12, 0, 0, TAU);
    ctx.fillStyle = '#05080b';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.3)';
    ctx.lineWidth = 1;
    ctx.stroke();

    /* ---- pelindung picu ---- */
    ctx.save();
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#1b2027';
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.moveTo(-52, 32);
    ctx.bezierCurveTo(-50, 72, 0, 74, 10, 28);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.16)';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();
    ctx.beginPath();
    ctx.roundRect(-24, 32, 11, 30, 5);
    const tg = ctx.createLinearGradient(-24, 32, -13, 62);
    tg.addColorStop(0, '#8d97a3');
    tg.addColorStop(1, '#1b2027');
    ctx.fillStyle = tg;
    ctx.fill();

    // kilau menyapu baja biru (hanya di permukaan logam)
    const sw = ((t * 0.3) % 1) * 460 - 230;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(-14, -44);
    ctx.lineTo(206, -40);
    ctx.lineTo(214, -22);
    ctx.lineTo(214, 12);
    ctx.lineTo(-14, 22);
    ctx.lineTo(-14, -28);
    ctx.closePath();
    ctx.moveTo(-116, -34);
    ctx.lineTo(-16, -38);
    ctx.lineTo(-6, -22);
    ctx.lineTo(-6, 30);
    ctx.lineTo(-116, 34);
    ctx.closePath();
    ctx.moveTo(-8, 8);
    ctx.roundRect(-8, 8, 116, 18, 5);
    ctx.clip();
    ctx.globalCompositeOperation = 'lighter';
    const sgr = ctx.createLinearGradient(sw - 46, -56, sw + 46, 30);
    sgr.addColorStop(0, 'rgba(190,225,255,0)');
    sgr.addColorStop(0.5, 'rgba(190,225,255,0.3)');
    sgr.addColorStop(1, 'rgba(190,225,255,0)');
    ctx.fillStyle = sgr;
    ctx.fillRect(-220, -60, 460, 120);
    ctx.restore();

    muzzleFlash(ctx, mx, my, fl, t, '#ffcf82');
  }
}
