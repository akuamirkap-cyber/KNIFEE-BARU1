import { glow, polyPath, star4 } from '../gfx';
import { addFlash, addRing } from '../particles';
import type { Ctx, Entity, World } from '../types';
import { clamp, easeOutBack, easeOutCubic, hsl, hsla, pick, rr, TAU } from '../util';
import { Flight, Weapon, type Bounds, type Features, type Theme } from '../weapon';

/** palet gradasi: pink – cyan – ungu (dirotasi per kristal) */
const PALS: number[][] = [
  [326, 186, 268],
  [186, 268, 326],
  [268, 326, 186],
];

/** Kristal prisma heksagonal bertembus cahaya, pangkal di (x,y), ujung searah `ang` */
export function drawCrystal(
  ctx: Ctx,
  x: number,
  y: number,
  ang: number,
  len: number,
  wd: number,
  pal: number,
  t: number,
  alpha = 1,
  boost = 0,
  seed = 0,
  hueShift = 0,
) {
  if (len < 1) return;
  const P = PALS[pal % 3].map((h) => h + hueShift);
  const s = len * 0.74;
  const hw = wd / 2;
  const th = wd / 6;
  const faces: { pts: [number, number][]; l: number }[] = [
    {
      pts: [
        [0, -hw],
        [s, -hw],
        [len, 0],
        [s, -th],
        [0, -th],
      ],
      l: 72,
    },
    {
      pts: [
        [0, -th],
        [s, -th],
        [len, 0],
        [s, th],
        [0, th],
      ],
      l: 84,
    },
    {
      pts: [
        [0, th],
        [s, th],
        [len, 0],
        [s, hw],
        [0, hw],
      ],
      l: 54,
    },
  ];
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(ang);
  ctx.lineJoin = 'round';
  // fill
  for (const f of faces) {
    const g = ctx.createLinearGradient(0, 0, len, 0);
    const L = clamp(f.l + boost * 18, 0, 96);
    g.addColorStop(0, hsla(P[0], 92, L, 0.5 * alpha));
    g.addColorStop(0.5, hsla(P[1], 96, L + 4, 0.78 * alpha));
    g.addColorStop(1, hsla(P[2], 96, L + 8, 0.92 * alpha));
    polyPath(ctx, f.pts);
    ctx.fillStyle = g;
    ctx.fill();
  }
  // kilau menyapu di dalam kristal
  ctx.save();
  polyPath(ctx, [
    [0, -hw],
    [s, -hw],
    [len, 0],
    [s, hw],
    [0, hw],
  ]);
  ctx.clip();
  const bx = ((t * 0.45 + seed * 0.37) % 1.7) * len * 1.3 - len * 0.3;
  const bg = ctx.createLinearGradient(bx - len * 0.12, -hw, bx + len * 0.12, hw);
  bg.addColorStop(0, 'rgba(255,255,255,0)');
  bg.addColorStop(0.5, `rgba(255,255,255,${0.42 * alpha})`);
  bg.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = bg;
  ctx.fillRect(-2, -hw - 2, len + 4, wd + 4);
  ctx.restore();
  // inti cahaya
  const cg = ctx.createLinearGradient(len * 0.05, 0, len * 0.92, 0);
  cg.addColorStop(0, 'rgba(255,255,255,0)');
  cg.addColorStop(0.55, `rgba(255,255,255,${(0.55 + boost * 0.4) * alpha})`);
  cg.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.strokeStyle = cg;
  ctx.lineWidth = Math.max(1, wd * 0.07);
  ctx.beginPath();
  ctx.moveTo(len * 0.05, 0);
  ctx.lineTo(len * 0.92, 0);
  ctx.stroke();
  // tepi
  ctx.strokeStyle = hsla(P[1], 100, 90, 0.9 * alpha);
  ctx.lineWidth = 1.1;
  polyPath(ctx, [
    [0, -hw],
    [s, -hw],
    [len, 0],
    [s, hw],
    [0, hw],
  ], false);
  ctx.stroke();
  ctx.strokeStyle = `rgba(255,255,255,${0.5 * alpha})`;
  ctx.lineWidth = 0.9;
  ctx.beginPath();
  ctx.moveTo(0, -th);
  ctx.lineTo(s, -th);
  ctx.lineTo(len, 0);
  ctx.moveTo(0, th);
  ctx.lineTo(s, th);
  ctx.lineTo(len, 0);
  ctx.moveTo(s, -hw);
  ctx.lineTo(s, hw);
  ctx.stroke();
  // cahaya dari dalam
  glow(ctx, len * 0.5, 0, Math.max(len, wd * 1.6) * 0.75, hsl(P[1], 100, 62), (0.2 + boost * 0.35) * alpha);
  glow(ctx, len * 0.94, 0, wd * 0.9, hsl(P[2], 100, 75), (0.25 + boost * 0.5) * alpha);
  ctx.restore();
}

interface CrystalDef {
  x: number;
  y: number;
  a: number;
  l: number;
  w: number;
  p: number;
}
const BACK: CrystalDef[] = [
  { x: -88, y: -18, a: -1.95, l: 92, w: 30, p: 1 },
  { x: -104, y: 6, a: Math.PI + 0.1, l: 102, w: 42, p: 2 },
  { x: -64, y: 26, a: 1.85, l: 128, w: 42, p: 0 },
  { x: -28, y: -24, a: -1.25, l: 98, w: 30, p: 2 },
  { x: 24, y: -24, a: -0.92, l: 84, w: 26, p: 1 },
];
const FRONT: CrystalDef[] = [
  { x: -44, y: -2, a: 0, l: 278, w: 62, p: 0 },
  { x: 96, y: -28, a: -0.5, l: 58, w: 18, p: 2 },
  { x: 34, y: 22, a: 0.95, l: 72, w: 24, p: 1 },
  { x: -6, y: 28, a: 1.35, l: 62, w: 22, p: 2 },
  { x: 132, y: 22, a: 0.45, l: 48, w: 16, p: 0 },
];
const ROCK: [number, number][] = [
  [-152, 8],
  [-128, -26],
  [-84, -38],
  [-24, -34],
  [30, -20],
  [46, 18],
  [2, 38],
  [-58, 46],
  [-120, 36],
];

const MX = 234;

export class CrystalGun extends Weapon {
  readonly id = 'crystal';
  readonly name = 'Crystal Gun';
  readonly tagline = 'Kristal hidup yang terus tumbuh';
  readonly accent = '#ff8be8';
  readonly theme: Theme = { top: '#12062b', bottom: '#2c1052', glow: '#ff6fe0' };
  readonly features: Features = {
    body: 'Kristal tumbuh bergradasi pink–cyan–ungu yang tembus cahaya.',
    bullet: 'Pecahan kristal runcing dengan jejak cahaya pelangi.',
    impact: 'Kristal kecil tumbuh sesaat di titik tumbukan lalu pecah.',
    idle: 'Kristal berdenyut dengan cahaya lembut.',
  };
  readonly bounds: Bounds = { x0: -220, x1: 244, y0: -124, y1: 152 };
  kick = 13;
  cooldown = 0.3;
  private glints: { x: number; y: number; life: number; max: number; s: number }[] = [];
  private acc = 0;

  constructor() {
    super();
    this.muzzle = { x: MX, y: -2 };
  }

  update(dt: number, w: World) {
    super.update(dt, w);
    this.acc += dt * 6;
    while (this.acc > 1) {
      this.acc -= 1;
      const c = pick([...BACK, ...FRONT]);
      const u = rr(0.4, 1);
      this.glints.push({
        x: c.x + Math.cos(c.a) * c.l * u + rr(-4, 4),
        y: c.y + Math.sin(c.a) * c.l * u + rr(-4, 4),
        life: 0,
        max: rr(0.6, 1.3),
        s: rr(5, 11),
      });
    }
    for (let i = this.glints.length - 1; i >= 0; i--) {
      this.glints[i].life += dt;
      if (this.glints[i].life > this.glints[i].max) this.glints.splice(i, 1);
    }
  }

  protected fire(w: World) {
    w.add(new CrystalShard(w));
    w.shake(1.6);
    for (let i = 0; i < 12; i++) {
      const a = w.aim + rr(-0.5, 0.5);
      const sp = rr(120, 380);
      w.fx.emit({
        x: w.muzzle.x,
        y: w.muzzle.y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.3, 0.6),
        size: rr(4, 8),
        kind: 'shard',
        rot: a,
        vr: rr(-6, 6),
        color: hsla(pick([326, 186, 268]), 95, 75, 0.8),
        drag: 3,
        add: false,
      });
    }
  }

  private drawSet(ctx: Ctx, set: CrystalDef[], off: number, fl: number) {
    const t = this.time;
    set.forEach((c, i) => {
      const k = i + off;
      const pulse = 0.5 + 0.5 * Math.sin(t * 1.6 - k * 0.6);
      const gr = 1 + 0.018 * Math.sin(t * 1.4 + k * 1.3) + 0.04 * fl * (k % 2);
      drawCrystal(ctx, c.x, c.y, c.a + Math.sin(t * 0.8 + k) * 0.006, c.l * gr, c.w * (1 + 0.02 * pulse), c.p, t, 1, 0.12 + 0.25 * pulse + 0.9 * fl, k, Math.sin(t * 0.5 + k) * 14);
    });
  }

  drawBody(ctx: Ctx, _w: World) {
    const t = this.time;
    const fl = this.flare(5);
    const pulse = 0.5 + 0.5 * Math.sin(t * 1.6);

    // aura lembut berdenyut
    ctx.save();
    ctx.translate(10, 10);
    ctx.scale(1, 0.55);
    glow(ctx, 0, 0, 250, '#ff6fe0', 0.12 + 0.1 * pulse + 0.3 * fl);
    glow(ctx, 40, 0, 190, '#5be9ff', 0.08 + 0.08 * (1 - pulse) + 0.2 * fl);
    ctx.restore();

    // lapisan belakang
    this.drawSet(ctx, BACK, 0, fl);

    // batuan dasar (geode ungu)
    ctx.save();
    ctx.beginPath();
    const R = ROCK;
    ctx.moveTo((R[0][0] + R[R.length - 1][0]) / 2, (R[0][1] + R[R.length - 1][1]) / 2);
    for (let i = 0; i < R.length; i++) {
      const n = R[(i + 1) % R.length];
      ctx.quadraticCurveTo(R[i][0], R[i][1], (R[i][0] + n[0]) / 2, (R[i][1] + n[1]) / 2);
    }
    ctx.closePath();
    ctx.shadowColor = 'rgba(190,100,255,0.6)';
    ctx.shadowBlur = 18;
    const rg = ctx.createLinearGradient(-150, -40, 40, 46);
    rg.addColorStop(0, '#5b2da8');
    rg.addColorStop(0.5, '#2d1260');
    rg.addColorStop(1, '#170838');
    ctx.fillStyle = rg;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.lineWidth = 1.4;
    ctx.strokeStyle = hsla(290, 90, 75, 0.7);
    ctx.stroke();
    ctx.clip();
    ctx.strokeStyle = hsla(300, 80, 80, 0.28);
    ctx.lineWidth = 1;
    R.forEach((p, i) => {
      ctx.beginPath();
      ctx.moveTo(-50, 2);
      ctx.lineTo(p[0], p[1]);
      ctx.stroke();
      if (i % 2) {
        ctx.beginPath();
        const n = R[(i + 3) % R.length];
        ctx.moveTo(p[0], p[1]);
        ctx.lineTo(n[0], n[1]);
        ctx.stroke();
      }
    });
    glow(ctx, -50, 4, 70, '#c070ff', 0.25 + 0.2 * pulse);
    ctx.restore();

    // kristal kecil menempel pada batu
    const small = [
      { x: -130, y: 24, a: 2.4, l: 22, w: 9, p: 0 },
      { x: -100, y: 40, a: 1.9, l: 26, w: 10, p: 1 },
      { x: -10, y: 34, a: 1.2, l: 24, w: 9, p: 2 },
      { x: 20, y: -22, a: -0.4, l: 24, w: 9, p: 0 },
      { x: -120, y: -22, a: -2.5, l: 26, w: 10, p: 2 },
    ];
    small.forEach((c, i) => drawCrystal(ctx, c.x, c.y, c.a, c.l * (1 + 0.05 * Math.sin(t * 2 + i)), c.w, c.p, t, 1, 0.2 + 0.3 * pulse, i + 9));

    // lapisan depan (laras kristal utama)
    this.drawSet(ctx, FRONT, 5, fl);

    // kilau acak
    for (const g of this.glints) {
      const k = g.life / g.max;
      const a = Math.sin(k * Math.PI);
      star4(ctx, g.x, g.y, g.s * (0.4 + 0.6 * a), g.life * 1.5, '#ffffff', a, 0.16);
      glow(ctx, g.x, g.y, g.s * 1.8, hsl(g.x * 2 + t * 30, 100, 75), a * 0.55);
    }

    // kilatan moncong: duri kristal pelangi
    if (fl > 0.03) {
      const mx = MX;
      const my = this.muzzle.y;
      glow(ctx, mx, my, 40 + 80 * fl, '#ff9af0', 0.8 * fl);
      glow(ctx, mx, my, 26 + 20 * fl, '#ffffff', fl);
      for (let i = 0; i < 7; i++) {
        const a = -1.3 + i * 0.43;
        const ee = easeOutCubic(clamp(this.since / 0.12, 0, 1));
        drawCrystal(ctx, mx, my, a, 52 * ee * (0.6 + 0.4 * ((i + 1) % 2)), 9, i, t, fl, 0.6, i, i * 20);
      }
      star4(ctx, mx, my, 24 + 50 * fl, t * 2, '#ffffff', fl, 0.12);
    }
  }
}

/* =========================== PELURU KRISTAL =========================== */

class CrystalShard extends Flight {
  constructor(w: World) {
    super(w, 1300, 0.05, 0.45, 0.17);
    this.trailMax = 26;
  }
  spinAngle() {
    return this.age * 20;
  }
  onMove(_dt: number, w: World) {
    const h = (this.age * 300) % 360;
    w.fx.emit({
      x: this.pos.x + rr(-4, 4),
      y: this.pos.y + rr(-4, 4),
      vx: rr(-30, 30),
      vy: rr(-30, 30),
      life: rr(0.3, 0.6),
      size: rr(5, 10),
      size1: 1,
      kind: 'glow',
      color: hsl(h + rr(-30, 30), 100, 65),
      drag: 2.5,
    });
    if (Math.random() < 0.5)
      w.fx.emit({
        x: this.pos.x,
        y: this.pos.y,
        vx: rr(-50, 50),
        vy: rr(-50, 50),
        life: rr(0.4, 0.8),
        size: rr(2.5, 6),
        kind: 'star',
        rot: rr(0, 3),
        vr: rr(-5, 5),
        color: hsl(h + 60, 100, 85),
        drag: 2,
      });
  }
  onHit(w: World, x: number, y: number) {
    w.add(new CrystalGrowth(x, y, this.heading));
    w.target.hit('#ff9af0');
    w.target.impulse(Math.cos(this.heading) * 60, Math.sin(this.heading) * 60);
    w.shake(1.5);
  }
  draw(ctx: Ctx) {
    const n = this.trail.length;
    const { x, y } = this.pos;
    const nx = -Math.sin(this.heading);
    const ny = Math.cos(this.heading);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round';
    // jejak pelangi (dua helai berpilin)
    for (let strand = 0; strand < 2; strand++) {
      for (let i = 1; i < n; i++) {
        const k = i / n;
        const a = this.trail[i - 1];
        const b = this.trail[i];
        const o0 = Math.sin(this.age * 26 + (i - 1) * 0.55 + strand * Math.PI) * 4.5 * k;
        const o1 = Math.sin(this.age * 26 + i * 0.55 + strand * Math.PI) * 4.5 * k;
        ctx.strokeStyle = hsla(this.age * 320 + i * 16 + strand * 150, 100, 66, 0.85 * k);
        ctx.lineWidth = 0.8 + 4.5 * k;
        ctx.beginPath();
        ctx.moveTo(a.x + nx * o0, a.y + ny * o0);
        ctx.lineTo(b.x + nx * o1, b.y + ny * o1);
        ctx.stroke();
      }
    }
    // jejak inti putih
    if (n > 1) {
      const t0 = this.trail[Math.max(0, n - 12)];
      const lg = ctx.createLinearGradient(t0.x, t0.y, x, y);
      lg.addColorStop(0, 'rgba(255,255,255,0)');
      lg.addColorStop(1, 'rgba(255,255,255,0.9)');
      ctx.strokeStyle = lg;
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(t0.x, t0.y);
      ctx.lineTo(x, y);
      ctx.stroke();
    }
    ctx.restore();
    glow(ctx, x, y, 34, hsl(this.age * 300, 100, 65), 0.7);
    glow(ctx, x, y, 16, '#ffffff', 0.7);
    const L = 42;
    const roll = 0.55 + 0.45 * Math.abs(Math.cos(this.age * 18));
    drawCrystal(
      ctx,
      x - Math.cos(this.heading) * L * 0.55,
      y - Math.sin(this.heading) * L * 0.55,
      this.heading,
      L,
      15 * roll,
      Math.floor(this.age * 6) % 3,
      this.age,
      1,
      0.7,
      1,
      this.age * 100,
    );
  }
}

/* =========================== TUMBUKAN KRISTAL =========================== */

interface GItem {
  a: number;
  len: number;
  w: number;
  delay: number;
  pal: number;
  seed: number;
}

class CrystalGrowth implements Entity {
  dead = false;
  layer: 0 | 1 = 1;
  age = 0;
  items: GItem[] = [];
  shatterAt: number;
  readonly GROW = 0.3;
  private sparkAcc = 0;
  constructor(
    private x: number,
    private y: number,
    heading: number,
  ) {
    this.items.push({ a: heading + Math.PI + rr(-0.2, 0.2), len: 82, w: 30, delay: 0, pal: 0, seed: 1 });
    const base = rr(0, TAU);
    const N = 7;
    for (let i = 0; i < N; i++) {
      const len = rr(34, 64);
      this.items.push({
        a: base + (i * TAU) / N + rr(-0.25, 0.25),
        len,
        w: len * 0.36,
        delay: rr(0.03, 0.16),
        pal: i + 1,
        seed: i + 2,
      });
    }
    this.shatterAt = 0.16 + this.GROW + 0.32;
  }

  update(dt: number, w: World) {
    this.age += dt;
    this.sparkAcc += dt * 40;
    while (this.sparkAcc > 1 && this.age < this.shatterAt) {
      this.sparkAcc -= 1;
      const it = this.items[Math.floor(rr(0, this.items.length))];
      const g = easeOutBack(clamp((this.age - it.delay) / this.GROW, 0, 1));
      w.fx.emit({
        x: this.x + Math.cos(it.a) * it.len * g,
        y: this.y + Math.sin(it.a) * it.len * g,
        vx: rr(-30, 30),
        vy: rr(-30, 30),
        life: rr(0.3, 0.6),
        size: rr(3, 7),
        kind: 'star',
        rot: rr(0, 3),
        vr: rr(-4, 4),
        color: hsl(rr(180, 340), 100, 82),
        drag: 2,
      });
    }
    if (this.age >= this.shatterAt) {
      this.shatter(w);
      this.dead = true;
    }
  }

  private shatter(w: World) {
    const { x, y } = this;
    for (const it of this.items) {
      for (let k = 0; k < 5; k++) {
        const u = rr(0.2, 1);
        const px = x + Math.cos(it.a) * it.len * u;
        const py = y + Math.sin(it.a) * it.len * u;
        const a = Math.atan2(py - y, px - x) + rr(-0.6, 0.6);
        const sp = rr(120, 400);
        w.fx.emit({
          x: px,
          y: py,
          vx: Math.cos(a) * sp,
          vy: Math.sin(a) * sp - 40,
          life: rr(0.6, 1.2),
          size: rr(4, 10),
          kind: 'shard',
          rot: rr(0, TAU),
          vr: rr(-12, 12),
          color: hsla(pick([326, 186, 268]) + rr(-15, 15), 95, 74, 0.8),
          drag: 1.8,
          g: 480,
          add: false,
          fade: 0.7,
        });
      }
      w.fx.emit({
        x: x + Math.cos(it.a) * it.len * 0.6,
        y: y + Math.sin(it.a) * it.len * 0.6,
        life: 0.5,
        size: it.len * 0.9,
        size1: 4,
        kind: 'glow',
        color: hsl(pick([326, 186, 268]), 100, 70),
        drag: 2,
      });
    }
    for (let i = 0; i < 12; i++) {
      const a = rr(0, TAU);
      const sp = rr(40, 260);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.5, 1.0),
        size: rr(4, 9),
        kind: 'star',
        rot: rr(0, 3),
        vr: rr(-4, 4),
        color: hsl(rr(170, 340), 100, 85),
        drag: 2.4,
      });
    }
    addFlash(w, x, y, 30, 140, 0.5, '#ff9af0', 1);
    addFlash(w, x, y, 20, 90, 0.4, '#7ff3ff', 0.9);
    addRing(w, x, y, 10, 110, 0.55, '#ffffff', 2.4, 0.2, 0.9);
    addRing(w, x, y, 10, 140, 0.7, '#ff7de6', 1.6, 0.2, 0.8, easeOutCubic, true, 0.05);
    w.target.hit('#7ff3ff');
    w.target.impulse(rr(-60, 60), rr(-60, 60));
    w.shake(3);
  }

  draw(ctx: Ctx) {
    const { x, y } = this;
    const near = clamp((this.age - (this.shatterAt - 0.14)) / 0.14, 0, 1);
    const gk = easeOutBack(clamp(this.age / 0.3, 0, 1));
    glow(ctx, x, y, 70 * gk, '#ff7de6', 0.35 + 0.4 * near);
    glow(ctx, x, y, 45 * gk, '#7ff3ff', 0.3 + 0.3 * near);
    for (const it of this.items) {
      const g = easeOutBack(clamp((this.age - it.delay) / this.GROW, 0, 1));
      if (g <= 0.01) continue;
      const jx = near * rr(-1.6, 1.6);
      const jy = near * rr(-1.6, 1.6);
      drawCrystal(ctx, x + jx, y + jy, it.a, it.len * g, it.w * Math.min(1, g), it.pal, this.age, 1, 0.35 + near * 0.9, it.seed);
    }
  }
}
