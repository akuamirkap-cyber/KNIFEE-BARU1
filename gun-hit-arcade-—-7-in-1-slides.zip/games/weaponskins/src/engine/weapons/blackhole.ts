import { glow, lens } from '../gfx';
import { addFlash, addRing } from '../particles';
import type { Ctx, Entity, World } from '../types';
import { clamp, easeInCubic, easeOutCubic, lerp, pick, rr, smooth, TAU } from '../util';
import { Flight, Weapon, type Bounds, type Features, type Theme } from '../weapon';

const PUR = '#a64dff';
const LIL = '#e2c8ff';
const VIOLETS = ['#8a3dff', '#b36bff', '#d9a8ff', '#e14bff', '#6d2bd9'];

function neon(ctx: Ctx, color: string, lw = 1.4, a = 1) {
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  ctx.strokeStyle = color;
  ctx.globalAlpha = 0.2 * a;
  ctx.lineWidth = lw * 5;
  ctx.stroke();
  ctx.globalAlpha = 0.45 * a;
  ctx.lineWidth = lw * 2.2;
  ctx.stroke();
  ctx.globalAlpha = 0.95 * a;
  ctx.lineWidth = lw * 0.8;
  ctx.stroke();
  ctx.restore();
}

interface Sucked {
  ang: number;
  rho: number;
  w: number;
  size: number;
  px: number;
  py: number;
  hue: number;
}

const MX = 242;

export class BlackHoleGun extends Weapon {
  readonly id = 'blackhole';
  readonly name = 'Black Hole Gun';
  readonly tagline = 'Gravitasi dalam genggaman';
  readonly accent = '#b36bff';
  readonly theme: Theme = { top: '#040208', bottom: '#190b32', glow: '#8b3dff' };
  readonly features: Features = {
    body: 'Rangka hitam-ungu futuristik, sel energi neon, cincin gravitasi berputar di moncong.',
    bullet: 'Bola gelap kecil dengan cincin ungu berputar dan distorsi cahaya.',
    impact: 'Titik hitam menyedot partikel & menarik target, lalu meledak lembut.',
    idle: 'Partikel-partikel kecil tersedot masuk ke moncong.',
  };
  readonly bounds: Bounds = { x0: -196, x1: 256, y0: -62, y1: 134 };
  kick = 11;
  cooldown = 0.4;
  private sucked: Sucked[] = [];
  private acc = 0;

  constructor() {
    super();
    this.muzzle = { x: MX, y: 0 };
  }

  private spawnSucked(rho0: number, hueIdx?: number) {
    const ang = rr(0, TAU);
    this.sucked.push({
      ang,
      rho: rho0,
      w: rr(0.85, 1.2),
      size: rr(1.2, 3),
      px: MX + Math.cos(ang) * rho0 * 0.6,
      py: Math.sin(ang) * rho0,
      hue: hueIdx ?? Math.floor(rr(0, VIOLETS.length)),
    });
  }

  update(dt: number, w: World) {
    super.update(dt, w);
    this.acc += dt * 36;
    while (this.acc > 1) {
      this.acc -= 1;
      this.spawnSucked(rr(60, 118));
    }
    for (let i = this.sucked.length - 1; i >= 0; i--) {
      const p = this.sucked[i];
      p.px = MX + Math.cos(p.ang) * p.rho * 0.6;
      p.py = Math.sin(p.ang) * p.rho;
      p.rho -= (26 + 2100 / (p.rho + 14)) * dt;
      p.ang += (2.2 + 170 / (p.rho + 12)) * dt * p.w;
      if (p.rho < 3) this.sucked.splice(i, 1);
    }
  }

  protected fire(w: World) {
    w.add(new DarkOrb(w));
    w.shake(1.4);
    for (let i = 0; i < 24; i++) this.spawnSucked(rr(70, 140));
  }

  drawBody(ctx: Ctx, _w: World) {
    const t = this.time;
    const s = this.since;
    const fl = this.flare(6);
    const pulse = 0.5 + 0.5 * Math.sin(t * 2.4);
    const charge = s < 0.12 ? s / 0.12 : Math.exp(-(s - 0.12) * 7);

    // medan gravitasi di sekitar senjata
    ctx.save();
    ctx.translate(70, 0);
    ctx.scale(1, 0.42);
    glow(ctx, 0, 0, 230, '#7a2bff', 0.16 + 0.07 * pulse + 0.2 * fl);
    ctx.restore();
    glow(ctx, MX, 0, 90 + 30 * pulse, '#7a2bff', 0.3 + 0.12 * pulse + 0.4 * fl);

    // ===== gagang =====
    ctx.beginPath();
    ctx.moveTo(-106, 28);
    ctx.lineTo(-54, 34);
    ctx.lineTo(-34, 116);
    ctx.quadraticCurveTo(-35, 130, -50, 132);
    ctx.lineTo(-84, 134);
    ctx.quadraticCurveTo(-98, 132, -98, 120);
    ctx.closePath();
    const gg = ctx.createLinearGradient(-100, 30, -40, 130);
    gg.addColorStop(0, '#2a1250');
    gg.addColorStop(0.5, '#120a24');
    gg.addColorStop(1, '#05030a');
    ctx.fillStyle = gg;
    ctx.fill();
    neon(ctx, PUR, 1.1, 0.8);
    ctx.save();
    ctx.clip();
    ctx.strokeStyle = 'rgba(166,77,255,0.35)';
    ctx.lineWidth = 2;
    for (let i = 0; i < 6; i++) {
      ctx.beginPath();
      ctx.moveTo(-100, 60 + i * 13);
      ctx.lineTo(-40, 66 + i * 13);
      ctx.stroke();
    }
    ctx.restore();
    // pelindung picu
    ctx.beginPath();
    ctx.moveTo(-50, 40);
    ctx.quadraticCurveTo(-34, 82, 6, 46);
    neon(ctx, PUR, 1.1, 0.8);
    ctx.beginPath();
    ctx.moveTo(-34, 44);
    ctx.lineTo(-28, 64);
    neon(ctx, LIL, 1.4, 0.9);

    // ===== popor =====
    ctx.beginPath();
    ctx.moveTo(-194, -28);
    ctx.lineTo(-126, -44);
    ctx.lineTo(-126, 38);
    ctx.lineTo(-154, 36);
    ctx.lineTo(-186, 6);
    ctx.closePath();
    const sg = ctx.createLinearGradient(-190, -30, -130, 40);
    sg.addColorStop(0, '#35176a');
    sg.addColorStop(1, '#0a0512');
    ctx.fillStyle = sg;
    ctx.fill();
    neon(ctx, PUR, 1.2, 0.85);
    ctx.beginPath();
    ctx.moveTo(-182, -16);
    ctx.lineTo(-132, -29);
    neon(ctx, MAGENTA, 1.2, 0.6 + 0.4 * pulse);

    // ===== badan utama =====
    const body = () => {
      ctx.beginPath();
      ctx.moveTo(-124, -42);
      ctx.lineTo(-40, -56);
      ctx.lineTo(66, -56);
      ctx.lineTo(126, -42);
      ctx.lineTo(148, -27);
      ctx.lineTo(148, 27);
      ctx.lineTo(108, 38);
      ctx.lineTo(-18, 44);
      ctx.lineTo(-124, 36);
      ctx.closePath();
    };
    body();
    const bg = ctx.createLinearGradient(0, -56, 0, 44);
    bg.addColorStop(0, '#41207c');
    bg.addColorStop(0.35, '#1d0d3a');
    bg.addColorStop(1, '#06030c');
    ctx.fillStyle = bg;
    ctx.fill();
    ctx.save();
    body();
    ctx.clip();
    const sh = ctx.createLinearGradient(-124, -56, 40, 20);
    sh.addColorStop(0, 'rgba(200,150,255,0.22)');
    sh.addColorStop(0.5, 'rgba(200,150,255,0.03)');
    sh.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = sh;
    ctx.fillRect(-130, -60, 290, 110);
    // garis panel
    ctx.strokeStyle = 'rgba(166,77,255,0.35)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-124, 6);
    ctx.lineTo(-50, 6);
    ctx.lineTo(-30, 26);
    ctx.lineTo(70, 26);
    ctx.lineTo(100, 8);
    ctx.lineTo(148, 8);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(70, -26);
    ctx.lineTo(70, 26);
    ctx.moveTo(-50, -26);
    ctx.lineTo(-50, 6);
    ctx.stroke();
    // ventilasi
    ctx.strokeStyle = 'rgba(225,75,255,0.5)';
    ctx.lineWidth = 2;
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.moveTo(-112 + i * 9, 30);
      ctx.lineTo(-100 + i * 9, 12);
      ctx.stroke();
    }
    ctx.restore();
    neon(ctx, PUR, 1.3, 0.9);

    // ===== jendela sel energi =====
    ctx.beginPath();
    ctx.roundRect(-86, -45, 160, 18, 5);
    ctx.fillStyle = '#04020a';
    ctx.fill();
    ctx.strokeStyle = 'rgba(166,77,255,0.7)';
    ctx.lineWidth = 1;
    ctx.stroke();
    for (let i = 0; i < 10; i++) {
      const x = -82 + i * 15.6;
      const wave = Math.exp(-Math.pow(i - s * 46, 2) / 5) * (s < 0.4 ? 1 : 0);
      const b = clamp(0.3 + 0.5 * (0.5 + 0.5 * Math.sin(t * 4 - i * 0.7)) + wave, 0, 1);
      ctx.fillStyle = `rgba(${Math.round(150 + 90 * b)},${Math.round(60 + 160 * b)},255,${0.35 + 0.65 * b})`;
      ctx.beginPath();
      ctx.roundRect(x, -42, 12.5, 12, 2.5);
      ctx.fill();
      glow(ctx, x + 6, -36, 11 + 6 * wave, PUR, b * 0.55);
    }

    // ===== emblem lubang hitam di badan =====
    ctx.save();
    ctx.translate(18, 6);
    glow(ctx, 0, 0, 30, '#8b3dff', 0.35 + 0.15 * pulse);
    ctx.strokeStyle = LIL;
    ctx.lineWidth = 1.2;
    for (let k = 0; k < 3; k++) {
      ctx.beginPath();
      ctx.arc(0, 0, 9 + k * 4.5, t * (k % 2 ? -1.6 : 1.6) + k, t * (k % 2 ? -1.6 : 1.6) + k + 3.6 - k * 0.6);
      ctx.globalAlpha = 0.9 - k * 0.2;
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    ctx.fillStyle = '#000';
    ctx.beginPath();
    ctx.arc(0, 0, 6, 0, TAU);
    ctx.fill();
    ctx.restore();

    // ===== selongsong laras =====
    ctx.beginPath();
    ctx.moveTo(146, -24);
    ctx.lineTo(200, -15);
    ctx.lineTo(200, 15);
    ctx.lineTo(146, 24);
    ctx.closePath();
    const sgr = ctx.createLinearGradient(146, 0, 200, 0);
    sgr.addColorStop(0, '#1c0d38');
    sgr.addColorStop(0.5, '#47227f');
    sgr.addColorStop(1, '#14082a');
    ctx.fillStyle = sgr;
    ctx.fill();
    neon(ctx, PUR, 1.1, 0.8);
    for (let i = 0; i < 4; i++) {
      const x = 156 + i * 11;
      const b = 0.4 + 0.6 * (0.5 + 0.5 * Math.sin(t * 5 - i * 1.1));
      ctx.beginPath();
      ctx.moveTo(x, -22 + i * 1.8);
      ctx.lineTo(x, 22 - i * 1.8);
      ctx.strokeStyle = `rgba(200,150,255,${0.25 + 0.5 * b})`;
      ctx.lineWidth = 1.4;
      ctx.stroke();
    }
    // batang laras
    ctx.beginPath();
    ctx.roundRect(198, -7, MX - 198, 14, 4);
    const rg = ctx.createLinearGradient(0, -7, 0, 7);
    rg.addColorStop(0, '#5a2ea0');
    rg.addColorStop(1, '#0d0618');
    ctx.fillStyle = rg;
    ctx.fill();
    neon(ctx, PUR, 1, 0.7);

    // ===== cincin gravitasi di moncong =====
    const rings = [
      { x: 205, ry: 38, rx: 6.5, dir: 1 },
      { x: 218, ry: 31, rx: 5.5, dir: -1 },
      { x: 231, ry: 24, rx: 4.5, dir: 1 },
    ];
    rings.forEach((r, i) => {
      const ry = r.ry * (1 - 0.3 * charge) * (1 + 0.03 * Math.sin(t * 3 + i));
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(r.x, 0, r.rx, ry, 0, 0, TAU);
      const gr = ctx.createLinearGradient(r.x, -ry, r.x, ry);
      gr.addColorStop(0, '#6d2bd9');
      gr.addColorStop(0.5, '#e2c8ff');
      gr.addColorStop(1, '#6d2bd9');
      ctx.strokeStyle = gr;
      ctx.lineWidth = 3.4;
      ctx.stroke();
      ctx.restore();
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(r.x, 0, r.rx, ry, 0, 0, TAU);
      ctx.setLineDash([16, 12]);
      ctx.lineDashOffset = -t * 70 * r.dir * (1 + 3 * fl);
      neon(ctx, '#f1e3ff', 1.2, 0.7 + 0.3 * pulse + fl);
      ctx.restore();
      glow(ctx, r.x, 0, ry * 1.1, PUR, 0.08 + 0.12 * fl);
    });

    // ===== singularitas di ujung =====
    const R = 10.5;
    glow(ctx, MX, 0, 38, '#b36bff', 0.5 + 0.2 * pulse + 0.4 * fl);
    ctx.save();
    ctx.translate(MX, 0);
    // cincin akresi (separuh belakang)
    ctx.save();
    ctx.rotate(Math.PI / 2);
    ctx.scale(1, 0.22);
    ctx.beginPath();
    ctx.arc(0, 0, 26, Math.PI, TAU);
    neon(ctx, '#d9a8ff', 2.2, 0.7);
    ctx.restore();
    const dg = ctx.createRadialGradient(0, 0, 0, 0, 0, R);
    dg.addColorStop(0, '#000');
    dg.addColorStop(0.7, '#050210');
    dg.addColorStop(1, '#2a0e52');
    ctx.fillStyle = dg;
    ctx.beginPath();
    ctx.arc(0, 0, R, 0, TAU);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(0, 0, R + 1, -1.2, 1.6);
    neon(ctx, '#f1e3ff', 1.4, 0.9);
    ctx.save();
    ctx.rotate(Math.PI / 2);
    ctx.scale(1, 0.22);
    ctx.beginPath();
    ctx.arc(0, 0, 26, 0, Math.PI);
    neon(ctx, '#f6edff', 2.4, 0.95);
    ctx.restore();
    ctx.restore();

    // ===== implosi saat menembak =====
    if (s < 0.3) {
      const u = s / 0.3;
      const rad = lerp(76, 6, easeInCubic(u));
      const a = Math.sin(u * Math.PI);
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(MX + 8, 0, rad * 0.5, rad, 0, 0, TAU);
      ctx.strokeStyle = '#e2c8ff';
      ctx.globalAlpha = a;
      ctx.lineWidth = 2.5;
      ctx.globalCompositeOperation = 'lighter';
      ctx.stroke();
      ctx.restore();
    }
    if (fl > 0.03) {
      glow(ctx, MX + 6, 0, 30 + 60 * fl, '#d9a8ff', 0.8 * fl);
    }

    // ===== partikel tersedot ke moncong =====
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round';
    for (const p of this.sucked) {
      const fadeIn = clamp((118 - p.rho) / 14, 0, 1) + 0.0;
      const fadeOut = clamp((p.rho - 3) / 14, 0, 1);
      const a = Math.min(Math.max(fadeIn, 0.25), 1) * fadeOut;
      const col = VIOLETS[p.hue];
      ctx.globalAlpha = a * 0.85;
      ctx.strokeStyle = col;
      ctx.lineWidth = p.size * 0.8;
      ctx.beginPath();
      ctx.moveTo(p.px, p.py);
      const nx = MX + Math.cos(p.ang) * p.rho * 0.6;
      const ny = Math.sin(p.ang) * p.rho;
      ctx.lineTo(nx, ny);
      ctx.stroke();
      glow(ctx, nx, ny, p.size * 3.2, col, a);
    }
    ctx.restore();
  }
}

const MAGENTA = '#e14bff';

/* =========================== PELURU =========================== */

class DarkOrb extends Flight {
  constructor(w: World) {
    super(w, 880, 0.45, 0.7, 0.24);
    this.trailMax = 14;
  }
  onMove(_dt: number, w: World) {
    // jejak materi gelap
    w.fx.emit({
      x: this.pos.x + rr(-2, 2),
      y: this.pos.y + rr(-2, 2),
      vx: rr(-20, 20),
      vy: rr(-20, 20),
      life: rr(0.35, 0.6),
      size: 7,
      size1: 0.5,
      kind: 'dot',
      color: 'rgba(8,3,16,0.8)',
      add: false,
      drag: 2,
    });
    // partikel kecil terseret ke bola
    if (Math.random() < 0.8) {
      const a = rr(0, TAU);
      const r = rr(16, 28);
      const self = this;
      w.fx.emit({
        x: this.pos.x + Math.cos(a) * r,
        y: this.pos.y + Math.sin(a) * r,
        life: rr(0.22, 0.4),
        size: rr(2, 4),
        size1: 0.5,
        kind: 'glow',
        color: pick(VIOLETS),
        step: (p, dt) => {
          const dx = self.pos.x - p.x;
          const dy = self.pos.y - p.y;
          p.vx += (dx * 70 - dy * 18) * dt;
          p.vy += (dy * 70 + dx * 18) * dt;
          p.vx *= 0.92;
          p.vy *= 0.92;
        },
      });
    }
  }
  spinAngle() {
    return this.age * 6;
  }
  onHit(w: World, x: number, y: number) {
    w.add(new HoleFX(x, y));
    w.target.hit('#b36bff');
    w.shake(1.5);
  }
  draw(ctx: Ctx) {
    const { x, y } = this.pos;
    const n = this.trail.length;
    // ekor gelap
    ctx.save();
    ctx.lineCap = 'round';
    for (let i = 1; i < n; i++) {
      const k = i / n;
      ctx.strokeStyle = `rgba(14,4,28,${0.55 * k})`;
      ctx.lineWidth = 2 + 11 * k;
      ctx.beginPath();
      ctx.moveTo(this.trail[i - 1].x, this.trail[i - 1].y);
      ctx.lineTo(this.trail[i].x, this.trail[i].y);
      ctx.stroke();
      ctx.globalCompositeOperation = 'lighter';
      ctx.strokeStyle = `rgba(166,77,255,${0.4 * k})`;
      ctx.lineWidth = 1.4;
      ctx.stroke();
      ctx.globalCompositeOperation = 'source-over';
    }
    ctx.restore();

    lens(ctx, x, y, 30, 1.8, this.age * 3);
    glow(ctx, x, y, 34, '#7a2bff', 0.55);

    for (let k = 0; k < 2; k++) {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(this.age * 5 * (k ? -1 : 1) + k * 1.3);
      ctx.scale(1, k ? 0.36 : 0.26);
      ctx.beginPath();
      ctx.arc(0, 0, 18 + k * 2, 0, TAU);
      ctx.globalCompositeOperation = 'lighter';
      ctx.setLineDash([22, 7]);
      ctx.lineDashOffset = -this.age * 80;
      ctx.strokeStyle = k ? '#e14bff' : '#c28bff';
      ctx.lineWidth = 3;
      ctx.globalAlpha = 0.95;
      ctx.stroke();
      ctx.restore();
    }
    ctx.save();
    const g = ctx.createRadialGradient(x, y, 0, x, y, 10);
    g.addColorStop(0, '#000');
    g.addColorStop(0.65, '#06020e');
    g.addColorStop(1, '#2a0e52');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, 9.5, 0, TAU);
    ctx.fill();
    ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = '#d9b8ff';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.arc(x, y, 10, this.age * 4, this.age * 4 + 1.8);
    ctx.stroke();
    ctx.restore();
  }
}

/* =========================== TUMBUKAN =========================== */

interface Orbiter {
  ang: number;
  rho: number;
  delay: number;
  size: number;
  hue: number;
  dir: number;
  px: number;
  py: number;
  dead: boolean;
}

class HoleFX implements Entity {
  dead = false;
  layer: 0 | 1 = 1;
  age = 0;
  exploded = false;
  readonly SUCK = 1.05;
  parts: Orbiter[] = [];
  constructor(
    private x: number,
    private y: number,
  ) {
    for (let i = 0; i < 80; i++) {
      const ang = rr(0, TAU);
      const rho = rr(42, 135);
      this.parts.push({
        ang,
        rho,
        delay: rr(0, 0.55),
        size: rr(1.2, 3.2),
        hue: Math.floor(rr(0, VIOLETS.length)),
        dir: 1,
        px: x + Math.cos(ang) * rho,
        py: y + Math.sin(ang) * rho,
        dead: false,
      });
    }
  }

  update(dt: number, w: World) {
    this.age += dt;
    const { x, y } = this;
    if (this.age < this.SUCK) {
      const k = smooth(this.age / 0.4);
      w.target.pull(x, y, 24 * k);
      w.attract(x, y, 320, 620 * k, dt);
      for (const p of this.parts) {
        if (p.dead || this.age < p.delay) continue;
        p.px = x + Math.cos(p.ang) * p.rho;
        p.py = y + Math.sin(p.ang) * p.rho;
        p.rho -= (36 + 2600 / (p.rho + 16)) * dt;
        p.ang += (2.6 + 200 / (p.rho + 12)) * dt * p.dir;
        if (p.rho < 3) p.dead = true;
      }
      if (Math.random() < 0.5)
        w.fx.emit({
          x: x + rr(-3, 3),
          y: y + rr(-3, 3),
          life: 0.25,
          size: 10,
          size1: 2,
          kind: 'glow',
          color: '#8b3dff',
        });
    } else if (!this.exploded) {
      this.exploded = true;
      this.explode(w);
    }
    if (this.age > this.SUCK + 0.7) this.dead = true;
  }

  private explode(w: World) {
    const { x, y } = this;
    addFlash(w, x, y, 20, 150, 0.7, '#9b5bff', 1);
    addFlash(w, x, y, 10, 70, 0.35, '#f1e3ff', 1);
    addRing(w, x, y, 8, 140, 0.8, '#c28bff', 7, 0.5, 0.95);
    addRing(w, x, y, 8, 200, 1.1, '#7a2bff', 3, 0.2, 0.6, easeOutCubic, true, 0.07);
    for (let i = 0; i < 56; i++) {
      const a = rr(0, TAU);
      const sp = rr(50, 270);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.5, 1.0),
        size: rr(6, 16),
        size1: 1,
        kind: 'glow',
        color: pick(VIOLETS),
        drag: 3.2,
      });
    }
    for (let i = 0; i < 18; i++) {
      const a = rr(0, TAU);
      const sp = rr(120, 340);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.4, 0.8),
        size: rr(1, 2),
        kind: 'streak',
        color: '#efe0ff',
        drag: 3,
        len: 0.05,
      });
    }
    // dorong target keluar (pantulan lembut)
    const dx = w.target.x - x;
    const dy = w.target.y - y;
    const d = Math.hypot(dx, dy) || 1;
    w.target.impulse((dx / d) * 260, (dy / d) * 260);
    w.target.hit('#d9a8ff');
    w.target.spin(1.2);
    w.shake(3);
  }

  draw(ctx: Ctx) {
    const { x, y } = this;
    if (this.age < this.SUCK) {
      const grow = easeOutCubic(this.age / 0.3);
      const collapse = this.age > this.SUCK - 0.12 ? 1 - (this.age - (this.SUCK - 0.12)) / 0.12 : 1;
      const R = (2 + 7 * grow) * collapse;
      const sz = grow * collapse;
      lens(ctx, x, y, 58 * sz, 2.2, this.age * 6);
      glow(ctx, x, y, 66 * sz, '#7a2bff', 0.55);
      glow(ctx, x, y, 28 * sz, '#d9a8ff', 0.4);
      // cincin akresi (belakang)
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(-0.35);
      ctx.scale(1, 0.3);
      ctx.beginPath();
      ctx.arc(0, 0, 28 * sz, Math.PI, TAU);
      neon(ctx, '#c28bff', 2.4, 0.8);
      ctx.restore();
      // partikel tersedot
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.lineCap = 'round';
      for (const p of this.parts) {
        if (p.dead || this.age < p.delay) continue;
        const nx = x + Math.cos(p.ang) * p.rho;
        const ny = y + Math.sin(p.ang) * p.rho;
        const a = clamp((this.age - p.delay) / 0.12, 0, 1) * clamp(p.rho / 12, 0, 1);
        ctx.globalAlpha = a * 0.9;
        ctx.strokeStyle = VIOLETS[p.hue];
        ctx.lineWidth = p.size * 0.8;
        ctx.beginPath();
        ctx.moveTo(p.px, p.py);
        ctx.lineTo(nx, ny);
        ctx.stroke();
        glow(ctx, nx, ny, p.size * 3.4, VIOLETS[p.hue], a);
      }
      ctx.restore();
      // titik hitam
      if (R > 0.3) {
        ctx.save();
        ctx.fillStyle = '#000';
        ctx.beginPath();
        ctx.arc(x, y, R, 0, TAU);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(x, y, R + 1.6, 0, TAU);
        neon(ctx, '#f1e3ff', 1.1, 0.9);
        ctx.restore();
        // cincin akresi (depan)
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(-0.35);
        ctx.scale(1, 0.3);
        ctx.beginPath();
        ctx.arc(0, 0, 28 * sz, 0, Math.PI);
        neon(ctx, '#f6edff', 2.6, 0.95);
        ctx.restore();
      }
    } else {
      const tt = (this.age - this.SUCK) / 0.5;
      if (tt < 1) {
        const e = easeOutCubic(tt);
        lens(ctx, x, y, 30 + 150 * e, 1.5, tt * 2, 1 - tt);
      }
    }
  }
}
