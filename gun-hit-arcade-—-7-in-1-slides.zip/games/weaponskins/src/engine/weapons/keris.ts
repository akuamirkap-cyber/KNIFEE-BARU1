import { glow, star4 } from '../gfx';
import { addFlash, addRing, Timed } from '../particles';
import type { Ctx, World } from '../types';
import { clamp, easeOutCubic, pick, rr, smooth, TAU, type Vec } from '../util';
import { Flight, Weapon, type Bounds, type Features, type Theme } from '../weapon';

const BX0 = -30;
const BX1 = 242;
const LAM = 66;
const GOLDS = ['#fff1a8', '#ffd36a', '#ffb23a', '#ff8a2a', '#ff5a3a'];

function bladeY(u: number, t: number, since: number) {
  const ramp = smooth((u - 0.24) / 0.24);
  const A = 10 * (0.85 + 0.15 * (1 - u)) * ramp * (1 + 0.04 * Math.sin(t * 1.6));
  const phase = 0.4 + Math.sin(t * 1.0) * 0.12;
  let y = A * Math.sin(((BX1 - BX0) * u * TAU) / LAM + phase);
  y += 6.5 * Math.exp(-since * 4.5) * Math.sin(u * 11 - since * 36) * u;
  return y;
}
function bladeHalfW(u: number) {
  const taper = u > 0.93 ? (1 - u) / 0.07 : 1;
  return (3.4 + 22 * Math.pow(1 - u, 0.82)) * taper;
}

interface Blade {
  top: Vec[];
  bot: Vec[];
  mid: Vec[];
  nrm: Vec[];
}
function computeBlade(t: number, since: number, n = 84): Blade {
  const top: Vec[] = [];
  const bot: Vec[] = [];
  const mid: Vec[] = [];
  const nrm: Vec[] = [];
  const len = BX1 - BX0;
  for (let i = 0; i <= n; i++) {
    const u = i / n;
    const x = BX0 + len * u;
    const y = bladeY(u, t, since);
    const e = 0.003;
    const dy = (bladeY(Math.min(1, u + e), t, since) - bladeY(Math.max(0, u - e), t, since)) / (len * 2 * e);
    const nl = Math.hypot(dy, 1);
    const nx = -dy / nl;
    const ny = 1 / nl;
    const hw = bladeHalfW(u);
    mid.push({ x, y });
    nrm.push({ x: nx, y: ny });
    top.push({ x: x - nx * hw, y: y - ny * hw });
    bot.push({ x: x + nx * hw, y: y + ny * hw });
  }
  return { top, bot, mid, nrm };
}

function bladePath(ctx: Ctx, b: Blade) {
  ctx.beginPath();
  ctx.moveTo(b.top[0].x, b.top[0].y);
  for (let i = 1; i < b.top.length; i++) ctx.lineTo(b.top[i].x, b.top[i].y);
  for (let i = b.bot.length - 1; i >= 0; i--) ctx.lineTo(b.bot[i].x, b.bot[i].y);
  ctx.closePath();
}

function flower(ctx: Ctx, x: number, y: number, r: number) {
  for (let k = 0; k < 4; k++) {
    const a = (k * Math.PI) / 2;
    ctx.beginPath();
    ctx.ellipse(x + Math.cos(a) * r * 0.5, y + Math.sin(a) * r * 0.5, r * 0.52, r * 0.26, a, 0, TAU);
    ctx.stroke();
  }
}

function ruby(ctx: Ctx, x: number, y: number, r: number, pulse: number) {
  glow(ctx, x, y, r * 3.2, '#ff2a3a', 0.3 + 0.2 * pulse);
  const g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.35, r * 0.1, x, y, r);
  g.addColorStop(0, '#ffc2b8');
  g.addColorStop(0.35, '#ff3347');
  g.addColorStop(1, '#5a0613');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, TAU);
  ctx.fill();
  ctx.strokeStyle = '#ffd98a';
  ctx.lineWidth = 1.2;
  ctx.stroke();
  ctx.fillStyle = 'rgba(255,255,255,0.85)';
  ctx.beginPath();
  ctx.arc(x - r * 0.3, y - r * 0.35, r * 0.18, 0, TAU);
  ctx.fill();
}

interface Mote {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  s: number;
  ph: number;
}

export class KerisGun extends Weapon {
  readonly id = 'keris';
  readonly name = 'Keris Gun';
  readonly tagline = 'Pusaka Nusantara berlaras rahasia';
  readonly accent = '#ffc94a';
  readonly theme: Theme = { top: '#12060a', bottom: '#33100f', glow: '#ff8a2a' };
  readonly features: Features = {
    body: 'Bilah berlekuk 7 luk, hulu berukir, sarung emas, laras tersembunyi di ujung bilah.',
    bullet: 'Bilah energi mini berlekuk emas-merah, berputar sambil melesat.',
    impact: 'Percikan emas + lingkaran aura mistis yang tipis.',
    idle: 'Bilah berkilau perlahan, aura samar berdenyut.',
  };
  readonly bounds: Bounds = { x0: -208, x1: 248, y0: -50, y1: 134 };
  kick = 16;
  cooldown = 0.3;
  private motes: Mote[] = [];
  private moteAcc = 0;

  constructor() {
    super();
    this.muzzle = { x: BX1, y: 0 };
  }

  update(dt: number, w: World) {
    super.update(dt, w);
    this.muzzle.x = BX1 - 2;
    this.muzzle.y = bladeY(0.995, this.time, this.since);
    this.moteAcc += dt * 16;
    while (this.moteAcc > 1) {
      this.moteAcc -= 1;
      const x = rr(40, 230);
      const u = (x - BX0) / (BX1 - BX0);
      this.motes.push({
        x,
        y: bladeY(u, this.time, 99) + rr(-12, 12),
        vx: rr(-5, 5),
        vy: -rr(10, 26),
        life: 0,
        max: rr(1.6, 2.9),
        s: rr(1, 2.6),
        ph: rr(0, TAU),
      });
    }
    for (let i = this.motes.length - 1; i >= 0; i--) {
      const m = this.motes[i];
      m.life += dt;
      if (m.life > m.max) {
        this.motes.splice(i, 1);
        continue;
      }
      m.x += (m.vx + Math.sin(this.time * 2 + m.ph) * 6) * dt;
      m.y += m.vy * dt;
    }
  }

  protected fire(w: World) {
    w.add(new KerisBolt(w));
    w.shake(1.6);
    for (let i = 0; i < 12; i++) {
      const a = w.aim + rr(-0.5, 0.5);
      const sp = rr(120, 380);
      w.fx.emit({
        x: w.muzzle.x,
        y: w.muzzle.y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.2, 0.45),
        size: rr(1, 2.2),
        kind: 'streak',
        color: pick(GOLDS),
        drag: 3,
      });
    }
  }

  drawBody(ctx: Ctx, _w: World) {
    const t = this.time;
    const fl = this.flare(5);
    const pulse = 0.5 + 0.5 * Math.sin(t * 2.2);
    const bl = computeBlade(t, this.since);

    // ===== aura samar berdenyut =====
    ctx.save();
    ctx.translate(95, 4);
    ctx.scale(1, 0.4);
    glow(ctx, 0, 0, 210, '#ff7a2a', 0.15 + 0.12 * pulse + 0.4 * fl);
    glow(ctx, 0, 0, 130, '#ffd36a', 0.08 + 0.08 * pulse + 0.3 * fl);
    ctx.restore();
    glow(ctx, -90, 20, 90, '#ff8a2a', 0.1 + 0.08 * pulse);

    // ===== bilah =====
    ctx.save();
    ctx.shadowColor = 'rgba(255,170,60,0.6)';
    ctx.shadowBlur = 16 + 14 * fl;
    bladePath(ctx, bl);
    const bg = ctx.createLinearGradient(BX0, 0, BX1, 0);
    bg.addColorStop(0, '#4a3520');
    bg.addColorStop(0.25, '#6f7686');
    bg.addColorStop(0.5, '#aeb5c4');
    bg.addColorStop(0.78, '#7d8698');
    bg.addColorStop(1, '#e6d4a0');
    ctx.fillStyle = bg;
    ctx.fill();
    ctx.restore();

    ctx.save();
    bladePath(ctx, bl);
    ctx.clip();
    // bayangan lekuk bawah
    ctx.beginPath();
    ctx.moveTo(bl.mid[0].x, bl.mid[0].y);
    for (const p of bl.mid) ctx.lineTo(p.x, p.y);
    for (let i = bl.bot.length - 1; i >= 0; i--) ctx.lineTo(bl.bot[i].x, bl.bot[i].y);
    ctx.closePath();
    ctx.fillStyle = 'rgba(60,40,30,0.32)';
    ctx.fill();
    // pamor (motif tempa)
    ctx.fillStyle = 'rgba(236,170,52,0.9)';
    for (let j = 0; j < 34; j++) {
      const k = 22 + Math.floor(j * 1.8);
      if (k >= bl.mid.length) break;
      const side = j % 2 ? 1 : -1;
      const hw = bladeHalfW(k / (bl.mid.length - 1)) * 0.58;
      const px = bl.mid[k].x + bl.nrm[k].x * hw * side;
      const py = bl.mid[k].y + bl.nrm[k].y * hw * side;
      ctx.beginPath();
      ctx.ellipse(px, py, 4.2 * (0.4 + hw / 14), 1.5, 0.7 * side, 0, TAU);
      ctx.fill();
    }
    // saluran energi merah-emas di tengah bilah
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    bl.mid.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.strokeStyle = `rgba(255,70,30,${0.3 + 0.22 * pulse + 0.45 * fl})`;
    ctx.lineWidth = 7;
    ctx.stroke();
    ctx.strokeStyle = `rgba(255,170,60,${0.3 + 0.2 * pulse + 0.4 * fl})`;
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.restore();
    // alur tengah (ridge)
    ctx.lineJoin = 'round';
    ctx.beginPath();
    bl.mid.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.strokeStyle = 'rgba(70,40,20,0.55)';
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.beginPath();
    bl.mid.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y - 1.1) : ctx.moveTo(p.x, p.y - 1.1)));
    ctx.strokeStyle = 'rgba(255,250,235,0.75)';
    ctx.lineWidth = 1;
    ctx.stroke();
    // kilau menyapu perlahan
    const ph = (t / 3.6) % 1;
    const sx = BX0 - 70 + ph * (BX1 - BX0 + 140);
    const sg = ctx.createLinearGradient(sx - 36, -34, sx + 36, 34);
    sg.addColorStop(0, 'rgba(255,248,220,0)');
    sg.addColorStop(0.5, 'rgba(255,248,220,0.5)');
    sg.addColorStop(1, 'rgba(255,248,220,0)');
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = sg;
    ctx.fillRect(sx - 140, -80, 280, 160);
    // energi menjalar saat menembak
    if (this.since < 0.55) {
      const fu = clamp(this.since * 3.2, 0, 1.3);
      const fx = BX0 + fu * (BX1 - BX0);
      const fg = ctx.createLinearGradient(fx - 60, 0, fx + 20, 0);
      fg.addColorStop(0, 'rgba(255,60,30,0)');
      fg.addColorStop(0.7, 'rgba(255,150,50,0.85)');
      fg.addColorStop(1, 'rgba(255,240,170,0)');
      ctx.globalAlpha = 1 - this.since / 0.55;
      ctx.fillStyle = fg;
      ctx.fillRect(fx - 64, -60, 90, 120);
    }
    ctx.restore();

    // tepi bilah
    ctx.lineJoin = 'round';
    ctx.beginPath();
    bl.top.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.beginPath();
    bl.bot.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.strokeStyle = 'rgba(150,85,25,0.9)';
    ctx.lineWidth = 1.1;
    ctx.stroke();

    // ===== hulu berukir (melengkung ke bawah seperti gagang pistol) =====
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(-100, -17);
    ctx.bezierCurveTo(-140, -32, -192, -32, -199, 8);
    ctx.bezierCurveTo(-204, 45, -192, 85, -184, 112);
    ctx.bezierCurveTo(-178, 128, -150, 128, -146, 112);
    ctx.bezierCurveTo(-140, 80, -138, 44, -120, 26);
    ctx.bezierCurveTo(-112, 20, -104, 18, -100, 17);
    ctx.closePath();
    const hg = ctx.createLinearGradient(-200, -30, -130, 120);
    hg.addColorStop(0, '#7a4521');
    hg.addColorStop(0.5, '#3d1b0b');
    hg.addColorStop(1, '#241006');
    ctx.fillStyle = hg;
    ctx.fill();
    ctx.lineWidth = 1.6;
    ctx.strokeStyle = '#e8b64a';
    ctx.stroke();
    ctx.clip();
    // ukiran sisik di sepanjang gagang
    ctx.strokeStyle = 'rgba(255,205,110,0.85)';
    ctx.lineWidth = 1.4;
    for (let i = 0; i < 9; i++) {
      const u = 0.06 + i * 0.105;
      const mt = 1 - u;
      const cx = mt ** 3 * -118 + 3 * mt * mt * u * -190 + 3 * mt * u * u * -186 + u ** 3 * -164;
      const cy = mt ** 3 * 0 + 3 * mt * mt * u * -4 + 3 * mt * u * u * 62 + u ** 3 * 108;
      ctx.beginPath();
      ctx.arc(cx, cy, 11, 0.2 * Math.PI, 0.8 * Math.PI);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx, cy + 6, 6, 0.2 * Math.PI, 0.8 * Math.PI);
      ctx.globalAlpha = 0.6;
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
    // kilau kayu
    ctx.strokeStyle = 'rgba(255,220,160,0.28)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-134, -22);
    ctx.bezierCurveTo(-176, -26, -190, 0, -190, 30);
    ctx.stroke();
    ctx.restore();
    // tutup hulu emas
    ctx.save();
    const cg = ctx.createLinearGradient(-190, 100, -140, 130);
    cg.addColorStop(0, '#fff0a8');
    cg.addColorStop(0.5, '#e0a528');
    cg.addColorStop(1, '#7a4a0c');
    ctx.fillStyle = cg;
    ctx.strokeStyle = '#6b3f0a';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.ellipse(-165, 116, 24, 10, -0.08, 0, TAU);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
    ruby(ctx, -165, 116, 4.5, pulse);

    // ===== mendak (cincin emas) =====
    ctx.save();
    const mg = ctx.createLinearGradient(-112, 0, -90, 0);
    mg.addColorStop(0, '#7a4a0c');
    mg.addColorStop(0.35, '#fff0a8');
    mg.addColorStop(1, '#a8700f');
    ctx.fillStyle = mg;
    ctx.beginPath();
    ctx.roundRect(-112, -28, 21, 56, 6);
    ctx.fill();
    ctx.strokeStyle = '#5b3408';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.strokeStyle = 'rgba(90,50,8,0.7)';
    for (let i = 0; i < 5; i++) {
      ctx.beginPath();
      ctx.moveTo(-108 + i * 4, -26);
      ctx.lineTo(-108 + i * 4, 26);
      ctx.stroke();
    }
    ctx.restore();

    // ===== sarung emas (warangka) =====
    ctx.save();
    const sheath = () => {
      ctx.beginPath();
      ctx.moveTo(-93, -25);
      ctx.bezierCurveTo(-84, -43, -52, -44, -24, -35);
      ctx.bezierCurveTo(-4, -29, 18, -26, 38, -23);
      ctx.quadraticCurveTo(47, -21, 47, -12);
      ctx.lineTo(47, 12);
      ctx.quadraticCurveTo(47, 21, 38, 23);
      ctx.bezierCurveTo(18, 26, -4, 29, -24, 35);
      ctx.bezierCurveTo(-52, 44, -84, 43, -93, 25);
      ctx.quadraticCurveTo(-98, 0, -93, -25);
      ctx.closePath();
    };
    sheath();
    ctx.shadowColor = 'rgba(255,170,40,0.55)';
    ctx.shadowBlur = 14;
    const sg2 = ctx.createLinearGradient(0, -44, 0, 44);
    sg2.addColorStop(0, '#fff3b0');
    sg2.addColorStop(0.22, '#f8d35c');
    sg2.addColorStop(0.5, '#dc9a2a');
    sg2.addColorStop(0.78, '#a86512');
    sg2.addColorStop(1, '#5a3208');
    ctx.fillStyle = sg2;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.lineWidth = 1.6;
    ctx.strokeStyle = '#6b3f0a';
    ctx.stroke();
    sheath();
    ctx.clip();
    // pita anyam di tengah
    ctx.lineWidth = 1.7;
    ctx.strokeStyle = 'rgba(110,62,8,0.8)';
    ctx.beginPath();
    for (let x = -88; x <= 44; x += 2) {
      const y = 3.6 * Math.sin((x + 90) * 0.26);
      x === -88 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,244,180,0.9)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = -88; x <= 44; x += 2) {
      const y = 3.6 * Math.sin((x + 90) * 0.26 + Math.PI);
      x === -88 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    }
    ctx.stroke();
    // motif kawung
    ctx.strokeStyle = 'rgba(100,56,8,0.75)';
    ctx.lineWidth = 1.1;
    flower(ctx, -62, -19, 9);
    flower(ctx, -62, 20, 9);
    flower(ctx, -8, -17, 7);
    flower(ctx, -8, 17, 7);
    flower(ctx, 26, -13, 5.5);
    flower(ctx, 26, 13, 5.5);
    // garis dalam (tepi berlapis)
    ctx.save();
    ctx.translate(-24, 0);
    ctx.scale(0.93, 0.78);
    ctx.translate(24, 0);
    sheath();
    ctx.strokeStyle = 'rgba(255,245,190,0.55)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.restore();
    // sorot kilau pada sarung
    const ph2 = (t / 3.6 + 0.12) % 1;
    const hx = -110 + ph2 * 220;
    const hg2 = ctx.createLinearGradient(hx - 22, -30, hx + 22, 30);
    hg2.addColorStop(0, 'rgba(255,255,230,0)');
    hg2.addColorStop(0.5, 'rgba(255,255,230,0.45)');
    hg2.addColorStop(1, 'rgba(255,255,230,0)');
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = hg2;
    ctx.fillRect(hx - 140, -80, 280, 160);
    ctx.restore();
    ruby(ctx, -38, 0, 7.5, pulse);
    ruby(ctx, 8, 0, 4.5, 1 - pulse);

    // kolar emas (ganja) di mulut sarung
    ctx.save();
    const cg2 = ctx.createLinearGradient(0, -26, 0, 26);
    cg2.addColorStop(0, '#fff0a8');
    cg2.addColorStop(0.5, '#d9962a');
    cg2.addColorStop(1, '#6b3f0a');
    ctx.fillStyle = cg2;
    ctx.beginPath();
    ctx.roundRect(42, -26, 10, 52, 4);
    ctx.fill();
    ctx.strokeStyle = '#5b3408';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,248,200,0.8)';
    ctx.beginPath();
    ctx.moveTo(45, -22);
    ctx.lineTo(45, 22);
    ctx.stroke();
    ctx.restore();

    // ===== pelindung picu =====
    ctx.save();
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#4a2806';
    ctx.lineWidth = 6.5;
    ctx.beginPath();
    ctx.moveTo(-138, 66);
    ctx.bezierCurveTo(-130, 100, -62, 100, -48, 36);
    ctx.stroke();
    ctx.strokeStyle = '#f2c14e';
    ctx.lineWidth = 4;
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,250,210,0.8)';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.strokeStyle = '#4a2806';
    ctx.lineWidth = 5.5;
    ctx.beginPath();
    ctx.moveTo(-86, 36);
    ctx.quadraticCurveTo(-84, 60, -76, 68);
    ctx.stroke();
    ctx.strokeStyle = '#ffd36a';
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.restore();

    // ===== ujung bilah: laras tersembunyi =====
    const mx = this.muzzle.x;
    const my = this.muzzle.y;
    glow(ctx, mx - 6, my, 10 + 8 * pulse, '#ffb347', 0.55 + 0.25 * pulse);
    if (fl > 0.02) {
      glow(ctx, mx, my, 40 + 80 * fl, '#ff9a3a', 0.9 * fl);
      glow(ctx, mx, my, 22 + 30 * fl, '#fff3c0', fl);
      star4(ctx, mx, my, 12 + 50 * fl, this.time * 2, '#fff3c0', fl);
      star4(ctx, mx, my, 8 + 28 * fl, this.time * 2 + 0.78, '#ffb347', fl * 0.9);
    }

    // ===== partikel pusaka melayang =====
    for (const m of this.motes) {
      const a = Math.sin((m.life / m.max) * Math.PI);
      glow(ctx, m.x, m.y, m.s * 5, '#ffcf5a', a * 0.8);
      if (m.s > 2) star4(ctx, m.x, m.y, m.s * 2.2, m.ph + this.time, '#fff3c0', a * 0.8);
    }
  }
}

function drawMini(ctx: Ctx, x: number, y: number, rot: number, scale: number, alpha: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(scale, scale);
  ctx.globalAlpha = alpha;
  const len = 42;
  const n = 16;
  const top: Vec[] = [];
  const bot: Vec[] = [];
  for (let i = 0; i <= n; i++) {
    const u = i / n;
    const px = (u - 0.5) * len;
    const yc = 3.4 * Math.sin(u * TAU * 1.5);
    const hw = (0.3 + 5.4 * Math.pow(1 - u, 1.2)) * (u < 0.06 ? 0.7 + u * 5 : 1);
    top.push({ x: px, y: yc - hw });
    bot.push({ x: px, y: yc + hw });
  }
  ctx.beginPath();
  ctx.moveTo(top[0].x, top[0].y);
  top.forEach((p) => ctx.lineTo(p.x, p.y));
  for (let i = bot.length - 1; i >= 0; i--) ctx.lineTo(bot[i].x, bot[i].y);
  ctx.closePath();
  const g = ctx.createLinearGradient(-len / 2, 0, len / 2, 0);
  g.addColorStop(0, '#c4161f');
  g.addColorStop(0.35, '#ff4a2a');
  g.addColorStop(0.7, '#ffb23a');
  g.addColorStop(1, '#fff3c0');
  ctx.fillStyle = g;
  ctx.fill();
  ctx.lineWidth = 0.9;
  ctx.strokeStyle = 'rgba(255,245,210,0.95)';
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(-len / 2 - 1, 0, 2.2, 0, TAU);
  ctx.fillStyle = '#ffd36a';
  ctx.fill();
  ctx.restore();
}

class KerisBolt extends Flight {
  constructor(w: World) {
    super(w, 1250, 0.05, 0.5);
    this.trailMax = 9;
  }
  spinAngle() {
    return this.age * 24;
  }
  onMove(_dt: number, w: World) {
    for (let i = 0; i < 2; i++) {
      w.fx.emit({
        x: this.pos.x + rr(-3, 3),
        y: this.pos.y + rr(-3, 3),
        vx: rr(-40, 40),
        vy: rr(-40, 40),
        life: rr(0.3, 0.6),
        size: rr(5, 11),
        size1: 1,
        kind: 'glow',
        color: pick(GOLDS),
        drag: 2.5,
      });
    }
    if (Math.random() < 0.35)
      w.fx.emit({
        x: this.pos.x,
        y: this.pos.y,
        vx: rr(-60, 60),
        vy: rr(-60, 60),
        life: rr(0.4, 0.8),
        size: rr(3, 6),
        kind: 'star',
        rot: rr(0, 3),
        vr: rr(-4, 4),
        color: '#fff3c0',
        drag: 2,
      });
  }
  onHit(w: World, x: number, y: number) {
    // percikan emas
    for (let i = 0; i < 30; i++) {
      const a = rr(0, TAU);
      const sp = rr(120, 480);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.35, 0.85),
        size: rr(1.1, 2.7),
        kind: 'streak',
        color: pick(GOLDS),
        drag: 3.2,
        g: 240,
        len: 0.05,
      });
    }
    for (let i = 0; i < 9; i++) {
      const a = rr(0, TAU);
      const sp = rr(30, 140);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.5, 1.0),
        size: rr(4, 10),
        kind: 'star',
        rot: rr(0, 3),
        vr: rr(-3, 3),
        color: pick(['#fff3c0', '#ffd36a']),
        drag: 2.4,
      });
    }
    for (let i = 0; i < 8; i++) {
      w.fx.emit({
        x,
        y,
        vx: rr(-60, 60),
        vy: rr(-60, 60),
        life: rr(0.4, 0.7),
        size: rr(14, 28),
        size1: 4,
        kind: 'glow',
        color: pick(['#ff8a2a', '#ffb23a']),
        drag: 3,
      });
    }
    addFlash(w, x, y, 14, 90, 0.4, '#ffb347', 0.95);
    addRing(w, x, y, 6, 64, 0.55, '#ffd36a', 2.2, 0.3, 0.95);
    addRing(w, x, y, 6, 104, 0.85, '#ff8a3a', 1.4, 0.2, 0.8, easeOutCubic, true, 0.05);

    // aura mistis tipis
    w.add(
      new Timed(1.2, (ctx, t, age) => {
        const e = easeOutCubic(t);
        const a = Math.pow(1 - t, 1.2);
        const R = 16 + 62 * e;
        ctx.globalCompositeOperation = 'lighter';
        glow(ctx, x, y, 24 + 70 * e, '#ff6a3a', 0.32 * a);
        ctx.strokeStyle = '#ffd36a';
        ctx.globalAlpha = 0.85 * a;
        ctx.lineWidth = 1;
        ctx.setLineDash([2, 6]);
        ctx.lineDashOffset = -age * 40;
        ctx.beginPath();
        ctx.arc(x, y, R * 0.82, 0, TAU);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.globalAlpha = 0.55 * a;
        ctx.beginPath();
        ctx.arc(x, y, R * 1.12, 0, TAU);
        ctx.stroke();
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(age * 0.9);
        ctx.strokeStyle = '#ffcf7a';
        ctx.globalAlpha = 0.75 * a;
        for (let k = 0; k < 8; k++) {
          ctx.rotate(TAU / 8);
          ctx.beginPath();
          ctx.moveTo(R * 0.3, 0);
          ctx.quadraticCurveTo(R * 0.65, R * 0.2, R, 0);
          ctx.quadraticCurveTo(R * 0.65, -R * 0.2, R * 0.3, 0);
          ctx.stroke();
        }
        ctx.rotate(-age * 1.8);
        ctx.globalAlpha = 0.6 * a;
        for (let k = 0; k < 24; k++) {
          ctx.rotate(TAU / 24);
          ctx.beginPath();
          ctx.moveTo(R * 1.2, 0);
          ctx.lineTo(R * 1.2 + (k % 3 === 0 ? 7 : 3.5), 0);
          ctx.stroke();
        }
        ctx.restore();
      }),
    );
    w.target.hit('#ffc94a');
    w.target.impulse(Math.cos(this.heading) * 70, Math.sin(this.heading) * 70);
    w.shake(2.2);
  }
  draw(ctx: Ctx) {
    const n = this.trail.length;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    glow(ctx, this.pos.x, this.pos.y, 40, '#ff6a2a', 0.65);
    glow(ctx, this.pos.x, this.pos.y, 20, '#ffd36a', 0.8);
    ctx.globalCompositeOperation = 'source-over';
    for (let i = 0; i < n - 1; i++) {
      const p = this.trail[i];
      const k = i / n;
      drawMini(ctx, p.x, p.y, p.r, 0.7 + 0.3 * k, Math.pow(k, 1.7) * 0.45);
    }
    drawMini(ctx, this.pos.x, this.pos.y, this.spinAngle(), 1.05, 1);
    ctx.restore();
  }
}
