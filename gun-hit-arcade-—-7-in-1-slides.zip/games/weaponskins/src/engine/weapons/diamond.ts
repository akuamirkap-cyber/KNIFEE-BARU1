import { glow, polyPath, star4 } from '../gfx';
import { addFlash, addRing, Timed } from '../particles';
import type { Ctx, World } from '../types';
import { clamp, hsl, pick, rr, TAU, type Vec } from '../util';
import { Flight, Weapon, type Bounds, type Features, type Theme } from '../weapon';

const PAL: [number, number[]][] = [
  [0, [16, 40, 96]],
  [0.25, [50, 108, 200]],
  [0.5, [128, 190, 252]],
  [0.75, [208, 234, 255]],
  [1, [255, 255, 255]],
];
function tone(v: number, a = 1) {
  v = clamp(v, 0, 1);
  for (let i = 1; i < PAL.length; i++) {
    if (v <= PAL[i][0]) {
      const [t0, c0] = PAL[i - 1];
      const [t1, c1] = PAL[i];
      const k = (v - t0) / (t1 - t0);
      return `rgba(${Math.round(c0[0] + (c1[0] - c0[0]) * k)},${Math.round(c0[1] + (c1[1] - c0[1]) * k)},${Math.round(c0[2] + (c1[2] - c0[2]) * k)},${a})`;
    }
  }
  return 'rgba(255,255,255,1)';
}

type V = readonly [number, number];
const V: Record<string, V> = {
  T0: [-180, -8],
  T1: [-120, -52],
  T2: [-36, -64],
  T3: [54, -58],
  T4: [146, -38],
  T5: [236, 2],
  M1: [-100, -6],
  M2: [-18, -12],
  M3: [66, -10],
  M4: [150, -2],
  B1: [-120, 40],
  B2: [-36, 50],
  B3: [54, 46],
  B4: [146, 32],
  K0: [-100, -56],
  K1: [-52, -88],
  K2: [40, -92],
  K3: [100, -52],
  Kc1: [-30, -63],
  Kc2: [50, -59],
  G0: [-86, 40],
  G1: [-34, 48],
  G2: [-12, 120],
  G3: [-62, 130],
  G4: [-50, 84],
};

type Facet = { v: string[]; t: number };
const BODY: Facet[] = [
  { v: ['T0', 'T1', 'M1'], t: 0.62 },
  { v: ['T1', 'T2', 'M1'], t: 0.9 },
  { v: ['T2', 'M2', 'M1'], t: 0.5 },
  { v: ['T2', 'T3', 'M2'], t: 0.78 },
  { v: ['T3', 'M3', 'M2'], t: 0.42 },
  { v: ['T3', 'T4', 'M3'], t: 0.95 },
  { v: ['T4', 'M4', 'M3'], t: 0.58 },
  { v: ['T4', 'T5', 'M4'], t: 0.8 },
  { v: ['T0', 'M1', 'B1'], t: 0.3 },
  { v: ['B1', 'M1', 'M2'], t: 0.55 },
  { v: ['B1', 'M2', 'B2'], t: 0.2 },
  { v: ['B2', 'M2', 'M3'], t: 0.45 },
  { v: ['B2', 'M3', 'B3'], t: 0.12 },
  { v: ['B3', 'M3', 'M4'], t: 0.38 },
  { v: ['B3', 'M4', 'B4'], t: 0.1 },
  { v: ['B4', 'M4', 'T5'], t: 0.3 },
];
const CROWN: Facet[] = [
  { v: ['K0', 'K1', 'Kc1'], t: 0.85 },
  { v: ['K1', 'K2', 'Kc1'], t: 1.0 },
  { v: ['K2', 'Kc2', 'Kc1'], t: 0.62 },
  { v: ['K2', 'K3', 'Kc2'], t: 0.72 },
];
const GRIP: Facet[] = [
  { v: ['G0', 'G1', 'G4'], t: 0.5 },
  { v: ['G1', 'G2', 'G4'], t: 0.72 },
  { v: ['G4', 'G2', 'G3'], t: 0.25 },
  { v: ['G0', 'G4', 'G3'], t: 0.4 },
];
const SILHOUETTE = ['T0', 'T1', 'T2', 'T3', 'T4', 'T5', 'B4', 'B3', 'B2', 'B1'].map((k) => V[k]);
const SPARK_POINTS = Object.values(V);

interface Spark {
  x: number;
  y: number;
  life: number;
  max: number;
  s: number;
}

export class DiamondGun extends Weapon {
  readonly id = 'diamond';
  readonly name = 'Diamond Gun';
  readonly tagline = 'Potongan sempurna, kilau abadi';
  readonly accent = '#8fd6ff';
  readonly theme: Theme = { top: '#050f20', bottom: '#0e2c52', glow: '#6fc8ff' };
  readonly features: Features = {
    body: 'Badan berlapis berlian faceted potongan geometris, putih kebiruan.',
    bullet: 'Berlian kecil berkilau yang memantulkan & menguraikan cahaya.',
    impact: 'Pecahan berlian beterbangan dan kilatan bintang.',
    idle: 'Kilau menyapu badan senjata secara berkala.',
  };
  readonly bounds: Bounds = { x0: -184, x1: 242, y0: -94, y1: 134 };
  kick = 15;
  cooldown = 0.26;
  private sparks: Spark[] = [];
  private acc = 0;

  constructor() {
    super();
    this.muzzle = { x: 236, y: 2 };
  }

  update(dt: number, w: World) {
    super.update(dt, w);
    this.acc += dt * 5;
    while (this.acc > 1) {
      this.acc -= 1;
      const p = pick(SPARK_POINTS);
      this.sparks.push({ x: p[0] + rr(-10, 10), y: p[1] + rr(-8, 8), life: 0, max: rr(0.5, 1.1), s: rr(6, 13) });
    }
    for (let i = this.sparks.length - 1; i >= 0; i--) {
      this.sparks[i].life += dt;
      if (this.sparks[i].life > this.sparks[i].max) this.sparks.splice(i, 1);
    }
  }

  protected fire(w: World) {
    w.add(new GemBullet(w));
    w.shake(1.8);
    for (let i = 0; i < 10; i++) {
      const a = w.aim + rr(-0.45, 0.45);
      const sp = rr(150, 420);
      w.fx.emit({
        x: w.muzzle.x,
        y: w.muzzle.y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.3, 0.6),
        size: rr(3, 6),
        kind: 'star',
        rot: rr(0, 3),
        vr: rr(-5, 5),
        color: pick(['#ffffff', '#bfe6ff', '#8fd6ff']),
        drag: 3,
      });
    }
  }

  private facet(ctx: Ctx, f: Facet, i: number, sweepPos: number, fl: number) {
    const pts = f.v.map((k) => V[k]);
    const cx = (pts[0][0] + pts[1][0] + pts[2][0]) / 3;
    const cy = (pts[0][1] + pts[1][1] + pts[2][1]) / 3;
    const t = this.time;
    const sc = cx * 0.9 + cy * 0.45;
    const sw = Math.exp(-Math.pow((sc - sweepPos) / 60, 2)) * 0.75;
    // gelombang cahaya saat menembak: belakang → depan
    const wavePos = -190 + this.since * 1500;
    const wv = this.since < 0.45 ? Math.exp(-Math.pow((cx - wavePos) / 55, 2)) * 0.8 : 0;
    const tw = Math.sin(t * 0.9 + i * 1.7) * 0.05;
    const tn = f.t + tw + sw + wv;
    const g = ctx.createLinearGradient(pts[0][0], pts[0][1], cx + (cx - pts[0][0]) * 0.2, cy + (cy - pts[0][1]) * 0.2);
    g.addColorStop(0, tone(tn + 0.14));
    g.addColorStop(1, tone(tn - 0.1));
    polyPath(ctx, pts);
    ctx.fillStyle = g;
    ctx.fill();
    if (f.t > 0.7) {
      polyPath(ctx, pts);
      ctx.fillStyle = hsl(t * 40 + i * 47, 100, 75).replace('hsl(', 'hsla(').replace(')', ',0.12)');
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.fill();
      ctx.restore();
    }
    polyPath(ctx, pts);
    ctx.strokeStyle = `rgba(255,255,255,${0.45 + 0.4 * sw + 0.3 * wv})`;
    ctx.lineWidth = 0.9;
    ctx.stroke();
    void fl;
  }

  drawBody(ctx: Ctx, _w: World) {
    const t = this.time;
    const fl = this.flare(5);
    const pulse = 0.5 + 0.5 * Math.sin(t * 1.8);
    const cyc = t % 3.8;
    const sweepPos = cyc < 1.2 ? -300 + (cyc / 1.2) * 720 : -9999;

    ctx.save();
    ctx.translate(30, 0);
    ctx.scale(1, 0.45);
    glow(ctx, 0, 0, 230, '#6fc8ff', 0.14 + 0.06 * pulse + 0.25 * fl);
    ctx.restore();

    // gagang + pelatuk
    ctx.save();
    ctx.shadowColor = 'rgba(120,200,255,0.5)';
    ctx.shadowBlur = 14;
    polyPath(
      ctx,
      GRIP[0].v.concat(['G2', 'G3']).map((k) => V[k]),
    );
    ctx.fillStyle = '#2c5da8';
    ctx.fill();
    ctx.restore();
    GRIP.forEach((f, i) => this.facet(ctx, f, i + 40, sweepPos, fl));
    polyPath(ctx, [
      [8, 48],
      [26, 68],
      [12, 92],
      [-2, 66],
    ]);
    const tg = ctx.createLinearGradient(0, 48, 20, 92);
    tg.addColorStop(0, tone(0.95));
    tg.addColorStop(1, tone(0.45));
    ctx.fillStyle = tg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.8)';
    ctx.lineWidth = 1;
    ctx.stroke();

    // badan
    ctx.save();
    ctx.shadowColor = 'rgba(130,205,255,0.65)';
    ctx.shadowBlur = 18 + 16 * fl;
    polyPath(ctx, SILHOUETTE);
    ctx.fillStyle = '#4a86d8';
    ctx.fill();
    ctx.restore();
    BODY.forEach((f, i) => this.facet(ctx, f, i, sweepPos, fl));

    // lapisan mahkota (atas)
    ctx.save();
    ctx.shadowColor = 'rgba(160,220,255,0.6)';
    ctx.shadowBlur = 12;
    polyPath(
      ctx,
      ['K0', 'K1', 'K2', 'K3', 'Kc2', 'Kc1'].map((k) => V[k]),
    );
    ctx.fillStyle = '#bfe3ff';
    ctx.fill();
    ctx.restore();
    CROWN.forEach((f, i) => this.facet(ctx, f, i + 20, sweepPos, fl));

    // garis lipatan utama (ridge) berkilau
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = 'rgba(190,230,255,0.55)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(...V.T0);
    ctx.lineTo(...V.M1);
    ctx.lineTo(...V.M2);
    ctx.lineTo(...V.M3);
    ctx.lineTo(...V.M4);
    ctx.lineTo(...V.T5);
    ctx.stroke();
    ctx.restore();

    // pita kilau menyapu
    if (cyc < 1.2) {
      ctx.save();
      polyPath(ctx, SILHOUETTE);
      ctx.clip();
      const sg = ctx.createLinearGradient(sweepPos / 0.9 - 36, sweepPos * 0.2 - 50, sweepPos / 0.9 + 36, sweepPos * 0.2 + 50);
      sg.addColorStop(0, 'rgba(255,255,255,0)');
      sg.addColorStop(0.5, 'rgba(255,255,255,0.55)');
      sg.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = sg;
      ctx.fillRect(-200, -110, 460, 240);
      ctx.restore();
      const sx = sweepPos / 0.9;
      if (sx > -170 && sx < 230) star4(ctx, sx, -20 + Math.sin(sx * 0.05) * 6, 18, 0, '#ffffff', 0.9);
    }

    // lensa moncong
    polyPath(ctx, [
      [210, 2],
      [224, -9],
      [240, 2],
      [224, 13],
    ]);
    const lg = ctx.createLinearGradient(210, 0, 240, 0);
    lg.addColorStop(0, tone(0.55));
    lg.addColorStop(0.5, tone(1));
    lg.addColorStop(1, tone(0.6));
    ctx.fillStyle = lg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.95)';
    ctx.lineWidth = 1;
    ctx.stroke();
    glow(ctx, 238, 2, 18 + 6 * pulse, '#bfe6ff', 0.55 + 0.2 * pulse);

    // kilau acak
    for (const s of this.sparks) {
      const k = s.life / s.max;
      const a = Math.sin(k * Math.PI);
      star4(ctx, s.x, s.y, s.s * (0.4 + 0.6 * a), Math.PI / 4 * (k > 0.5 ? 1 : 0), '#ffffff', a);
      glow(ctx, s.x, s.y, s.s * 1.6, '#bfe6ff', a * 0.6);
    }

    // kilatan moncong
    if (fl > 0.03) {
      const mx = 238;
      const my = 2;
      glow(ctx, mx, my, 50 + 70 * fl, '#9fd8ff', 0.9 * fl);
      glow(ctx, mx, my, 22 + 20 * fl, '#ffffff', fl);
      star4(ctx, mx, my, 20 + 80 * fl, 0, '#ffffff', fl, 0.1);
      star4(ctx, mx, my, 14 + 50 * fl, Math.PI / 4, '#bfe6ff', fl * 0.9, 0.1);
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.lineWidth = 1.5;
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * TAU + 0.2;
        const l = (30 + (i % 3) * 20) * (0.4 + fl);
        ctx.strokeStyle = hsl(i * 36, 100, 70).replace('hsl(', 'hsla(').replace(')', `,${0.8 * fl})`);
        ctx.beginPath();
        ctx.moveTo(mx + Math.cos(a) * 8, my + Math.sin(a) * 8);
        ctx.lineTo(mx + Math.cos(a) * l, my + Math.sin(a) * l);
        ctx.stroke();
      }
      ctx.restore();
    }
  }
}

/* =========================== PELURU BERLIAN =========================== */

const GEM: { v: V[]; t: number }[] = [
  { v: [[-1, 0], [-0.58, -0.6], [-0.3, 0]], t: 0.55 },
  { v: [[-0.58, -0.6], [0.58, -0.6], [0.3, 0], [-0.3, 0]], t: 0.98 },
  { v: [[0.58, -0.6], [1, 0], [0.3, 0]], t: 0.35 },
  { v: [[-1, 0], [-0.3, 0], [0, 1]], t: 0.3 },
  { v: [[-0.3, 0], [0.3, 0], [0, 1]], t: 0.72 },
  { v: [[0.3, 0], [1, 0], [0, 1]], t: 0.16 },
];

function drawGem(ctx: Ctx, x: number, y: number, size: number, heading: number, ang: number, t: number) {
  const cs = Math.cos(ang);
  const sx = Math.max(0.3, Math.abs(cs));
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(heading - Math.PI / 2);
  ctx.scale(size * sx, size);
  ctx.shadowColor = 'rgba(160,220,255,0.9)';
  ctx.shadowBlur = 14;
  GEM.forEach((f, i) => {
    polyPath(ctx, f.v);
    const tn = f.t + 0.28 * Math.sin(ang * 1.5 + i * 1.3) * (cs < 0 ? -1 : 1);
    ctx.fillStyle = tone(tn);
    ctx.fill();
  });
  ctx.shadowBlur = 0;
  GEM.forEach((f) => {
    polyPath(ctx, f.v);
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.lineWidth = 1.1 / size;
    ctx.stroke();
  });
  // pantulan prisma
  ctx.globalCompositeOperation = 'lighter';
  polyPath(ctx, GEM[1].v);
  ctx.fillStyle = hsl(t * 200 + ang * 60, 100, 70).replace('hsl(', 'hsla(').replace(')', ',0.3)');
  ctx.fill();
  ctx.restore();
}

class GemBullet extends Flight {
  constructor(w: World) {
    super(w, 1500, 0.05, 0.4, 0.14);
    this.trailMax = 12;
  }
  spinAngle() {
    return this.age * 16;
  }
  onMove(_dt: number, w: World) {
    for (let i = 0; i < 2; i++) {
      w.fx.emit({
        x: this.pos.x + rr(-4, 4),
        y: this.pos.y + rr(-4, 4),
        vx: rr(-25, 25),
        vy: rr(-25, 25),
        life: rr(0.3, 0.65),
        size: rr(2.5, 6),
        kind: 'star',
        rot: rr(0, 3),
        vr: rr(-4, 4),
        color: pick(['#ffffff', '#bfe6ff', '#9fd8ff']),
        drag: 2,
      });
    }
  }
  onHit(w: World, x: number, y: number) {
    // pecahan berlian
    for (let i = 0; i < 22; i++) {
      const a = rr(0, TAU);
      const sp = rr(120, 480);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 60,
        life: rr(0.7, 1.4),
        size: rr(5, 12),
        kind: 'shard',
        rot: rr(0, TAU),
        vr: rr(-14, 14),
        color: pick(['rgba(223,242,255,0.9)', 'rgba(160,214,255,0.9)', 'rgba(110,176,245,0.9)', 'rgba(255,255,255,0.95)']),
        drag: 1.8,
        g: 520,
        add: false,
        fade: 0.6,
      });
    }
    // kilau bintang kecil
    for (let i = 0; i < 18; i++) {
      const a = rr(0, TAU);
      const sp = rr(20, 220);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.5, 1.2),
        size: rr(3, 9),
        kind: 'star',
        rot: pick([0, Math.PI / 4]),
        vr: 0,
        color: pick(['#ffffff', '#bfe6ff']),
        drag: 2.5,
      });
    }
    addFlash(w, x, y, 20, 120, 0.45, '#8fd6ff', 1);
    addFlash(w, x, y, 10, 60, 0.3, '#ffffff', 1);
    addRing(w, x, y, 6, 90, 0.5, '#bfe6ff', 2, 0.2, 0.95);
    // kilatan bintang + sinar prisma
    w.add(
      new Timed(0.6, (ctx, t, age) => {
        const e = Math.sin(Math.min(1, t * 1.6) * Math.PI * 0.5);
        const a = Math.pow(1 - t, 1.3);
        ctx.globalCompositeOperation = 'lighter';
        star4(ctx, x, y, 110 * e, 0, '#ffffff', a, 0.08);
        star4(ctx, x, y, 70 * e, Math.PI / 4, '#bfe6ff', a * 0.9, 0.1);
        star4(ctx, x, y, 34 * e, age * 3, '#ffffff', a, 0.2);
        ctx.lineWidth = 1.4;
        for (let i = 0; i < 12; i++) {
          const ang = (i / 12) * TAU + 0.1;
          const l = (36 + (i % 4) * 22) * e;
          ctx.strokeStyle = hsl(i * 30, 100, 70).replace('hsl(', 'hsla(').replace(')', `,${0.85 * a})`);
          ctx.beginPath();
          ctx.moveTo(x + Math.cos(ang) * 10, y + Math.sin(ang) * 10);
          ctx.lineTo(x + Math.cos(ang) * (10 + l), y + Math.sin(ang) * (10 + l));
          ctx.stroke();
        }
      }),
    );
    w.target.hit('#9fdcff');
    w.target.impulse(Math.cos(this.heading) * 80, Math.sin(this.heading) * 80);
    w.shake(2.4);
  }
  draw(ctx: Ctx, w: World) {
    const { x, y } = this.pos;
    const n = this.trail.length;
    if (n > 1) {
      const t0 = this.trail[0];
      const nx = -Math.sin(this.heading);
      const ny = Math.cos(this.heading);
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.lineCap = 'round';
      const lg = ctx.createLinearGradient(t0.x, t0.y, x, y);
      lg.addColorStop(0, 'rgba(160,220,255,0)');
      lg.addColorStop(1, 'rgba(235,248,255,0.95)');
      ctx.strokeStyle = lg;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(t0.x, t0.y);
      ctx.lineTo(x, y);
      ctx.stroke();
      // dispersi warna prisma
      const cols = ['rgba(255,70,90,0.55)', 'rgba(90,255,140,0.5)', 'rgba(90,140,255,0.65)'];
      cols.forEach((c, i) => {
        const o = (i - 1) * 3.2;
        const g2 = ctx.createLinearGradient(t0.x, t0.y, x, y);
        g2.addColorStop(0, 'rgba(0,0,0,0)');
        g2.addColorStop(1, c);
        ctx.strokeStyle = g2;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(t0.x + nx * o * 0.2, t0.y + ny * o * 0.2);
        ctx.lineTo(x + nx * o, y + ny * o);
        ctx.stroke();
      });
      ctx.restore();
    }
    glow(ctx, x, y, 34, '#8fd6ff', 0.8);
    glow(ctx, x, y, 16, '#ffffff', 0.8);
    drawGem(ctx, x, y, 12, this.heading, this.spinAngle(), w.time);
    // kilau pada permukaan
    const g = 0.5 + 0.5 * Math.sin(this.age * 30);
    star4(ctx, x - 2, y - 2, 10 + 10 * g, this.age * 4, '#ffffff', 0.5 + 0.5 * g);
  }
}

export type { Vec };
