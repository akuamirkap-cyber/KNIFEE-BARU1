import { glow, lens, star4 } from '../gfx';
import { addFlash, addRing } from '../particles';
import type { Ctx, Entity, World } from '../types';
import { clamp, easeOutCubic, hsla, pick, rr, TAU } from '../util';
import { Flight, Weapon, type Bounds, type Features, type Theme } from '../weapon';

const MX = 232;

/** Kepingan salju enam lengan */
function flake(ctx: Ctx, x: number, y: number, r: number, rot: number, alpha = 1, color = '#eaf7ff') {
  if (r < 1 || alpha <= 0) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.globalAlpha = clamp(alpha, 0, 1);
  ctx.strokeStyle = color;
  ctx.lineCap = 'round';
  ctx.lineWidth = Math.max(0.8, r * 0.13);
  for (let i = 0; i < 6; i++) {
    ctx.rotate(Math.PI / 3);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(r, 0);
    ctx.moveTo(r * 0.52, 0);
    ctx.lineTo(r * 0.76, r * 0.27);
    ctx.moveTo(r * 0.52, 0);
    ctx.lineTo(r * 0.76, -r * 0.27);
    ctx.moveTo(r * 0.2, 0);
    ctx.lineTo(r * 0.36, r * 0.16);
    ctx.moveTo(r * 0.2, 0);
    ctx.lineTo(r * 0.36, -r * 0.16);
    ctx.stroke();
  }
  ctx.restore();
}

interface Snow {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  rot: number;
  vr: number;
  life: number;
  max: number;
}

export class SnowballGun extends Weapon {
  readonly id = 'snowball';
  readonly name = 'Snowball Gun';
  readonly tagline = 'Salju padat dari puncak es — dingin sampai ke tulang';
  readonly accent = '#9fe2ff';
  readonly theme: Theme = { top: '#0a1c33', bottom: '#16405f', glow: '#8fd8ff' };
  readonly features: Features = {
    body: 'Badan es berfacet dengan tumpukan salju, popor kayu hangat, inti beku bercahaya, dan moncong es bergerigi.',
    bullet: 'Bola salju padat dengan kristal es mengorbit dan jejak debu salju.',
    impact: 'Awan bubuk salju, cincin embun beku, serpihan es, dan gundukan salju yang runtuh.',
    idle: 'Kepingan salju berjatuhan, kilau embun beku, dan kabut dingin dari moncong.',
  };
  readonly bounds: Bounds = { x0: -196, x1: 250, y0: -116, y1: 132 };
  kick = 15;
  cooldown = 0.32;
  private flakes: Snow[] = [];
  private acc = 0;
  private mist = 0;

  constructor() {
    super();
    this.muzzle = { x: MX, y: -4 };
    for (let i = 0; i < 26; i++) {
      this.flakes.push({
        x: rr(-190, 240),
        y: rr(-110, 110),
        vx: rr(-16, 16),
        vy: rr(12, 34),
        r: rr(3, 9),
        rot: rr(0, TAU),
        vr: rr(-0.8, 0.8),
        life: 0,
        max: rr(2.2, 4),
      });
    }
  }

  update(dt: number, w: World) {
    super.update(dt, w);
    this.acc += dt * 26;
    while (this.acc > 1) {
      this.acc -= 1;
      const f = this.flakes[Math.floor(rr(0, this.flakes.length))];
      f.x = rr(-190, 240);
      f.y = -112;
      f.life = 0;
    }
    for (const f of this.flakes) {
      f.life += dt;
      f.x += (f.vx + Math.sin(this.time * 1.1 + f.r) * 12) * dt;
      f.y += f.vy * dt;
      f.rot += f.vr * dt;
      if (f.y > 116) {
        f.y = -112;
        f.x = rr(-190, 240);
      }
    }
    this.mist += dt;
    if (this.mist > 1.25) {
      this.mist = 0;
      w.fx.emit({
        x: MX - 6,
        y: -2,
        vx: rr(60, 130),
        vy: rr(-14, 6),
        life: 1.1,
        size: 16,
        size1: 46,
        kind: 'smoke',
        color: 'rgba(228,246,255,1)',
        add: false,
        drag: 1.3,
      });
    }
  }

  protected fire(w: World) {
    w.add(new Snowball(w));
    w.shake(2);
    for (let i = 0; i < 14; i++) {
      const a = w.aim + rr(-0.6, 0.6);
      const sp = rr(100, 330);
      w.fx.emit({
        x: w.muzzle.x,
        y: w.muzzle.y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.35, 0.8),
        size: rr(10, 22),
        size1: 2,
        kind: 'smoke',
        color: 'rgba(232,248,255,1)',
        add: false,
        drag: 2.2,
      });
    }
    for (let i = 0; i < 8; i++) {
      w.fx.emit({
        x: w.muzzle.x,
        y: w.muzzle.y,
        vx: Math.cos(w.aim + rr(-0.5, 0.5)) * rr(120, 320),
        vy: Math.sin(w.aim + rr(-0.5, 0.5)) * rr(120, 320),
        life: rr(0.5, 0.9),
        size: rr(3, 6),
        kind: 'star',
        rot: rr(0, 3),
        vr: rr(-3, 3),
        color: '#eaf7ff',
        drag: 2.4,
      });
    }
  }

  drawBody(ctx: Ctx, _w: World) {
    const t = this.time;
    const fl = this.flare(5);
    const pulse = 0.5 + 0.5 * Math.sin(t * 1.7);

    /* ---------- pendar dingin ---------- */
    ctx.save();
    ctx.translate(30, 0);
    ctx.scale(1, 0.5);
    glow(ctx, 0, 0, 290, '#8fd8ff', 0.13 + 0.06 * pulse + 0.2 * fl);
    glow(ctx, -80, 0, 180, '#dff2ff', 0.08 + 0.05 * pulse + 0.14 * fl);
    ctx.restore();

    /* ================= POpor KAYU ================= */
    ctx.beginPath();
    ctx.moveTo(-188, -22);
    ctx.lineTo(-126, -38);
    ctx.lineTo(-118, 34);
    ctx.lineTo(-140, 38);
    ctx.lineTo(-176, 12);
    ctx.closePath();
    const wg = ctx.createLinearGradient(-188, -30, -120, 38);
    wg.addColorStop(0, '#8b5a2c');
    wg.addColorStop(0.5, '#5e3a17');
    wg.addColorStop(1, '#33200c');
    ctx.fillStyle = wg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,220,170,0.35)';
    ctx.lineWidth = 1.1;
    ctx.stroke();
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(-188, -22);
    ctx.lineTo(-126, -38);
    ctx.lineTo(-118, 34);
    ctx.lineTo(-140, 38);
    ctx.lineTo(-176, 12);
    ctx.closePath();
    ctx.clip();
    for (let i = 0; i < 5; i++) {
      ctx.beginPath();
      ctx.moveTo(-190, -22 + i * 13);
      ctx.quadraticCurveTo(-152, -28 + i * 13, -118, -14 + i * 13);
      ctx.strokeStyle = 'rgba(255,215,160,0.22)';
      ctx.lineWidth = 2;
      ctx.stroke();
    }
    // salju menempel
    ctx.fillStyle = 'rgba(238,250,255,0.92)';
    ctx.beginPath();
    ctx.moveTo(-190, -30);
    ctx.quadraticCurveTo(-166, -44, -124, -40);
    ctx.lineTo(-122, -32);
    ctx.quadraticCurveTo(-160, -30, -190, -22);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    /* ================= BADAN ES ================= */
    const body = () => {
      ctx.beginPath();
      ctx.moveTo(-122, -46);
      ctx.lineTo(-70, -60);
      ctx.lineTo(64, -58);
      ctx.lineTo(126, -42);
      ctx.lineTo(150, -18);
      ctx.lineTo(150, 22);
      ctx.lineTo(112, 44);
      ctx.lineTo(-20, 52);
      ctx.lineTo(-104, 46);
      ctx.lineTo(-128, 22);
      ctx.closePath();
    };
    body();
    const bg = ctx.createLinearGradient(0, -60, 0, 52);
    bg.addColorStop(0, '#f2fbff');
    bg.addColorStop(0.35, '#bfe6fb');
    bg.addColorStop(0.62, '#6fb2dd');
    bg.addColorStop(1, '#245a8c');
    ctx.fillStyle = bg;
    ctx.fill();
    ctx.save();
    body();
    ctx.clip();
    // facet es
    const facets: [number, number][][] = [
      [
        [-122, -46],
        [-70, -60],
        [-60, -10],
      ],
      [
        [-70, -60],
        [20, -58],
        [-8, -6],
      ],
      [
        [20, -58],
        [64, -58],
        [64, -6],
      ],
      [
        [64, -58],
        [126, -42],
        [78, 4],
      ],
      [
        [-128, 22],
        [-60, -10],
        [-20, 52],
      ],
      [
        [-60, -10],
        [-8, -6],
        [-20, 52],
      ],
      [
        [-8, -6],
        [64, -6],
        [112, 44],
      ],
    ];
    facets.forEach((f, i) => {
      ctx.beginPath();
      ctx.moveTo(f[0][0], f[0][1]);
      for (let k = 1; k < f.length; k++) ctx.lineTo(f[k][0], f[k][1]);
      ctx.closePath();
      const v = 0.5 + 0.42 * Math.sin(t * 1.1 + i * 1.3);
      ctx.fillStyle = hsla(200 + i * 6, 62, 42 + v * 34, 0.32);
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.5)';
      ctx.lineWidth = 1;
      ctx.stroke();
    });
    // kilau embun beku (menyapu)
    const sw = ((t * 0.28) % 1) * 400 - 220;
    ctx.globalCompositeOperation = 'lighter';
    const sg = ctx.createLinearGradient(sw - 60, -60, sw + 60, 50);
    sg.addColorStop(0, 'rgba(220,245,255,0)');
    sg.addColorStop(0.5, 'rgba(220,245,255,0.42)');
    sg.addColorStop(1, 'rgba(220,245,255,0)');
    ctx.fillStyle = sg;
    ctx.fillRect(-140, -70, 320, 130);
    ctx.globalCompositeOperation = 'source-over';
    // bayangan bawah
    const lo = ctx.createLinearGradient(0, 18, 0, 54);
    lo.addColorStop(0, 'rgba(20,60,110,0)');
    lo.addColorStop(1, 'rgba(20,60,110,0.35)');
    ctx.fillStyle = lo;
    ctx.fillRect(-140, 18, 320, 40);
    ctx.restore();
    body();
    ctx.strokeStyle = 'rgba(255,255,255,0.75)';
    ctx.lineWidth = 1.3;
    ctx.stroke();

    /* ================= INTI BEKU ================= */
    const cx = -34;
    const cy = -4;
    ctx.save();
    glow(ctx, cx, cy, 62 + 20 * pulse + 44 * fl, '#8fd8ff', 0.4 + 0.18 * pulse + 0.3 * fl);
    ctx.beginPath();
    ctx.arc(cx, cy, 30, 0, TAU);
    const cg = ctx.createRadialGradient(cx - 8, cy - 10, 2, cx, cy, 30);
    cg.addColorStop(0, '#ffffff');
    cg.addColorStop(0.45, '#bfe9ff');
    cg.addColorStop(1, '#2c79b4');
    ctx.fillStyle = cg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.lineWidth = 1.8;
    ctx.stroke();
    flake(ctx, cx, cy, 17, t * 0.35, 0.9, '#ffffff');
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU + t * 0.5;
      star4(ctx, cx + Math.cos(a) * 38, cy + Math.sin(a) * 38, 3.2, a, '#eaf7ff', 0.6 + 0.3 * Math.sin(t * 3 + i));
    }
    ctx.restore();

    /* ================= TUMPUKAN SALJU DI ATAS ================= */
    ctx.save();
    ctx.fillStyle = 'rgba(244,251,255,0.95)';
    ctx.beginPath();
    ctx.moveTo(-120, -46);
    ctx.quadraticCurveTo(-92, -76, -52, -68);
    ctx.quadraticCurveTo(-22, -84, 12, -66);
    ctx.quadraticCurveTo(48, -82, 84, -60);
    ctx.quadraticCurveTo(112, -62, 126, -42);
    ctx.lineTo(64, -58);
    ctx.lineTo(-70, -60);
    ctx.closePath();
    ctx.fill();
    const sng = ctx.createLinearGradient(0, -84, 0, -42);
    sng.addColorStop(0, '#ffffff');
    sng.addColorStop(1, '#c8e6f7');
    ctx.fillStyle = sng;
    ctx.fill();
    ctx.restore();
    for (let i = 0; i < 6; i++) {
      const x = -104 + i * 40;
      const y = -62 - Math.abs(Math.sin(i * 1.7)) * 12;
      star4(ctx, x, y, 4 + 3 * Math.abs(Math.sin(t * 1.6 + i)), 0, '#ffffff', 0.75);
    }

    /* ================= GAGANG & PICU ================= */
    ctx.beginPath();
    ctx.moveTo(-108, 26);
    ctx.lineTo(-58, 32);
    ctx.lineTo(-38, 114);
    ctx.quadraticCurveTo(-40, 130, -58, 130);
    ctx.lineTo(-88, 130);
    ctx.quadraticCurveTo(-104, 128, -102, 112);
    ctx.lineTo(-108, 44);
    ctx.closePath();
    const gg = ctx.createLinearGradient(-104, 26, -44, 130);
    gg.addColorStop(0, '#dff1fb');
    gg.addColorStop(0.5, '#5d90c4');
    gg.addColorStop(1, '#1c3f6b');
    ctx.fillStyle = gg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.5)';
    ctx.lineWidth = 1.1;
    ctx.stroke();
    ctx.save();
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#1c3f6b';
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.moveTo(-72, 36);
    ctx.bezierCurveTo(-68, 80, -18, 80, -10, 34);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(230,248,255,0.6)';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();

    /* ================= MONCONG ES ================= */
    const shards = [
      { x: 148, a: -0.25, l: 62, w: 20 },
      { x: 176, a: -0.12, l: 52, w: 16 },
      { x: 202, a: 0, l: 44, w: 14 },
    ];
    for (const s of shards) {
      ctx.beginPath();
      ctx.moveTo(s.x, -22);
      ctx.lineTo(s.x + s.l, s.a * 10);
      ctx.lineTo(s.x, 22);
      ctx.closePath();
      const ig = ctx.createLinearGradient(s.x, -22, s.x + s.l, 22);
      ig.addColorStop(0, 'rgba(255,255,255,0.95)');
      ig.addColorStop(0.5, 'rgba(160,215,250,0.85)');
      ig.addColorStop(1, 'rgba(40,110,175,0.75)');
      ctx.fillStyle = ig;
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.8)';
      ctx.lineWidth = 1.1;
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(s.x + 6, -6);
      ctx.lineTo(s.x + s.l * 0.8, s.a * 10);
      ctx.strokeStyle = 'rgba(255,255,255,0.65)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    const mx = this.muzzle.x;
    const my = this.muzzle.y;
    glow(ctx, mx, my, 22 + 6 * pulse, '#c9edff', 0.4 + 0.2 * pulse);
    if (fl > 0.02) {
      glow(ctx, mx, my, 54 + 100 * fl, '#8fd8ff', 1.05 * fl);
      glow(ctx, mx, my, 22 + 28 * fl, '#ffffff', fl);
      star4(ctx, mx, my, 20 + 62 * fl, t * 1.6, '#ffffff', fl, 0.11);
      flake(ctx, mx + 26, my, 26 * fl + 8, t * 1.2, fl);
    }

    /* ================= SALJU BERJATUHAN & KABUT ================= */
    for (const f of this.flakes) {
      const a = clamp(Math.sin((f.life / f.max) * Math.PI) * 1.6, 0, 1) * 0.85;
      flake(ctx, f.x, f.y, f.r, f.rot, a, '#eaf7ff');
    }
    glow(ctx, mx - 10, my, 30, '#dff2ff', 0.12 + 0.1 * pulse);
    void pick;
  }
}

/* ================================ PELURU ================================ */

class Snowball extends Flight {
  private crystals: { a: number; r: number; s: number; ph: number }[] = [];
  constructor(w: World) {
    super(w, 1080, 0.1, 0.5, 0.2);
    this.trailMax = 14;
    for (let i = 0; i < 7; i++) {
      this.crystals.push({ a: rr(0, TAU), r: rr(20, 32), s: rr(2.5, 5), ph: rr(0, TAU) });
    }
  }
  onMove(_dt: number, w: World) {
    if (Math.random() < 0.7)
      w.fx.emit({
        x: this.pos.x + rr(-6, 6),
        y: this.pos.y + rr(-6, 6),
        vx: rr(-24, 24),
        vy: rr(-10, 30),
        life: rr(0.4, 0.8),
        size: rr(12, 24),
        size1: 2,
        kind: 'smoke',
        color: 'rgba(235,248,255,1)',
        add: false,
        drag: 2,
      });
    if (Math.random() < 0.5)
      w.fx.emit({
        x: this.pos.x,
        y: this.pos.y,
        vx: rr(-50, 50),
        vy: rr(-50, 50),
        life: rr(0.4, 0.8),
        size: rr(2, 4),
        kind: 'star',
        rot: rr(0, 3),
        vr: rr(-4, 4),
        color: '#eaf7ff',
        drag: 2.2,
      });
  }
  onHit(w: World, x: number, y: number) {
    w.add(new SnowPoof(x, y, w));
    w.target.hit('#bfe9ff');
    w.target.impulse(Math.cos(this.heading) * 160, Math.sin(this.heading) * 160);
    w.target.spin(1.2);
    w.shake(2.6);
  }
  draw(ctx: Ctx) {
    const { x, y } = this.pos;
    const n = this.trail.length;
    ctx.save();
    ctx.lineCap = 'round';
    for (let i = 1; i < n; i++) {
      const k = i / n;
      const a = this.trail[i - 1];
      const b = this.trail[i];
      ctx.strokeStyle = `rgba(225,242,255,${0.3 * k})`;
      ctx.lineWidth = 2 + 11 * k;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
    ctx.restore();
    lens(ctx, x, y, 30, 1.3, this.age * 2.2);
    glow(ctx, x, y, 38, '#8fd8ff', 0.55);
    const g = ctx.createRadialGradient(x - 7, y - 8, 2, x, y, 21);
    g.addColorStop(0, '#ffffff');
    g.addColorStop(0.55, '#e8f6ff');
    g.addColorStop(0.85, '#b8dcf5');
    g.addColorStop(1, '#7fb2dd');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, 20, 0, TAU);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.7)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    // butiran salju
    for (let i = 0; i < 10; i++) {
      const a = i * 2.4 + this.age * 2;
      const r = 2 + (i % 3) * 4;
      ctx.beginPath();
      ctx.arc(x + Math.cos(a) * r * 1.4, y + Math.sin(a) * r * 1.4, 1.4, 0, TAU);
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      ctx.fill();
    }
    // kristal es mengorbit
    for (const c of this.crystals) {
      const a = c.a + this.age * 2.4;
      const px = x + Math.cos(a) * c.r;
      const py = y + Math.sin(a) * c.r * 0.72;
      star4(ctx, px, py, c.s, a + this.age, '#eaf7ff', 0.9);
    }
    star4(ctx, x - 6, y - 7, 10, 0.4, '#ffffff', 0.8);
  }
}

/* ================================ TUMBUKAN ================================ */

class SnowPoof implements Entity {
  dead = false;
  layer: 0 | 1 = 1;
  age = 0;
  constructor(
    private x: number,
    private y: number,
    w: World,
  ) {
    for (let i = 0; i < 16; i++) {
      const a = rr(0, TAU);
      const sp = rr(40, 190);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 40,
        life: rr(0.8, 1.6),
        size: rr(22, 42),
        size1: 72,
        kind: 'smoke',
        color: 'rgba(238,249,255,1)',
        add: false,
        drag: 1.8,
        g: -30,
      });
    }
    for (let i = 0; i < 26; i++) {
      const a = rr(0, TAU);
      const sp = rr(120, 420);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 90,
        life: rr(0.6, 1.2),
        size: rr(5, 11),
        kind: 'shard',
        rot: rr(0, TAU),
        vr: rr(-12, 12),
        color: 'rgba(214,238,255,0.9)',
        drag: 1.9,
        g: 480,
        add: false,
        fade: 0.7,
      });
    }
    for (let i = 0; i < 14; i++) {
      const a = rr(0, TAU);
      const sp = rr(60, 300);
      w.fx.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.5, 1.0),
        size: rr(3, 6),
        kind: 'star',
        rot: rr(0, 3),
        vr: rr(-3, 3),
        color: '#eaf7ff',
        drag: 2.2,
      });
    }
    addFlash(w, x, y, 22, 150, 0.45, '#d8f2ff', 1);
    addRing(w, x, y, 10, 210, 0.72, '#eaf7ff', 4, 0.3, 0.95);
    addRing(w, x, y, 10, 150, 0.5, '#8fd8ff', 2, 0.2, 0.85, easeOutCubic, true, 0.08);
  }
  update(dt: number) {
    this.age += dt;
    if (this.age > 1.5) this.dead = true;
  }
  draw(ctx: Ctx) {
    const { x, y } = this;
    const a = this.age;
    if (a < 0.6) {
      const e = easeOutCubic(a / 0.6);
      const k = 1 - a / 0.6;
      glow(ctx, x, y, 70 + 150 * e, '#dff2ff', 0.55 * k);
      lens(ctx, x, y, 30 + 130 * e, 1.4, a * 2, k);
    }
    // gundukan salju yang terbentuk lalu runtuh
    if (a < 1.25) {
      const grow = clamp(a / 0.22, 0, 1);
      const crumble = clamp((a - 0.75) / 0.5, 0, 1);
      const R = 42 * grow * (1 - crumble * 0.45);
      const alpha = 0.95 * (1 - crumble);
      if (R > 1) {
        const g = ctx.createRadialGradient(x, y - R * 0.25, 1, x, y, R);
        g.addColorStop(0, `rgba(255,255,255,${alpha})`);
        g.addColorStop(0.6, `rgba(232,246,255,${alpha * 0.85})`);
        g.addColorStop(1, 'rgba(190,225,252,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.ellipse(x, y + R * 0.18, R, R * 0.55, 0, 0, TAU);
        ctx.fill();
        // kerak es
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        ctx.beginPath();
        ctx.ellipse(x, y + R * 0.18, R * 0.82, R * 0.4, 0, Math.PI, TAU);
        ctx.strokeStyle = `rgba(255,255,255,${0.6 * (1 - crumble)})`;
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.restore();
      }
    }
    // kepingan salju melayang dari pusat
    if (a < 1.4) {
      const u = a / 1.4;
      for (let i = 0; i < 6; i++) {
        const ang = (i / 6) * TAU + a * 0.5;
        const r = 20 + 120 * u;
        flake(ctx, x + Math.cos(ang) * r, y + Math.sin(ang) * r * 0.7, 9 * (1 - u * 0.5), ang + a, (1 - u) * 0.9);
      }
    }
    void hsla;
  }
}
