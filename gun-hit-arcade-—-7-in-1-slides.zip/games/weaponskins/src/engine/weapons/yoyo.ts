import { glow, star4 } from '../gfx';
import { addFlash, addRing } from '../particles';
import type { Ctx, Entity, World } from '../types';
import {
  clamp,
  easeInCubic,
  easeOutCubic,
  hsl,
  lerp,
  rr,
  smooth,
  TAU,
  type Vec,
} from '../util';
import { Weapon, type Bounds, type Features, type Theme } from '../weapon';

const YX = 174; // pusat yoyo (moncong)
const YR = 54;
const ANCH = { x: 76, y: -62 }; // titik keluar tali dari gulungan

/** Roda yoyo berwarna cerah, tampak depan */
export function drawYoyo(ctx: Ctx, x: number, y: number, r: number, rot: number, spin = 0, hue = 0) {
  ctx.save();
  ctx.translate(x, y);
  glow(ctx, 0, 0, r * 2.2, hsl(hue + 320, 100, 60), 0.3 + 0.2 * spin);
  // pelek warna-warni (conic gradient)
  const cg = ctx.createConicGradient(rot, 0, 0);
  const n = 12;
  for (let i = 0; i <= n; i++) cg.addColorStop(i / n, hsl(hue + i * 30, 95, 60));
  ctx.fillStyle = cg;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, TAU);
  ctx.fill();
  // tepi mengilap
  ctx.strokeStyle = 'rgba(255,255,255,0.9)';
  ctx.lineWidth = r * 0.07;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.965, 0, TAU);
  ctx.stroke();
  ctx.strokeStyle = 'rgba(50,10,90,0.5)';
  ctx.lineWidth = r * 0.05;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.77, 0, TAU);
  ctx.stroke();
  // cakram dalam
  const ig = ctx.createRadialGradient(-r * 0.22, -r * 0.28, r * 0.05, 0, 0, r * 0.76);
  ig.addColorStop(0, '#ffffff');
  ig.addColorStop(0.55, '#ffe0f4');
  ig.addColorStop(1, '#ff9ad6');
  ctx.fillStyle = ig;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.74, 0, TAU);
  ctx.fill();
  // irisan berputar
  ctx.save();
  ctx.rotate(rot * 1.1);
  for (let k = 0; k < 8; k += 2) {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, r * 0.73, (k * TAU) / 8, ((k + 1) * TAU) / 8);
    ctx.closePath();
    ctx.fillStyle = `hsla(${Math.round(hue + k * 45) % 360},95%,60%,${0.6 * (1 - spin * 0.75)})`;
    ctx.fill();
  }
  ctx.restore();
  if (spin > 0.2) {
    // kabur gerak: cincin konsentris
    ctx.strokeStyle = `rgba(255,255,255,${0.35 * spin})`;
    ctx.lineWidth = 1.3;
    for (let k = 1; k < 4; k++) {
      ctx.beginPath();
      ctx.arc(0, 0, r * (0.15 + k * 0.17), 0, TAU);
      ctx.stroke();
    }
  }
  ctx.strokeStyle = 'rgba(255,255,255,0.8)';
  ctx.lineWidth = r * 0.035;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.45, 0, TAU);
  ctx.stroke();
  // as tengah + bintang
  const ag = ctx.createRadialGradient(-r * 0.05, -r * 0.06, 1, 0, 0, r * 0.2);
  ag.addColorStop(0, '#ffffff');
  ag.addColorStop(0.5, '#ffe14a');
  ag.addColorStop(1, '#ff8a2a');
  ctx.fillStyle = ag;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.2, 0, TAU);
  ctx.fill();
  ctx.save();
  ctx.rotate(-rot * 1.3);
  ctx.fillStyle = '#7b3dff';
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const a = (i * TAU) / 10 - Math.PI / 2;
    const rad = i % 2 ? r * 0.05 : r * 0.12;
    ctx.lineTo(Math.cos(a) * rad, Math.sin(a) * rad);
  }
  ctx.closePath();
  ctx.fill();
  ctx.restore();
  // kilau
  ctx.save();
  ctx.rotate(-0.75);
  ctx.globalAlpha = 0.55;
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.ellipse(0, -r * 0.84, r * 0.3, r * 0.06, 0, 0, TAU);
  ctx.fill();
  ctx.restore();
  ctx.restore();
}

/** Tali elastis bergelombang */
function drawString(ctx: Ctx, a: Vec, b: Vec, amp: number, waves: number, phase: number, sag: number, alpha = 1) {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const len = Math.hypot(dx, dy) || 1;
  const nx = -dy / len;
  const ny = dx / len;
  const A = Math.min(amp, len * 0.3);
  const N = 36;
  const path = () => {
    ctx.beginPath();
    for (let i = 0; i <= N; i++) {
      const u = i / N;
      const env = Math.sin(Math.PI * u);
      const off = A * env * Math.sin(u * waves * TAU + phase);
      const x = a.x + dx * u + nx * off;
      const y = a.y + dy * u + ny * off + sag * 4 * u * (1 - u);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
  };
  ctx.save();
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.globalCompositeOperation = 'lighter';
  path();
  ctx.strokeStyle = 'rgba(255,170,240,0.35)';
  ctx.globalAlpha = alpha;
  ctx.lineWidth = 4.5;
  ctx.stroke();
  ctx.globalCompositeOperation = 'source-over';
  path();
  ctx.strokeStyle = 'rgba(255,255,255,0.95)';
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.restore();
}

export class YoyoGun extends Weapon {
  readonly id = 'yoyo';
  readonly name = 'Yoyo Gun';
  readonly tagline = 'Mainan ceria, tembakan berputar';
  readonly accent = '#ff6fd0';
  readonly theme: Theme = { top: '#150c3b', bottom: '#341a76', glow: '#ff5fc8' };
  readonly features: Features = {
    body: 'Badan permen berwarna cerah dengan roda yoyo besar di bagian depan dan gulungan tali.',
    bullet: 'Yoyo melesat ke target, BERPUTAR di titik tumbukan, lalu kembali lewat tali elastis.',
    impact: 'Percikan warna-warni dan putaran cepat.',
    idle: 'Yoyo berayun kecil naik-turun di dudukannya.',
  };
  readonly bounds: Bounds = { x0: -164, x1: 234, y0: -74, y1: 130 };
  kick = 10;
  cooldown = 0.2;
  out = false;
  catchT = 99;
  wobble = 0;
  reelSpin = 0;

  constructor() {
    super();
    this.muzzle = { x: YX, y: 0 };
  }

  canFire() {
    return !this.out && super.canFire();
  }

  update(dt: number, w: World) {
    super.update(dt, w);
    this.catchT += dt;
    this.wobble *= Math.exp(-dt * 3.2);
    this.muzzle.y = Math.sin(this.time * 2.3) * 8;
  }

  /** dipanggil saat yoyo kembali ke dudukannya */
  catchBack(w: World) {
    this.out = false;
    this.catchT = 0;
    this.wobble = 1;
    this.cd = 0.12;
    const m = w.muzzle;
    for (let i = 0; i < 12; i++) {
      const a = rr(0, TAU);
      const sp = rr(60, 220);
      w.fx.emit({
        x: m.x,
        y: m.y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.3, 0.6),
        size: rr(1.2, 2.2),
        kind: 'streak',
        color: hsl(rr(0, 360), 100, 68),
        drag: 3,
      });
    }
    addRing(w, m.x, m.y, 30, 84, 0.4, '#ff9ae6', 3, 0.5, 0.9);
    w.shake(1.8);
  }

  protected fire(w: World) {
    this.out = true;
    w.add(new YoyoBolt(w, this));
    w.shake(1.2);
    for (let i = 0; i < 14; i++) {
      const a = w.aim + rr(-0.7, 0.7);
      const sp = rr(100, 320);
      w.fx.emit({
        x: w.muzzle.x,
        y: w.muzzle.y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.25, 0.5),
        size: rr(1.4, 2.4),
        kind: 'streak',
        color: hsl(rr(0, 360), 100, 68),
        drag: 3,
      });
    }
  }

  drawBody(ctx: Ctx, _w: World) {
    const t = this.time;
    const bob = Math.sin(t * 2.3) * 8;
    const sway = Math.sin(t * 1.7) * 0.12;
    const pulse = 0.5 + 0.5 * Math.sin(t * 2.6);

    // pendar latar
    ctx.save();
    ctx.translate(40, 8);
    ctx.scale(1, 0.45);
    glow(ctx, 0, 0, 230, '#ff5fc8', 0.14 + 0.05 * pulse);
    ctx.restore();

    // ===== gagang =====
    ctx.beginPath();
    ctx.moveTo(-122, 28);
    ctx.lineTo(-64, 32);
    ctx.quadraticCurveTo(-58, 78, -62, 110);
    ctx.quadraticCurveTo(-64, 126, -82, 127);
    ctx.lineTo(-104, 127);
    ctx.quadraticCurveTo(-124, 125, -124, 106);
    ctx.quadraticCurveTo(-126, 68, -122, 28);
    ctx.closePath();
    const gg = ctx.createLinearGradient(-124, 30, -62, 120);
    gg.addColorStop(0, '#ffe45a');
    gg.addColorStop(1, '#ff8f2e');
    ctx.fillStyle = gg;
    ctx.fill();
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = 'rgba(255,255,255,0.7)';
    ctx.stroke();
    ctx.save();
    ctx.clip();
    ctx.strokeStyle = 'rgba(190,80,20,0.55)';
    ctx.lineWidth = 3;
    for (let i = 0; i < 5; i++) {
      ctx.beginPath();
      ctx.moveTo(-126, 58 + i * 14);
      ctx.quadraticCurveTo(-92, 66 + i * 14, -58, 58 + i * 14);
      ctx.stroke();
    }
    ctx.restore();
    // lencana bintang
    ctx.fillStyle = '#ff4fa3';
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const a = (i * TAU) / 10 - Math.PI / 2;
      const rad = i % 2 ? 4 : 9;
      ctx.lineTo(-92 + Math.cos(a) * rad, 42 + Math.sin(a) * rad);
    }
    ctx.closePath();
    ctx.fill();

    // pelindung picu
    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineWidth = 7;
    ctx.strokeStyle = '#1fd2ee';
    ctx.beginPath();
    ctx.moveTo(-60, 40);
    ctx.bezierCurveTo(-56, 84, -4, 84, 0, 44);
    ctx.stroke();
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'rgba(255,255,255,0.8)';
    ctx.stroke();
    ctx.lineWidth = 7;
    ctx.strokeStyle = '#ff4fa3';
    ctx.beginPath();
    ctx.moveTo(-34, 44);
    ctx.lineTo(-30, 62);
    ctx.stroke();
    ctx.restore();

    // ===== badan kapsul =====
    const body = () => {
      ctx.beginPath();
      ctx.roundRect(-156, -42, 262, 84, 40);
    };
    ctx.save();
    ctx.shadowColor = 'rgba(255,120,210,0.55)';
    ctx.shadowBlur = 22;
    body();
    const bg = ctx.createLinearGradient(0, -42, 0, 42);
    bg.addColorStop(0, '#ffffff');
    bg.addColorStop(0.55, '#ffe4f3');
    bg.addColorStop(1, '#ffa6d4');
    ctx.fillStyle = bg;
    ctx.fill();
    ctx.restore();
    ctx.save();
    body();
    ctx.clip();
    // tutup kuning belakang
    ctx.fillStyle = '#ffd23f';
    ctx.beginPath();
    ctx.moveTo(-160, -50);
    ctx.lineTo(-114, -50);
    ctx.quadraticCurveTo(-98, 0, -114, 50);
    ctx.lineTo(-160, 50);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.7)';
    ctx.lineWidth = 2;
    ctx.stroke();
    // pita diagonal tosca & ungu
    const sg = ctx.createLinearGradient(-30, 0, 40, 0);
    sg.addColorStop(0, '#2ee6ff');
    sg.addColorStop(1, '#8a5bff');
    ctx.fillStyle = sg;
    ctx.beginPath();
    ctx.moveTo(-26, -46);
    ctx.lineTo(26, -46);
    ctx.lineTo(-4, 46);
    ctx.lineTo(-56, 46);
    ctx.fill();
    ctx.fillStyle = '#ffd23f';
    ctx.beginPath();
    ctx.moveTo(34, -46);
    ctx.lineTo(48, -46);
    ctx.lineTo(18, 46);
    ctx.lineTo(4, 46);
    ctx.fill();
    // polkadot
    ctx.fillStyle = 'rgba(255,79,163,0.75)';
    [
      [-94, -24, 6],
      [-80, 6, 4.5],
      [-98, 20, 3.5],
      [66, -14, 5],
      [82, 12, 4],
      [92, -20, 3],
    ].forEach(([x, y, r]) => {
      ctx.beginPath();
      ctx.arc(x, y, r, 0, TAU);
      ctx.fill();
    });
    // kilau atas
    const gl = ctx.createLinearGradient(0, -42, 0, -12);
    gl.addColorStop(0, 'rgba(255,255,255,0.95)');
    gl.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = gl;
    ctx.beginPath();
    ctx.roundRect(-130, -38, 220, 22, 12);
    ctx.fill();
    // bayangan bawah
    const sh = ctx.createLinearGradient(0, 14, 0, 42);
    sh.addColorStop(0, 'rgba(200,60,150,0)');
    sh.addColorStop(1, 'rgba(200,60,150,0.35)');
    ctx.fillStyle = sh;
    ctx.fillRect(-160, 14, 270, 30);
    ctx.restore();
    ctx.lineWidth = 1.6;
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    body();
    ctx.stroke();

    // ===== gulungan tali =====
    ctx.save();
    ctx.translate(66, -54);
    // dudukan
    ctx.fillStyle = '#7b3dff';
    ctx.beginPath();
    ctx.roundRect(-9, 4, 18, 14, 4);
    ctx.fill();
    const rg = ctx.createRadialGradient(-3, -4, 2, 0, 0, 17);
    rg.addColorStop(0, '#b6f6ff');
    rg.addColorStop(0.6, '#2ee6ff');
    rg.addColorStop(1, '#1b8fc9');
    ctx.fillStyle = rg;
    ctx.beginPath();
    ctx.arc(0, 0, 16, 0, TAU);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.65)';
    ctx.lineWidth = 1;
    for (let k = 1; k < 3; k++) {
      ctx.beginPath();
      ctx.arc(0, 0, 4 + k * 3.4, 0, TAU);
      ctx.stroke();
    }
    ctx.save();
    ctx.rotate(this.reelSpin);
    ctx.strokeStyle = '#ff4fa3';
    ctx.lineWidth = 2;
    for (let k = 0; k < 3; k++) {
      ctx.rotate(TAU / 3);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(11, 0);
      ctx.stroke();
    }
    ctx.restore();
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.arc(0, 0, 2.6, 0, TAU);
    ctx.fill();
    ctx.restore();

    // ===== dudukan (cradle) yoyo =====
    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineWidth = 9;
    ctx.strokeStyle = '#18b8d8';
    ctx.beginPath();
    ctx.arc(YX, 0, YR + 9, Math.PI * 0.6, Math.PI * 1.4);
    ctx.stroke();
    ctx.lineWidth = 6;
    ctx.strokeStyle = '#2ee6ff';
    ctx.stroke();
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.beginPath();
    ctx.arc(YX, 0, YR + 10.5, Math.PI * 0.64, Math.PI * 1.36);
    ctx.stroke();
    ctx.restore();

    if (this.out) {
      // dudukan kosong: cincin hantu + as
      ctx.save();
      ctx.globalAlpha = 0.28 + 0.15 * pulse;
      ctx.setLineDash([6, 7]);
      ctx.lineDashOffset = -t * 30;
      ctx.strokeStyle = '#ffd0f2';
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.arc(YX, 0, YR, 0, TAU);
      ctx.stroke();
      ctx.restore();
      glow(ctx, YX, 0, 26, '#ff7ad9', 0.4 + 0.2 * pulse);
      ctx.fillStyle = '#ffe14a';
      ctx.beginPath();
      ctx.arc(YX, 0, 6, 0, TAU);
      ctx.fill();
    } else {
      // tali (dengan getar elastis setelah ditangkap)
      const a = { x: ANCH.x, y: ANCH.y };
      const b = { x: YX - 6, y: bob - 6 };
      drawString(ctx, a, b, 1.2 + 9 * this.wobble, 2 + this.wobble * 1.5, t * 3 + this.catchT * 30, 5 + bob * 0.3);
      // yoyo
      const cs = 1 + 0.26 * Math.exp(-this.catchT * 8) * Math.cos(this.catchT * 24);
      ctx.save();
      ctx.translate(YX, bob);
      ctx.rotate(sway);
      ctx.scale(cs, cs);
      drawYoyo(ctx, 0, 0, YR, t * 1.6, 0, Math.sin(t * 0.4) * 20);
      ctx.restore();
      // percik bintang berkelip
      for (let k = 0; k < 3; k++) {
        const ang = t * 0.9 + k * 2.1;
        const al = 0.5 + 0.5 * Math.sin(t * 3 + k * 2);
        star4(
          ctx,
          YX + Math.cos(ang) * YR * 1.35,
          bob + Math.sin(ang) * YR * 1.2,
          3 + 4 * al,
          ang,
          hsl(k * 120 + 330, 100, 82),
          al * 0.9,
        );
      }
      if (this.catchT < 0.45) {
        const u = this.catchT / 0.45;
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        ctx.globalAlpha = 1 - u;
        ctx.strokeStyle = hsl(330 + u * 200, 100, 75);
        ctx.lineWidth = 3 * (1 - u) + 0.5;
        ctx.beginPath();
        ctx.arc(YX, bob, YR * (1 + u * 0.9), 0, TAU);
        ctx.stroke();
        ctx.restore();
      }
    }
  }
}

/* =========================== PELURU YOYO =========================== */

type Phase = 'out' | 'spin' | 'back';

class YoyoBolt implements Entity {
  dead = false;
  layer: 0 | 1 = 1;
  age = 0;
  phase: Phase = 'out';
  pt = 0;
  pos: Vec;
  from: Vec;
  hitOff: Vec;
  rot = 0;
  hue = rr(0, 360);
  r: number;
  dur: number;
  private sparkAcc = 0;
  private jitterAcc = 0;
  private hitAcc = 0;
  readonly SPIN = 0.9;
  readonly BACK = 0.62;

  constructor(
    w: World,
    private weapon: YoyoGun,
  ) {
    this.pos = { x: w.muzzle.x, y: w.muzzle.y };
    this.from = { x: w.muzzle.x, y: w.muzzle.y };
    const a = rr(0, TAU);
    const d = rr(0.1, 0.35) * w.target.r;
    this.hitOff = { x: Math.cos(a) * d, y: Math.sin(a) * d };
    this.r = clamp(YR * w.scale * 0.52, 16, 34);
    const dist = Math.hypot(w.target.x - w.muzzle.x, w.target.y - w.muzzle.y);
    this.dur = clamp(dist / 1500, 0.26, 0.5);
  }

  private tp(w: World): Vec {
    return { x: w.target.x + this.hitOff.x, y: w.target.y + this.hitOff.y };
  }

  update(dt: number, w: World) {
    this.age += dt;
    this.hue = (this.hue + dt * 320) % 360;
    const spinSpeed = this.phase === 'spin' ? 46 : 24;
    this.rot += dt * spinSpeed;
    this.weapon.reelSpin += dt * (this.phase === 'back' ? -26 : 18);

    if (this.phase === 'out') {
      this.pt += dt / this.dur;
      const tp = this.tp(w);
      const e = easeOutCubic(this.pt);
      this.pos.x = lerp(this.from.x, tp.x, e);
      this.pos.y = lerp(this.from.y, tp.y, e);
      w.fx.emit({
        x: this.pos.x,
        y: this.pos.y,
        life: 0.35,
        size: this.r * 0.9,
        size1: 1,
        kind: 'glow',
        color: hsl(this.hue, 100, 62),
        vx: rr(-20, 20),
        vy: rr(-20, 20),
        drag: 2,
      });
      if (this.pt >= 1) {
        this.pt = 0;
        this.phase = 'spin';
        this.pos = tp;
        this.impact(w, tp);
      }
    } else if (this.phase === 'spin') {
      this.pt += dt / this.SPIN;
      const tp = this.tp(w);
      this.pos.x = tp.x + rr(-1.2, 1.2);
      this.pos.y = tp.y + rr(-1.2, 1.2);
      // percikan gesekan di tepi yoyo
      this.sparkAcc += dt * 90;
      while (this.sparkAcc > 1) {
        this.sparkAcc -= 1;
        const a = rr(0, TAU);
        const tx = -Math.sin(a);
        const ty = Math.cos(a);
        const sp = rr(120, 330);
        w.fx.emit({
          x: this.pos.x + Math.cos(a) * this.r,
          y: this.pos.y + Math.sin(a) * this.r,
          vx: tx * sp + Math.cos(a) * rr(30, 120),
          vy: ty * sp + Math.sin(a) * rr(30, 120),
          life: rr(0.25, 0.55),
          size: rr(1.2, 2.4),
          kind: 'streak',
          color: hsl(rr(0, 360), 100, 66),
          drag: 2.2,
          g: 260,
        });
      }
      this.jitterAcc += dt;
      if (this.jitterAcc > 0.05) {
        this.jitterAcc = 0;
        w.target.impulse(rr(-60, 60), rr(-60, 60));
      }
      this.hitAcc += dt;
      if (this.hitAcc > 0.18) {
        this.hitAcc = 0;
        w.target.hit(hsl(this.hue, 100, 65));
        addRing(w, this.pos.x, this.pos.y, this.r, this.r * 2.6, 0.4, hsl(this.hue + 120, 100, 70), 2, 0.3, 0.8);
      }
      if (this.pt >= 1) {
        this.pt = 0;
        this.phase = 'back';
        this.from = { x: this.pos.x, y: this.pos.y };
      }
    } else {
      this.pt += dt / this.BACK;
      const m = w.muzzle;
      const p = this.pt;
      const e = p < 0.14 ? -0.07 * Math.sin((p / 0.14) * Math.PI) : easeInCubic((p - 0.14) / 0.86);
      this.pos.x = lerp(this.from.x, m.x, e);
      this.pos.y = lerp(this.from.y, m.y, e);
      w.fx.emit({
        x: this.pos.x,
        y: this.pos.y,
        life: 0.3,
        size: this.r * 0.7,
        size1: 1,
        kind: 'glow',
        color: hsl(this.hue, 100, 62),
        drag: 2,
      });
      if (this.pt >= 1) {
        this.weapon.catchBack(w);
        this.dead = true;
      }
    }
  }

  private impact(w: World, p: Vec) {
    for (let i = 0; i < 44; i++) {
      const a = rr(0, TAU);
      const sp = rr(140, 520);
      w.fx.emit({
        x: p.x,
        y: p.y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.4, 0.9),
        size: rr(1.4, 3),
        kind: 'streak',
        color: hsl(i * 8.5 + rr(-10, 10), 100, 64),
        drag: 3,
        g: 280,
        len: 0.05,
      });
    }
    for (let i = 0; i < 18; i++) {
      const a = rr(0, TAU);
      const sp = rr(60, 300);
      w.fx.emit({
        x: p.x,
        y: p.y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.6, 1.2),
        size: rr(2.5, 5),
        kind: 'dot',
        color: hsl(rr(0, 360), 100, 66),
        drag: 1.8,
        g: 340,
      });
    }
    for (let i = 0; i < 8; i++) {
      const a = rr(0, TAU);
      w.fx.emit({
        x: p.x,
        y: p.y,
        vx: Math.cos(a) * rr(30, 160),
        vy: Math.sin(a) * rr(30, 160),
        life: rr(0.5, 0.9),
        size: rr(5, 10),
        kind: 'star',
        rot: rr(0, 3),
        vr: rr(-4, 4),
        color: hsl(rr(0, 360), 100, 82),
        drag: 2,
      });
    }
    addFlash(w, p.x, p.y, 20, 110, 0.4, '#ff8fe0', 0.9);
    addRing(w, p.x, p.y, 8, 90, 0.5, '#ff6ad5', 3, 0.4, 0.95);
    addRing(w, p.x, p.y, 8, 120, 0.6, '#5be9ff', 2.4, 0.3, 0.9, easeOutCubic, true, 0.06);
    addRing(w, p.x, p.y, 8, 150, 0.7, '#ffe14a', 1.8, 0.2, 0.9, easeOutCubic, true, 0.12);
    w.target.hit(hsl(this.hue, 100, 65));
    w.target.spin(3.2);
    w.shake(2.4);
  }

  draw(ctx: Ctx, w: World) {
    const a = w.toWorld(ANCH.x, ANCH.y);
    const p = this.pos;
    // tali
    if (this.phase === 'out') {
      drawString(ctx, a, p, 4 * (1 - this.pt) + 2, 1.5, -this.age * 40, 0);
    } else if (this.phase === 'spin') {
      drawString(ctx, a, p, 1.6 * Math.sin(this.age * 70) + 1.6, 3, this.age * 90, 0);
    } else {
      const s = Math.sin(this.pt * Math.PI);
      drawString(ctx, a, p, 34 * s * (1 - this.pt * 0.5), 1.2 + this.pt * 0.8, -this.age * 22, 20 * (1 - this.pt));
    }

    // putaran cepat di titik tumbukan
    if (this.phase === 'spin') {
      const k = easeOutCubic(Math.min(1, this.pt * 6)) * (1 - smooth((this.pt - 0.72) / 0.28));
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.lineCap = 'round';
      for (let j = 0; j < 3; j++) {
        const R = this.r * (1.35 + j * 0.42) + 3 * Math.sin(this.age * 22 + j);
        const dir = j % 2 ? -1 : 1;
        for (let m = 0; m < 3; m++) {
          const st = this.rot * 0.55 * dir + (m * TAU) / 3 + j;
          ctx.strokeStyle = hsl(this.hue + j * 70 + m * 40, 100, 66);
          ctx.globalAlpha = 0.85 * k;
          ctx.lineWidth = 4 - j;
          ctx.beginPath();
          ctx.arc(p.x, p.y, R, st, st + 1.25);
          ctx.stroke();
        }
      }
      ctx.globalAlpha = 0.5 * k;
      ctx.lineWidth = 1.5;
      for (let i = 0; i < 14; i++) {
        const an = this.rot * 0.4 + (i * TAU) / 14;
        ctx.strokeStyle = hsl(this.hue + i * 26, 100, 72);
        ctx.beginPath();
        ctx.moveTo(p.x + Math.cos(an) * this.r * 1.7, p.y + Math.sin(an) * this.r * 1.7);
        ctx.lineTo(p.x + Math.cos(an) * this.r * 2.5, p.y + Math.sin(an) * this.r * 2.5);
        ctx.stroke();
      }
      ctx.restore();
    }

    const spinK = this.phase === 'spin' ? 1 : 0.5;
    const big = w.scale * YR;
    const k =
      this.phase === 'out'
        ? 1 - easeOutCubic(Math.min(1, this.pt * 1.6))
        : this.phase === 'back'
          ? easeInCubic(this.pt)
          : 0;
    const rad = this.r + (big - this.r) * k;
    drawYoyo(ctx, p.x, p.y, rad, this.rot, spinK, this.hue);
  }
}
