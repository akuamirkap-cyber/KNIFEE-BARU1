import { glow, lens, star4 } from '../gfx';
import { addFlash, addRing, Timed } from '../particles';
import type { Ctx, World } from '../types';
import { clamp, easeOutBack, easeOutCubic, hsl, hsla, pick, rr, TAU } from '../util';
import { Flight, Weapon, type Bounds, type Features, type Theme } from '../weapon';

/* =============================== HELPER =============================== */

/** Irisan pisang berputar */
function bananaSlice(ctx: Ctx, x: number, y: number, r: number, rot: number, alpha = 1) {
  if (r < 0.6 || alpha <= 0) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.globalAlpha = clamp(alpha, 0, 1);
  const pg = ctx.createRadialGradient(-r * 0.2, -r * 0.25, r * 0.1, 0, 0, r);
  pg.addColorStop(0, '#fff6c8');
  pg.addColorStop(0.7, '#f4d265');
  pg.addColorStop(1, '#c9932a');
  ctx.fillStyle = pg;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, TAU);
  ctx.fill();
  ctx.fillStyle = '#fff8dc';
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.76, 0, TAU);
  ctx.fill();
  for (let i = 0; i < 5; i++) {
    const a = i * 1.25 + rot;
    ctx.beginPath();
    ctx.arc(Math.cos(a) * r * 0.3, Math.sin(a) * r * 0.3, r * 0.085, 0, TAU);
    ctx.fillStyle = 'rgba(122,82,20,0.55)';
    ctx.fill();
  }
  ctx.strokeStyle = 'rgba(255,255,255,0.8)';
  ctx.lineWidth = Math.max(0.7, r * 0.07);
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.92, 0, TAU);
  ctx.stroke();
  ctx.restore();
}

/** Pita keriting */
function streamer(ctx: Ctx, x: number, y: number, len: number, curl: number, hue: number, phase: number, alpha: number, width = 4) {
  ctx.save();
  ctx.translate(x, y);
  ctx.globalAlpha = clamp(alpha, 0, 1);
  ctx.strokeStyle = hsl(hue, 95, 62);
  ctx.lineWidth = width;
  ctx.lineCap = 'round';
  ctx.beginPath();
  for (let i = 0; i <= 24; i++) {
    const u = i / 24;
    const px = u * len;
    const py = Math.sin(u * curl * TAU + phase) * (6 + u * 22);
    i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
  }
  ctx.stroke();
  ctx.restore();
}

/** Goo pisang yang meletus */
function bananaGoo(ctx: Ctx, x: number, y: number, r: number, alpha: number) {
  const g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.35, r * 0.1, x, y, r);
  g.addColorStop(0, `rgba(255,247,205,${0.95 * alpha})`);
  g.addColorStop(0.55, `rgba(246,212,90,${0.85 * alpha})`);
  g.addColorStop(1, 'rgba(196,146,32,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, TAU);
  ctx.fill();
}

/* =============================== BANANA GUN =============================== */

export class BananaGun extends Weapon {
  readonly id = 'banana';
  readonly name = 'Banana Gun';
  readonly tagline = 'Kuning matang, lengkungan sempurna';
  readonly accent = '#ffd23a';
  readonly theme: Theme = { top: '#241a05', bottom: '#4a3407', glow: '#ffc93a' };
  readonly features: Features = {
    body: 'Badan pisang lengkung dengan ujung cokelat, flap kulit sebagai gagang, dan irisan pisang berputar di tengah.',
    bullet: 'Irisan pisang berputar yang MELENGKUNG seperti bumerang menuju target.',
    impact: 'Percikan goo pisang, potongan kulit beterbangan, dan kilau bintang kuning.',
    idle: 'Pisang bergoyang pelan, flap kulit berayun, dan kilau berkelip di sepanjang badan.',
  };
  readonly bounds: Bounds = { x0: -190, x1: 254, y0: -96, y1: 136 };
  kick = 12;
  cooldown = 0.32;

  constructor() {
    super();
    this.muzzle = { x: 238, y: 4 };
  }

  update(dt: number, w: World) {
    super.update(dt, w);
    const sway = Math.sin(this.time * 1.9) * 2.2;
    this.muzzle.y = 4 + sway * 0.5;
  }

  protected fire(w: World) {
    w.add(new BananaBolt(w));
    w.shake(1.8);
    for (let i = 0; i < 12; i++) {
      const a = w.aim + rr(-0.7, 0.7);
      const sp = rr(120, 360);
      w.fx.emit({
        x: w.muzzle.x,
        y: w.muzzle.y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.3, 0.7),
        size: rr(2, 4),
        kind: 'rect',
        rot: rr(0, TAU),
        vr: rr(-10, 10),
        color: pick(['#ffd23a', '#fff3b0', '#b7e04a']),
        drag: 2.6,
        add: false,
      });
    }
  }

  drawBody(ctx: Ctx, _w: World) {
    const t = this.time;
    const fl = this.flare(6);
    const wobble = Math.sin(t * 1.9) * 0.012;
    const pulse = 0.5 + 0.5 * Math.sin(t * 2.2);

    ctx.save();
    ctx.translate(30, 0);
    ctx.scale(1, 0.5);
    glow(ctx, 0, 0, 270, '#ffc93a', 0.12 + 0.05 * pulse + 0.22 * fl);
    ctx.restore();

    ctx.save();
    ctx.rotate(wobble);

    /* ---- flap kulit (gagang) ---- */
    const flap = (dx: number, dy: number, rot: number, inner: boolean) => {
      ctx.save();
      ctx.translate(dx, dy);
      ctx.rotate(rot + Math.sin(t * 1.7 + dx * 0.02) * 0.03);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.bezierCurveTo(-8, 36, 6, 70, 38, 86);
      ctx.quadraticCurveTo(62, 98, 72, 78);
      ctx.bezierCurveTo(56, 62, 38, 38, 32, -6);
      ctx.closePath();
      const g = ctx.createLinearGradient(0, 0, 62, 84);
      if (inner) {
        g.addColorStop(0, '#fff6cf');
        g.addColorStop(0.55, '#f6e6b4');
        g.addColorStop(1, '#d8c088');
      } else {
        g.addColorStop(0, '#ffd94a');
        g.addColorStop(0.6, '#eab72c');
        g.addColorStop(1, '#a97c12');
      }
      ctx.fillStyle = g;
      ctx.fill();
      ctx.strokeStyle = inner ? 'rgba(180,150,80,0.6)' : 'rgba(140,100,16,0.7)';
      ctx.lineWidth = 1.3;
      ctx.stroke();
      if (inner) {
        for (let i = 0; i < 5; i++) {
          ctx.strokeStyle = 'rgba(190,160,90,0.35)';
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(4 + i * 7, 4);
          ctx.bezierCurveTo(8 + i * 7, 34, 26 + i * 7, 58, 46 + i * 7, 72);
          ctx.stroke();
        }
      }
      ctx.restore();
    };
    flap(-104, 22, 0.16, false);
    flap(-80, 16, 0.42, true);

    /* ---- badan pisang ---- */
    const body = () => {
      ctx.beginPath();
      ctx.moveTo(-152, -70);
      ctx.bezierCurveTo(-46, -80, 118, -50, 236, 6);
      ctx.bezierCurveTo(152, 48, 18, 92, -118, 50);
      ctx.bezierCurveTo(-152, 34, -170, -40, -152, -70);
      ctx.closePath();
    };
    ctx.save();
    ctx.shadowColor = 'rgba(255,190,40,0.5)';
    ctx.shadowBlur = 20;
    body();
    const bg = ctx.createLinearGradient(0, -80, 0, 90);
    bg.addColorStop(0, '#fff3a8');
    bg.addColorStop(0.32, '#ffd94a');
    bg.addColorStop(0.62, '#e8b32c');
    bg.addColorStop(1, '#a97c12');
    ctx.fillStyle = bg;
    ctx.fill();
    ctx.restore();

    ctx.save();
    body();
    ctx.clip();
    // sorot panjang
    const hi = ctx.createLinearGradient(0, -80, 0, -10);
    hi.addColorStop(0, 'rgba(255,255,235,0.85)');
    hi.addColorStop(1, 'rgba(255,255,235,0)');
    ctx.fillStyle = hi;
    ctx.fillRect(-180, -84, 440, 78);
    // bayangan bawah
    const lo = ctx.createLinearGradient(0, 30, 0, 92);
    lo.addColorStop(0, 'rgba(120,80,10,0)');
    lo.addColorStop(1, 'rgba(120,80,10,0.38)');
    ctx.fillStyle = lo;
    ctx.fillRect(-180, 30, 440, 66);
    // bintik kematangan
    for (let i = 0; i < 34; i++) {
      const x = -150 + i * 11.5;
      const u = (x + 152) / 388;
      const y = -66 + u * 84 + Math.sin(i * 2.1) * 16;
      ctx.fillStyle = `rgba(120,80,14,${0.1 + 0.12 * Math.abs(Math.sin(i * 1.7))})`;
      ctx.beginPath();
      ctx.ellipse(x, y, 5.5, 2.4, 0.5, 0, TAU);
      ctx.fill();
    }
    // garis memanjang
    ctx.strokeStyle = 'rgba(160,112,18,0.35)';
    ctx.lineWidth = 1.6;
    for (let k = 0; k < 3; k++) {
      ctx.beginPath();
      ctx.moveTo(-150, -46 + k * 26);
      ctx.bezierCurveTo(-40, -58 + k * 26, 120, -30 + k * 26, 232, 6 + k * 12);
      ctx.stroke();
    }
    // kilau menyapu
    const sw = ((t * 0.3) % 1) * 420 - 220;
    ctx.globalCompositeOperation = 'lighter';
    const sg = ctx.createLinearGradient(sw - 46, -80, sw + 46, 40);
    sg.addColorStop(0, 'rgba(255,255,220,0)');
    sg.addColorStop(0.5, 'rgba(255,255,220,0.4)');
    sg.addColorStop(1, 'rgba(255,255,220,0)');
    ctx.fillStyle = sg;
    ctx.fillRect(-180, -90, 440, 190);
    ctx.restore();

    /* ---- ujung cokelat ---- */
    ctx.save();
    body();
    ctx.clip();
    const tipL = ctx.createLinearGradient(-172, -70, -120, -30);
    tipL.addColorStop(0, '#5a3608');
    tipL.addColorStop(1, 'rgba(90,54,8,0)');
    ctx.fillStyle = tipL;
    ctx.fillRect(-180, -90, 80, 190);
    const tipR = ctx.createLinearGradient(236, 6, 190, 30);
    tipR.addColorStop(0, '#4a2c06');
    tipR.addColorStop(1, 'rgba(74,44,6,0)');
    ctx.fillStyle = tipR;
    ctx.fillRect(180, -40, 80, 120);
    ctx.restore();

    /* ---- batang + daun ---- */
    ctx.save();
    ctx.translate(-152, -66);
    ctx.rotate(-0.7 + Math.sin(t * 1.4) * 0.02);
    ctx.beginPath();
    ctx.roundRect(-8, -10, 34, 20, 8);
    const st = ctx.createLinearGradient(-8, -10, 26, 10);
    st.addColorStop(0, '#6f8f2a');
    st.addColorStop(1, '#2f4a12');
    ctx.fillStyle = st;
    ctx.fill();
    ctx.strokeStyle = 'rgba(190,230,120,0.5)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(18, -4);
    ctx.quadraticCurveTo(56, -28, 78, -14);
    ctx.quadraticCurveTo(52, 4, 20, 8);
    ctx.closePath();
    const lg = ctx.createLinearGradient(18, -14, 78, 4);
    lg.addColorStop(0, '#7fbb3a');
    lg.addColorStop(1, '#2e5c14');
    ctx.fillStyle = lg;
    ctx.fill();
    ctx.restore();

    /* ---- irisan pisang berputar di tengah ---- */
    const cx = 40;
    const cy = 6;
    ctx.save();
    glow(ctx, cx, cy, 66 + 18 * pulse + 40 * fl, '#ffe27a', 0.35 + 0.14 * pulse + 0.3 * fl);
    ctx.beginPath();
    ctx.arc(cx, cy, 40, 0, TAU);
    const ch = ctx.createRadialGradient(cx - 10, cy - 12, 3, cx, cy, 40);
    ch.addColorStop(0, '#fffbe6');
    ch.addColorStop(0.6, '#e8c657');
    ch.addColorStop(1, '#8d6410');
    ctx.fillStyle = ch;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,246,200,0.8)';
    ctx.lineWidth = 2;
    ctx.stroke();
    bananaSlice(ctx, cx, cy, 30, t * 1.1, 1);
    ctx.restore();

    /* ---- pelindung picu + picu ---- */
    ctx.save();
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#7a5410';
    ctx.lineWidth = 13;
    ctx.beginPath();
    ctx.moveTo(-38, 60);
    ctx.bezierCurveTo(-32, 98, 22, 98, 30, 56);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,246,200,0.5)';
    ctx.lineWidth = 3.4;
    ctx.stroke();
    ctx.restore();
    ctx.save();
    ctx.translate(-4, 62);
    ctx.rotate((1 - Math.min(1, this.since * 6)) * 0.32);
    ctx.beginPath();
    ctx.roundRect(-6, 0, 12, 30, 6);
    const tg = ctx.createLinearGradient(-6, 0, 6, 30);
    tg.addColorStop(0, '#ffe98f');
    tg.addColorStop(1, '#a97c12');
    ctx.fillStyle = tg;
    ctx.fill();
    ctx.restore();

    /* ---- moncong ---- */
    const mx = this.muzzle.x;
    const my = this.muzzle.y;
    glow(ctx, mx - 8, my, 16 + 5 * pulse, '#ffe27a', 0.5 + 0.18 * pulse);
    if (fl > 0.02) {
      glow(ctx, mx, my, 52 + 100 * fl, '#ffd23a', 1.1 * fl);
      glow(ctx, mx, my, 22 + 26 * fl, '#fffbe6', fl);
      star4(ctx, mx, my, 20 + 66 * fl, t * 2, '#fffbe6', fl, 0.12);
      for (let i = 0; i < 5; i++) {
        bananaSlice(ctx, mx + 26 + i * 22, my + Math.sin(i * 1.7) * 16, 7 + i * 2, t * 4 + i, fl * (1 - i * 0.15));
      }
    }
    ctx.restore();

    /* ---- kilau bintang ---- */
    for (let i = 0; i < 4; i++) {
      const a = t * 0.8 + i * 1.6;
      const al = 0.45 + 0.45 * Math.sin(t * 2.6 + i * 1.4);
      star4(ctx, 40 + Math.cos(a) * 170, 10 + Math.sin(a) * 78, 5 + 4 * al, a, '#fff6c8', al, 0.14);
    }
  }
}

class BananaBolt extends Flight {
  private arc: number;
  constructor(w: World) {
    super(w, 1120, 0.12, 0.5, 0.22);
    this.arc = rr(70, 140) * (Math.random() < 0.5 ? 1 : -1);
    this.trailMax = 14;
  }
  onMove(_dt: number, w: World, p: number) {
    const off = Math.sin(p * Math.PI) * this.arc;
    this.pos.x += off * 0.28;
    this.pos.y += off;
    w.fx.emit({
      x: this.pos.x,
      y: this.pos.y,
      life: 0.42,
      size: rr(6, 12),
      size1: 1,
      kind: 'glow',
      color: pick(['#ffd23a', '#ffe98f']),
      drag: 2.4,
    });
    if (Math.random() < 0.5)
      w.fx.emit({
        x: this.pos.x,
        y: this.pos.y,
        vx: rr(-50, 50),
        vy: rr(-50, 50),
        life: rr(0.35, 0.8),
        size: rr(2, 4),
        kind: 'rect',
        rot: rr(0, TAU),
        vr: rr(-10, 10),
        color: pick(['#fff3b0', '#b7e04a']),
        drag: 2,
        add: false,
      });
  }
  onHit(w: World, x: number, y: number) {
    bananaImpact(w, x, y);
  }
  draw(ctx: Ctx) {
    const { x, y } = this.pos;
    const n = this.trail.length;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round';
    for (let i = 1; i < n; i++) {
      const k = i / n;
      const a = this.trail[i - 1];
      const b = this.trail[i];
      ctx.strokeStyle = `rgba(255,214,90,${0.34 * k})`;
      ctx.lineWidth = 2 + 12 * k;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
    ctx.restore();
    glow(ctx, x, y, 40, '#ffd23a', 0.7);
    bananaSlice(ctx, x, y, 17, this.age * 13, 1);
  }
}

function bananaImpact(w: World, x: number, y: number) {
  for (let i = 0; i < 30; i++) {
    const a = rr(0, TAU);
    const sp = rr(110, 430);
    w.fx.emit({
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp - 60,
      life: rr(0.45, 1.0),
      size: rr(3, 7),
      kind: 'dot',
      color: pick(['#ffe98f', '#ffd23a', '#f4d265']),
      add: false,
      g: 520,
      drag: 1.6,
    });
  }
  for (let i = 0; i < 16; i++) {
    const a = rr(0, TAU);
    const sp = rr(120, 380);
    w.fx.emit({
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp - 120,
      life: rr(0.6, 1.2),
      size: rr(5, 10),
      kind: 'shard',
      rot: rr(0, TAU),
      vr: rr(-12, 12),
      color: pick(['rgba(234,183,44,0.95)', 'rgba(255,246,200,0.95)', 'rgba(140,100,16,0.9)']),
      drag: 1.6,
      g: 560,
      add: false,
      fade: 0.7,
    });
  }
  for (let i = 0; i < 10; i++) {
    w.fx.emit({
      x,
      y,
      vx: rr(-140, 140),
      vy: rr(-140, 140),
      life: rr(0.4, 0.8),
      size: rr(6, 12),
      kind: 'star',
      rot: rr(0, 3),
      vr: rr(-4, 4),
      color: '#fff6c8',
      drag: 2.4,
    });
  }
  addFlash(w, x, y, 18, 130, 0.42, '#ffd23a', 1);
  addRing(w, x, y, 8, 140, 0.55, '#ffe98f', 3, 0.25, 0.95);
  addRing(w, x, y, 8, 190, 0.75, '#b7e04a', 1.6, 0.2, 0.8, easeOutCubic, true, 0.07);
  w.add(
    new Timed(0.75, (ctx, t) => {
      const e = easeOutBack(clamp(t * 2, 0, 1));
      const fade = Math.pow(1 - t, 1.2);
      bananaGoo(ctx, x, y, 26 + 60 * easeOutCubic(t), fade);
      bananaSlice(ctx, x, y, 40 * e * (1 - t * 0.4), t * 6, fade);
    }),
  );
  w.target.hit('#ffd23a');
  w.target.impulse(rr(-90, 90), -110);
  w.target.spin(2.2);
  w.shake(2.2);
}

/* =============================== CONFETTI GUN =============================== */

export class ConfettiGun extends Weapon {
  readonly id = 'confetti';
  readonly name = 'Confetti Gun';
  readonly tagline = 'Meriam pesta — satu tembakan, satu perayaan';
  readonly accent = '#ff5fa2';
  readonly theme: Theme = { top: '#1b0a24', bottom: '#3d1046', glow: '#ff4f9a' };
  readonly features: Features = {
    body: 'Badan kertas pesta bergaris pelangi, tabung spiral, pinggiran rumbai, dan pita keriting menggantung.',
    bullet: 'Paket konfeti berputar yang meledak jadi hujan kertas warna-warni.',
    impact: 'Badai konfeti, pita keriting melengkung, terompet pesta, dan cincin pelangi.',
    idle: 'Garis berkilau berganti warna, konfeti melayang, dan rumbai bergetar tertiup angin.',
  };
  readonly bounds: Bounds = { x0: -186, x1: 256, y0: -104, y1: 138 };
  kick = 10;
  cooldown = 0.3;

  constructor() {
    super();
    this.muzzle = { x: 242, y: 0 };
  }

  protected fire(w: World) {
    w.add(new ConfettiPacket(w));
    w.shake(1.6);
    for (let i = 0; i < 26; i++) {
      const a = w.aim + rr(-0.5, 0.5);
      const sp = rr(120, 420);
      w.fx.emit({
        x: w.muzzle.x,
        y: w.muzzle.y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rr(0.5, 1.1),
        size: rr(3, 6),
        kind: 'rect',
        rot: rr(0, TAU),
        vr: rr(-12, 12),
        color: hsl(rr(0, 360), 95, 62),
        drag: 2.2,
        g: 240,
        add: false,
      });
    }
  }

  drawBody(ctx: Ctx, _w: World) {
    const t = this.time;
    const fl = this.flare(6);
    const pulse = 0.5 + 0.5 * Math.sin(t * 2.4);

    ctx.save();
    ctx.translate(30, 0);
    ctx.scale(1, 0.5);
    glow(ctx, 0, 0, 280, '#ff4f9a', 0.12 + 0.06 * pulse + 0.22 * fl);
    ctx.restore();

    /* ---- pita keriting menggantung ---- */
    for (let i = 0; i < 4; i++) {
      const x = -120 + i * 70;
      streamer(ctx, x, 52, 62, 2.4 + i * 0.3, i * 84 + t * 30, t * 2 + i, 0.85, 4.5);
    }

    /* ---- tabung pesta ---- */
    const tube = () => {
      ctx.beginPath();
      ctx.moveTo(-150, -50);
      ctx.lineTo(36, -58);
      ctx.lineTo(36, 58);
      ctx.lineTo(-150, 50);
      ctx.closePath();
    };
    ctx.save();
    ctx.shadowColor = 'rgba(255,90,170,0.5)';
    ctx.shadowBlur = 18;
    tube();
    ctx.fillStyle = '#f6f2ff';
    ctx.fill();
    ctx.restore();
    ctx.save();
    tube();
    ctx.clip();
    // garis pesta melingkar
    for (let i = 0; i < 9; i++) {
      const x = -152 + i * 22;
      ctx.fillStyle = hsla(i * 42 + t * 26, 92, 58, 0.92);
      ctx.beginPath();
      ctx.moveTo(x, -62);
      ctx.lineTo(x + 14, -62);
      ctx.lineTo(x + 2, 62);
      ctx.lineTo(x - 12, 62);
      ctx.closePath();
      ctx.fill();
    }
    // kilau
    const hi = ctx.createLinearGradient(0, -58, 0, -6);
    hi.addColorStop(0, 'rgba(255,255,255,0.55)');
    hi.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = hi;
    ctx.fillRect(-160, -60, 210, 56);
    const lo = ctx.createLinearGradient(0, 18, 0, 58);
    lo.addColorStop(0, 'rgba(60,10,70,0)');
    lo.addColorStop(1, 'rgba(60,10,70,0.32)');
    ctx.fillStyle = lo;
    ctx.fillRect(-160, 18, 210, 44);
    ctx.restore();
    tube();
    ctx.strokeStyle = 'rgba(255,255,255,0.7)';
    ctx.lineWidth = 1.4;
    ctx.stroke();

    /* ---- cincin pita ---- */
    for (const x of [-142, -34, 28]) {
      ctx.beginPath();
      ctx.roundRect(x, -58, 12, 116, 5);
      const g = ctx.createLinearGradient(x, -58, x + 12, 58);
      g.addColorStop(0, '#fff3b0');
      g.addColorStop(0.5, '#ffd23a');
      g.addColorStop(1, '#c98f1c');
      ctx.fillStyle = g;
      ctx.fill();
      ctx.strokeStyle = 'rgba(120,80,10,0.5)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    /* ---- tabung spiral ke moncong ---- */
    ctx.beginPath();
    ctx.moveTo(36, -46);
    ctx.lineTo(150, -34);
    ctx.lineTo(150, 34);
    ctx.lineTo(36, 46);
    ctx.closePath();
    const sn = ctx.createLinearGradient(36, -46, 150, 34);
    sn.addColorStop(0, '#fff0f8');
    sn.addColorStop(1, '#d8c6ea');
    ctx.fillStyle = sn;
    ctx.fill();
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(36, -46);
    ctx.lineTo(150, -34);
    ctx.lineTo(150, 34);
    ctx.lineTo(36, 46);
    ctx.closePath();
    ctx.clip();
    for (let i = 0; i < 7; i++) {
      const x = 40 + i * 17;
      ctx.fillStyle = hsla(i * 52 + t * 40, 92, 60, 0.9);
      ctx.beginPath();
      ctx.moveTo(x, -50);
      ctx.lineTo(x + 10, -50);
      ctx.lineTo(x - 6, 50);
      ctx.lineTo(x - 16, 50);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
    ctx.strokeStyle = 'rgba(255,255,255,0.6)';
    ctx.lineWidth = 1.1;
    ctx.stroke();

    /* ---- corong rumbai ---- */
    ctx.beginPath();
    ctx.moveTo(150, -36);
    ctx.lineTo(214, -62);
    ctx.lineTo(214, 62);
    ctx.lineTo(150, 36);
    ctx.closePath();
    const fn = ctx.createLinearGradient(150, -62, 214, 62);
    fn.addColorStop(0, '#ffe6f2');
    fn.addColorStop(0.5, '#ff8fc4');
    fn.addColorStop(1, '#c93c86');
    ctx.fillStyle = fn;
    ctx.fill();
    // rumbai
    for (let i = 0; i < 13; i++) {
      const u = i / 12;
      const y = -62 + u * 124;
      const flap = Math.sin(t * 3 + i * 0.9) * 4;
      ctx.beginPath();
      ctx.moveTo(214, y);
      ctx.lineTo(232 + flap, y - 5);
      ctx.lineTo(232 + flap, y + 5);
      ctx.closePath();
      ctx.fillStyle = hsla(i * 28 + t * 30, 92, 62, 0.95);
      ctx.fill();
    }
    ctx.strokeStyle = 'rgba(255,255,255,0.5)';
    ctx.lineWidth = 1.1;
    ctx.beginPath();
    ctx.moveTo(150, -36);
    ctx.lineTo(214, -62);
    ctx.moveTo(150, 36);
    ctx.lineTo(214, 62);
    ctx.stroke();

    /* ---- gagang ---- */
    ctx.beginPath();
    ctx.moveTo(-118, 32);
    ctx.lineTo(-56, 38);
    ctx.lineTo(-44, 112);
    ctx.quadraticCurveTo(-46, 128, -66, 128);
    ctx.lineTo(-96, 126);
    ctx.quadraticCurveTo(-112, 124, -110, 106);
    ctx.closePath();
    const gg = ctx.createLinearGradient(-112, 32, -46, 128);
    gg.addColorStop(0, '#fff3b0');
    gg.addColorStop(0.5, '#ffd23a');
    gg.addColorStop(1, '#b57e14');
    ctx.fillStyle = gg;
    ctx.fill();
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(-118, 32);
    ctx.lineTo(-56, 38);
    ctx.lineTo(-44, 112);
    ctx.quadraticCurveTo(-46, 128, -66, 128);
    ctx.lineTo(-96, 126);
    ctx.quadraticCurveTo(-112, 124, -110, 106);
    ctx.closePath();
    ctx.clip();
    for (let i = 0; i < 6; i++) {
      ctx.fillStyle = hsla(i * 60 + t * 30, 92, 58, 0.75);
      ctx.beginPath();
      ctx.moveTo(-124 + i * 16, 28);
      ctx.lineTo(-112 + i * 16, 28);
      ctx.lineTo(-104 + i * 16, 132);
      ctx.lineTo(-116 + i * 16, 132);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
    ctx.strokeStyle = 'rgba(255,255,255,0.55)';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    /* ---- pelindung picu ---- */
    ctx.save();
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#c88c18';
    ctx.lineWidth = 13;
    ctx.beginPath();
    ctx.moveTo(-72, 38);
    ctx.bezierCurveTo(-70, 80, -16, 80, -8, 34);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.42)';
    ctx.lineWidth = 3.4;
    ctx.stroke();
    ctx.restore();

    /* ---- moncong ---- */
    const mx = this.muzzle.x;
    const my = this.muzzle.y;
    glow(ctx, mx, my, 24 + 8 * pulse, '#ff8fc4', 0.45 + 0.2 * pulse);
    if (fl > 0.02) {
      glow(ctx, mx, my, 56 + 110 * fl, hsl(t * 260, 95, 65), 1.1 * fl);
      star4(ctx, mx, my, 24 + 74 * fl, t * 2, '#ffffff', fl, 0.11);
      star4(ctx, mx, my, 16 + 40 * fl, t * 2 + 0.78, hsl(t * 300, 95, 72), fl * 0.9, 0.13);
    }

    /* ---- konfeti melayang ---- */
    for (let i = 0; i < 14; i++) {
      const ph = (t * 0.22 + i * 0.13) % 1;
      const x = -170 + i * 30 + Math.sin(t * 1.2 + i) * 12;
      const y = 110 - ph * 210;
      const al = 0.85 * Math.sin(ph * Math.PI);
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(t * 2 + i);
      ctx.fillStyle = hsla(i * 26 + t * 40, 95, 62, al);
      ctx.fillRect(-5, -3, 10, 6);
      ctx.restore();
    }
  }
}

class ConfettiPacket extends Flight {
  constructor(w: World) {
    super(w, 1250, 0.1, 0.45, 0.18);
    this.trailMax = 12;
  }
  onMove(_dt: number, w: World) {
    w.fx.emit({
      x: this.pos.x,
      y: this.pos.y,
      vx: rr(-40, 40),
      vy: rr(-40, 40),
      life: rr(0.3, 0.7),
      size: rr(3, 5),
      kind: 'rect',
      rot: rr(0, TAU),
      vr: rr(-12, 12),
      color: hsl(rr(0, 360), 95, 62),
      drag: 2,
      add: false,
    });
    if (Math.random() < 0.6)
      w.fx.emit({
        x: this.pos.x,
        y: this.pos.y,
        life: 0.35,
        size: 12,
        size1: 2,
        kind: 'glow',
        color: hsl(rr(0, 360), 95, 68),
      });
  }
  onHit(w: World, x: number, y: number) {
    confettiImpact(w, x, y);
  }
  draw(ctx: Ctx) {
    const { x, y } = this.pos;
    const n = this.trail.length;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round';
    for (let i = 1; i < n; i++) {
      const k = i / n;
      const a = this.trail[i - 1];
      const b = this.trail[i];
      ctx.strokeStyle = hsla(this.age * 300 + i * 20, 95, 62, 0.32 * k);
      ctx.lineWidth = 2 + 9 * k;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
    ctx.restore();
    glow(ctx, x, y, 30, hsl(this.age * 300, 95, 66), 0.7);
    // paket kertas berputar
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(this.age * 12);
    for (let i = 0; i < 6; i++) {
      ctx.fillStyle = hsla(i * 60 + this.age * 200, 95, 62, 0.95);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, 15, (i * TAU) / 6, ((i + 1) * TAU) / 6);
      ctx.closePath();
      ctx.fill();
    }
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.arc(0, 0, 5, 0, TAU);
    ctx.fill();
    ctx.restore();
  }
}

function confettiImpact(w: World, x: number, y: number) {
  for (let i = 0; i < 90; i++) {
    const a = rr(0, TAU);
    const sp = rr(90, 520);
    w.fx.emit({
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp - 140,
      life: rr(0.9, 1.9),
      size: rr(3, 6.5),
      kind: 'rect',
      rot: rr(0, TAU),
      vr: rr(-16, 16),
      color: hsl(i * 4 + rr(-12, 12), 95, 62),
      drag: 1.5,
      g: 300,
      add: false,
      fade: 0.55,
    });
  }
  for (let i = 0; i < 24; i++) {
    const a = rr(0, TAU);
    const sp = rr(60, 300);
    w.fx.emit({
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp,
      life: rr(0.5, 1.0),
      size: rr(6, 12),
      kind: 'star',
      rot: rr(0, 3),
      vr: rr(-5, 5),
      color: hsl(rr(0, 360), 95, 82),
      drag: 2.2,
    });
  }
  for (let i = 0; i < 12; i++) {
    w.fx.emit({
      x,
      y,
      vx: rr(-120, 120),
      vy: rr(-120, 120),
      life: rr(0.4, 0.8),
      size: rr(16, 30),
      size1: 3,
      kind: 'glow',
      color: hsl(rr(0, 360), 95, 66),
      drag: 2.6,
    });
  }
  addFlash(w, x, y, 22, 160, 0.5, '#ffffff', 1);
  addRing(w, x, y, 10, 210, 0.7, '#ffffff', 3, 0.3, 0.95);
  w.add(
    new Timed(1.15, (ctx, t, age) => {
      const fade = Math.pow(1 - t, 1.2);
      ctx.globalCompositeOperation = 'lighter';
      // pita keriting meledak keluar
      for (let i = 0; i < 9; i++) {
        const ang = (i / 9) * TAU + age * 0.5;
        const r = 30 + 190 * easeOutCubic(t);
        ctx.save();
        ctx.translate(x + Math.cos(ang) * r * 0.4, y + Math.sin(ang) * r * 0.4);
        ctx.rotate(ang);
        streamer(ctx, 0, 0, r * 0.9, 2.6 + i * 0.2, i * 40 + age * 160, age * 5 + i, fade * 0.95, 5);
        ctx.restore();
      }
      // cincin pelangi
      for (let k = 0; k < 3; k++) {
        const R = 20 + (120 + k * 70) * easeOutCubic(clamp(t * 1.4 - k * 0.12, 0, 1));
        ctx.beginPath();
        ctx.arc(x, y, R, 0, TAU);
        ctx.strokeStyle = hsla(age * 300 + k * 110, 95, 64, fade * 0.8);
        ctx.lineWidth = 6 - k * 1.6;
        ctx.stroke();
      }
    }),
  );
  w.target.hit('#ff8fc4');
  w.target.impulse(rr(-80, 80), -140);
  w.target.spin(2.6);
  w.shake(1.8);
}

/* =============================== BUBBLE GUN =============================== */

export class BubbleGun extends Weapon {
  readonly id = 'bubble';
  readonly name = 'Bubble Gun';
  readonly tagline = 'Gelembung sabun yang tak pernah diam';
  readonly accent = '#7fe8ff';
  readonly theme: Theme = { top: '#0b1c2c', bottom: '#20365c', glow: '#7fe8ff' };
  readonly features: Features = {
    body: 'Badan transparan berkilau sabun dengan tangki berisi busa dan cincin gelembung di moncong.',
    bullet: 'Gelembung sabun berwarna-warni yang melayang bergelombang sambil memecahkan cahaya.',
    impact: 'Pecah jadi cincin tipis, tetesan air, serpih film berkilau, dan gelembung kecil melayang naik.',
    idle: 'Gelembung melayang di sekitar badan, film sabun berkilau berganti warna, dan busa bergerak di tangki.',
  };
  readonly bounds: Bounds = { x0: -186, x1: 252, y0: -112, y1: 136 };
  kick = 8;
  cooldown = 0.36;
  private bubbles: { x: number; y: number; r: number; vy: number; ph: number }[] = [];

  constructor() {
    super();
    this.muzzle = { x: 222, y: 0 };
    for (let i = 0; i < 18; i++) {
      this.bubbles.push({
        x: rr(-160, 220),
        y: rr(-90, 110),
        r: rr(5, 17),
        vy: rr(12, 30),
        ph: rr(0, TAU),
      });
    }
  }

  update(dt: number, w: World) {
    super.update(dt, w);
    for (const b of this.bubbles) {
      b.y -= b.vy * dt;
      b.x += Math.sin(this.time * 1.3 + b.ph) * 12 * dt;
      if (b.y < -108) {
        b.y = 118;
        b.x = rr(-160, 220);
      }
    }
  }

  protected fire(w: World) {
    w.add(new BubbleShot(w));
    w.shake(0.9);
    for (let i = 0; i < 8; i++) {
      w.fx.emit({
        x: w.muzzle.x + rr(-6, 16),
        y: w.muzzle.y + rr(-10, 10),
        vx: rr(80, 240),
        vy: rr(-40, 40),
        life: rr(0.5, 1.0),
        size: rr(4, 9),
        kind: 'glow',
        color: pick(['#a8f2ff', '#ffc2f0', '#c8ffd8']),
        drag: 1.8,
      });
    }
  }

  drawBody(ctx: Ctx, _w: World) {
    const t = this.time;
    const fl = this.flare(6);
    const pulse = 0.5 + 0.5 * Math.sin(t * 1.8);

    ctx.save();
    ctx.translate(30, 0);
    ctx.scale(1, 0.5);
    glow(ctx, 0, 0, 270, '#7fe8ff', 0.11 + 0.05 * pulse + 0.2 * fl);
    glow(ctx, -60, -20, 190, '#ff9ee0', 0.07 + 0.05 * pulse + 0.14 * fl);
    ctx.restore();

    /* ---- tangki sabun ---- */
    ctx.save();
    const tank = () => {
      ctx.beginPath();
      ctx.roundRect(-104, -96, 132, 56, 22);
    };
    tank();
    const tg = ctx.createLinearGradient(-104, -96, 28, -40);
    tg.addColorStop(0, 'rgba(235,252,255,0.92)');
    tg.addColorStop(0.5, 'rgba(150,232,255,0.6)');
    tg.addColorStop(1, 'rgba(255,180,235,0.55)');
    ctx.fillStyle = tg;
    ctx.fill();
    tank();
    ctx.clip();
    // busa bergerak
    for (let i = 0; i < 12; i++) {
      const ph = (t * 0.28 + i * 0.09) % 1;
      const x = -98 + i * 11.5 + Math.sin(t + i) * 4;
      const y = -42 - ph * 46;
      ctx.beginPath();
      ctx.arc(x, y, 4 + (i % 3) * 2.4, 0, TAU);
      ctx.fillStyle = 'rgba(255,255,255,0.4)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(160,235,255,0.7)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    const sg = ctx.createLinearGradient(-104, -96, -60, -40);
    sg.addColorStop(0, 'rgba(255,255,255,0.7)');
    sg.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = sg;
    ctx.fillRect(-110, -100, 150, 40);
    ctx.restore();
    tank();
    ctx.strokeStyle = 'rgba(255,255,255,0.65)';
    ctx.lineWidth = 1.3;
    ctx.stroke();

    /* ---- badan transparan ---- */
    const body = () => {
      ctx.beginPath();
      ctx.moveTo(-152, -42);
      ctx.quadraticCurveTo(-150, -56, -128, -58);
      ctx.lineTo(72, -56);
      ctx.quadraticCurveTo(132, -52, 158, -32);
      ctx.quadraticCurveTo(172, -6, 158, 20);
      ctx.quadraticCurveTo(132, 44, 72, 50);
      ctx.lineTo(-128, 48);
      ctx.quadraticCurveTo(-152, 46, -152, 30);
      ctx.quadraticCurveTo(-158, -6, -152, -42);
      ctx.closePath();
    };
    ctx.save();
    ctx.shadowColor = 'rgba(120,225,255,0.45)';
    ctx.shadowBlur = 18;
    body();
    const bg = ctx.createLinearGradient(0, -58, 0, 50);
    bg.addColorStop(0, 'rgba(250,255,255,0.95)');
    bg.addColorStop(0.42, 'rgba(178,238,255,0.8)');
    bg.addColorStop(1, 'rgba(120,180,255,0.7)');
    ctx.fillStyle = bg;
    ctx.fill();
    ctx.restore();

    ctx.save();
    body();
    ctx.clip();
    // kilau film sabun (konis)
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.34;
    ctx.fillStyle = paintSoap(ctx, 20, -4, t * 0.6);
    ctx.fillRect(-160, -60, 340, 112);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
    // aliran cairan
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      for (let x = -160; x <= 170; x += 6) {
        const y = -10 + i * 15 + Math.sin(x * 0.028 + t * (1.2 + i * 0.25)) * 6;
        x === -160 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      ctx.strokeStyle = 'rgba(255,255,255,0.3)';
      ctx.lineWidth = 4 - i;
      ctx.stroke();
    }
    const hi = ctx.createLinearGradient(0, -58, 0, -8);
    hi.addColorStop(0, 'rgba(255,255,255,0.8)');
    hi.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = hi;
    ctx.fillRect(-160, -58, 340, 52);
    ctx.restore();
    body();
    ctx.strokeStyle = 'rgba(255,255,255,0.7)';
    ctx.lineWidth = 1.3;
    ctx.stroke();

    /* ---- gagang ---- */
    ctx.beginPath();
    ctx.moveTo(-112, 26);
    ctx.lineTo(-56, 32);
    ctx.lineTo(-42, 110);
    ctx.quadraticCurveTo(-44, 126, -62, 126);
    ctx.lineTo(-92, 124);
    ctx.quadraticCurveTo(-108, 122, -106, 104);
    ctx.closePath();
    const gg = ctx.createLinearGradient(-108, 26, -44, 126);
    gg.addColorStop(0, 'rgba(226,250,255,0.95)');
    gg.addColorStop(0.5, 'rgba(140,215,255,0.9)');
    gg.addColorStop(1, 'rgba(80,130,210,0.9)');
    ctx.fillStyle = gg;
    ctx.fill();
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(-112, 26);
    ctx.lineTo(-56, 32);
    ctx.lineTo(-42, 110);
    ctx.quadraticCurveTo(-44, 126, -62, 126);
    ctx.lineTo(-92, 124);
    ctx.quadraticCurveTo(-108, 122, -106, 104);
    ctx.closePath();
    ctx.clip();
    ctx.fillStyle = paintSoap(ctx, -80, 80, t * 0.5);
    ctx.globalAlpha = 0.4;
    ctx.fillRect(-120, 20, 100, 120);
    ctx.globalAlpha = 1;
    ctx.restore();
    ctx.strokeStyle = 'rgba(255,255,255,0.6)';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    /* ---- pelindung picu ---- */
    ctx.save();
    ctx.lineCap = 'round';
    ctx.strokeStyle = 'rgba(96,158,228,0.95)';
    ctx.lineWidth = 13;
    ctx.beginPath();
    ctx.moveTo(-70, 32);
    ctx.bezierCurveTo(-70, 74, -18, 74, -10, 28);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.5)';
    ctx.lineWidth = 3.4;
    ctx.stroke();
    ctx.restore();
    // picu di dalam pelindung
    ctx.save();
    ctx.translate(-40, 30);
    ctx.rotate((1 - Math.min(1, this.since * 6)) * 0.3);
    ctx.beginPath();
    ctx.roundRect(-7, 0, 13, 32, 6);
    const bt = ctx.createLinearGradient(-7, 0, 6, 32);
    bt.addColorStop(0, '#eafcff');
    bt.addColorStop(1, '#4b7fc4');
    ctx.fillStyle = bt;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.55)';
    ctx.lineWidth = 1.1;
    ctx.stroke();
    ctx.restore();

    /* ---- moncong: tabung penyemprot + cincin gelembung ---- */
    ctx.beginPath();
    ctx.roundRect(142, -18, 82, 36, 14);
    const nt = ctx.createLinearGradient(142, -18, 224, 18);
    nt.addColorStop(0, 'rgba(232,251,255,0.95)');
    nt.addColorStop(0.5, 'rgba(152,222,255,0.82)');
    nt.addColorStop(1, 'rgba(112,176,255,0.88)');
    ctx.fillStyle = nt;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.6)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    for (let k = 0; k < 2; k++) {
      const x = 158 + k * 34;
      const ry = 27 - k * 3;
      ctx.beginPath();
      ctx.ellipse(x, 0, 8, ry, 0, 0, TAU);
      const ng = ctx.createLinearGradient(x, -ry, x, ry);
      ng.addColorStop(0, '#eafcff');
      ng.addColorStop(0.5, '#8fd8f5');
      ng.addColorStop(1, '#4b7fc4');
      ctx.fillStyle = ng;
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.6)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    // film sabun menempel di mulut tabung
    const mx = this.muzzle.x;
    const my = this.muzzle.y;
    ctx.save();
    ctx.beginPath();
    ctx.ellipse(216, my, 6, 19, 0, 0, TAU);
    ctx.fillStyle = paintSoap(ctx, 216, my, t * 1.4);
    ctx.globalAlpha = 0.72;
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.strokeStyle = 'rgba(255,255,255,0.7)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.restore();
    glow(ctx, mx, my, 24 + 7 * pulse, '#a8f2ff', 0.42 + 0.2 * pulse);
    if (fl > 0.02) {
      glow(ctx, mx, my, 50 + 96 * fl, '#a8f2ff', 1.05 * fl);
      glow(ctx, mx, my, 22 + 26 * fl, '#ffffff', fl);
      star4(ctx, mx, my, 18 + 58 * fl, t * 2, '#ffffff', fl, 0.12);
    }

    /* ---- gelembung melayang ---- */
    for (const b of this.bubbles) {
      const shimmer = 0.5 + 0.5 * Math.sin(t * 2 + b.ph);
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.r, 0, TAU);
      ctx.fillStyle = 'rgba(255,255,255,0.12)';
      ctx.fill();
      ctx.strokeStyle = paintSoap(ctx, b.x, b.y, t * 1.2 + b.ph);
      ctx.globalAlpha = 0.85;
      ctx.lineWidth = 1.6;
      ctx.stroke();
      ctx.globalAlpha = 1;
      ctx.beginPath();
      ctx.arc(b.x - b.r * 0.32, b.y - b.r * 0.36, b.r * 0.22, 0, TAU);
      ctx.fillStyle = `rgba(255,255,255,${0.5 + 0.4 * shimmer})`;
      ctx.fill();
    }
    void lens;
    void hsla;
    void pick;
  }
}

/** Gradasi film sabun berwarna-warni */
function paintSoap(ctx: Ctx, cx: number, cy: number, rot: number) {
  const g = ctx.createConicGradient(rot, cx, cy);
  g.addColorStop(0, '#8ff0ff');
  g.addColorStop(0.25, '#c8a8ff');
  g.addColorStop(0.5, '#ff9ee0');
  g.addColorStop(0.75, '#b8ffd0');
  g.addColorStop(1, '#8ff0ff');
  return g;
}

class BubbleShot extends Flight {
  private wob = rr(40, 90);
  private ph = rr(0, TAU);
  private smalls: { a: number; r: number; s: number }[] = [];
  constructor(w: World) {
    super(w, 820, 0.15, 0.6, 0.28);
    this.trailMax = 10;
    for (let i = 0; i < 5; i++) this.smalls.push({ a: rr(0, TAU), r: rr(22, 34), s: rr(3, 7) });
  }
  onMove(_dt: number, w: World, p: number) {
    const off = Math.sin(p * Math.PI * 2.3 + this.ph) * this.wob * Math.sin(p * Math.PI);
    this.pos.x += off * 0.25;
    this.pos.y += off;
    if (Math.random() < 0.6)
      w.fx.emit({
        x: this.pos.x + rr(-10, 10),
        y: this.pos.y + rr(-10, 10),
        life: rr(0.4, 0.8),
        size: rr(4, 9),
        kind: 'glow',
        color: pick(['#a8f2ff', '#ffc2f0', '#d8ffbe']),
        drag: 1.6,
      });
  }
  onHit(w: World, x: number, y: number) {
    bubbleImpact(w, x, y);
  }
  draw(ctx: Ctx) {
    const { x, y } = this.pos;
    const r = 22;
    glow(ctx, x, y, 42, '#a8f2ff', 0.5);
    lens(ctx, x, y, 30, 1.25, this.age * 1.5);
    // film sabun
    ctx.save();
    ctx.globalAlpha = 0.28;
    ctx.fillStyle = paintSoap(ctx, x, y, this.age * 1.6);
    ctx.beginPath();
    ctx.arc(x, y, r, 0, TAU);
    ctx.fill();
    ctx.restore();
    // tepi berwarna
    ctx.save();
    ctx.beginPath();
    ctx.arc(x, y, r, 0, TAU);
    ctx.strokeStyle = paintSoap(ctx, x, y, this.age * 2.2);
    ctx.lineWidth = 2.6;
    ctx.globalAlpha = 0.95;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(x, y, r * 0.985, this.age * 1.2, this.age * 1.2 + 2.4);
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.lineWidth = 1.6;
    ctx.stroke();
    ctx.restore();
    // sorot
    ctx.beginPath();
    ctx.arc(x - r * 0.36, y - r * 0.4, r * 0.2, 0, TAU);
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    ctx.fill();
    ctx.beginPath();
    ctx.arc(x + r * 0.34, y + r * 0.36, r * 0.1, 0, TAU);
    ctx.fillStyle = 'rgba(255,255,255,0.5)';
    ctx.fill();
    // gelembung kecil pengiring
    for (const s of this.smalls) {
      const a = s.a + this.age * 1.6;
      const px = x + Math.cos(a) * s.r;
      const py = y + Math.sin(a) * s.r * 0.8;
      ctx.beginPath();
      ctx.arc(px, py, s.s, 0, TAU);
      ctx.strokeStyle = paintSoap(ctx, px, py, this.age * 2);
      ctx.lineWidth = 1.3;
      ctx.stroke();
    }
  }
}

function bubbleImpact(w: World, x: number, y: number) {
  for (let i = 0; i < 22; i++) {
    const a = rr(0, TAU);
    const sp = rr(60, 320);
    w.fx.emit({
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp - 60,
      life: rr(0.5, 1.1),
      size: rr(1.6, 3.6),
      kind: 'dot',
      color: 'rgba(228,250,255,0.9)',
      add: false,
      g: 380,
      drag: 1.4,
    });
  }
  for (let i = 0; i < 16; i++) {
    const a = rr(0, TAU);
    const sp = rr(60, 260);
    w.fx.emit({
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp - 90,
      life: rr(0.7, 1.5),
      size: rr(3, 7),
      kind: 'glow',
      color: pick(['#a8f2ff', '#ffc2f0', '#d8ffbe', '#ffe9a8']),
      drag: 1.7,
      g: -60,
    });
  }
  for (let i = 0; i < 12; i++) {
    const a = rr(0, TAU);
    const sp = rr(90, 340);
    w.fx.emit({
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp,
      life: rr(0.6, 1.2),
      size: rr(4, 8),
      kind: 'shard',
      rot: rr(0, TAU),
      vr: rr(-10, 10),
      color: pick(['rgba(180,240,255,0.75)', 'rgba(255,190,235,0.75)', 'rgba(200,255,215,0.75)']),
      drag: 1.8,
      add: false,
      fade: 0.8,
    });
  }
  addFlash(w, x, y, 16, 120, 0.4, '#d8f8ff', 1);
  addRing(w, x, y, 12, 150, 0.55, '#eafcff', 2.2, 0.2, 0.9);
  addRing(w, x, y, 12, 110, 0.4, '#ffc2f0', 1.6, 0.15, 0.85, easeOutCubic, true, 0.06);
  w.add(
    new Timed(0.85, (ctx, t, age) => {
      const e = easeOutCubic(t);
      const fade = Math.pow(1 - t, 1.3);
      const R = 16 + 120 * e;
      // cangkang tipis yang menipis lalu pecah
      ctx.save();
      ctx.globalAlpha = 0.5 * fade;
      ctx.beginPath();
      ctx.arc(x, y, R, 0, TAU);
      ctx.strokeStyle = paintSoap(ctx, x, y, age * 3);
      ctx.lineWidth = 2.4 * fade + 0.4;
      ctx.stroke();
      ctx.restore();
      // kilau bintang sabun
      for (let i = 0; i < 8; i++) {
        const ang = (i / 8) * TAU + age * 1.4;
        const r = R * 0.92;
        star4(ctx, x + Math.cos(ang) * r, y + Math.sin(ang) * r, 8 * (1 - t) + 2, ang, '#ffffff', fade * 0.8);
      }
    }),
  );
  w.target.hit('#a8f2ff');
  w.target.impulse(rr(-50, 50), -60);
  w.target.spin(0.9);
  w.shake(0.9);
}
