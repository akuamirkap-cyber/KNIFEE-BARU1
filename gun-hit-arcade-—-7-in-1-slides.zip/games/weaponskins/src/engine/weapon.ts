import type { Ctx, Entity, World } from './types';
import { clamp, easeOutCubic, rr, TAU, type Vec } from './util';

export interface Theme {
  top: string;
  bottom: string;
  glow: string;
}

export interface Features {
  body: string;
  bullet: string;
  impact: string;
  idle: string;
}

export interface Bounds {
  x0: number;
  x1: number;
  y0: number;
  y1: number;
}

/** Kelas dasar semua senjata. Semua gambar memakai koordinat lokal (moncong ke +x). */
export abstract class Weapon {
  abstract readonly id: string;
  abstract readonly name: string;
  abstract readonly tagline: string;
  abstract readonly accent: string;
  abstract readonly theme: Theme;
  abstract readonly features: Features;
  abstract readonly bounds: Bounds;
  muzzle: Vec = { x: 230, y: 0 };
  kick = 14;
  cooldown = 0.28;
  since = 99;
  cd = 0;
  time = Math.random() * 10;

  get center(): Vec {
    const b = this.bounds;
    return { x: (b.x0 + b.x1) / 2, y: (b.y0 + b.y1) / 2 };
  }

  canFire() {
    return this.cd <= 0;
  }

  /** Envelope hentakan: naik cepat lalu berayun redam */
  kickEnv() {
    const s = this.since;
    if (s < 0.03) return s / 0.03;
    const u = s - 0.03;
    return Math.exp(-u * 9) * Math.cos(u * 13);
  }
  recoilShift() {
    return -this.kick * this.kickEnv();
  }
  recoilTilt() {
    return -0.035 * this.kickEnv();
  }
  /** kilatan 1 → 0 setelah menembak */
  flare(rate = 5) {
    return Math.exp(-this.since * rate);
  }

  trigger(w: World): boolean {
    if (!this.canFire()) return false;
    this.cd = this.cooldown;
    this.since = 0;
    this.fire(w);
    return true;
  }

  update(dt: number, _w: World) {
    this.time += dt;
    this.since += dt;
    this.cd -= dt;
  }

  protected abstract fire(w: World): void;
  abstract drawBody(ctx: Ctx, w: World): void;
}

/** Peluru yang melesat dari moncong ke target (mengikuti posisi target secara langsung) */
export abstract class Flight implements Entity {
  dead = false;
  layer: 0 | 1 = 1;
  age = 0;
  dur: number;
  start: Vec;
  pos: Vec;
  hitOff: Vec;
  heading: number;
  trail: { x: number; y: number; r: number }[] = [];
  trailMax = 10;

  constructor(w: World, speed = 1100, hitMin = 0.1, hitMax = 0.5, minDur = 0.17) {
    this.start = { x: w.muzzle.x, y: w.muzzle.y };
    this.pos = { x: w.muzzle.x, y: w.muzzle.y };
    const a = rr(0, TAU);
    const d = rr(hitMin, hitMax) * w.target.r;
    this.hitOff = { x: Math.cos(a) * d, y: Math.sin(a) * d };
    const dx = w.target.x + this.hitOff.x - this.start.x;
    const dy = w.target.y + this.hitOff.y - this.start.y;
    this.heading = Math.atan2(dy, dx);
    this.dur = Math.max(minDur, Math.hypot(dx, dy) / speed);
  }

  ease(p: number) {
    return p;
  }

  dest(w: World): Vec {
    return { x: w.target.x + this.hitOff.x, y: w.target.y + this.hitOff.y };
  }

  update(dt: number, w: World) {
    this.age += dt;
    const p = clamp(this.age / this.dur, 0, 1);
    const d = this.dest(w);
    const e = this.ease(p);
    const nx = this.start.x + (d.x - this.start.x) * e;
    const ny = this.start.y + (d.y - this.start.y) * e;
    if (Math.hypot(nx - this.pos.x, ny - this.pos.y) > 0.01) this.heading = Math.atan2(ny - this.pos.y, nx - this.pos.x);
    this.pos.x = nx;
    this.pos.y = ny;
    this.onMove(dt, w, p);
    this.trail.push({ x: nx, y: ny, r: this.spinAngle() });
    if (this.trail.length > this.trailMax) this.trail.shift();
    if (p >= 1) {
      this.dead = true;
      this.onHit(w, nx, ny);
    }
  }

  spinAngle() {
    return 0;
  }
  onMove(_dt: number, _w: World, _p: number) {}
  abstract onHit(w: World, x: number, y: number): void;
  abstract draw(ctx: Ctx, w: World): void;
}

export { easeOutCubic };
