import type { Particles } from './particles';
import type { Vec } from './util';

export type Ctx = CanvasRenderingContext2D;

export interface Entity {
  dead: boolean;
  /** 0 = di belakang senjata, 1 = di depan senjata */
  layer: 0 | 1;
  update(dt: number, w: World): void;
  draw(ctx: Ctx, w: World): void;
}

export interface TargetLike {
  /** posisi target saat ini (sudah termasuk tarikan/guncangan) */
  readonly x: number;
  readonly y: number;
  readonly r: number;
  /** tarik target ke arah (x,y) sejauh `amount` px (panggil tiap frame) */
  pull(x: number, y: number, amount: number): void;
  impulse(dx: number, dy: number): void;
  hit(color: string): void;
  spin(v: number): void;
}

export interface World {
  time: number;
  width: number;
  height: number;
  scale: number;
  /** posisi moncong dalam koordinat dunia */
  muzzle: Vec;
  aim: number;
  target: TargetLike;
  fx: Particles;
  toWorld(lx: number, ly: number): Vec;
  add(e: Entity): void;
  shake(amount: number): void;
  /** menarik debu ambient ke titik (x,y) */
  attract(x: number, y: number, radius: number, strength: number, dt: number): void;
}
