import { Particles } from './particles';
import type { World } from './types';
import type { Weapon } from './weapon';
import { BlackHoleGun } from './weapons/blackhole';
import { CrystalGun } from './weapons/crystal';
import { DiamondGun } from './weapons/diamond';
import { Ak47Gun, PistolGun, RevolverGun } from './weapons/arms';
import { BubbleGun, ConfettiGun, BananaGun } from './weapons/party';
import { KerisGun } from './weapons/keris';
import { ObliteratorGun } from './weapons/obliterator';
import { RainbowGun } from './weapons/rainbow';
import { SnowballGun } from './weapons/snowball';
import { WaterGun } from './weapons/water';
import { YoyoGun } from './weapons/yoyo';

export { Arena } from './arena';
export type { Weapon } from './weapon';

export function createWeapons(): Weapon[] {
  return [
    new KerisGun(),
    new BlackHoleGun(),
    new YoyoGun(),
    new DiamondGun(),
    new CrystalGun(),
    new ObliteratorGun(),
    new RainbowGun(),
    new WaterGun(),
    new SnowballGun(),
    new PistolGun(),
    new Ak47Gun(),
    new RevolverGun(),
    new BananaGun(),
    new ConfettiGun(),
    new BubbleGun(),
  ];
}

/** Pratinjau kecil (kartu senjata) dengan animasi idle */
export function startPreview(canvas: HTMLCanvasElement, weapon: Weapon): () => void {
  const ctx = canvas.getContext('2d')!;
  let running = true;
  let raf = 0;
  let last = performance.now();
  let cw = 0;
  let ch = 0;
  let dpr = 1;

  const world: World = {
    time: 0,
    width: 0,
    height: 0,
    scale: 1,
    muzzle: { x: 0, y: 0 },
    aim: 0,
    target: { x: 0, y: 0, r: 40, pull() {}, impulse() {}, hit() {}, spin() {} },
    fx: new Particles(),
    toWorld: (x, y) => ({ x, y }),
    add() {},
    shake() {},
    attract() {},
  };

  const measure = () => {
    const r = canvas.getBoundingClientRect();
    dpr = Math.min(2, window.devicePixelRatio || 1);
    cw = r.width;
    ch = r.height;
    canvas.width = Math.round(cw * dpr);
    canvas.height = Math.round(ch * dpr);
  };
  measure();
  const ro = new ResizeObserver(measure);
  ro.observe(canvas);

  const loop = (now: number) => {
    if (!running) return;
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    world.time += dt;
    weapon.update(dt, world);
    if (cw > 0 && ch > 0) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, cw, ch);
      const b = weapon.bounds;
      const s = Math.min((cw * 0.86) / (b.x1 - b.x0), (ch * 0.84) / (b.y1 - b.y0));
      const c = weapon.center;
      ctx.save();
      ctx.translate(cw / 2, ch / 2);
      ctx.scale(s, s);
      ctx.translate(-c.x, -c.y);
      weapon.drawBody(ctx, world);
      ctx.restore();
    }
    raf = requestAnimationFrame(loop);
  };
  raf = requestAnimationFrame(loop);

  return () => {
    running = false;
    cancelAnimationFrame(raf);
    ro.disconnect();
  };
}
