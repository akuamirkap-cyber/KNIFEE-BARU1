import { glow, star4 } from './gfx';
import { clamp, easeOutCubic, hsl, hsla, pick, rr, TAU } from './util';

type Ctx = CanvasRenderingContext2D;

/* ============================ DESAIN RODA ============================ */

export interface Skin {
  id: string;
  name: string;
  tag: string;
  accent: string;
  bg: [string, string];
  draw: (ctx: Ctx, r: number, t: number) => void;
}

function rivet(ctx: Ctx, x: number, y: number, rad: number, light = '#e8e2d4', dark = '#2b2118') {
  const g = ctx.createRadialGradient(x - rad * 0.35, y - rad * 0.4, rad * 0.1, x, y, rad);
  g.addColorStop(0, light);
  g.addColorStop(1, dark);
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, rad, 0, TAU);
  ctx.fill();
}

/** 1. Kayu Bertotem — gelondongan kayu dengan cincin tumbuh dan ukiran */
const wood: Skin = {
  id: 'wood',
  name: 'Kayu Bertotem',
  tag: 'Gelondongan kayu purba dengan ukiran suku',
  accent: '#e0a75c',
  bg: ['#241608', '#120a04'],
  draw(ctx, r, t) {
    const g = ctx.createRadialGradient(-r * 0.2, -r * 0.25, r * 0.1, 0, 0, r);
    g.addColorStop(0, '#b57a3c');
    g.addColorStop(0.55, '#8a5423');
    g.addColorStop(1, '#4c2c0e');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, TAU);
    ctx.fill();
    // cincin tumbuh
    for (let i = 1; i <= 7; i++) {
      ctx.beginPath();
      for (let a = 0; a <= 64; a++) {
        const ang = (a / 64) * TAU;
        const rr2 = (r * i) / 7 + Math.sin(ang * 5 + i * 1.4) * r * 0.016;
        const x = Math.cos(ang) * rr2;
        const y = Math.sin(ang) * rr2;
        a ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
      ctx.closePath();
      ctx.strokeStyle = `rgba(60,32,12,${0.32 - i * 0.02})`;
      ctx.lineWidth = 1.6;
      ctx.stroke();
    }
    // retak
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * TAU + 0.3;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      for (let k = 1; k <= 5; k++) {
        const rr2 = (r * k) / 5;
        ctx.lineTo(Math.cos(a + Math.sin(k * 2.1 + i) * 0.08) * rr2, Math.sin(a + Math.sin(k * 2.1 + i) * 0.08) * rr2);
      }
      ctx.strokeStyle = 'rgba(40,20,6,0.45)';
      ctx.lineWidth = 2.2;
      ctx.stroke();
    }
    // ikatan besi
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.93, 0, TAU);
    ctx.strokeStyle = '#3a2c20';
    ctx.lineWidth = r * 0.13;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.93, 0, TAU);
    ctx.strokeStyle = 'rgba(220,190,150,0.32)';
    ctx.lineWidth = r * 0.05;
    ctx.stroke();
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * TAU + t * 0.05;
      rivet(ctx, Math.cos(a) * r * 0.93, Math.sin(a) * r * 0.93, r * 0.032);
    }
    // ukiran tengah
    ctx.strokeStyle = 'rgba(250,210,150,0.5)';
    ctx.lineWidth = r * 0.028;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.arc(0, 0, r * (0.22 + i * 0.14), t * 0.25 + i, t * 0.25 + i + 3.6);
      ctx.stroke();
    }
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * TAU - Math.PI / 2;
      const rr2 = i % 2 ? r * 0.16 : r * 0.32;
      ctx.lineTo(Math.cos(a) * rr2, Math.sin(a) * rr2);
    }
    ctx.closePath();
    ctx.strokeStyle = 'rgba(255,224,170,0.65)';
    ctx.lineWidth = r * 0.03;
    ctx.stroke();
  },
};

/** 2. Giok Nebula — batu giok dengan glyph menyala */
const jade: Skin = {
  id: 'jade',
  name: 'Giok Nebula',
  tag: 'Batu giok dalam dengan glyph bercahaya',
  accent: '#4ce0b4',
  bg: ['#04231d', '#020f0c'],
  draw(ctx, r, t) {
    const g = ctx.createRadialGradient(-r * 0.25, -r * 0.3, r * 0.1, 0, 0, r);
    g.addColorStop(0, '#2fae8e');
    g.addColorStop(0.55, '#156b5c');
    g.addColorStop(1, '#06302b');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, TAU);
    ctx.fill();
    for (let i = 0; i < 14; i++) {
      const a0 = (i / 14) * TAU;
      const a1 = ((i + 0.92) / 14) * TAU;
      const grad = ctx.createRadialGradient(0, 0, r * 0.1, 0, 0, r);
      grad.addColorStop(0, 'rgba(120,255,215,0)');
      grad.addColorStop(1, `rgba(120,255,215,${0.06 + 0.05 * Math.sin(t * 1.4 + i)})`);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, r * 0.86, a0, a1);
      ctx.closePath();
      ctx.fillStyle = grad;
      ctx.fill();
    }
    // glyph menyala
    ctx.save();
    ctx.rotate(t * 0.18);
    ctx.strokeStyle = 'rgba(120,255,220,0.85)';
    ctx.lineWidth = r * 0.035;
    ctx.lineCap = 'round';
    for (let i = 0; i < 6; i++) {
      ctx.rotate(TAU / 6);
      ctx.beginPath();
      ctx.moveTo(r * 0.3, 0);
      ctx.lineTo(r * 0.52, 0);
      ctx.lineTo(r * 0.44, r * 0.16);
      ctx.moveTo(r * 0.52, 0);
      ctx.lineTo(r * 0.44, -r * 0.16);
      ctx.stroke();
    }
    ctx.restore();
    ctx.save();
    ctx.rotate(-t * 0.12);
    for (let i = 0; i < 6; i++) {
      ctx.rotate(TAU / 6);
      star4(ctx, r * 0.68, 0, r * 0.07, 0, '#b6fff0', 0.5 + 0.4 * Math.sin(t * 2 + i));
    }
    ctx.restore();
    glow(ctx, 0, 0, r * 0.55, '#4ce0b4', 0.3 + 0.12 * Math.sin(t * 1.6));
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.92, 0, TAU);
    ctx.strokeStyle = 'rgba(140,255,225,0.5)';
    ctx.lineWidth = r * 0.05;
    ctx.stroke();
  },
};

/** 3. Kristal Es — facet es dengan kilau */
const ice: Skin = {
  id: 'ice',
  name: 'Kristal Es',
  tag: 'Bongkah es facet yang tak pernah mencair',
  accent: '#8fd8ff',
  bg: ['#0b2440', '#05101c'],
  draw(ctx, r, t) {
    const g = ctx.createLinearGradient(-r, -r, r, r);
    g.addColorStop(0, '#dff2ff');
    g.addColorStop(0.5, '#8fc6ee');
    g.addColorStop(1, '#2f6ea8');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, TAU);
    ctx.fill();
    for (let i = 0; i < 12; i++) {
      const a0 = (i / 12) * TAU;
      const a1 = ((i + 0.94) / 12) * TAU;
      const k = 0.5 + 0.5 * Math.sin(t * 1.2 + i * 1.1);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(Math.cos(a0) * r * 0.9, Math.sin(a0) * r * 0.9);
      ctx.lineTo(Math.cos(a1) * r * 0.9, Math.sin(a1) * r * 0.9);
      ctx.closePath();
      ctx.fillStyle = hsla(200 + i * 4, 70, 46 + k * 30, 0.32);
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.42)';
      ctx.lineWidth = 1.1;
      ctx.stroke();
    }
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.42, 0, TAU);
    ctx.fillStyle = 'rgba(255,255,255,0.35)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.7)';
    ctx.lineWidth = r * 0.025;
    ctx.stroke();
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU + t * 0.35;
      star4(ctx, Math.cos(a) * r * 0.66, Math.sin(a) * r * 0.66, r * 0.06, 0, '#ffffff', 0.4 + 0.5 * Math.sin(t * 2.4 + i));
    }
    glow(ctx, 0, 0, r * 1.15, '#8fd8ff', 0.22 + 0.1 * Math.sin(t * 1.5));
  },
};

/** 4. Gigi Emas — roda gigi kuningan jam */
const gear: Skin = {
  id: 'gear',
  name: 'Gigi Emas',
  tag: 'Roda gigi kuningan dari mesin raksasa',
  accent: '#ffc95c',
  bg: ['#2b1c05', '#120b02'],
  draw(ctx, r, t) {
    // gerigi
    ctx.save();
    for (let i = 0; i < 16; i++) {
      ctx.rotate(TAU / 16);
      const g = ctx.createLinearGradient(0, -r, 0, -r * 1.18);
      g.addColorStop(0, '#e8b64c');
      g.addColorStop(1, '#8a6014');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(r * 0.86, -r * 0.08);
      ctx.lineTo(r * 1.14, -r * 0.12);
      ctx.lineTo(r * 1.14, r * 0.12);
      ctx.lineTo(r * 0.86, r * 0.08);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,232,180,0.35)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    ctx.restore();
    const g = ctx.createRadialGradient(-r * 0.25, -r * 0.3, r * 0.1, 0, 0, r);
    g.addColorStop(0, '#f7d888');
    g.addColorStop(0.5, '#c69328');
    g.addColorStop(1, '#7a5210');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.9, 0, TAU);
    ctx.fill();
    // cincin ukir
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.arc(0, 0, r * (0.72 - i * 0.14), 0, TAU);
      ctx.strokeStyle = 'rgba(90,60,10,0.5)';
      ctx.lineWidth = r * 0.035;
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, 0, r * (0.72 - i * 0.14), 0, TAU);
      ctx.strokeStyle = 'rgba(255,236,190,0.35)';
      ctx.lineWidth = r * 0.012;
      ctx.stroke();
    }
    // jari-jari
    ctx.save();
    ctx.rotate(t * 0.12);
    for (let i = 0; i < 8; i++) {
      ctx.rotate(TAU / 8);
      ctx.beginPath();
      ctx.moveTo(r * 0.22, -r * 0.055);
      ctx.lineTo(r * 0.66, -r * 0.1);
      ctx.lineTo(r * 0.66, r * 0.1);
      ctx.lineTo(r * 0.22, r * 0.055);
      ctx.closePath();
      ctx.fillStyle = 'rgba(122,82,16,0.45)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,236,190,0.32)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    ctx.restore();
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU + t * 0.12;
      rivet(ctx, Math.cos(a) * r * 0.46, Math.sin(a) * r * 0.46, r * 0.05, '#fff0c2', '#6b4708');
    }
    glow(ctx, 0, 0, r * 0.5, '#ffc95c', 0.22 + 0.1 * Math.sin(t * 1.8));
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.2, 0, TAU);
    const cg = ctx.createRadialGradient(-r * 0.05, -r * 0.06, r * 0.02, 0, 0, r * 0.2);
    cg.addColorStop(0, '#fff6d8');
    cg.addColorStop(1, '#a97c12');
    ctx.fillStyle = cg;
    ctx.fill();
  },
};

/** 5. Neraka Retak — batu bara dengan retakan magma */
const hell: Skin = {
  id: 'hell',
  name: 'Neraka Retak',
  tag: 'Batu bara panas dengan retakan magma',
  accent: '#ff6a2a',
  bg: ['#2a0a05', '#120302'],
  draw(ctx, r, t) {
    const g = ctx.createRadialGradient(0, 0, r * 0.1, 0, 0, r);
    g.addColorStop(0, '#4a2116');
    g.addColorStop(0.6, '#2a120b');
    g.addColorStop(1, '#100604');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, TAU);
    ctx.fill();
    // retakan magma
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * TAU + t * 0.06;
      const pulse = 0.55 + 0.45 * Math.sin(t * 2.2 + i * 1.3);
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * r * 0.16, Math.sin(a) * r * 0.16);
      for (let k = 1; k <= 6; k++) {
        const rr2 = r * 0.16 + (r * 0.74 * k) / 6;
        const wob = Math.sin(k * 1.9 + i * 2.3) * 0.16;
        ctx.lineTo(Math.cos(a + wob) * rr2, Math.sin(a + wob) * rr2);
      }
      ctx.strokeStyle = `rgba(255,${Math.round(90 + 90 * pulse)},20,${0.35 + 0.5 * pulse})`;
      ctx.lineWidth = r * 0.055;
      ctx.lineCap = 'round';
      ctx.stroke();
      ctx.strokeStyle = `rgba(255,230,160,${0.35 + 0.45 * pulse})`;
      ctx.lineWidth = r * 0.018;
      ctx.stroke();
    }
    glow(ctx, 0, 0, r * 1.1, '#ff6a2a', 0.28 + 0.12 * Math.sin(t * 2.4));
    for (let i = 0; i < 16; i++) {
      const a = (i / 16) * TAU - t * 0.4;
      const rr2 = r * (0.34 + 0.1 * Math.sin(t * 1.6 + i));
      glow(ctx, Math.cos(a) * rr2, Math.sin(a) * rr2, r * 0.075, '#ffb347', 0.35 + 0.3 * Math.sin(t * 3 + i));
    }
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.22, 0, TAU);
    const cg = ctx.createRadialGradient(0, 0, r * 0.02, 0, 0, r * 0.22);
    cg.addColorStop(0, '#ffe6a8');
    cg.addColorStop(0.5, '#ff7a2a');
    cg.addColorStop(1, 'rgba(120,20,0,0.2)');
    ctx.fillStyle = cg;
    ctx.fill();
  },
};

/** 6. Galaksi Pusar — nebula berputar dengan bintang */
const cosmic: Skin = {
  id: 'cosmic',
  name: 'Galaksi Pusar',
  tag: 'Nebula mini yang berputar selamanya',
  accent: '#b98cff',
  bg: ['#100732', '#050216'],
  draw(ctx, r, t) {
    const g = ctx.createRadialGradient(0, 0, 1, 0, 0, r);
    g.addColorStop(0, '#2c1a66');
    g.addColorStop(0.55, '#170b42');
    g.addColorStop(1, '#080322');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, TAU);
    ctx.fill();
    // pusaran konis
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.rotate(t * 0.32);
    const cg = ctx.createConicGradient(0, 0, 0);
    for (let i = 0; i <= 10; i++) cg.addColorStop(i / 10, hsla(250 + i * 14, 85, 60, 0.32));
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.92, 0, TAU);
    ctx.fill();
    // lengan spiral
    for (let s = 0; s < 2; s++) {
      ctx.beginPath();
      for (let i = 0; i <= 60; i++) {
        const u = i / 60;
        const ang = u * 4.2 + s * Math.PI + t * 0.32;
        const rr2 = r * 0.12 + u * r * 0.78;
        const x = Math.cos(ang) * rr2;
        const y = Math.sin(ang) * rr2;
        i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
      ctx.strokeStyle = 'rgba(190,160,255,0.5)';
      ctx.lineWidth = r * 0.1;
      ctx.stroke();
    }
    ctx.restore();
    // bintang
    for (let i = 0; i < 34; i++) {
      const a = i * 2.399;
      const rr2 = r * 0.2 + ((i * 37) % 100) * 0.007 * r;
      const tw = 0.35 + 0.65 * Math.abs(Math.sin(t * 1.8 + i));
      star4(ctx, Math.cos(a) * rr2, Math.sin(a) * rr2, r * 0.035 * (0.6 + tw), 0, '#ffffff', tw);
    }
    glow(ctx, 0, 0, r * 0.75, '#b98cff', 0.3 + 0.12 * Math.sin(t * 1.7));
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.93, 0, TAU);
    ctx.strokeStyle = 'rgba(200,175,255,0.55)';
    ctx.lineWidth = r * 0.045;
    ctx.stroke();
  },
};

export const SKINS: Skin[] = [wood, jade, ice, gear, hell, cosmic];

/* ============================ MESIN PERMAINAN ============================ */

interface P {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  rot: number;
  vr: number;
  color: string;
  kind: 'dot' | 'star' | 'shard' | 'glow';
  g: number;
}

export interface WheelStats {
  level: number;
  left: number;
  score: number;
  best: number;
  state: 'ready' | 'playing' | 'gameover' | 'clear';
  skin: Skin;
  challenge: string;
  pattern: string;
  apples: number;
}

const norm = (a: number) => {
  while (a > Math.PI) a -= TAU;
  while (a < -Math.PI) a += TAU;
  return a;
};

export class WheelGame {
  private ctx: CanvasRenderingContext2D;
  private dpr = 1;
  private W = 0;
  private H = 0;
  private raf = 0;
  private running = false;
  private last = 0;
  private t = 0;

  cx = 0;
  cy = 0;
  R = 100;
  angle = 0;
  level = 1;
  score = 0;
  best = 0;
  state: 'ready' | 'playing' | 'gameover' | 'clear' = 'ready';
  knives: number[] = [];
  obstacles: { ang: number; size: number }[] = [];
  apples: { ang: number }[] = [];
  flying: { y: number; vy: number; hit: boolean } | null = null;
  falling: { x: number; y: number; vx: number; vy: number; rot: number; vr: number } | null = null;
  private parts: P[] = [];
  private shake = 0;
  private flash = 0;
  private sinceThrow = 0;
  onChange?: () => void;

  constructor(private canvas: HTMLCanvasElement) {
    this.ctx = canvas.getContext('2d')!;
    this.best = Number(localStorage.getItem('wheel-best') || 0);
    canvas.addEventListener('pointerdown', this.onDown);
    window.addEventListener('keydown', this.onKey);
    this.setupLevel(1, true);
  }

  destroy() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    this.canvas.removeEventListener('pointerdown', this.onDown);
    window.removeEventListener('keydown', this.onKey);
  }

  private onDown = () => this.throwKnife();
  private onKey = (e: KeyboardEvent) => {
    if (e.code === 'Space') {
      e.preventDefault();
      this.throwKnife();
    }
  };

  start() {
    if (this.running) return;
    this.running = true;
    this.last = performance.now();
    const loop = (now: number) => {
      if (!this.running) return;
      const dt = Math.min(0.05, (now - this.last) / 1000);
      this.last = now;
      if (this.W > 0) {
        this.update(dt);
        this.draw();
      }
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  resize(w: number, h: number) {
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    this.W = w;
    this.H = h;
    this.canvas.width = Math.round(w * this.dpr);
    this.canvas.height = Math.round(h * this.dpr);
    this.canvas.style.width = `${w}px`;
    this.canvas.style.height = `${h}px`;
    this.cx = w / 2;
    this.cy = h * (h > w ? 0.34 : 0.4);
    this.R = clamp(Math.min(w, h) * (h > w ? 0.19 : 0.21), 62, 132);
  }

  /* ---------------- konfigurasi level ---------------- */

  get skin(): Skin {
    return SKINS[(this.level - 1) % SKINS.length];
  }
  get required(): number {
    return 6 + Math.min(6, Math.floor(this.level / 1.5));
  }
  get applesLeft(): number {
    return this.apples.length;
  }

  get pattern(): string {
    switch ((this.level - 1) % 5) {
      case 0:
        return 'Putaran konstan';
      case 1:
        return 'Kecepatan meningkat';
      case 2:
        return 'Akselerasi berayun';
      case 3:
        return 'Bolak-balik';
      default:
        return 'Putar balik mendadak';
    }
  }

  get challenge(): string {
    if (this.level === 1) return 'Roda kayu berputar pelan — ambil ritmenya.';
    if (this.level === 2) return 'Kecepatan naik. Jangan terburu-buru.';
    if (this.level === 3) return 'Baut baja ikut berputar. Hindari mereka!';
    if (this.level === 4) return 'Roda bolak-balik — tebak arah putarannya.';
    if (this.level === 5) return 'Putaran bisa berbalik mendadak kapan saja.';
    return 'Kecepatan penuh. Semua ancaman aktif!';
  }

  get stats(): WheelStats {
    return {
      level: this.level,
      left: this.required - this.knives.length,
      score: this.score,
      best: this.best,
      state: this.state,
      skin: this.skin,
      challenge: this.challenge,
      pattern: this.pattern,
      apples: this.applesLeft,
    };
  }

  private setupLevel(level: number, resetScore = false) {
    this.level = level;
    if (resetScore) this.score = 0;
    this.knives = [];
    this.obstacles = [];
    this.apples = [];
    this.flying = null;
    this.falling = null;
    this.angle = rr(0, TAU);
    this.state = 'playing';
    const n = level >= 3 ? Math.min(5, level - 1) : 0;
    for (let i = 0; i < n; i++) this.obstacles.push({ ang: rr(0, TAU), size: this.R * 0.13 });
    const ap = level % 2 === 0 ? 2 : 1;
    for (let i = 0; i < ap; i++) this.apples.push({ ang: rr(0, TAU) });
    this.onChange?.();
  }

  nextLevel() {
    this.setupLevel(this.level + 1);
  }
  retry() {
    this.setupLevel(this.level, true);
  }

  throwKnife() {
    if (this.state !== 'playing' || this.flying) return;
    this.flying = { y: this.H + 40, vy: -this.H * 2.1, hit: false };
    this.sinceThrow = 0;
    this.onChange?.();
  }

  /* ---------------- logika ---------------- */

  private burst(x: number, y: number, color: string, n = 14, power = 1) {
    for (let i = 0; i < n; i++) {
      const a = rr(0, TAU);
      const sp = rr(90, 380) * power;
      this.parts.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: 0,
        max: rr(0.35, 0.85),
        size: rr(2, 6),
        rot: rr(0, TAU),
        vr: rr(-12, 12),
        color,
        kind: Math.random() < 0.35 ? 'star' : 'shard',
        g: 520,
      });
    }
  }

  private speedAt(t: number) {
    const base = 1.05 + this.level * 0.14;
    switch ((this.level - 1) % 5) {
      case 0:
        return base * 0.85;
      case 1:
        return base * 1.05;
      case 2:
        return base * (1 + 0.65 * Math.sin(t * 1.7));
      case 3:
        return base * Math.sin(t * 1.15) * 1.25;
      default:
        return base * (Math.sin(t * 2.3) > 0 ? 1.3 : -1.3);
    }
  }

  private update(dt: number) {
    this.t += dt;
    this.sinceThrow += dt;
    this.angle += this.speedAt(this.t) * dt;
    this.shake *= Math.exp(-dt * 9);
    this.flash = Math.max(0, this.flash - dt * 2.4);

    if (this.flying) {
      this.flying.y += this.flying.vy * dt;
      const tipY = this.cy + this.R;
      if (!this.flying.hit && this.flying.y <= tipY) {
        this.flying.hit = true;
        this.resolve();
      }
      if (this.flying && this.flying.y < -200) this.flying = null;
    }
    if (this.falling) {
      this.falling.vy += 1500 * dt;
      this.falling.x += this.falling.vx * dt;
      this.falling.y += this.falling.vy * dt;
      this.falling.rot += this.falling.vr * dt;
      if (this.falling.y > this.H + 120) this.falling = null;
    }
    for (let i = this.parts.length - 1; i >= 0; i--) {
      const p = this.parts[i];
      p.life += dt;
      if (p.life > p.max) {
        this.parts.splice(i, 1);
        continue;
      }
      p.vy += p.g * dt;
      p.vx *= Math.exp(-dt * 1.2);
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
    }
  }

  private resolve() {
    const rel = norm(Math.PI / 2 - this.angle);
    const hitX = this.cx;
    const hitY = this.cy + this.R;
    // tabrakan dengan pisau lain
    for (const k of this.knives) {
      if (Math.abs(norm(k - rel)) < 0.28) return this.fail(hitX, hitY);
    }
    // tabrakan dengan baut
    for (const o of this.obstacles) {
      if (Math.abs(norm(o.ang - rel)) < 0.3) return this.fail(hitX, hitY);
    }
    // apel
    for (let i = this.apples.length - 1; i >= 0; i--) {
      if (Math.abs(norm(this.apples[i].ang - rel)) < 0.32) {
        this.apples.splice(i, 1);
        this.score += 50;
        this.burst(hitX, hitY, '#ff5a5a', 18, 1.15);
      }
    }
    this.knives.push(rel);
    this.score += 10 + this.level * 2;
    this.shake = Math.max(this.shake, 2.6);
    this.burst(hitX, hitY, this.skin.accent, 12, 0.85);
    for (let i = 0; i < 6; i++) {
      this.parts.push({
        x: hitX + rr(-10, 10),
        y: hitY + rr(-10, 10),
        vx: rr(-120, 120),
        vy: rr(-320, -60),
        life: 0,
        max: rr(0.4, 0.8),
        size: rr(2, 4),
        rot: 0,
        vr: 0,
        color: '#ffe6b8',
        kind: 'glow',
        g: 320,
      });
    }
    if (this.knives.length >= this.required) {
      this.score += 120 * this.level;
      this.state = 'clear';
      if (this.score > this.best) {
        this.best = this.score;
        localStorage.setItem('wheel-best', String(this.best));
      }
      this.flash = 0.8;
      this.burst(this.cx, this.cy, '#ffe27a', 30, 1.4);
    }
    this.flying = null;
    this.onChange?.();
  }

  private fail(x: number, y: number) {
    this.state = 'gameover';
    this.flash = 1;
    this.shake = 12;
    this.falling = { x, y: y - 40, vx: rr(-160, 160), vy: -220, rot: 0, vr: rr(-12, 12) };
    this.burst(x, y, '#ff4d4d', 26, 1.3);
    this.flying = null;
    if (this.score > this.best) {
      this.best = this.score;
      localStorage.setItem('wheel-best', String(this.best));
    }
    this.onChange?.();
  }

  /* ---------------- gambar ---------------- */

  private drawKnife(ctx: Ctx, len: number) {
    // ujung di (0,0), gagang ke +y
    const w = len * 0.072;
    // mata bilah
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(w * 0.92, len * 0.17);
    ctx.lineTo(w * 1.12, len * 0.52);
    ctx.lineTo(-w * 1.12, len * 0.52);
    ctx.lineTo(-w * 0.92, len * 0.17);
    ctx.closePath();
    const bg = ctx.createLinearGradient(-w * 1.2, 0, w * 1.2, 0);
    bg.addColorStop(0, '#b7c4d2');
    bg.addColorStop(0.42, '#ffffff');
    bg.addColorStop(0.72, '#d6e0ea');
    bg.addColorStop(1, '#66768a');
    ctx.fillStyle = bg;
    ctx.fill();
    ctx.strokeStyle = 'rgba(24,34,48,0.6)';
    ctx.lineWidth = 1;
    ctx.stroke();
    // pias tengah
    ctx.beginPath();
    ctx.moveTo(0, len * 0.08);
    ctx.lineTo(0, len * 0.5);
    ctx.strokeStyle = 'rgba(120,140,165,0.55)';
    ctx.lineWidth = Math.max(0.8, w * 0.16);
    ctx.stroke();
    // perisai gagang
    const gg = ctx.createLinearGradient(-w * 2, 0, w * 2, 0);
    gg.addColorStop(0, '#6b7787');
    gg.addColorStop(0.5, '#c8d3de');
    gg.addColorStop(1, '#4a5462');
    ctx.fillStyle = gg;
    ctx.beginPath();
    ctx.roundRect(-w * 2, len * 0.5, w * 4, len * 0.045, w * 0.3);
    ctx.fill();
    // gagang kulit
    const hg = ctx.createLinearGradient(-w * 1.6, 0, w * 1.6, 0);
    hg.addColorStop(0, '#6f3512');
    hg.addColorStop(0.42, '#c1762f');
    hg.addColorStop(1, '#4a2208');
    ctx.fillStyle = hg;
    ctx.beginPath();
    ctx.roundRect(-w * 1.55, len * 0.55, w * 3.1, len * 0.42, w * 0.9);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,214,170,0.28)';
    ctx.lineWidth = 1;
    ctx.stroke();
    for (let i = 0; i < 2; i++) {
      ctx.beginPath();
      ctx.moveTo(-w * 1.55, len * (0.68 + i * 0.13));
      ctx.lineTo(w * 1.55, len * (0.68 + i * 0.13));
      ctx.strokeStyle = 'rgba(58,26,6,0.5)';
      ctx.lineWidth = Math.max(1, w * 0.2);
      ctx.stroke();
    }
    // ujung gagang
    const eg = ctx.createRadialGradient(0, len * 0.97, 1, 0, len * 0.97, w * 1.5);
    eg.addColorStop(0, '#e2d0b8');
    eg.addColorStop(1, '#7a5a34');
    ctx.fillStyle = eg;
    ctx.beginPath();
    ctx.arc(0, len * 0.96, w * 1.35, 0, TAU);
    ctx.fill();
  }

  private draw() {
    const ctx = this.ctx;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.clearRect(0, 0, this.W, this.H);

    const skin = this.skin;
    // latar
    const bg = ctx.createLinearGradient(0, 0, 0, this.H);
    bg.addColorStop(0, skin.bg[0]);
    bg.addColorStop(1, skin.bg[1]);
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, this.W, this.H);
    glow(ctx, this.cx, this.cy, this.R * 3.1, skin.accent, 0.12 + 0.05 * Math.sin(this.t * 1.6));
    // partikel latar
    for (let i = 0; i < 26; i++) {
      const a = i * 2.399 + this.t * 0.06;
      const rr2 = this.R * (1.5 + ((i * 53) % 100) * 0.012);
      const x = this.cx + Math.cos(a) * rr2;
      const y = this.cy + Math.sin(a) * rr2 * 0.8;
      ctx.fillStyle = hsla(0, 0, 100, 0.06 + 0.06 * Math.abs(Math.sin(this.t + i)));
      ctx.fillRect(x, y, 2, 2);
    }

    ctx.save();
    if (this.shake > 0.05) ctx.translate(rr(-this.shake, this.shake), rr(-this.shake, this.shake));

    // bayangan roda
    ctx.save();
    ctx.translate(this.cx, this.cy + this.R * 1.12);
    ctx.scale(1, 0.16);
    glow(ctx, 0, 0, this.R * 1.25, '#000000', 0.5);
    ctx.restore();

    // roda
    ctx.save();
    ctx.translate(this.cx, this.cy);
    ctx.rotate(this.angle);
    skin.draw(ctx, this.R, this.t);
    ctx.restore();
    // tepi luar
    ctx.beginPath();
    ctx.arc(this.cx, this.cy, this.R, 0, TAU);
    ctx.strokeStyle = 'rgba(255,255,255,0.18)';
    ctx.lineWidth = 2;
    ctx.stroke();

    // apel
    for (const ap of this.apples) {
      const a = this.angle + ap.ang;
      const x = this.cx + Math.cos(a) * this.R * 0.55;
      const y = this.cy + Math.sin(a) * this.R * 0.55;
      glow(ctx, x, y, this.R * 0.3, '#ff5a5a', 0.35);
      const g = ctx.createRadialGradient(x - 5, y - 6, 1, x, y, this.R * 0.13);
      g.addColorStop(0, '#ff8f8f');
      g.addColorStop(0.6, '#e23b3b');
      g.addColorStop(1, '#8c1414');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(x, y, this.R * 0.12, 0, TAU);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(x, y - this.R * 0.11);
      ctx.quadraticCurveTo(x + 6, y - this.R * 0.2, x + 12, y - this.R * 0.17);
      ctx.strokeStyle = '#5c8c2a';
      ctx.lineWidth = 3;
      ctx.stroke();
    }

    // baut rintangan
    for (const o of this.obstacles) {
      const a = this.angle + o.ang;
      const x = this.cx + Math.cos(a) * this.R * 0.72;
      const y = this.cy + Math.sin(a) * this.R * 0.72;
      const g = ctx.createRadialGradient(x - 4, y - 5, 1, x, y, o.size * 1.6);
      g.addColorStop(0, '#c8d2dc');
      g.addColorStop(0.6, '#63707c');
      g.addColorStop(1, '#232a31');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(x, y, o.size, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.35)';
      ctx.lineWidth = 1.6;
      ctx.stroke();
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(a * 2);
      ctx.fillStyle = '#1b2126';
      ctx.fillRect(-o.size * 0.75, -o.size * 0.18, o.size * 1.5, o.size * 0.36);
      ctx.restore();
    }

    // pisau menempel
    for (const k of this.knives) {
      const a = this.angle + k;
      const x = this.cx + Math.cos(a) * this.R * 0.94;
      const y = this.cy + Math.sin(a) * this.R * 0.94;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(a - Math.PI / 2);
      this.drawKnife(ctx, this.R * 0.92);
      ctx.restore();
    }

    // pisau terbang
    if (this.flying) {
      ctx.save();
      ctx.translate(this.cx, this.flying.y);
      this.drawKnife(ctx, this.R * 0.92);
      ctx.restore();
    }
    // pisau jatuh
    if (this.falling) {
      ctx.save();
      ctx.translate(this.falling.x, this.falling.y);
      ctx.rotate(this.falling.rot);
      this.drawKnife(ctx, this.R * 0.92);
      ctx.restore();
    }

    // partikel
    for (const p of this.parts) {
      const k = 1 - p.life / p.max;
      const a = clamp(k, 0, 1);
      if (p.kind === 'glow') {
        glow(ctx, p.x, p.y, p.size * 4, p.color, a);
        continue;
      }
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      ctx.globalAlpha = a;
      if (p.kind === 'star') {
        star4(ctx, 0, 0, p.size * 1.8, p.rot, p.color, a);
      } else {
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.moveTo(p.size, 0);
        ctx.lineTo(0, p.size * 0.6);
        ctx.lineTo(-p.size * 0.8, 0);
        ctx.lineTo(0, -p.size * 0.6);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
    }

    ctx.restore();

    // kilat gagal / level selesai
    if (this.flash > 0.01) {
      ctx.fillStyle = this.state === 'gameover' ? `rgba(255,40,40,${this.flash * 0.32})` : `rgba(255,225,120,${this.flash * 0.24})`;
      ctx.fillRect(0, 0, this.W, this.H);
    }

    // vinyet
    const vg = ctx.createRadialGradient(this.cx, this.cy, this.R, this.cx, this.cy, Math.max(this.W, this.H) * 0.78);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, 'rgba(0,0,0,0.6)');
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, this.W, this.H);

    void easeOutCubic;
    void pick;
    void hsl;
  }
}
