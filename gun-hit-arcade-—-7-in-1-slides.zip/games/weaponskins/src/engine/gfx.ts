import type { Ctx } from './types';
import { TAU, clamp } from './util';

const glowCache = new Map<string, HTMLCanvasElement>();

function glowSprite(color: string): HTMLCanvasElement {
  let c = glowCache.get(color);
  if (c) return c;
  c = document.createElement('canvas');
  c.width = c.height = 128;
  const g = c.getContext('2d')!;
  g.fillStyle = color;
  g.fillRect(0, 0, 128, 128);
  g.globalCompositeOperation = 'destination-in';
  const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  gr.addColorStop(0, 'rgba(0,0,0,1)');
  gr.addColorStop(0.22, 'rgba(0,0,0,0.6)');
  gr.addColorStop(0.5, 'rgba(0,0,0,0.2)');
  gr.addColorStop(0.78, 'rgba(0,0,0,0.05)');
  gr.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = gr;
  g.fillRect(0, 0, 128, 128);
  glowCache.set(color, c);
  return c;
}

/** Cahaya lembut aditif (sprite radial gradient ter-cache) */
export function glow(ctx: Ctx, x: number, y: number, r: number, color: string, alpha = 1) {
  if (r <= 0 || alpha <= 0) return;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = clamp(alpha, 0, 1);
  ctx.drawImage(glowSprite(color), x - r, y - r, r * 2, r * 2);
  ctx.restore();
}

/** Bintang kilau 4 sudut */
export function star4(ctx: Ctx, x: number, y: number, r: number, rot = 0, color = '#fff', alpha = 1, thin = 0.14) {
  if (r <= 0 || alpha <= 0) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.globalAlpha = clamp(alpha, 0, 1);
  ctx.fillStyle = color;
  const k = r * thin;
  ctx.beginPath();
  ctx.moveTo(r, 0);
  ctx.quadraticCurveTo(k, k, 0, r);
  ctx.quadraticCurveTo(-k, k, -r, 0);
  ctx.quadraticCurveTo(-k, -k, 0, -r);
  ctx.quadraticCurveTo(k, -k, r, 0);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

/**
 * Lensa distorsi: menyalin isi kanvas di sekitar titik, memperbesar & memutarnya
 * (efek pembengkokan cahaya / gravitational lensing).
 */
export function lens(ctx: Ctx, x: number, y: number, r: number, mag = 1.6, rot = 0, alpha = 1) {
  if (r <= 1) return;
  const m = ctx.getTransform();
  const cx = m.a * x + m.c * y + m.e;
  const cy = m.b * x + m.d * y + m.f;
  const sc = Math.hypot(m.a, m.b);
  const src = ctx.canvas;
  const layers = 3;
  for (let i = 0; i < layers; i++) {
    const R = r * sc * (1 - i * 0.3);
    const mg = 1 + (mag - 1) * (0.4 + i * 0.3);
    const sr = R / mg;
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, TAU);
    ctx.clip();
    ctx.globalAlpha = clamp(alpha, 0, 1);
    ctx.translate(cx, cy);
    ctx.rotate(rot * (1 + i * 0.7));
    try {
      ctx.drawImage(src, cx - sr, cy - sr, sr * 2, sr * 2, -R, -R, R * 2, R * 2);
    } catch {
      /* di luar kanvas */
    }
    ctx.restore();
  }
}

export function polyPath(ctx: Ctx, pts: ArrayLike<readonly [number, number]>, close = true) {
  ctx.beginPath();
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i];
    if (i === 0) ctx.moveTo(p[0], p[1]);
    else ctx.lineTo(p[0], p[1]);
  }
  if (close) ctx.closePath();
}
