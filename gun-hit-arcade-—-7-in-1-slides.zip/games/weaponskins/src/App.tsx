import { useCallback, useEffect, useRef, useState } from 'react';
import ArenaView from './components/ArenaView';
import WeaponCard from './components/WeaponCard';
import WheelChallenge from './components/WheelChallenge';
import { createWeapons, type Arena } from './engine';

const WEAPONS = createWeapons();

const ROWS: { key: 'body' | 'bullet' | 'impact' | 'idle'; label: string }[] = [
  { key: 'body', label: 'Badan' },
  { key: 'bullet', label: 'Peluru' },
  { key: 'impact', label: 'Tumbukan' },
  { key: 'idle', label: 'Idle' },
];

type Mode = 'arsenal' | 'wheels';

export default function App() {
  const [mode, setMode] = useState<Mode>('arsenal');
  const [index, setIndex] = useState(0);
  const [auto, setAuto] = useState(false);
  const [showInfo, setShowInfo] = useState(() => (typeof window === 'undefined' ? true : window.innerWidth >= 768));
  const arenaRef = useRef<Arena | null>(null);
  const modeRef = useRef<Mode>(mode);
  modeRef.current = mode;
  const onReady = useCallback((a: Arena | null) => {
    arenaRef.current = a;
  }, []);

  const w = WEAPONS[index];
  const acc = mode === 'arsenal' ? w.accent : '#ffc95c';

  useEffect(() => {
    let buf = '';
    let timer = 0;
    const applyDigit = () => {
      const n = parseInt(buf, 10);
      if (n >= 1 && n <= WEAPONS.length) setIndex(n - 1);
      buf = '';
    };
    const down = (e: KeyboardEvent) => {
      if (modeRef.current !== 'arsenal') return;
      if (e.code === 'Space') {
        e.preventDefault();
        arenaRef.current?.fire();
        return;
      }
      if (/^[0-9]$/.test(e.key)) {
        const next = buf + e.key;
        const value = parseInt(next, 10);
        window.clearTimeout(timer);
        if (value >= 1 && value <= WEAPONS.length && next.length < 2) {
          buf = next;
          timer = window.setTimeout(applyDigit, 620);
        } else if (value >= 1 && value <= WEAPONS.length) {
          buf = next;
          applyDigit();
        } else {
          buf = e.key;
          timer = window.setTimeout(applyDigit, 620);
        }
        return;
      }
      if (e.key === 'a' || e.key === 'A') setAuto((v) => !v);
      if (e.key === 'ArrowRight') setIndex((i) => (i + 1) % WEAPONS.length);
      if (e.key === 'ArrowLeft') setIndex((i) => (i - 1 + WEAPONS.length) % WEAPONS.length);
    };
    const up = (e: KeyboardEvent) => {
      if (e.code === 'Space') e.preventDefault();
    };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
    };
  }, []);



  return (
    <div className="flex h-dvh w-full flex-col overflow-hidden bg-[#05030a] text-white">
      {/* ===== header ===== */}
      <header className="relative z-10 shrink-0 px-4 pt-3 md:px-7 md:pt-4">
        <div className="flex items-start justify-between gap-3">
          <div key={mode === 'arsenal' ? w.id : 'wheels'} className="rise min-w-0">
            <p className="text-[10px] uppercase tracking-[0.32em] text-white/45 md:text-[11px]">
              {mode === 'arsenal'
                ? `Arsenal Skin · ${String(index + 1).padStart(2, '0')} / ${String(WEAPONS.length).padStart(2, '0')}`
                : 'Mode Tantangan · Lempar Pisau'}
            </p>
            <h1
              className="truncate text-[26px] font-extrabold leading-tight tracking-tight md:text-[40px]"
              style={{
                backgroundImage: `linear-gradient(90deg, #ffffff 0%, ${acc} 70%, ${mode === 'arsenal' ? w.theme.glow : '#ff8a4c'} 100%)`,
                WebkitBackgroundClip: 'text',
                backgroundClip: 'text',
                color: 'transparent',
              }}
            >
              {mode === 'arsenal' ? w.name : 'Tantangan Roda'}
            </h1>
            <p className="text-xs text-white/60 md:text-sm">
              {mode === 'arsenal' ? w.tagline : 'Roda unik berputar, pisau menempel, satu kesalahan = tamat'}
            </p>
          </div>

          <div className="mt-1 flex shrink-0 flex-col items-end gap-2">
            <div className="flex rounded-full border border-white/12 bg-white/5 p-1 backdrop-blur">
              {(['arsenal', 'wheels'] as Mode[]).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={(e) => {
                    setMode(m);
                    e.currentTarget.blur();
                  }}
                  className="rounded-full px-3 py-1.5 text-[11px] font-semibold transition md:px-4"
                  style={
                    mode === m
                      ? { background: acc, color: '#120a02', boxShadow: `0 0 18px ${acc}66` }
                      : { color: 'rgba(255,255,255,0.65)' }
                  }
                >
                  {m === 'arsenal' ? 'Arena Senjata' : 'Tantangan Roda'}
                </button>
              ))}
            </div>
            {mode === 'arsenal' && (
              <button
                type="button"
                onClick={(e) => {
                  setShowInfo((v) => !v);
                  e.currentTarget.blur();
                }}
                className="rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-[11px] font-medium text-white/80 backdrop-blur transition hover:bg-white/10 md:text-xs"
              >
                {showInfo ? 'Sembunyikan detail' : 'Lihat detail'}
              </button>
            )}
          </div>
        </div>

        {mode === 'arsenal' && showInfo && (
          <div key={w.id + 'i'} className="rise mt-3 grid grid-cols-2 gap-2 md:grid-cols-4">
            {ROWS.map((r) => (
              <div
                key={r.key}
                className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 backdrop-blur-sm"
                style={{ boxShadow: `inset 0 1px 0 ${acc}22` }}
              >
                <div className="mb-0.5 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.2em]" style={{ color: acc }}>
                  <span className="inline-block h-1.5 w-1.5 rounded-full" style={{ background: acc, boxShadow: `0 0 8px ${acc}` }} />
                  {r.label}
                </div>
                <p className="text-[11px] leading-snug text-white/70 md:text-xs">{w.features[r.key]}</p>
              </div>
            ))}
          </div>
        )}
      </header>

      {/* ===== arena / tantangan ===== */}
      <main className="relative min-h-0 flex-1">
        {mode === 'wheels' ? (
          <WheelChallenge />
        ) : (
          <>
            <ArenaView index={index} auto={auto} onReady={onReady} />

            <p className="pointer-events-none absolute inset-x-0 top-1 px-4 text-center text-[10.5px] text-white/40 md:text-[11px]">
              Klik arena atau tekan <b className="text-white/70">SPASI</b> untuk menembak · seret lingkaran target · tombol{' '}
              <b className="text-white/70">1–{WEAPONS.length}</b> ganti senjata
            </p>

            <div className="absolute bottom-3 right-3 z-10 flex items-center gap-2 md:bottom-5 md:right-6">
              <button
                type="button"
                onClick={(e) => {
                  setAuto((v) => !v);
                  e.currentTarget.blur();
                }}
                aria-pressed={auto}
                className="rounded-full border px-4 py-2.5 text-[11px] font-semibold uppercase tracking-widest backdrop-blur transition md:text-xs"
                style={{
                  borderColor: auto ? acc : 'rgba(255,255,255,0.18)',
                  color: auto ? acc : 'rgba(255,255,255,0.7)',
                  background: auto ? `${acc}22` : 'rgba(0,0,0,0.35)',
                  boxShadow: auto ? `0 0 18px ${acc}55` : 'none',
                }}
              >
                Auto {auto ? 'ON' : 'OFF'}
              </button>
              <button
                type="button"
                onClick={(e) => {
                  arenaRef.current?.fire();
                  e.currentTarget.blur();
                }}
                className="rounded-full px-7 py-3 text-sm font-extrabold uppercase tracking-[0.2em] text-black transition active:scale-95 md:px-9 md:py-3.5"
                style={{
                  background: `linear-gradient(135deg, #ffffff 0%, ${acc} 55%, ${w.theme.glow} 100%)`,
                  boxShadow: `0 0 30px ${acc}77, 0 6px 22px rgba(0,0,0,0.45)`,
                }}
              >
                Tembak
              </button>
            </div>
          </>
        )}
      </main>

      {/* ===== dock senjata ===== */}
      {mode === 'arsenal' && (
        <footer className="relative z-10 shrink-0 border-t border-white/10 bg-black/50 backdrop-blur-md">
          <div className="dock mx-auto flex max-w-6xl gap-2.5 overflow-x-auto px-4 pb-3 pt-4 md:justify-center md:gap-3">
            {WEAPONS.map((wp, i) => (
              <WeaponCard key={wp.id} weapon={wp} index={i} active={i === index} onSelect={() => setIndex(i)} />
            ))}
          </div>
        </footer>
      )}
    </div>
  );
}
