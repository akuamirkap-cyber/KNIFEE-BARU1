import { useState, useEffect } from 'react';
import { GameCanvas } from './game/GameCanvas';
import { SHARK_GUNS } from './data/guns';
import { SharkGunConfig } from './types/game';
import { GunShopModal } from './components/GunShopModal';
import { GameOverModal } from './components/GameOverModal';
import { SettingsModal } from './components/SettingsModal';
import { sounds } from './audio/soundManager';
import { ShoppingBag, Settings, Volume2, VolumeX, Flame } from 'lucide-react';

export function App() {
  // Game states
  const [guns, setGuns] = useState<SharkGunConfig[]>(() => {
    try {
      const saved = localStorage.getItem('shark_guns_unlocked');
      if (saved) {
        const unlockedIds: string[] = JSON.parse(saved);
        return SHARK_GUNS.map(g => ({
          ...g,
          unlocked: g.unlocked || unlockedIds.includes(g.id)
        }));
      }
    } catch {
      // fallback
    }
    return SHARK_GUNS;
  });

  const [selectedGunId, setSelectedGunId] = useState<string>(() => {
    return localStorage.getItem('shark_gun_selected') || 'great_white';
  });

  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(() => {
    return parseInt(localStorage.getItem('shark_hit_high_score') || '0', 10);
  });
  const [stage, setStage] = useState(1);
  const [sharksLeft, setSharksLeft] = useState(6);
  const [pearls, setPearls] = useState(() => {
    return parseInt(localStorage.getItem('shark_pearls') || '25', 10);
  });
  const [sessionPearlsGained, setSessionPearlsGained] = useState(0);

  // Settings
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [musicEnabled, setMusicEnabled] = useState(false);
  const [screenShake, setScreenShake] = useState(true);
  const [laserSight, setLaserSight] = useState(true);
  const [lang, setLang] = useState<'id' | 'en'>('id');

  // Modals
  const [isShopOpen, setIsShopOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isGameOverOpen, setIsGameOverOpen] = useState(false);

  const currentGun = guns.find(g => g.id === selectedGunId) || guns[0];

  // Save high score
  useEffect(() => {
    if (score > highScore) {
      setHighScore(score);
      localStorage.setItem('shark_hit_high_score', score.toString());
    }
  }, [score, highScore]);

  // Save pearls
  useEffect(() => {
    localStorage.setItem('shark_pearls', pearls.toString());
  }, [pearls]);

  // Save selected gun
  useEffect(() => {
    localStorage.setItem('shark_gun_selected', selectedGunId);
  }, [selectedGunId]);

  const handleScoreUpdate = (newScore: number) => {
    setScore(newScore);
  };

  const handleSharksLeftUpdate = (count: number) => {
    setSharksLeft(count);
  };

  const handleStageClear = (nextStage: number) => {
    setStage(nextStage);
    setScore(prev => prev + 5); // stage clear bonus
  };

  const handleGameOver = () => {
    setIsGameOverOpen(true);
  };

  const handleRestart = () => {
    setIsGameOverOpen(false);
    setScore(0);
    setStage(1);
    setSessionPearlsGained(0);
  };

  const handlePearlsGained = (amount: number) => {
    setPearls(prev => prev + amount);
    setSessionPearlsGained(prev => prev + amount);
  };

  const handleUnlockGun = (gun: SharkGunConfig) => {
    if (pearls >= gun.price) {
      sounds.playCollect();
      const updatedPearls = pearls - gun.price;
      setPearls(updatedPearls);

      const updatedGuns = guns.map(g => (g.id === gun.id ? { ...g, unlocked: true } : g));
      setGuns(updatedGuns);
      setSelectedGunId(gun.id);

      const unlockedIds = updatedGuns.filter(g => g.unlocked).map(g => g.id);
      localStorage.setItem('shark_guns_unlocked', JSON.stringify(unlockedIds));
    }
  };

  const isBossStage = stage % 5 === 0;

  return (
    <div className="min-h-screen w-full bg-slate-950 flex flex-col items-center justify-between p-2 sm:p-4 select-none overflow-x-hidden font-['Rajdhani']">
      {/* Top Header Bar */}
      <header className="w-full max-w-[420px] flex items-center justify-between px-3 py-2 bg-slate-900/90 backdrop-blur-md rounded-2xl border border-sky-500/20 shadow-lg z-20 mb-2">
        {/* Game Title & Stage */}
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="text-xl">🦈</span>
            <h1 className="text-base font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-200 to-blue-400 font-['Orbitron']">
              SHARK GUN HIT
            </h1>
          </div>
          {/* Stage badge */}
          <div className="flex items-center gap-1.5 mt-0.5">
            <span
              className={`text-[11px] font-black px-2 py-0.5 rounded-md uppercase tracking-wider ${
                isBossStage
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40 animate-pulse'
                  : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
              }`}
            >
              {isBossStage
                ? lang === 'id'
                  ? `STAGE ${stage} (BOSS 💀)`
                  : `STAGE ${stage} (BOSS 💀)`
                : `STAGE ${stage}`}
            </span>
            <span className="text-slate-400 text-xs">
              {lang === 'id' ? 'Skor' : 'Score'}:{' '}
              <strong className="text-cyan-300 font-bold">{score}</strong>
            </span>
          </div>
        </div>

        {/* Currency & Quick Buttons */}
        <div className="flex items-center gap-2">
          {/* Pearls */}
          <div
            onClick={() => setIsShopOpen(true)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold cursor-pointer hover:bg-amber-500/25 transition-colors"
          >
            <span className="font-black">{pearls}</span>
            <span>🦪</span>
          </div>

          {/* Sound Toggle */}
          <button
            onClick={() => {
              const next = sounds.toggleSound();
              setSoundEnabled(next);
            }}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer transition-colors border border-slate-700"
            title="Toggle Sound"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* Shop button */}
          <button
            onClick={() => setIsShopOpen(true)}
            className="p-1.5 rounded-xl bg-cyan-600/30 hover:bg-cyan-500/40 text-cyan-300 cursor-pointer transition-colors border border-cyan-500/30 relative"
            title="Shark Gun Armory"
          >
            <ShoppingBag className="w-4 h-4" />
          </button>

          {/* Settings button */}
          <button
            onClick={() => setIsSettingsOpen(true)}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer transition-colors border border-slate-700"
            title="Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Game Screen */}
      <main className="relative w-full max-w-[420px] flex-1 flex flex-col items-center justify-center min-h-[560px]">
        {/* Left Side: Ammunition Shark Icons Indicator */}
        <div className="absolute left-3 bottom-24 z-10 flex flex-col-reverse gap-1.5 bg-slate-950/70 p-2 rounded-2xl border border-cyan-500/20 backdrop-blur-sm pointer-events-none">
          <div className="text-[10px] font-black text-center text-cyan-400 mb-0.5">
            {sharksLeft}
          </div>
          {Array.from({ length: sharksLeft }).map((_, idx) => (
            <div
              key={idx}
              className="w-5 h-6 rounded-md flex items-center justify-center text-xs transition-all duration-150 animate-in zoom-in-50"
              style={{
                backgroundColor: `${currentGun.colors.accent}25`,
                borderColor: currentGun.colors.accent,
                borderWidth: '1px'
              }}
            >
              🦈
            </div>
          ))}
        </div>

        {/* Top-Right High Score Indicator */}
        <div className="absolute right-3 top-4 z-10 px-2.5 py-1 rounded-xl bg-slate-950/75 border border-slate-800 text-[11px] text-slate-300 font-bold backdrop-blur-sm flex items-center gap-1 pointer-events-none">
          <Flame className="w-3.5 h-3.5 text-amber-400" />
          <span>TOP: {highScore}</span>
        </div>

        {/* 2D Canvas */}
        <GameCanvas
          currentGun={currentGun}
          stage={stage}
          score={score}
          sharksLeft={sharksLeft}
          onScoreUpdate={handleScoreUpdate}
          onSharksLeftUpdate={handleSharksLeftUpdate}
          onStageClear={handleStageClear}
          onGameOver={handleGameOver}
          onPearlsGained={handlePearlsGained}
          laserSight={laserSight}
          screenShakeEnabled={screenShake}
          lang={lang}
        />
      </main>

      {/* Bottom Hint Bar & Active Weapon Info */}
      <footer className="w-full max-w-[420px] mt-2 flex flex-col items-center gap-1 px-3 py-2 bg-slate-900/80 rounded-2xl border border-slate-800 text-center">
        <div className="flex items-center justify-between w-full text-xs">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">{lang === 'id' ? 'Senjata:' : 'Weapon:'}</span>
            <span className="font-bold text-cyan-300">
              {lang === 'id' ? currentGun.nameId : currentGun.name}
            </span>
          </div>
          <span
            className="text-[10px] px-2 py-0.5 rounded font-black uppercase"
            style={{
              backgroundColor: `${currentGun.colors.accent}25`,
              color: currentGun.colors.accent
            }}
          >
            {currentGun.rarity}
          </span>
        </div>

        <p className="text-[11px] text-slate-400 tracking-wide font-medium">
          {lang === 'id'
            ? '🎯 Sentuh Layar / Spasi untuk tembak Hiu Raksasa 2x ukuran senjata!'
            : '🎯 Tap Screen or Spacebar to fire Giant 2x Shark at spinning wheel!'}
        </p>
      </footer>

      {/* Modals */}
      <GunShopModal
        isOpen={isShopOpen}
        onClose={() => setIsShopOpen(false)}
        guns={guns}
        selectedGun={currentGun}
        onSelectGun={gun => setSelectedGunId(gun.id)}
        onUnlockGun={handleUnlockGun}
        pearls={pearls}
        lang={lang}
      />

      <GameOverModal
        isOpen={isGameOverOpen}
        score={score}
        highScore={highScore}
        stage={stage}
        pearlsGained={sessionPearlsGained}
        onRestart={handleRestart}
        onOpenShop={() => {
          setIsGameOverOpen(false);
          setIsShopOpen(true);
        }}
        lang={lang}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
        musicEnabled={musicEnabled}
        setMusicEnabled={setMusicEnabled}
        screenShake={screenShake}
        setScreenShake={setScreenShake}
        laserSight={laserSight}
        setLaserSight={setLaserSight}
        lang={lang}
        setLang={setLang}
      />
    </div>
  );
}

export default App;
