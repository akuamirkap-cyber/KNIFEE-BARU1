export type GunTheme = 'great_white' | 'cyber_neon' | 'abyssal_megalodon' | 'golden_emperor' | 'toxic_bio';

export interface SharkGunConfig {
  id: GunTheme;
  name: string;
  nameId: string; // Indonesian name
  description: string;
  descriptionId: string;
  price: number;
  unlocked: boolean;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    glow: string;
    belly: string;
    eye: string;
    teeth: string;
  };
  projectileColor: string;
  trailColor: string;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary' | 'Mythic';
}

export interface FlyingShark {
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
  mouthOpenProgress: number; // 0 (closed) to 1 (wide open jaws)
  gunTheme: GunTheme;
  tailWag: number;
}

export interface AttachedShark {
  angle: number; // angle around the target board in radians
  depth: number; // how deep teeth bite into the board rim
  gunTheme: GunTheme;
  biteWiggle: number;
  tailPhase: number;
  id: number;
}

export interface TargetItem {
  angle: number;
  type: 'pearl' | 'meat' | 'shell';
  collected: boolean;
  pulse: number;
}

export interface TargetObstacle {
  angle: number;
  widthAngle: number;
  type: 'spike' | 'shield' | 'coral';
}

export interface TargetBoard {
  radius: number;
  rotation: number;
  baseSpeed: number;
  currentSpeed: number;
  speedPattern: 'constant' | 'variable' | 'reverse' | 'stutter' | 'boss_dash';
  patternTimer: number;
  woodTextureSeed: number;
  sharksRequired: number;
  attachedSharks: AttachedShark[];
  items: TargetItem[];
  obstacles: TargetObstacle[];
  name: string;
  isBoss: boolean;
  bossHealth?: number;
  maxBossHealth?: number;
  hitFlash: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  type: 'bubble' | 'spark' | 'wood_chip' | 'blood' | 'water_splash' | 'ring';
  rotation?: number;
  vRot?: number;
}

export interface FloatingText {
  id: number;
  x: number;
  y: number;
  text: string;
  color: string;
  size: number;
  alpha: number;
  vy: number;
}

export interface BoardFragment {
  x: number;
  y: number;
  vx: number;
  vy: number;
  rotation: number;
  vRot: number;
  radius: number;
  startAngle: number;
  endAngle: number;
  color: string;
  alpha: number;
}
