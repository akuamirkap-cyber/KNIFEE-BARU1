import { SharkGunConfig } from '../types/game';

export const SHARK_GUNS: SharkGunConfig[] = [
  {
    id: 'great_white',
    name: 'Apex Great White',
    nameId: 'Hiu Putih Pemangsa',
    description: 'Sleek naval predator cannon forged from titanium and oceanic hydro-energy.',
    descriptionId: 'Meriam predator laut futuristik dengan gigi titanium dan energi hidro biru bercahaya.',
    price: 0,
    unlocked: true,
    colors: {
      primary: '#334e68',
      secondary: '#486581',
      accent: '#38bdf8',
      glow: '#00f0ff',
      belly: '#f0f9ff',
      eye: '#38bdf8',
      teeth: '#ffffff'
    },
    projectileColor: '#38bdf8',
    trailColor: 'rgba(56, 189, 248, 0.4)',
    rarity: 'Common'
  },
  {
    id: 'cyber_neon',
    name: 'Cyber Neon Hunter',
    nameId: 'Hiu Siber Neon 2099',
    description: 'Bioluminescent synthwave shark cannon with high-frequency neon teeth.',
    descriptionId: 'Meriam hiu synthwave bercahaya neon ungu-cyan dengan gigi laser berfrekuensi tinggi.',
    price: 50,
    unlocked: false,
    colors: {
      primary: '#1e1b4b',
      secondary: '#4c1d95',
      accent: '#ec4899',
      glow: '#f43f5e',
      belly: '#818cf8',
      eye: '#22d3ee',
      teeth: '#00f0ff'
    },
    projectileColor: '#ec4899',
    trailColor: 'rgba(236, 72, 153, 0.5)',
    rarity: 'Epic'
  },
  {
    id: 'abyssal_megalodon',
    name: 'Abyssal Megalodon',
    nameId: 'Megalodon Magma Purba',
    description: 'Ancient volcanic titan dredged from Mariana Trench, spitting molten magma sharks.',
    descriptionId: 'Titan purba berurat magma dari Palung Mariana terdalam, melontarkan hiu lava neraka.',
    price: 120,
    unlocked: false,
    colors: {
      primary: '#18181b',
      secondary: '#27272a',
      accent: '#f97316',
      glow: '#ef4444',
      belly: '#7f1d1d',
      eye: '#ffea00',
      teeth: '#fbbf24'
    },
    projectileColor: '#f97316',
    trailColor: 'rgba(249, 115, 22, 0.6)',
    rarity: 'Legendary'
  },
  {
    id: 'golden_emperor',
    name: 'Golden Emperor',
    nameId: 'Hiu Emas Kaisar Laut',
    description: 'Ceremonial 24K solid gold shark cannon studded with abyssal rubies.',
    descriptionId: 'Meriam hiu emas murni 24 karat bertahtakan permata delima laut dalam.',
    price: 250,
    unlocked: false,
    colors: {
      primary: '#b45309',
      secondary: '#d97706',
      accent: '#fde047',
      glow: '#f59e0b',
      belly: '#fef08a',
      eye: '#ef4444',
      teeth: '#ffffff'
    },
    projectileColor: '#fbbf24',
    trailColor: 'rgba(251, 191, 36, 0.5)',
    rarity: 'Mythic'
  },
  {
    id: 'toxic_bio',
    name: 'Bio-Toxic Leviathan',
    nameId: 'Hiu Mutasi Bio-Hazard',
    description: 'Genetically mutated apex shark spitting radioactive corrosive jaws.',
    descriptionId: 'Hiu mutasi laboratorium dengan rahang asam radioaktif hijau menyengat.',
    price: 80,
    unlocked: false,
    colors: {
      primary: '#064e3b',
      secondary: '#047857',
      accent: '#10b981',
      glow: '#4ade80',
      belly: '#a7f3d0',
      eye: '#facc15',
      teeth: '#bbf7d0'
    },
    projectileColor: '#10b981',
    trailColor: 'rgba(74, 222, 128, 0.5)',
    rarity: 'Rare'
  }
];
