export interface BossDef {
  level: number;
  name: string;
  nameId: string;
  sharksRequired: number;
  speed: number;
  speedPattern: 'variable' | 'reverse' | 'stutter' | 'boss_dash';
  themeColor: string;
  glowColor: string;
  hasObstacles: boolean;
  obstacleCount: number;
  subtitle: string;
  subtitleId: string;
}

export const BOSS_LEVELS: Record<number, BossDef> = {
  5: {
    level: 5,
    name: 'Ancient Megalodon Fossil',
    nameId: 'Fosil Purba Megalodon',
    sharksRequired: 9,
    speed: 0.038,
    speedPattern: 'variable',
    themeColor: '#78350f',
    glowColor: '#f59e0b',
    hasObstacles: true,
    obstacleCount: 2,
    subtitle: 'BOSS STAGE - Crush the Fossil!',
    subtitleId: 'STAGE BOSS - Hancurkan Fosil Megalodon!'
  },
  10: {
    level: 10,
    name: 'Ghost Captain Galleon Core',
    nameId: 'Kemudi Kapal Hantu Bajak Laut',
    sharksRequired: 11,
    speed: 0.046,
    speedPattern: 'reverse',
    themeColor: '#1e293b',
    glowColor: '#38bdf8',
    hasObstacles: true,
    obstacleCount: 3,
    subtitle: 'BOSS STAGE - Ghost Pirate Wheel!',
    subtitleId: 'STAGE BOSS - Kemudi Terkutuk!'
  },
  15: {
    level: 15,
    name: 'Cyberpunk Kraken Reactor',
    nameId: 'Reaktor Kraken Sibernetik',
    sharksRequired: 12,
    speed: 0.052,
    speedPattern: 'stutter',
    themeColor: '#581c87',
    glowColor: '#ec4899',
    hasObstacles: true,
    obstacleCount: 4,
    subtitle: 'BOSS STAGE - Overload the Reactor!',
    subtitleId: 'STAGE BOSS - Hancurkan Inti Kraken!'
  },
  20: {
    level: 20,
    name: 'Abyssal Magma Core',
    nameId: 'Inti Magma Palung Neraka',
    sharksRequired: 14,
    speed: 0.058,
    speedPattern: 'boss_dash',
    themeColor: '#7f1d1d',
    glowColor: '#ef4444',
    hasObstacles: true,
    obstacleCount: 4,
    subtitle: 'BOSS STAGE - Extinguish the Core!',
    subtitleId: 'STAGE BOSS - Taklukkan Inti Vulkanik!'
  }
};
