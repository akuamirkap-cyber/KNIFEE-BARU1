import { SharkGunConfig, AttachedShark, TargetBoard, Particle, FloatingText } from '../types/game';

// Helper to convert hex to rgba
export function hexToRgba(hex: string, alpha: number): string {
  let c = hex.replace('#', '');
  if (c.length === 3) {
    c = c.split('').map(x => x + x).join('');
  }
  const num = parseInt(c, 16);
  const r = (num >> 16) & 255;
  const g = (num >> 8) & 255;
  const b = num & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

/**
 * Draws the gorgeous 2D Shark Gun stationed at bottom center, aiming straight UP.
 * Redesigned: elegant mounted turret with gold trims, glass energy orb,
 * polished specular body, layered curved fins, and shark-jaw muzzle with thick teeth.
 */
export function drawSharkGun(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  gun: SharkGunConfig,
  recoil: number, // 0 to 1
  animTime: number
) {
  ctx.save();
  const recoilOffset = recoil * 14;
  ctx.translate(x, y);

  const colors = gun.colors;

  // ========= 0. BASE MOUNT PLATFORM (does not recoil) =========
  // Glowing floor ring
  const ringPulse = 0.5 + Math.sin(animTime * 3) * 0.5;
  ctx.strokeStyle = hexToRgba(colors.glow, 0.25 + ringPulse * 0.2);
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.ellipse(0, 42, 46, 10, 0, 0, Math.PI * 2);
  ctx.stroke();

  // Platform pedestal
  const pedGrad = ctx.createLinearGradient(-36, 28, 36, 28);
  pedGrad.addColorStop(0, '#0b1220');
  pedGrad.addColorStop(0.5, '#1e293b');
  pedGrad.addColorStop(1, '#0b1220');
  ctx.fillStyle = pedGrad;
  ctx.beginPath();
  ctx.moveTo(-30, 30);
  ctx.lineTo(30, 30);
  ctx.lineTo(38, 44);
  ctx.lineTo(-38, 44);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = hexToRgba(colors.accent, 0.6);
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Pedestal glowing energy strip
  ctx.fillStyle = hexToRgba(colors.glow, 0.5 + ringPulse * 0.3);
  ctx.beginPath();
  ctx.roundRect(-22, 35, 44, 3.5, 2);
  ctx.fill();

  // ========= Recoiling upper assembly =========
  ctx.translate(0, recoilOffset);

  // 1. Muzzle Flash & Energy Glow (if in recoil)
  if (recoil > 0.05) {
    const flashSize = recoil * 38;
    const grad = ctx.createRadialGradient(0, -64, 2, 0, -64, flashSize);
    grad.addColorStop(0, '#ffffff');
    grad.addColorStop(0.3, colors.glow);
    grad.addColorStop(1, 'transparent');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(0, -64, flashSize, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = colors.accent;
    ctx.lineWidth = 2.5;
    for (let i = 0; i < 5; i++) {
      const angle = -Math.PI / 2 + (i - 2) * 0.28;
      const len = 32 * recoil + Math.sin(animTime * 15 + i) * 6;
      ctx.beginPath();
      ctx.moveTo(0, -64);
      ctx.lineTo(Math.cos(angle) * len, -64 + Math.sin(angle) * len);
      ctx.stroke();
    }
  }

  // 2. Rear Stock with gold trim
  const stockGrad = ctx.createLinearGradient(-14, 18, 14, 18);
  stockGrad.addColorStop(0, '#0b1220');
  stockGrad.addColorStop(0.5, '#1f2a3d');
  stockGrad.addColorStop(1, '#0b1220');
  ctx.fillStyle = stockGrad;
  ctx.strokeStyle = colors.primary;
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.roundRect(-14, 14, 28, 20, [4, 4, 10, 10]);
  ctx.fill();
  ctx.stroke();

  // Gold trim band on stock
  ctx.strokeStyle = hexToRgba('#fbbf24', 0.85);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-13, 20);
  ctx.lineTo(13, 20);
  ctx.stroke();

  // 3. Layered Curved Side Fins (double-layer hydrofoil wings)
  // Rear dark layer
  ctx.fillStyle = '#122032';
  ctx.beginPath();
  ctx.moveTo(-16, 2);
  ctx.quadraticCurveTo(-46, 10, -50, 28);
  ctx.quadraticCurveTo(-32, 24, -18, 20);
  ctx.closePath();
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(16, 2);
  ctx.quadraticCurveTo(46, 10, 50, 28);
  ctx.quadraticCurveTo(32, 24, 18, 20);
  ctx.closePath();
  ctx.fill();

  // Front colored fin layer
  ctx.fillStyle = colors.secondary;
  ctx.strokeStyle = hexToRgba(colors.accent, 0.8);
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.moveTo(-15, 0);
  ctx.quadraticCurveTo(-40, 7, -43, 22);
  ctx.quadraticCurveTo(-27, 18, -16, 15);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(15, 0);
  ctx.quadraticCurveTo(40, 7, 43, 22);
  ctx.quadraticCurveTo(27, 18, 16, 15);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Fin glow filaments
  ctx.strokeStyle = hexToRgba(colors.glow, 0.7);
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(-18, 5);
  ctx.quadraticCurveTo(-34, 10, -38, 19);
  ctx.moveTo(18, 5);
  ctx.quadraticCurveTo(34, 10, 38, 19);
  ctx.stroke();

  // 4. Main Body: Sleek polished chassis
  const bodyGrad = ctx.createLinearGradient(-22, 0, 22, 0);
  bodyGrad.addColorStop(0, colors.secondary);
  bodyGrad.addColorStop(0.28, colors.primary);
  bodyGrad.addColorStop(0.72, colors.primary);
  bodyGrad.addColorStop(1, colors.secondary);

  ctx.fillStyle = bodyGrad;
  ctx.strokeStyle = colors.accent;
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(0, -62); // Snout muzzle tip
  ctx.bezierCurveTo(20, -46, 23, -12, 18, 16);
  ctx.quadraticCurveTo(0, 22, -18, 16);
  ctx.bezierCurveTo(-23, -12, -20, -46, 0, -62);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Specular highlight streak (polished shine)
  ctx.fillStyle = 'rgba(255, 255, 255, 0.14)';
  ctx.beginPath();
  ctx.moveTo(-9, -52);
  ctx.quadraticCurveTo(-15, -20, -12, 10);
  ctx.quadraticCurveTo(-7, -20, -4, -50);
  ctx.closePath();
  ctx.fill();

  // Gold trim contour lines along body
  ctx.strokeStyle = hexToRgba('#fbbf24', 0.55);
  ctx.lineWidth = 1.3;
  ctx.beginPath();
  ctx.moveTo(-16, 10);
  ctx.bezierCurveTo(-20, -14, -17, -40, -2, -56);
  ctx.moveTo(16, 10);
  ctx.bezierCurveTo(20, -14, 17, -40, 2, -56);
  ctx.stroke();

  // 5. Dorsal Fin Crest (elegant curved blade)
  ctx.fillStyle = colors.accent;
  ctx.beginPath();
  ctx.moveTo(0, -44);
  ctx.quadraticCurveTo(-8, -30, -3, -14);
  ctx.quadraticCurveTo(1, -28, 0, -44);
  ctx.closePath();
  ctx.fill();

  // 6. Subtle Gill Vents (soft glow)
  const gillPulse = 0.5 + Math.sin(animTime * 5) * 0.5;
  ctx.lineWidth = 2;
  ctx.strokeStyle = hexToRgba(colors.glow, 0.5 + gillPulse * 0.4);
  for (let i = 0; i < 3; i++) {
    const gy = -16 + i * 8;
    ctx.beginPath();
    ctx.moveTo(-15, gy);
    ctx.quadraticCurveTo(-19, gy + 3, -13, gy + 6);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(15, gy);
    ctx.quadraticCurveTo(19, gy + 3, 13, gy + 6);
    ctx.stroke();
  }

  // 7. Glass Energy Orb Core (pulsing heart of the gun)
  const orbY = -2;
  const orbR = 9;
  // Outer glow halo
  const orbHalo = ctx.createRadialGradient(0, orbY, 2, 0, orbY, orbR * 2.2);
  orbHalo.addColorStop(0, hexToRgba(colors.glow, 0.5 + gillPulse * 0.3));
  orbHalo.addColorStop(1, 'transparent');
  ctx.fillStyle = orbHalo;
  ctx.beginPath();
  ctx.arc(0, orbY, orbR * 2.2, 0, Math.PI * 2);
  ctx.fill();

  // Glass sphere
  const orbGrad = ctx.createRadialGradient(-3, orbY - 3, 1, 0, orbY, orbR);
  orbGrad.addColorStop(0, '#ffffff');
  orbGrad.addColorStop(0.35, colors.glow);
  orbGrad.addColorStop(1, colors.accent);
  ctx.fillStyle = orbGrad;
  ctx.beginPath();
  ctx.arc(0, orbY, orbR, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = hexToRgba('#fbbf24', 0.9);
  ctx.lineWidth = 1.8;
  ctx.stroke();

  // Tiny bubbles rising inside the orb
  ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
  for (let b = 0; b < 3; b++) {
    const bOffset = (animTime * 14 + b * 6) % (orbR * 1.6);
    ctx.beginPath();
    ctx.arc(-2.5 + (b % 2) * 5, orbY + orbR * 0.7 - bOffset, 1.1, 0, Math.PI * 2);
    ctx.fill();
  }

  // 8. Predator Eyes on Snout (sleek)
  const eyeGlow = 0.7 + Math.sin(animTime * 4) * 0.3;
  ctx.fillStyle = colors.eye;
  ctx.shadowColor = colors.eye;
  ctx.shadowBlur = 7 * eyeGlow;
  ctx.beginPath();
  ctx.ellipse(-10, -40, 3.5, 1.8, Math.PI / 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(10, -40, 3.5, 1.8, -Math.PI / 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;

  // 9. Shark Jaw Muzzle: THICK Teeth lining the barrel mouth
  ctx.fillStyle = colors.teeth;
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.35)';
  ctx.lineWidth = 1;
  for (let t = -2; t <= 2; t++) {
    const tx = t * 5.4;
    ctx.beginPath();
    ctx.moveTo(tx - 2.8, -53);
    ctx.lineTo(tx, -62);
    ctx.lineTo(tx + 2.8, -53);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  // 10. Golden Muzzle Ring + rotating holo ring
  ctx.strokeStyle = hexToRgba('#fbbf24', 0.95);
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.ellipse(0, -62, 9, 3.5, 0, 0, Math.PI * 2);
  ctx.stroke();

  // Rotating holographic targeting ring above muzzle
  ctx.save();
  ctx.translate(0, -70);
  ctx.rotate(animTime * 1.6);
  ctx.strokeStyle = hexToRgba(colors.glow, 0.45);
  ctx.lineWidth = 1.5;
  ctx.setLineDash([5, 6]);
  ctx.beginPath();
  ctx.arc(0, 0, 13, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();

  ctx.restore();
}

/**
 * Internal: draws ONE organic shark body viewed from above,
 * head pointing toward -Y (up), centered at origin.
 * Used by both flying and attached sharks so they look identical.
 */
function drawOrganicSharkBody(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  mouthOpen: number, // 0..1
  colors: SharkGunConfig['colors'],
  tailWag: number
) {
  const hw = width / 2;
  const L = height;
  const sway = Math.sin(tailWag) * hw * 0.38;
  const jaw = mouthOpen * hw * 0.8;

  const darkStroke = 'rgba(0, 0, 0, 0.3)';

  // ---- 1. Lunate Crescent Caudal Tail (natural shark tail, swaying) ----
  ctx.fillStyle = colors.secondary;
  ctx.strokeStyle = darkStroke;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(0, L * 0.3);
  ctx.quadraticCurveTo(-hw * 0.9 + sway, L * 0.4, -hw * 0.85 + sway, L * 0.6);
  ctx.quadraticCurveTo(-hw * 0.3 + sway * 0.6, L * 0.49, sway * 0.4, L * 0.46);
  ctx.quadraticCurveTo(hw * 0.3 + sway * 0.6, L * 0.49, hw * 0.75 + sway, L * 0.57);
  ctx.quadraticCurveTo(hw * 0.8 + sway, L * 0.4, 0, L * 0.3);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // ---- 2. Swept-back Pectoral Fins (natural wing-like curves) ----
  const finFlap = Math.sin(tailWag * 0.6) * 2;
  ctx.fillStyle = colors.secondary;
  ctx.strokeStyle = darkStroke;
  ctx.lineWidth = 1.5;
  // Left pectoral
  ctx.beginPath();
  ctx.moveTo(-hw * 0.68, -L * 0.04);
  ctx.quadraticCurveTo(-hw * 1.55, L * 0.1 + finFlap, -hw * 1.3, L * 0.26 + finFlap);
  ctx.quadraticCurveTo(-hw * 0.88, L * 0.2, -hw * 0.52, L * 0.12);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  // Right pectoral
  ctx.beginPath();
  ctx.moveTo(hw * 0.68, -L * 0.04);
  ctx.quadraticCurveTo(hw * 1.55, L * 0.1 + finFlap, hw * 1.3, L * 0.26 + finFlap);
  ctx.quadraticCurveTo(hw * 0.88, L * 0.2, hw * 0.52, L * 0.12);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Small pelvic fins near tail
  ctx.beginPath();
  ctx.moveTo(-hw * 0.3, L * 0.22);
  ctx.quadraticCurveTo(-hw * 0.72, L * 0.32, -hw * 0.55, L * 0.38);
  ctx.quadraticCurveTo(-hw * 0.32, L * 0.32, -hw * 0.2, L * 0.28);
  ctx.closePath();
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(hw * 0.3, L * 0.22);
  ctx.quadraticCurveTo(hw * 0.72, L * 0.32, hw * 0.55, L * 0.38);
  ctx.quadraticCurveTo(hw * 0.32, L * 0.32, hw * 0.2, L * 0.28);
  ctx.closePath();
  ctx.fill();

  // ---- 3. Main Organic Torso (blunt rounded snout, smooth taper) ----
  const bodyGrad = ctx.createLinearGradient(-hw, 0, hw, 0);
  bodyGrad.addColorStop(0, colors.secondary);
  bodyGrad.addColorStop(0.5, colors.primary);
  bodyGrad.addColorStop(1, colors.secondary);

  ctx.fillStyle = bodyGrad;
  ctx.strokeStyle = darkStroke;
  ctx.lineWidth = 2;

  ctx.beginPath();
  ctx.moveTo(-hw * 0.16, L * 0.33); // tail base left
  ctx.bezierCurveTo(-hw * 0.8, L * 0.16, -hw * 0.92, -L * 0.1, -hw * 0.62 - jaw * 0.35, -L * 0.33);
  // left jaw up to tip (rounded)
  ctx.quadraticCurveTo(-hw * 0.5 - jaw, -L * 0.45, -hw * 0.22 - jaw, -L * 0.5);
  if (mouthOpen > 0.08) {
    // open gape: curve dips toward throat
    ctx.quadraticCurveTo(0, -L * 0.5 + mouthOpen * L * 0.11, hw * 0.22 + jaw, -L * 0.5);
  } else {
    // blunt rounded snout
    ctx.quadraticCurveTo(0, -L * 0.565, hw * 0.22, -L * 0.5);
  }
  ctx.quadraticCurveTo(hw * 0.5 + jaw, -L * 0.45, hw * 0.62 + jaw * 0.35, -L * 0.33);
  ctx.bezierCurveTo(hw * 0.92, -L * 0.1, hw * 0.8, L * 0.16, hw * 0.16, L * 0.33);
  ctx.quadraticCurveTo(0, L * 0.37, -hw * 0.16, L * 0.33);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Soft belly countershading streak along the spine
  ctx.fillStyle = hexToRgba(colors.belly, 0.38);
  ctx.beginPath();
  ctx.ellipse(0, -L * 0.04, hw * 0.42, L * 0.3, 0, 0, Math.PI * 2);
  ctx.fill();

  // Subtle skin speckles (organic texture)
  ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
  const speckles: [number, number][] = [
    [-0.35, -0.2], [0.3, -0.12], [-0.2, 0.05], [0.4, 0.08], [-0.42, 0.15], [0.15, -0.3], [0.05, 0.18]
  ];
  speckles.forEach(([sx, sy]) => {
    ctx.beginPath();
    ctx.arc(sx * hw, sy * L, 1.6, 0, Math.PI * 2);
    ctx.fill();
  });

  // ---- 4. Open Mouth: red gullet + THICK triangular teeth ----
  if (mouthOpen > 0.08) {
    const gape = mouthOpen;
    const span = hw * 0.3 + jaw * 0.9;

    // Crimson mouth interior
    ctx.fillStyle = '#7f1d1d';
    ctx.beginPath();
    ctx.moveTo(-span, -L * 0.47);
    ctx.quadraticCurveTo(0, -L * 0.5 + gape * L * 0.14, span, -L * 0.47);
    ctx.quadraticCurveTo(0, -L * 0.34, -span, -L * 0.47);
    ctx.closePath();
    ctx.fill();

    // Dark deep throat
    ctx.fillStyle = '#450a0a';
    ctx.beginPath();
    ctx.ellipse(0, -L * 0.41, span * 0.45 * gape + 2, L * 0.045 * gape + 2, 0, 0, Math.PI * 2);
    ctx.fill();

    // THICK upper row teeth (pointing down into the gape)
    ctx.fillStyle = colors.teeth;
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.lineWidth = 1;
    const nTeeth = 6;
    for (let t = 0; t < nTeeth; t++) {
      const fx = (t / (nTeeth - 1)) * 2 - 1;
      const tx = fx * span * 0.82;
      const baseY = -L * 0.49 + Math.abs(fx) * L * 0.015;
      const th = 7 + gape * 7;
      ctx.beginPath();
      ctx.moveTo(tx - 4.6, baseY);
      ctx.lineTo(tx, baseY + th);
      ctx.lineTo(tx + 4.6, baseY);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
    // THICK lower row teeth (pointing up)
    for (let t = 0; t < nTeeth - 1; t++) {
      const fx = ((t + 0.5) / (nTeeth - 1)) * 2 - 1;
      const tx = fx * span * 0.72;
      const baseY = -L * 0.355;
      const th = 6 + gape * 5;
      ctx.beginPath();
      ctx.moveTo(tx - 4, baseY);
      ctx.lineTo(tx, baseY - th);
      ctx.lineTo(tx + 4, baseY);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
  }

  // ---- 5. Dorsal fin seen from above (narrow sliver on the back) ----
  ctx.fillStyle = colors.primary;
  ctx.strokeStyle = darkStroke;
  ctx.lineWidth = 1.3;
  ctx.beginPath();
  ctx.moveTo(0, -L * 0.1);
  ctx.quadraticCurveTo(-hw * 0.16, L * 0.02, -hw * 0.1, L * 0.12);
  ctx.quadraticCurveTo(0, L * 0.06, hw * 0.1, L * 0.12);
  ctx.quadraticCurveTo(hw * 0.16, L * 0.02, 0, -L * 0.1);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // ---- 6. Natural Black Shark Eyes with glint ----
  const eyeX = hw * 0.48 + jaw * 0.5;
  const eyeY = -L * 0.38;
  ctx.fillStyle = '#0a0a0a';
  ctx.beginPath();
  ctx.ellipse(-eyeX, eyeY, 3.2, 4, Math.PI / 10, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(eyeX, eyeY, 3.2, 4, -Math.PI / 10, 0, Math.PI * 2);
  ctx.fill();
  // White glints
  ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
  ctx.beginPath();
  ctx.arc(-eyeX + 1, eyeY - 1.2, 1.1, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(eyeX - 1, eyeY - 1.2, 1.1, 0, Math.PI * 2);
  ctx.fill();

  // ---- 7. Dark natural gill slits (5 per side, no neon) ----
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.38)';
  ctx.lineWidth = 1.8;
  for (let g = 0; g < 5; g++) {
    const gy = -L * 0.26 + g * (L * 0.035);
    const gx = hw * (0.6 - g * 0.025);
    ctx.beginPath();
    ctx.moveTo(-gx, gy);
    ctx.quadraticCurveTo(-gx - 4, gy + 3, -gx + 1, gy + 5);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(gx, gy);
    ctx.quadraticCurveTo(gx + 4, gy + 3, gx - 1, gy + 5);
    ctx.stroke();
  }
}

/**
 * Draws the Flying Shark (2x the size of the gun!) — organic, alive, swimming.
 * As it approaches the rotating board, its jaws violently GAP WIDE OPEN!
 */
export function drawFlyingShark(
  ctx: CanvasRenderingContext2D,
  shark: {
    x: number;
    y: number;
    width: number;
    height: number;
    mouthOpenProgress: number; // 0 (closed) to 1 (huge bite open)
    gunTheme: SharkGunConfig;
    tailWag: number;
  }
) {
  const { x, y, width, height, mouthOpenProgress, gunTheme, tailWag } = shark;
  const colors = gunTheme.colors;

  ctx.save();
  ctx.translate(x, y);

  // Soft bubble wake trailing behind (no rocket thrust!)
  for (let i = 0; i < 6; i++) {
    const wy = height * 0.42 + i * 15;
    ctx.fillStyle = hexToRgba(colors.accent, Math.max(0.04, 0.3 - i * 0.05));
    ctx.beginPath();
    ctx.arc(Math.sin(tailWag * 0.8 + i * 1.3) * 8, wy, (6 - i) * 2.4, 0, Math.PI * 2);
    ctx.fill();
  }
  // Tiny white froth bubbles
  ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
  for (let i = 0; i < 4; i++) {
    const wy = height * 0.5 + i * 20;
    ctx.beginPath();
    ctx.arc(Math.cos(tailWag + i * 2) * 12, wy, 2, 0, Math.PI * 2);
    ctx.fill();
  }

  drawOrganicSharkBody(ctx, width, height, mouthOpenProgress, colors, tailWag);

  ctx.restore();
}

/**
 * Draws a Shark bitten onto the rotating target board — TOP-DOWN view,
 * drawn ON TOP of the board so the head is fully VISIBLE eating the rim!
 * The open jaws straddle the board edge: upper jaw overlaps the wood,
 * teeth clamp down on the rim, body + swishing tail extend radially outward.
 */
export function drawAttachedShark(
  ctx: CanvasRenderingContext2D,
  shark: AttachedShark,
  boardRadius: number,
  gunTheme: SharkGunConfig,
  animTime: number
) {
  const { angle, biteWiggle, tailPhase } = shark;
  const colors = gunTheme.colors;

  ctx.save();
  // Rotate to the shark's attached angle around the wheel.
  // Convention: (rotate(angle) -> translate(0, r)) lands on the bite point.
  ctx.rotate(angle);
  // Move to the rim of the board
  ctx.translate(0, boardRadius);

  // Fresh-bite recoil wiggle (shivers right after chomping)
  const wiggleOffset = Math.sin(biteWiggle * 18) * 2;
  ctx.translate(wiggleOffset * 0.4, 0);

  const sW = 36; // Attached shark width
  const sH = 92; // Attached shark length
  const biteDepth = 12; // how far the snout overlaps ONTO the board surface

  // --- 1. Soft crushed-wood dent UNDER the jaws (no messy web cracks) ---
  ctx.fillStyle = 'rgba(25, 14, 5, 0.65)';
  ctx.beginPath();
  ctx.ellipse(0, -biteDepth * 0.4, sW * 0.46, biteDepth * 0.8, 0, 0, Math.PI * 2);
  ctx.fill();

  // --- 2. Organic shark body, mouth CLOSED (clean intact head, visible on top) ---
  // Body spans head at -L/2 ... tail at +L/2 around its origin.
  // Shift so the snout tip lands at y = -biteDepth (overlapping the board!).
  ctx.save();
  ctx.translate(0, sH * 0.5 - biteDepth);
  drawOrganicSharkBody(ctx, sW, sH, 0, colors, animTime * 6 + tailPhase);
  ctx.restore();

  ctx.restore();
}

/**
 * Draws the rotating target board (Wood log / Coral Reef / Cyber Core / Boss Wheel).
 */
export function drawTargetBoard(
  ctx: CanvasRenderingContext2D,
  board: TargetBoard,
  animTime: number
) {
  const { radius, isBoss, hitFlash } = board;

  ctx.save();
  // Rotate canvas according to board.rotation
  ctx.rotate(board.rotation);

  // Outer glow if boss or hit flash
  if (isBoss || hitFlash > 0) {
    ctx.shadowColor = isBoss ? '#f43f5e' : '#38bdf8';
    ctx.shadowBlur = isBoss ? 20 + Math.sin(animTime * 6) * 8 : hitFlash * 25;
  }

  // 1. Board Outer Rim
  const rimGrad = ctx.createRadialGradient(0, 0, radius * 0.75, 0, 0, radius);
  if (isBoss) {
    rimGrad.addColorStop(0, '#450a0a');
    rimGrad.addColorStop(0.85, '#7f1d1d');
    rimGrad.addColorStop(1, '#ef4444');
  } else {
    rimGrad.addColorStop(0, '#593217');
    rimGrad.addColorStop(0.85, '#3d1f0d');
    rimGrad.addColorStop(1, '#854d0e');
  }

  ctx.fillStyle = rimGrad;
  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;

  // Outer metal / iron band
  ctx.strokeStyle = isBoss ? '#fbbf24' : '#92400e';
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.arc(0, 0, radius - 3, 0, Math.PI * 2);
  ctx.stroke();

  // 2. Inner Board Texture (Wood Rings & Radial Planks)
  const innerRadius = radius - 7;
  const innerGrad = ctx.createRadialGradient(0, 0, 10, 0, 0, innerRadius);
  if (isBoss) {
    innerGrad.addColorStop(0, '#991b1b');
    innerGrad.addColorStop(0.6, '#450a0a');
    innerGrad.addColorStop(1, '#1c1917');
  } else {
    innerGrad.addColorStop(0, '#a16207');
    innerGrad.addColorStop(0.5, '#78350f');
    innerGrad.addColorStop(1, '#451a03');
  }
  ctx.fillStyle = innerGrad;
  ctx.beginPath();
  ctx.arc(0, 0, innerRadius, 0, Math.PI * 2);
  ctx.fill();

  // Wood concentric growth rings
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.22)';
  ctx.lineWidth = 1.5;
  for (let r = 18; r < innerRadius; r += 16) {
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, Math.PI * 2);
    ctx.stroke();
  }

  // Radial wood spokes / metal ribs (8 segments)
  const spokeCount = 8;
  for (let s = 0; s < spokeCount; s++) {
    const sAngle = (s * Math.PI * 2) / spokeCount;
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.3)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(Math.cos(sAngle) * 16, Math.sin(sAngle) * 16);
    ctx.lineTo(Math.cos(sAngle) * (innerRadius - 4), Math.sin(sAngle) * (innerRadius - 4));
    ctx.stroke();

    // Steel rivets near rim
    const rivetX = Math.cos(sAngle) * (radius - 12);
    const rivetY = Math.sin(sAngle) * (radius - 12);
    ctx.fillStyle = '#e2e8f0';
    ctx.beginPath();
    ctx.arc(rivetX, rivetY, 3, 0, Math.PI * 2);
    ctx.fill();
  }

  // 3. Center Hub (Shark Emblem or Boss Skull)
  const hubRadius = 26;
  const hubGrad = ctx.createRadialGradient(0, 0, 4, 0, 0, hubRadius);
  hubGrad.addColorStop(0, isBoss ? '#f43f5e' : '#38bdf8');
  hubGrad.addColorStop(1, isBoss ? '#7f1d1d' : '#0369a1');

  ctx.fillStyle = hubGrad;
  ctx.strokeStyle = '#f8fafc';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(0, 0, hubRadius, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Center Emblem: Fierce Shark Fin / Jaws
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.moveTo(0, -14);
  ctx.lineTo(10, 8);
  ctx.lineTo(-10, 8);
  ctx.closePath();
  ctx.fill();

  // White hit flash overlay
  if (hitFlash > 0.05) {
    ctx.fillStyle = `rgba(255, 255, 255, ${hitFlash * 0.6})`;
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.fill();
  }

  // 4. Target Collectibles (Golden Pearls / Meat / Shells)
  board.items.forEach(item => {
    if (item.collected) return;
    ctx.save();
    ctx.rotate(item.angle);
    ctx.translate(0, radius - 4);

    const pulse = Math.sin(animTime * 6 + item.pulse) * 2;

    if (item.type === 'pearl') {
      // Golden Shimmering Pearl
      ctx.shadowColor = '#fbbf24';
      ctx.shadowBlur = 10;
      const pearlGrad = ctx.createRadialGradient(-2, -2, 1, 0, 0, 9 + pulse);
      pearlGrad.addColorStop(0, '#ffffff');
      pearlGrad.addColorStop(0.5, '#fde047');
      pearlGrad.addColorStop(1, '#eab308');
      ctx.fillStyle = pearlGrad;
      ctx.beginPath();
      ctx.arc(0, 0, 9 + pulse, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#b45309';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    } else if (item.type === 'meat') {
      // Shark Bait Meat Chunk
      ctx.shadowColor = '#f87171';
      ctx.shadowBlur = 8;
      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.roundRect(-8, -8, 16, 16, 4);
      ctx.fill();
      // Bone center
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(0, 0, 3.5, 0, Math.PI * 2);
      ctx.fill();
    } else {
      // Nautilus Shell
      ctx.shadowColor = '#67e8f9';
      ctx.shadowBlur = 8;
      ctx.fillStyle = '#06b6d4';
      ctx.beginPath();
      ctx.arc(0, 0, 8, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  });

  // 5. Boss Obstacles (Spiked Armor Plates / Shields)
  board.obstacles.forEach(obs => {
    ctx.save();
    ctx.rotate(obs.angle);
    ctx.translate(0, radius);

    // Spiked Metal Shield
    ctx.fillStyle = '#334155';
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 2.5;

    // Curved shield block
    ctx.beginPath();
    ctx.roundRect(-20, -10, 40, 22, 6);
    ctx.fill();
    ctx.stroke();

    // Dangerous glowing spikes
    ctx.fillStyle = '#ef4444';
    for (let sp = -14; sp <= 14; sp += 14) {
      ctx.beginPath();
      ctx.moveTo(sp - 4, 12);
      ctx.lineTo(sp, 26);
      ctx.lineTo(sp + 4, 12);
      ctx.closePath();
      ctx.fill();
    }

    // Hazard stripes
    ctx.fillStyle = '#facc15';
    ctx.beginPath();
    ctx.arc(0, 0, 4, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  });

  ctx.restore();
}

/**
 * Draws floating visual text (e.g., "CHOMP!", "+10 PEARLS", "COMBO x3!").
 */
export function drawFloatingText(ctx: CanvasRenderingContext2D, text: FloatingText) {
  ctx.save();
  ctx.globalAlpha = Math.max(0, text.alpha);
  ctx.font = `900 ${text.size}px 'Black Ops One', 'Orbitron', sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  // Glow / outline
  ctx.strokeStyle = '#000000';
  ctx.lineWidth = 4;
  ctx.strokeText(text.text, text.x, text.y);

  ctx.fillStyle = text.color;
  ctx.fillText(text.text, text.x, text.y);
  ctx.restore();
}

/**
 * Draws all particle types: bubbles, wood chips, bite rings, water splashes, blood sparks.
 */
export function drawParticle(ctx: CanvasRenderingContext2D, p: Particle) {
  ctx.save();
  ctx.globalAlpha = Math.max(0, p.alpha);

  if (p.type === 'ring') {
    // Shockwave expansion ring
    ctx.strokeStyle = p.color;
    ctx.lineWidth = Math.max(1, p.size * 0.15);
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.stroke();
  } else if (p.type === 'bubble') {
    // Water Bubble with highlight
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.beginPath();
    ctx.arc(p.x - p.size * 0.3, p.y - p.size * 0.3, p.size * 0.3, 0, Math.PI * 2);
    ctx.fill();
  } else if (p.type === 'wood_chip') {
    // Splintered wood chip
    ctx.translate(p.x, p.y);
    if (p.rotation) ctx.rotate(p.rotation);
    ctx.fillStyle = p.color;
    ctx.fillRect(-p.size / 2, -p.size, p.size, p.size * 2);
  } else if (p.type === 'water_splash') {
    // Stretched water droplet aligned to its fall
    ctx.translate(p.x, p.y);
    const ang = Math.atan2(p.vy, p.vx) + Math.PI / 2;
    ctx.rotate(ang);
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.ellipse(0, 0, p.size * 0.55, p.size, 0, 0, Math.PI * 2);
    ctx.fill();
    // highlight
    ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
    ctx.beginPath();
    ctx.arc(-p.size * 0.15, -p.size * 0.3, p.size * 0.22, 0, Math.PI * 2);
    ctx.fill();
  } else {
    // Spark / Blood
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}
