import React, { useEffect, useRef, useCallback } from 'react';
import { SharkGunConfig, TargetBoard, FlyingShark, Particle, FloatingText, BoardFragment } from '../types/game';
import { drawSharkGun, drawFlyingShark, drawAttachedShark, drawTargetBoard, drawParticle, drawFloatingText } from './drawingUtils';
import { sounds } from '../audio/soundManager';
import { BOSS_LEVELS } from '../data/bosses';
import confetti from 'canvas-confetti';

interface GameCanvasProps {
  currentGun: SharkGunConfig;
  stage: number;
  score: number;
  sharksLeft: number;
  onScoreUpdate: (newScore: number) => void;
  onSharksLeftUpdate: (count: number) => void;
  onStageClear: (nextStage: number) => void;
  onGameOver: (finalScore: number, stage: number) => void;
  onPearlsGained: (amount: number) => void;
  laserSight: boolean;
  screenShakeEnabled: boolean;
  lang: 'id' | 'en';
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  currentGun,
  stage,
  score,
  sharksLeft,
  onScoreUpdate,
  onSharksLeftUpdate,
  onStageClear,
  onGameOver,
  onPearlsGained,
  laserSight,
  screenShakeEnabled,
  lang
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Game state references across frames
  const gameStateRef = useRef({
    board: null as TargetBoard | null,
    flyingShark: null as FlyingShark | null,
    recoil: 0,
    particles: [] as Particle[],
    floatingTexts: [] as FloatingText[],
    boardFragments: [] as BoardFragment[],
    screenShake: 0,
    animTime: 0,
    isStageTransitioning: false,
    combo: 0,
    lastHitTime: 0,
    bouncingShark: null as { x: number; y: number; vx: number; vy: number; rot: number; vRot: number } | null,
    gameOverTriggered: false
  });

  // Keep latest props in ref
  const propsRef = useRef({
    currentGun,
    stage,
    score,
    sharksLeft,
    laserSight,
    screenShakeEnabled,
    lang,
    onScoreUpdate,
    onSharksLeftUpdate,
    onStageClear,
    onGameOver,
    onPearlsGained
  });

  useEffect(() => {
    propsRef.current = {
      currentGun,
      stage,
      score,
      sharksLeft,
      laserSight,
      screenShakeEnabled,
      lang,
      onScoreUpdate,
      onSharksLeftUpdate,
      onStageClear,
      onGameOver,
      onPearlsGained
    };
  }, [currentGun, stage, score, sharksLeft, laserSight, screenShakeEnabled, lang, onScoreUpdate, onSharksLeftUpdate, onStageClear, onGameOver, onPearlsGained]);

  // Generate a Target Board for the current stage
  const initBoardForStage = useCallback((stg: number): TargetBoard => {
    const isBoss = stg % 5 === 0;
    const bossDef = BOSS_LEVELS[stg];

    // Determine sharks required
    let required = 6 + Math.min(stg - 1, 6);
    let speed = 0.024 + Math.min(stg * 0.0025, 0.035);
    let pattern: TargetBoard['speedPattern'] = 'variable';
    let name = `Reef Target #${stg}`;

    if (isBoss) {
      if (bossDef) {
        required = bossDef.sharksRequired;
        speed = bossDef.speed;
        pattern = bossDef.speedPattern;
        name = lang === 'id' ? bossDef.nameId : bossDef.name;
      } else {
        required = 10 + Math.floor(stg / 5);
        speed = 0.045;
        pattern = 'boss_dash';
        name = `Boss Titan #${stg}`;
      }
    } else {
      if (stg % 3 === 0) pattern = 'reverse';
      else if (stg % 4 === 0) pattern = 'stutter';
    }

    // Generate random items to collect (Pearls / Meat)
    const items: TargetBoard['items'] = [];
    const itemCount = Math.random() < 0.65 ? 1 + Math.floor(Math.random() * 2) : 0;
    for (let i = 0; i < itemCount; i++) {
      items.push({
        angle: Math.random() * Math.PI * 2,
        type: Math.random() < 0.6 ? 'pearl' : 'meat',
        collected: false,
        pulse: Math.random() * Math.PI
      });
    }

    // Generate boss obstacles if boss
    const obstacles: TargetBoard['obstacles'] = [];
    if (isBoss) {
      const obsCount = bossDef ? bossDef.obstacleCount : 2;
      for (let o = 0; o < obsCount; o++) {
        obstacles.push({
          angle: (o * (Math.PI * 2)) / obsCount + Math.PI / 4,
          widthAngle: 0.35,
          type: 'shield'
        });
      }
    }

    return {
      radius: isBoss ? 82 : 74,
      rotation: 0,
      baseSpeed: speed,
      currentSpeed: speed,
      speedPattern: pattern,
      patternTimer: 0,
      woodTextureSeed: Math.random(),
      sharksRequired: required,
      attachedSharks: [],
      items,
      obstacles,
      name,
      isBoss,
      hitFlash: 0
    };
  }, [lang]);

  // Initialize board on stage change
  useEffect(() => {
    const board = initBoardForStage(stage);
    gameStateRef.current.board = board;
    gameStateRef.current.isStageTransitioning = false;
    gameStateRef.current.gameOverTriggered = false;
    gameStateRef.current.flyingShark = null;
    gameStateRef.current.bouncingShark = null;
    propsRef.current.onSharksLeftUpdate(board.sharksRequired);

    if (board.isBoss) {
      sounds.playBossAlert();
      // Floating alert
      gameStateRef.current.floatingTexts.push({
        id: Date.now(),
        x: 200,
        y: 280,
        text: lang === 'id' ? '⚠️ TAHAP BOSS! ⚠️' : '⚠️ BOSS STAGE! ⚠️',
        color: '#f43f5e',
        size: 26,
        alpha: 1.2,
        vy: -0.6
      });
    }
  }, [stage, initBoardForStage, lang]);

  // Screen shake trigger
  const triggerScreenShake = useCallback((strength: number) => {
    if (propsRef.current.screenShakeEnabled) {
      gameStateRef.current.screenShake = strength;
    }
  }, []);

  // Fire action: Shoot the 2x Shark Gun projectile
  const fireShark = useCallback(() => {
    const state = gameStateRef.current;
    if (state.flyingShark || state.isStageTransitioning || state.bouncingShark || state.gameOverTriggered) {
      return;
    }
    if (propsRef.current.sharksLeft <= 0) {
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;

    const width = canvas.width;
    const height = canvas.height;

    // Gun dimensions: stationed at bottom center aiming UP
    const gunX = width / 2;
    const gunY = height - 90;

    // Flying Shark size: exactly 2x the gun's visual mass!
    // Gun is ~44x75px, flying shark is ~52x125px (imposing 2x predatory beast!)
    state.flyingShark = {
      x: gunX,
      y: gunY - 45,
      width: 52,
      height: 125,
      speed: 34, // fast, crisp arcade projectile speed
      mouthOpenProgress: 0,
      gunTheme: propsRef.current.currentGun.id,
      tailWag: 0
    };

    // Gun Recoil
    state.recoil = 1;

    // Audio
    sounds.playShoot();

    // Muzzle particles (water jet bubbles + sparks)
    for (let i = 0; i < 16; i++) {
      const angle = -Math.PI / 2 + (Math.random() - 0.5) * 1.2;
      const spd = 4 + Math.random() * 8;
      state.particles.push({
        x: gunX + (Math.random() - 0.5) * 16,
        y: gunY - 50,
        vx: Math.cos(angle) * spd,
        vy: Math.sin(angle) * spd,
        size: 3 + Math.random() * 5,
        color: propsRef.current.currentGun.colors.glow,
        alpha: 0.9,
        life: 0,
        maxLife: 20 + Math.random() * 15,
        type: Math.random() < 0.6 ? 'bubble' : 'spark'
      });
    }

    // Muzzle blast shockwave ring
    state.particles.push({
      x: gunX,
      y: gunY - 55,
      vx: 0,
      vy: -2,
      size: 15,
      color: propsRef.current.currentGun.colors.accent,
      alpha: 0.8,
      life: 0,
      maxLife: 14,
      type: 'ring'
    });
  }, []);

  // Keyboard handler (Spacebar / Up Arrow to shoot)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.key === ' ' || e.code === 'ArrowUp') {
        e.preventDefault();
        fireShark();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [fireShark]);

  // Main 60fps Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animFrameId: number;

    const render = () => {
      const state = gameStateRef.current;
      const props = propsRef.current;
      const board = state.board;

      state.animTime += 0.016;

      // Reset transforms
      ctx.setTransform(1, 0, 0, 1, 0, 0);

      // Handle screen shake
      let shakeX = 0;
      let shakeY = 0;
      if (state.screenShake > 0) {
        shakeX = (Math.random() - 0.5) * state.screenShake * 12;
        shakeY = (Math.random() - 0.5) * state.screenShake * 12;
        state.screenShake = Math.max(0, state.screenShake - 0.08);
      }

      ctx.translate(shakeX, shakeY);

      // Clear & draw deep abyssal oceanic gradient
      const w = canvas.width;
      const h = canvas.height;

      const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
      bgGrad.addColorStop(0, '#030712'); // Pitch abyssal deep
      bgGrad.addColorStop(0.35, '#082f49'); // Ocean blue mid
      bgGrad.addColorStop(0.7, '#0c4a6e'); // Hydro radiance
      bgGrad.addColorStop(1, '#02182b'); // Dark ocean bed
      ctx.fillStyle = bgGrad;
      ctx.fillRect(-20, -20, w + 40, h + 40);

      // Ambient rising deep-sea bubbles
      if (Math.random() < 0.25) {
        state.particles.push({
          x: Math.random() * w,
          y: h + 10,
          vx: (Math.random() - 0.5) * 0.6,
          vy: -1.2 - Math.random() * 1.5,
          size: 1.5 + Math.random() * 3.5,
          color: 'rgba(56, 189, 248, 0.25)',
          alpha: 0.6,
          life: 0,
          maxLife: 260,
          type: 'bubble'
        });
      }

      // God rays / ocean light beams in background
      ctx.save();
      ctx.globalAlpha = 0.04;
      ctx.fillStyle = '#38bdf8';
      for (let r = 0; r < 4; r++) {
        const rx = (w * 0.2) + r * (w * 0.22);
        ctx.beginPath();
        ctx.moveTo(rx - 25, 0);
        ctx.lineTo(rx + 25, 0);
        ctx.lineTo(rx + 75, h);
        ctx.lineTo(rx - 75, h);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();

      // Gun Position
      const gunX = w / 2;
      const gunY = h - 90;

      // Board Center Position
      const boardCenterX = w / 2;
      const boardCenterY = 175;

      // 1. Draw Target Board & Update Rotation
      if (board && !state.isStageTransitioning) {
        // Rotate board according to its speedPattern
        board.patternTimer += 0.016;
        if (board.speedPattern === 'variable') {
          board.currentSpeed = board.baseSpeed * (0.6 + Math.sin(board.patternTimer * 2) * 0.7);
        } else if (board.speedPattern === 'reverse') {
          // Switch direction every 2.5 seconds
          const phase = Math.sin(board.patternTimer * 1.3);
          board.currentSpeed = board.baseSpeed * Math.sign(phase) * (Math.abs(phase) > 0.15 ? 1 : 0.2);
        } else if (board.speedPattern === 'stutter') {
          // Pause briefly, then burst
          const cycle = (board.patternTimer % 2.2);
          if (cycle < 0.5) board.currentSpeed = 0.005;
          else board.currentSpeed = board.baseSpeed * 1.8;
        } else if (board.speedPattern === 'boss_dash') {
          const dash = Math.sin(board.patternTimer * 3);
          board.currentSpeed = board.baseSpeed * (dash > 0.4 ? 2.2 : 0.4);
        } else {
          board.currentSpeed = board.baseSpeed;
        }

        board.rotation += board.currentSpeed;
        board.hitFlash = Math.max(0, board.hitFlash - 0.08);

        // Draw at center. ORDER: board first, then sharks ON TOP so their
        // heads stay fully visible chomping over the board rim (top-down view).
        ctx.save();
        ctx.translate(boardCenterX, boardCenterY);

        // Board underneath
        drawTargetBoard(ctx, board, state.animTime);

        // Attached sharks spin WITH the board, heads visibly eating the rim
        ctx.save();
        ctx.rotate(board.rotation);
        board.attachedSharks.forEach(attached => {
          attached.biteWiggle = Math.max(0, attached.biteWiggle - 0.06);
          drawAttachedShark(ctx, attached, board.radius, props.currentGun, state.animTime);
        });
        ctx.restore();

        ctx.restore();
      }

      // Draw Shattering Fragments if in transition
      if (state.boardFragments.length > 0) {
        state.boardFragments.forEach(frag => {
          frag.x += frag.vx;
          frag.y += frag.vy;
          frag.vy += 0.4; // gravity
          frag.rotation += frag.vRot;
          frag.alpha = Math.max(0, frag.alpha - 0.012);

          ctx.save();
          ctx.translate(frag.x, frag.y);
          ctx.rotate(frag.rotation);
          ctx.globalAlpha = frag.alpha;
          ctx.fillStyle = frag.color;
          ctx.beginPath();
          ctx.arc(0, 0, frag.radius, frag.startAngle, frag.endAngle);
          ctx.lineTo(0, 0);
          ctx.closePath();
          ctx.fill();
          ctx.strokeStyle = '#f59e0b';
          ctx.lineWidth = 2;
          ctx.stroke();
          ctx.restore();
        });
        // Remove dead fragments
        state.boardFragments = state.boardFragments.filter(f => f.alpha > 0.02);
      }

      // 2. Draw Optional Laser Sight straight UP
      if (props.laserSight && !state.flyingShark && !state.isStageTransitioning && !state.gameOverTriggered) {
        ctx.save();
        const laserGrad = ctx.createLinearGradient(gunX, gunY - 55, gunX, boardCenterY + (board?.radius || 74));
        laserGrad.addColorStop(0, 'rgba(56, 189, 248, 0.6)');
        laserGrad.addColorStop(1, 'rgba(56, 189, 248, 0.05)');
        ctx.strokeStyle = laserGrad;
        ctx.lineWidth = 2;
        ctx.setLineDash([6, 6]);
        ctx.beginPath();
        ctx.moveTo(gunX, gunY - 55);
        ctx.lineTo(gunX, boardCenterY + (board?.radius || 74));
        ctx.stroke();
        ctx.restore();
      }

      // 3. Update & Draw Flying Shark Projectile
      if (state.flyingShark && board) {
        const shark = state.flyingShark;
        shark.y -= shark.speed;
        shark.tailWag += 0.45;

        // Target rim Y position where the jaws will snap onto the board
        const targetImpactY = boardCenterY + board.radius;

        // Calculate distance to board rim
        const distToRim = shark.y - targetImpactY;

        // AS IT FLIES TOWARD THE BOARD, ITS MOUTH EXPANDS WIDE OPEN!
        // When within 220px, mouthOpenProgress ramps up aggressively from 0 to 1
        if (distToRim < 220) {
          const openFrac = Math.max(0, Math.min(1, 1 - distToRim / 220));
          shark.mouthOpenProgress = Math.pow(openFrac, 0.7); // snappy jaw flare
        } else {
          shark.mouthOpenProgress = 0;
        }

        // Draw the massive 2x Flying Shark with its gaping jaws!
        drawFlyingShark(ctx, {
          x: shark.x,
          y: shark.y,
          width: shark.width,
          height: shark.height,
          mouthOpenProgress: shark.mouthOpenProgress,
          gunTheme: props.currentGun,
          tailWag: shark.tailWag
        });

        // 4. Collision Detection with the Board Rim!
        if (shark.y <= targetImpactY) {
          // The shark's jaws reach the rotating board rim at the BOTTOM of the wheel!
          // Drawing convention: ctx.rotate(board.rotation) -> ctx.rotate(shark.angle) -> translate(0, radius)
          // lands at world bottom (0, +r) when (board.rotation + shark.angle) === 0.
          // So the correct local attach angle is exactly -board.rotation.
          let hitAngle = (-board.rotation) % (Math.PI * 2);
          if (hitAngle < 0) hitAngle += Math.PI * 2;

          // Check for CLASH against already attached sharks
          // Two sharks collide if angular difference is < ~0.24 radians (~14 degrees)
          const minAngularClearance = 0.24;
          let clashOccurred = false;

          for (const attached of board.attachedSharks) {
            let diff = Math.abs(attached.angle - hitAngle);
            if (diff > Math.PI) diff = Math.PI * 2 - diff;

            if (diff < minAngularClearance) {
              clashOccurred = true;
              break;
            }
          }

          // Check for CLASH against boss obstacles
          if (!clashOccurred && board.obstacles) {
            for (const obs of board.obstacles) {
              let diff = Math.abs(obs.angle - hitAngle);
              if (diff > Math.PI) diff = Math.PI * 2 - diff;

              if (diff < obs.widthAngle / 2 + 0.12) {
                clashOccurred = true;
                break;
              }
            }
          }

          if (clashOccurred) {
            // DEFLECTION / CLASH! Shark bounces off and breaks!
            sounds.playClash();
            triggerScreenShake(1.2);

            // Bouncing shark physics
            state.bouncingShark = {
              x: shark.x,
              y: targetImpactY,
              vx: (Math.random() - 0.5) * 12,
              vy: 6,
              rot: 0,
              vRot: 0.35
            };

            // Sparks & blood particles on clash
            for (let i = 0; i < 22; i++) {
              const ang = Math.random() * Math.PI * 2;
              const spd = 4 + Math.random() * 8;
              state.particles.push({
                x: shark.x,
                y: targetImpactY,
                vx: Math.cos(ang) * spd,
                vy: Math.sin(ang) * spd,
                size: 3 + Math.random() * 4,
                color: Math.random() < 0.5 ? '#f43f5e' : '#facc15',
                alpha: 1,
                life: 0,
                maxLife: 25,
                type: 'spark'
              });
            }

            state.floatingTexts.push({
              id: Date.now(),
              x: shark.x,
              y: targetImpactY - 20,
              text: props.lang === 'id' ? 'BERTABRAKAN!' : 'CLASH!',
              color: '#ef4444',
              size: 26,
              alpha: 1.2,
              vy: -0.8
            });

            state.flyingShark = null;
            state.gameOverTriggered = true;

            setTimeout(() => {
              props.onGameOver(props.score, props.stage);
            }, 900);
          } else {
            // SUCCESSFUL CHOMP! The shark sinks its razor teeth into the wood!
            sounds.playChomp();
            triggerScreenShake(0.65);
            board.hitFlash = 1;

            // Attach the shark onto the rotating board
            board.attachedSharks.push({
              angle: hitAngle,
              depth: 8,
              gunTheme: props.currentGun.id,
              biteWiggle: 1,
              tailPhase: Math.random() * 10,
              id: Date.now()
            });

            // Splinter wood particles & bite shockwave ring
            for (let i = 0; i < 16; i++) {
              const ang = Math.PI / 2 + (Math.random() - 0.5) * 1.6;
              const spd = 3 + Math.random() * 7;
              state.particles.push({
                x: shark.x,
                y: targetImpactY,
                vx: Math.cos(ang) * spd,
                vy: Math.sin(ang) * spd,
                size: 2.5 + Math.random() * 4,
                color: board.isBoss ? '#ef4444' : '#d97706',
                alpha: 1,
                life: 0,
                maxLife: 24,
                type: 'wood_chip',
                rotation: Math.random() * Math.PI,
                vRot: (Math.random() - 0.5) * 0.4
              });
            }

            // Water splash & bite ripple
            state.particles.push({
              x: shark.x,
              y: targetImpactY,
              vx: 0,
              vy: 0,
              size: 16,
              color: props.currentGun.colors.glow,
              alpha: 0.9,
              life: 0,
              maxLife: 16,
              type: 'ring'
            });

            // 💦 BIG WATER SPLASH! Crown of droplets spraying outward on impact
            for (let i = 0; i < 26; i++) {
              // Fan the splash out mostly sideways & upward like a real impact crown
              const spreadAng = Math.PI + (i / 25) * Math.PI; // upward half-circle
              const spd = 2.5 + Math.random() * 7.5;
              const splashColors = ['#e0f2fe', '#bae6fd', '#7dd3fc', '#ffffff', props.currentGun.colors.glow];
              state.particles.push({
                x: shark.x + (Math.random() - 0.5) * 24,
                y: targetImpactY + (Math.random() - 0.5) * 6,
                vx: Math.cos(spreadAng) * spd * (0.6 + Math.random() * 0.8),
                vy: Math.sin(spreadAng) * spd - Math.random() * 3,
                size: 2.5 + Math.random() * 4,
                color: splashColors[Math.floor(Math.random() * splashColors.length)],
                alpha: 0.95,
                life: 0,
                maxLife: 28 + Math.random() * 16,
                type: 'water_splash'
              });
            }

            // Mist / fine spray bubbles around the bite point
            for (let i = 0; i < 10; i++) {
              const ang = Math.random() * Math.PI * 2;
              const spd = 1 + Math.random() * 3;
              state.particles.push({
                x: shark.x,
                y: targetImpactY,
                vx: Math.cos(ang) * spd,
                vy: Math.sin(ang) * spd - 1.5,
                size: 1.5 + Math.random() * 2.5,
                color: 'rgba(224, 242, 254, 0.8)',
                alpha: 0.8,
                life: 0,
                maxLife: 22,
                type: 'bubble'
              });
            }

            // Check Collectibles pickup
            board.items.forEach(item => {
              if (item.collected) return;
              let diff = Math.abs(item.angle - hitAngle);
              if (diff > Math.PI) diff = Math.PI * 2 - diff;
              if (diff < 0.26) {
                item.collected = true;
                sounds.playCollect();
                const pearlBonus = item.type === 'meat' ? 3 : 2;
                props.onPearlsGained(pearlBonus);

                state.floatingTexts.push({
                  id: Date.now() + Math.random(),
                  x: shark.x + 35,
                  y: targetImpactY - 25,
                  text: `+${pearlBonus} 🦪`,
                  color: '#fbbf24',
                  size: 20,
                  alpha: 1.2,
                  vy: -1
                });
              }
            });

            // Combo counter
            const now = Date.now();
            if (now - state.lastHitTime < 1400) {
              state.combo += 1;
            } else {
              state.combo = 1;
            }
            state.lastHitTime = now;

            // Score increment
            const comboBonus = Math.min(state.combo, 5);
            props.onScoreUpdate(props.score + comboBonus);

            // Floating "CHOMP!" text
            const chompTexts = props.lang === 'id' 
              ? ['GIGITAN KERAS!', 'KRAK!', 'CHOMP!', 'PREDATOR!', 'MANTAP!'] 
              : ['HARD CHOMP!', 'CRUNCH!', 'JAWS LOCKED!', 'SAVAGE!', 'PERFECT!'];
            const randomChomp = chompTexts[Math.floor(Math.random() * chompTexts.length)];

            state.floatingTexts.push({
              id: Date.now(),
              x: shark.x,
              y: targetImpactY - 32,
              text: state.combo > 2 ? `${randomChomp} x${state.combo}` : randomChomp,
              color: state.combo > 2 ? '#f59e0b' : '#38bdf8',
              size: state.combo > 2 ? 24 : 20,
              alpha: 1.2,
              vy: -1.2
            });

            // Decrement remaining sharks
            const newSharksLeft = props.sharksLeft - 1;
            props.onSharksLeftUpdate(newSharksLeft);
            state.flyingShark = null;

            // Check if stage is completed!
            if (newSharksLeft <= 0) {
              // BOARD SHATTERS IN PIECES!
              state.isStageTransitioning = true;
              sounds.playShatter();
              triggerScreenShake(1.6);

              // Confetti celebration
              try {
                confetti({
                  particleCount: 50,
                  spread: 70,
                  origin: { y: 0.28 }
                });
              } catch {
                // fallback
              }

              // Create breaking fragments of the rotating board
              const sliceCount = 8;
              for (let s = 0; s < sliceCount; s++) {
                const sAngle = (s * Math.PI * 2) / sliceCount;
                const eAngle = ((s + 1) * Math.PI * 2) / sliceCount;
                const midAngle = (sAngle + eAngle) / 2 + board.rotation;
                const spd = 5 + Math.random() * 8;
                state.boardFragments.push({
                  x: boardCenterX,
                  y: boardCenterY,
                  vx: Math.cos(midAngle) * spd,
                  vy: Math.sin(midAngle) * spd - 3,
                  rotation: board.rotation,
                  vRot: (Math.random() - 0.5) * 0.3,
                  radius: board.radius,
                  startAngle: sAngle,
                  endAngle: eAngle,
                  color: board.isBoss ? '#991b1b' : '#78350f',
                  alpha: 1
                });
              }

              state.floatingTexts.push({
                id: Date.now(),
                x: boardCenterX,
                y: boardCenterY - 40,
                text: props.lang === 'id' ? 'PAPAN HANCUR LEBUR!' : 'TARGET DESTROYED!',
                color: '#22c55e',
                size: 28,
                alpha: 1.4,
                vy: -0.6
              });

              // Advance to next stage after animation
              setTimeout(() => {
                props.onStageClear(props.stage + 1);
              }, 1100);
            }
          }
        }
      }

      // 5. Draw Bouncing Shark on Clash
      if (state.bouncingShark) {
        const b = state.bouncingShark;
        b.x += b.vx;
        b.y += b.vy;
        b.vy += 0.9; // heavy fall
        b.rot += b.vRot;

        ctx.save();
        ctx.translate(b.x, b.y);
        ctx.rotate(b.rot);
        drawFlyingShark(ctx, {
          x: 0,
          y: 0,
          width: 44,
          height: 100,
          mouthOpenProgress: 0.3,
          gunTheme: props.currentGun,
          tailWag: 0
        });
        ctx.restore();
      }

      // 6. Draw The Gorgeous Shark Gun at bottom center
      // Handle recoil recovery spring
      if (state.recoil > 0) {
        state.recoil = Math.max(0, state.recoil - 0.08);
      }
      drawSharkGun(ctx, gunX, gunY, props.currentGun, state.recoil, state.animTime);

      // 7. Update and Draw Particles
      state.particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;
        // Gravity: water droplets and wood chips fall naturally in an arc
        if (p.type === 'water_splash') {
          p.vy += 0.38;
          p.vx *= 0.985;
        } else if (p.type === 'wood_chip') {
          p.vy += 0.3;
        }
        p.life += 1;
        p.alpha = Math.max(0, 1 - p.life / p.maxLife);
        if (p.vRot && p.rotation !== undefined) {
          p.rotation += p.vRot;
        }
        drawParticle(ctx, p);
      });
      state.particles = state.particles.filter(p => p.life < p.maxLife && p.alpha > 0.01);

      // 8. Update and Draw Floating Texts
      state.floatingTexts.forEach(ft => {
        ft.y += ft.vy;
        ft.alpha -= 0.02;
        drawFloatingText(ctx, ft);
      });
      state.floatingTexts = state.floatingTexts.filter(ft => ft.alpha > 0.05);

      animFrameId = requestAnimationFrame(render);
    };

    animFrameId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animFrameId);
  }, [triggerScreenShake]);

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center select-none overflow-hidden touch-none">
      <canvas
        ref={canvasRef}
        width={420}
        height={680}
        onClick={fireShark}
        className="w-full max-w-[420px] h-full max-h-[680px] bg-slate-950 rounded-2xl shadow-2xl border border-sky-500/30 cursor-crosshair active:scale-[0.99] transition-transform duration-75"
        style={{ touchAction: 'none' }}
      />
    </div>
  );
};
