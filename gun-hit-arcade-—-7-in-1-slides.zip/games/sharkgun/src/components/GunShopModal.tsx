import React from 'react';
import { SharkGunConfig } from '../types/game';
import { X, Lock, Check, Sparkles } from 'lucide-react';
import { sounds } from '../audio/soundManager';

interface GunShopModalProps {
  isOpen: boolean;
  onClose: () => void;
  guns: SharkGunConfig[];
  selectedGun: SharkGunConfig;
  onSelectGun: (gun: SharkGunConfig) => void;
  onUnlockGun: (gun: SharkGunConfig) => void;
  pearls: number;
  lang: 'id' | 'en';
}

export const GunShopModal: React.FC<GunShopModalProps> = ({
  isOpen,
  onClose,
  guns,
  selectedGun,
  onSelectGun,
  onUnlockGun,
  pearls,
  lang
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-slate-900/95 border border-cyan-500/40 rounded-3xl p-6 shadow-2xl flex flex-col max-h-[85vh] text-white">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-cyan-500/20 pb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-cyan-400 animate-pulse" />
            <h2 className="text-xl font-black tracking-wider text-cyan-300 font-['Orbitron']">
              {lang === 'id' ? 'ARSENAL SENJATA HIU' : 'SHARK GUN ARMORY'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Currency display */}
        <div className="flex items-center justify-between bg-slate-950/80 px-4 py-2.5 rounded-xl border border-amber-500/30 my-4">
          <span className="text-xs uppercase tracking-wider text-amber-200/80 font-bold">
            {lang === 'id' ? 'Mutiara Emas Kamu:' : 'Your Golden Pearls:'}
          </span>
          <div className="flex items-center gap-1.5 text-amber-400 font-black text-lg">
            <span>{pearls}</span>
            <span>🦪</span>
          </div>
        </div>

        {/* Guns Grid */}
        <div className="flex-1 overflow-y-auto space-y-3.5 pr-1 custom-scrollbar">
          {guns.map(gun => {
            const isEquipped = selectedGun.id === gun.id;
            const canAfford = pearls >= gun.price;

            return (
              <div
                key={gun.id}
                className={`p-4 rounded-2xl border transition-all duration-200 flex flex-col gap-3 ${
                  isEquipped
                    ? 'bg-cyan-950/40 border-cyan-400 shadow-lg shadow-cyan-500/10'
                    : gun.unlocked
                    ? 'bg-slate-800/60 border-slate-700 hover:border-cyan-500/40'
                    : 'bg-slate-950/50 border-slate-800/80 opacity-90'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-base text-white">
                        {lang === 'id' ? gun.nameId : gun.name}
                      </h3>
                      <span
                        className="text-[10px] px-2 py-0.5 rounded-full font-black uppercase tracking-wider"
                        style={{
                          backgroundColor: `${gun.colors.accent}20`,
                          color: gun.colors.accent,
                          borderColor: `${gun.colors.accent}50`,
                          borderWidth: '1px'
                        }}
                      >
                        {gun.rarity}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5 line-clamp-2">
                      {lang === 'id' ? gun.descriptionId : gun.description}
                    </p>
                  </div>

                  {/* Gun Theme Color Dots */}
                  <div className="flex gap-1 shrink-0 mt-1">
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-white/20 shadow-sm"
                      style={{ backgroundColor: gun.colors.accent }}
                    />
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-white/20 shadow-sm"
                      style={{ backgroundColor: gun.colors.glow }}
                    />
                  </div>
                </div>

                {/* Visual Preview Bar */}
                <div
                  className="h-9 rounded-xl flex items-center justify-center px-4 relative overflow-hidden"
                  style={{
                    background: `linear-gradient(90deg, ${gun.colors.primary} 0%, ${gun.colors.secondary} 100%)`,
                    borderColor: gun.colors.accent,
                    borderWidth: '1px'
                  }}
                >
                  <span className="text-xs font-black tracking-widest text-white drop-shadow">
                    🦈 {lang === 'id' ? 'PROYEKTIL HIU GIGIT' : 'CHOMP SHARK PROD'} 🦈
                  </span>
                  <div
                    className="absolute inset-0 opacity-20 pointer-events-none"
                    style={{
                      backgroundImage: `radial-gradient(circle, ${gun.colors.glow} 1px, transparent 1px)`,
                      backgroundSize: '12px 12px'
                    }}
                  />
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between pt-1">
                  <div>
                    {!gun.unlocked && (
                      <div className="flex items-center gap-1 text-sm font-bold text-amber-300">
                        <span>{gun.price}</span>
                        <span>🦪</span>
                      </div>
                    )}
                  </div>

                  {gun.unlocked ? (
                    isEquipped ? (
                      <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/20 text-cyan-300 text-xs font-bold border border-cyan-500/40">
                        <Check className="w-4 h-4" />
                        <span>{lang === 'id' ? 'DIPAKAI' : 'EQUIPPED'}</span>
                      </div>
                    ) : (
                      <button
                        onClick={() => {
                          sounds.playCollect();
                          onSelectGun(gun);
                        }}
                        className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-colors cursor-pointer shadow-md"
                      >
                        {lang === 'id' ? 'PAKAI' : 'EQUIP'}
                      </button>
                    )
                  ) : (
                    <button
                      disabled={!canAfford}
                      onClick={() => {
                        if (canAfford) {
                          onUnlockGun(gun);
                        }
                      }}
                      className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        canAfford
                          ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-black shadow-lg shadow-amber-500/20'
                          : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                      }`}
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>{lang === 'id' ? 'BUKA KUNCI' : 'UNLOCK'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
