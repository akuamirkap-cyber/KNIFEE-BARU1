import React from 'react';
import { RotateCcw, Trophy, ShoppingBag, ShieldAlert } from 'lucide-react';

interface GameOverModalProps {
  isOpen: boolean;
  score: number;
  highScore: number;
  stage: number;
  pearlsGained: number;
  onRestart: () => void;
  onOpenShop: () => void;
  lang: 'id' | 'en';
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  isOpen,
  score,
  highScore,
  stage,
  pearlsGained,
  onRestart,
  onOpenShop,
  lang
}) => {
  if (!isOpen) return null;

  const isNewHighScore = score > highScore;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm bg-gradient-to-b from-slate-900 to-slate-950 border border-rose-500/40 rounded-3xl p-6 shadow-2xl flex flex-col items-center text-center text-white">
        {/* Warning Icon */}
        <div className="w-16 h-16 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 mb-3 animate-bounce">
          <ShieldAlert className="w-8 h-8" />
        </div>

        <h2 className="text-2xl font-black text-rose-400 tracking-wider font-['Orbitron']">
          {lang === 'id' ? 'HIU BERTABRAKAN!' : 'SHARKS CLASHED!'}
        </h2>
        <p className="text-xs text-slate-400 mt-1 mb-4">
          {lang === 'id'
            ? 'Moncong hiu menabrak hiu lain yang sudah menempel di papan!'
            : 'Your flying shark collided into an attached shark on the spinning target!'}
        </p>

        {/* Stats card */}
        <div className="w-full bg-slate-950/80 rounded-2xl p-4 border border-slate-800 space-y-3 mb-5">
          <div className="flex justify-between items-center text-sm">
            <span className="text-slate-400">{lang === 'id' ? 'Skor Akhir' : 'Final Score'}</span>
            <span className="text-2xl font-black text-cyan-400 font-['Orbitron']">{score}</span>
          </div>

          <div className="flex justify-between items-center text-sm border-t border-slate-800/80 pt-2">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Trophy className="w-4 h-4 text-amber-400" />
              {lang === 'id' ? 'Skor Tertinggi' : 'High Score'}
            </span>
            <span className="font-bold text-amber-300">
              {Math.max(score, highScore)} {isNewHighScore && '🔥 REKOR!'}
            </span>
          </div>

          <div className="flex justify-between items-center text-sm border-t border-slate-800/80 pt-2">
            <span className="text-slate-400">{lang === 'id' ? 'Tahap Dicapai' : 'Stage Reached'}</span>
            <span className="font-bold text-white">Stage {stage}</span>
          </div>

          <div className="flex justify-between items-center text-sm border-t border-slate-800/80 pt-2">
            <span className="text-slate-400">{lang === 'id' ? 'Mutiara Didapat' : 'Pearls Looted'}</span>
            <span className="font-bold text-amber-400">+{pearlsGained} 🦪</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2.5">
          <button
            onClick={onRestart}
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-base flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer font-['Orbitron'] active:scale-95"
          >
            <RotateCcw className="w-5 h-5 text-slate-950" />
            <span>{lang === 'id' ? 'TEMBAK LAGI' : 'RETRY SHOOTING'}</span>
          </button>

          <button
            onClick={onOpenShop}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer border border-slate-700"
          >
            <ShoppingBag className="w-4 h-4 text-cyan-400" />
            <span>{lang === 'id' ? 'GANTI SENJATA HIU' : 'CHANGE SHARK GUN'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
