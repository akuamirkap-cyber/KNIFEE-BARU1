import React from 'react';
import { X, Volume2, VolumeX, Music, Compass, Eye, Globe } from 'lucide-react';
import { sounds } from '../audio/soundManager';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  soundEnabled: boolean;
  setSoundEnabled: (v: boolean) => void;
  musicEnabled: boolean;
  setMusicEnabled: (v: boolean) => void;
  screenShake: boolean;
  setScreenShake: (v: boolean) => void;
  laserSight: boolean;
  setLaserSight: (v: boolean) => void;
  lang: 'id' | 'en';
  setLang: (lang: 'id' | 'en') => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  soundEnabled,
  setSoundEnabled,
  musicEnabled,
  setMusicEnabled,
  screenShake,
  setScreenShake,
  laserSight,
  setLaserSight,
  lang,
  setLang
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl p-6 shadow-2xl flex flex-col text-white">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <h2 className="text-lg font-black text-cyan-400 font-['Orbitron']">
            {lang === 'id' ? 'PENGATURAN' : 'SETTINGS'}
          </h2>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          {/* Sound FX Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-slate-800">
            <div className="flex items-center gap-2.5">
              {soundEnabled ? (
                <Volume2 className="w-5 h-5 text-cyan-400" />
              ) : (
                <VolumeX className="w-5 h-5 text-slate-500" />
              )}
              <span className="text-sm font-bold">
                {lang === 'id' ? 'Efek Suara (SFX)' : 'Sound Effects'}
              </span>
            </div>
            <button
              onClick={() => {
                const next = sounds.toggleSound();
                setSoundEnabled(next);
              }}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                soundEnabled ? 'bg-cyan-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  soundEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Music Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-slate-800">
            <div className="flex items-center gap-2.5">
              <Music className={`w-5 h-5 ${musicEnabled ? 'text-cyan-400' : 'text-slate-500'}`} />
              <span className="text-sm font-bold">
                {lang === 'id' ? 'Musik Laut Synth' : 'Ocean Synth Music'}
              </span>
            </div>
            <button
              onClick={() => {
                const next = sounds.toggleMusic();
                setMusicEnabled(next);
              }}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                musicEnabled ? 'bg-cyan-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  musicEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Laser Sight */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-slate-800">
            <div className="flex items-center gap-2.5">
              <Eye className={`w-5 h-5 ${laserSight ? 'text-cyan-400' : 'text-slate-500'}`} />
              <span className="text-sm font-bold">
                {lang === 'id' ? 'Garis Laser Bidik' : 'Laser Aiming Sight'}
              </span>
            </div>
            <button
              onClick={() => setLaserSight(!laserSight)}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                laserSight ? 'bg-cyan-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  laserSight ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Screen Shake */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-slate-800">
            <div className="flex items-center gap-2.5">
              <Compass className={`w-5 h-5 ${screenShake ? 'text-cyan-400' : 'text-slate-500'}`} />
              <span className="text-sm font-bold">
                {lang === 'id' ? 'Getaran Layar (Shake)' : 'Screen Shake FX'}
              </span>
            </div>
            <button
              onClick={() => setScreenShake(!screenShake)}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                screenShake ? 'bg-cyan-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  screenShake ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Language Switch */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-slate-800">
            <div className="flex items-center gap-2.5">
              <Globe className="w-5 h-5 text-cyan-400" />
              <span className="text-sm font-bold">
                {lang === 'id' ? 'Bahasa / Language' : 'Language'}
              </span>
            </div>
            <div className="flex gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
              <button
                onClick={() => setLang('id')}
                className={`px-2.5 py-1 text-xs font-bold rounded-lg cursor-pointer transition-colors ${
                  lang === 'id' ? 'bg-cyan-500 text-slate-950 font-black' : 'text-slate-400 hover:text-white'
                }`}
              >
                ID
              </button>
              <button
                onClick={() => setLang('en')}
                className={`px-2.5 py-1 text-xs font-bold rounded-lg cursor-pointer transition-colors ${
                  lang === 'en' ? 'bg-cyan-500 text-slate-950 font-black' : 'text-slate-400 hover:text-white'
                }`}
              >
                EN
              </button>
            </div>
          </div>
        </div>

        {/* Tutorial summary */}
        <div className="mt-5 p-3 rounded-xl bg-cyan-950/30 border border-cyan-800/40 text-[11px] text-cyan-200/80 leading-relaxed">
          <p className="font-bold text-cyan-300 mb-1">
            {lang === 'id' ? '💡 CARA MAIN:' : '💡 HOW TO PLAY:'}
          </p>
          {lang === 'id'
            ? 'Ketuk layar atau tekan Spacebar untuk melontarkan hiu berukuran 2x dari senjata. Hiu akan membuka rahangnya dan menggigit papan target. Hindari mengenai hiu lain yang sudah menancap!'
            : 'Tap screen or press Spacebar to fire a giant 2x shark from your gun. The shark expands its jaws and clamps tightly into the board. Avoid hitting already attached sharks!'}
        </div>
      </div>
    </div>
  );
};
