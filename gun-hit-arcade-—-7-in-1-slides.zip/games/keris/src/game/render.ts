import type { TargetKind } from './types';
import { TAU } from './types';

/* ================= palette — dawn of the kraton ================= */

const GOLD = { bright: '#fff6cf', hi: '#ffe08a', mid: '#e8b64c', deep: '#b57d16', dark: '#8a5a10', ink: '#4a2c15' };

function lg(ctx: CanvasRenderingContext2D, x0: number, y0: number, x1: number, y1: number, stops: [number, string][]) {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  for (const [o, c] of stops) g.addColorStop(o, c);
  return g;
}

function rg(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, stops: [number, string][]) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  for (const [o, c] of stops) g.addColorStop(o, c);
  return g;
}

/* soft glow = halo + core, readable on bright skies */
function glowDot(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, color: string, core: string, a: number) {
  ctx.globalAlpha = a * 0.3;
  ctx.beginPath();
  ctx.arc(x, y, r * 2.6, 0, TAU);
  ctx.fillStyle = color;
  ctx.fill();
  ctx.globalAlpha = a;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, TAU);
  ctx.fillStyle = core;
  ctx.fill();
  ctx.globalAlpha = 1;
}

/* ================= GOLDEN LIGHTNING ================= */

type Pt = { x: number; y: number };

/** jagged polyline between two points via midpoint displacement */
export function boltPts(x0: number, y0: number, x1: number, y1: number, rough: number): Pt[] {
  let pts: Pt[] = [
    { x: x0, y: y0 },
    { x: x1, y: y1 },
  ];
  let off = rough;
  for (let pass = 0; pass < 5; pass++) {
    const next: Pt[] = [pts[0]];
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i];
      const b = pts[i + 1];
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const len = Math.hypot(dx, dy) || 1;
      const nx = -dy / len;
      const ny = dx / len;
      const d = (Math.random() * 2 - 1) * off;
      next.push({ x: (a.x + b.x) / 2 + nx * d, y: (a.y + b.y) / 2 + ny * d });
      next.push(b);
    }
    pts = next;
    off *= 0.5;
  }
  return pts;
}

/** multi-pass golden strike: amber corona → gold body → white-hot core */
export function strokeJolt(ctx: CanvasRenderingContext2D, pts: Pt[], w: number, alpha: number) {
  if (alpha <= 0.01 || pts.length < 2) return;
  ctx.save();
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  const passes: [number, string][] = [
    [w * 4.6, `rgba(255,170,40,${0.13 * alpha})`],
    [w * 2.3, `rgba(255,205,80,${0.45 * alpha})`],
    [w, `rgba(255,244,200,${0.9 * alpha})`],
    [w * 0.42, `rgba(255,255,252,${0.95 * alpha})`],
  ];
  ctx.beginPath();
  pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
  for (const [width, color] of passes) {
    ctx.lineWidth = width;
    ctx.strokeStyle = color;
    ctx.stroke();
  }
  ctx.restore();
}

/** convenience: strike from A to B */
export function drawJolt(ctx: CanvasRenderingContext2D, x0: number, y0: number, x1: number, y1: number, rough: number, w: number, alpha: number) {
  strokeJolt(ctx, boltPts(x0, y0, x1, y1, rough), w, alpha);
}

/* ================= RADIANT KERIS BULLET ================= */
/**
 * The projectile: a miniature keris of solid holy light.
 * Local space: pointing UP, tip at (0,-23), hilt ends ~ (0,22).
 */
export function drawKerisBullet(ctx: CanvasRenderingContext2D, variant: 'hero' | 'enemy') {
  const LUK = 3;
  const top = -21;
  const bot = 3;
  const amp = 1.9;
  const cx = (t: number) => amp * Math.sin(t * LUK * Math.PI);
  const hw = (t: number) => 3.6 * Math.pow(1 - t, 0.8) + 0.4;

  // wavy blade silhouette
  ctx.beginPath();
  const N = 22;
  for (let i = 0; i <= N; i++) {
    const t = i / N;
    const y = bot - t * (bot - top);
    const x = cx(t) - hw(t);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  for (let i = N; i >= 0; i--) {
    const t = i / N;
    ctx.lineTo(cx(t) + hw(t), bot - t * (bot - top));
  }
  ctx.closePath();

  const blade = ctx.createLinearGradient(0, bot, 0, top);
  if (variant === 'hero') {
    blade.addColorStop(0, '#f2d98c');
    blade.addColorStop(0.4, '#fffdf6');
    blade.addColorStop(0.75, '#fff6cf');
    blade.addColorStop(1, '#ffedb0');
  } else {
    blade.addColorStop(0, '#5e2126');
    blade.addColorStop(0.45, '#8c3a40');
    blade.addColorStop(0.85, '#421519');
    blade.addColorStop(1, '#2c0e12');
  }
  ctx.fillStyle = blade;
  ctx.fill();
  ctx.lineWidth = 1;
  ctx.strokeStyle = variant === 'hero' ? GOLD.deep : 'rgba(20,5,8,0.9)';
  ctx.stroke();

  // centre ridge
  ctx.beginPath();
  for (let i = 0; i <= N; i++) {
    const t = i / N;
    const y = bot - 1 - t * (bot - top - 1.5);
    if (i === 0) ctx.moveTo(cx(t), y);
    else ctx.lineTo(cx(t), y);
  }
  ctx.lineWidth = 0.7;
  ctx.strokeStyle = variant === 'hero' ? 'rgba(181,125,22,0.55)' : 'rgba(0,0,0,0.55)';
  ctx.stroke();

  // pamor shimmer
  if (variant === 'hero') {
    ctx.lineWidth = 0.5;
    ctx.strokeStyle = 'rgba(181,125,22,0.5)';
    for (const s of [-0.45, 0.45]) {
      ctx.beginPath();
      for (let i = 0; i <= N; i++) {
        const t = i / N;
        const y = bot - t * (bot - top);
        const x = cx(t) + s * hw(t);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    // glowing thunder runes along the spine
    for (let i = 0; i < 3; i++) {
      const tt = 0.24 + i * 0.26;
      const y = bot - tt * (bot - top);
      const x = cx(tt);
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(Math.PI / 4);
      ctx.fillStyle = 'rgba(255,190,60,0.95)';
      const s = 1.05 + i * 0.12;
      ctx.fillRect(-s, -s, s * 2, s * 2);
      ctx.restore();
    }
    // edge glint
    ctx.beginPath();
    for (let i = 0; i <= N; i++) {
      const t = i / N;
      const y = bot - t * (bot - top);
      const x = cx(t) - hw(t) + 0.7;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.lineWidth = 0.6;
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.stroke();
  }

  // holy halo at the ganja
  if (variant === 'hero') glowDot(ctx, 0, 6.5, 3.4, '#ffd98a', '#fffdf6', 0.8);

  // ganja — gold baseplate
  ctx.beginPath();
  ctx.moveTo(-4.5, 5);
  ctx.quadraticCurveTo(0, 2.6, 4.5, 5);
  ctx.lineTo(1.6, 9.5);
  ctx.lineTo(0, 11.2);
  ctx.lineTo(-1.6, 9.5);
  ctx.closePath();
  ctx.fillStyle = lg(ctx, -4, 3, 4, 11, [
    [0, GOLD.bright],
    [0.5, GOLD.mid],
    [1, GOLD.deep],
  ]);
  ctx.fill();
  ctx.strokeStyle = GOLD.dark;
  ctx.lineWidth = 0.8;

  // hulu
  if (variant === 'hero') {
    ctx.beginPath();
    ctx.moveTo(-3, 10.5);
    ctx.bezierCurveTo(3.5, 10, 6.6, 14.5, 5.6, 19);
    ctx.bezierCurveTo(5.2, 21.2, 2.9, 22, 2.2, 19.8);
    ctx.bezierCurveTo(3.4, 16.6, 1.4, 13, -2, 12.4);
    ctx.closePath();
    ctx.fillStyle = lg(ctx, -2, 9, 5, 22, [
      [0, GOLD.hi],
      [0.6, GOLD.deep],
      [1, GOLD.ink],
    ]);
    ctx.fill();
    ctx.strokeStyle = GOLD.ink;
    ctx.lineWidth = 0.8;
    ctx.stroke();
  } else {
    ctx.beginPath();
    ctx.moveTo(-2.6, 10.5);
    ctx.bezierCurveTo(2.4, 10.4, 4.4, 14.5, 3.8, 20);
    ctx.lineTo(1.6, 20.5);
    ctx.bezierCurveTo(1.8, 15.5, 0.2, 13, -2.2, 12.6);
    ctx.closePath();
    ctx.fillStyle = '#2a1d16';
    ctx.fill();
  }
}

/* ================= THE KERIS GUN — a walking pusaka ================= */
/**
 * The weapon IS the keris: ornate golden hulu + a great holy luk blade.
 * Local space: pointing UP, blade tip at (0,-150), hulu heel at y≈+102.
 */
export function drawKerisGun(ctx: CanvasRenderingContext2D, t: number, glow: number) {
  const pulse = 0.6 + 0.4 * Math.sin(t * 2.2);

  /* ambient holy aura */
  ctx.fillStyle = rg(ctx, 0, -45, 150, [
    [0, `rgba(240,190,90,${0.16 + glow * 0.12})`],
    [0.6, `rgba(240,190,90,${0.06 + glow * 0.05})`],
    [1, 'rgba(240,190,90,0)'],
  ]);
  ctx.fillRect(-150, -200, 300, 320);

  /* halo rings embracing the blade */
  const rings: [number, number, number, number][] = [
    [-118, 26, 7, 1.7],
    [-78, 32, 8.4, -1.2],
    [-38, 38, 9.6, 0.9],
  ];
  rings.forEach(([ry, rx, ey, sp], idx) => {
    ctx.strokeStyle = `rgba(181,125,22,${0.42 + glow * 0.3})`;
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.ellipse(0, ry, rx, ey, 0, 0, TAU);
    ctx.stroke();
    ctx.strokeStyle = `rgba(255,236,170,${0.3 + glow * 0.3})`;
    ctx.lineWidth = 0.6;
    ctx.beginPath();
    ctx.ellipse(0, ry, rx + 2.6, ey + 1.2, 0, 0, TAU);
    ctx.stroke();
    // orbiting rune
    const a = t * sp + idx * 2.1;
    glowDot(ctx, Math.cos(a) * rx, ry + Math.sin(a) * ey, 1.6, '#e8b64c', '#fffdf6', 0.9);
  });

  /* ---------------- WILAH — the great luk blade ---------------- */
  const TOP = -146;
  const BASE = 36;
  const LUK = 5;
  const amp = (tt: number) => 5 * (1 - tt * 0.5);
  const halfw = (tt: number) => 14 * Math.pow(1 - tt, 0.82) + 1.4;
  const bx = (tt: number) => amp(tt) * Math.sin(tt * LUK * Math.PI);
  const by = (tt: number) => BASE - tt * (BASE - TOP);

  // silhouette
  ctx.beginPath();
  const NB = 42;
  for (let i = 0; i <= NB; i++) {
    const tt = i / NB;
    const x = bx(tt) - halfw(tt);
    if (i === 0) ctx.moveTo(x, by(tt));
    else ctx.lineTo(x, by(tt));
  }
  for (let i = NB; i >= 0; i--) {
    const tt = i / NB;
    ctx.lineTo(bx(tt) + halfw(tt), by(tt));
  }
  ctx.closePath();
  ctx.fillStyle = lg(ctx, -16, 0, 16, 0, [
    [0, '#c98a1e'],
    [0.16, '#f0cf7d'],
    [0.38, '#fffdf4'],
    [0.5, '#ffffff'],
    [0.62, '#fffdf4'],
    [0.84, '#f0cf7d'],
    [1, '#c98a1e'],
  ]);
  ctx.fill();
  ctx.lineWidth = 1.1;
  ctx.strokeStyle = GOLD.dark;
  ctx.stroke();

  // pamor echo lines
  ctx.lineWidth = 1.1;
  ctx.strokeStyle = 'rgba(176,120,40,0.55)';
  for (const s of [-0.5, 0.5]) {
    ctx.beginPath();
    for (let i = 0; i <= NB; i++) {
      const tt = i / NB;
      const x = bx(tt) + s * halfw(tt);
      if (i === 0) ctx.moveTo(x, by(tt));
      else ctx.lineTo(x, by(tt));
    }
    ctx.stroke();
  }

  // channel of holy light along the spine
  ctx.lineWidth = 6;
  ctx.strokeStyle = `rgba(255,226,150,${0.3 + glow * 0.4})`;
  ctx.beginPath();
  for (let i = 0; i <= NB; i++) {
    const tt = i / NB;
    const x = bx(tt);
    if (i === 0) ctx.moveTo(x, by(tt));
    else ctx.lineTo(x, by(tt));
  }
  ctx.stroke();
  ctx.lineWidth = 2.2;
  ctx.strokeStyle = `rgba(255,255,255,${0.8 + glow * 0.2})`;
  ctx.stroke();

  // golden lightning living inside the blade
  if (glow > 0.1) {
    strokeJolt(ctx, boltPts(0, BASE - 6, 0, TOP + 12, 7), 1.3, Math.min(1, glow + 0.15));
    drawJolt(ctx, bx(0.5), by(0.5), bx(0.5) - 11, by(0.5) - 14, 3, 0.9, glow * 0.8);
    drawJolt(ctx, bx(0.72), by(0.72), bx(0.72) + 10, by(0.72) - 11, 3, 0.9, glow * 0.8);
  }

  // floating rune diamonds beside the edges
  for (let i = 0; i < 5; i++) {
    const y = -22 - i * 26;
    const tt = (BASE - y) / (BASE - TOP);
    if (tt > 0.97) continue;
    const side = i % 2 === 0 ? 1 : -1;
    const x = side * (bx(tt) + halfw(tt) + 7.5);
    const sa = 0.45 + 0.3 * Math.sin(t * 3 + i * 1.4);
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(Math.PI / 4);
    ctx.globalAlpha = sa;
    ctx.fillStyle = '#e8b64c';
    ctx.fillRect(-1.7, -1.7, 3.4, 3.4);
    ctx.strokeStyle = '#8a5a10';
    ctx.lineWidth = 0.5;
    ctx.strokeRect(-1.7, -1.7, 3.4, 3.4);
    ctx.restore();
  }

  // naga crests — flame-dragons with ruby eyes at the blade base
  for (const m of [-1, 1]) {
    ctx.beginPath();
    ctx.moveTo(m * 4, 37);
    ctx.bezierCurveTo(m * 16, 34, m * 20, 22, m * 12, 14);
    ctx.bezierCurveTo(m * 16, 21, m * 12, 27, m * 4.5, 29);
    ctx.closePath();
    ctx.fillStyle = lg(ctx, m * 20, 14, m * 4, 37, [
      [0, GOLD.bright],
      [0.55, GOLD.mid],
      [1, GOLD.dark],
    ]);
    ctx.fill();
    ctx.strokeStyle = GOLD.ink;
    ctx.lineWidth = 0.9;
    ctx.stroke();
    ctx.strokeStyle = 'rgba(110,66,10,0.8)';
    ctx.lineWidth = 0.7;
    ctx.beginPath();
    ctx.moveTo(m * 6.5, 33);
    ctx.bezierCurveTo(m * 12, 30, m * 14.5, 24, m * 12.5, 18.5);
    ctx.stroke();
    glowDot(ctx, m * 11.5, 18.5, 1.15, '#ff8aa0', '#e02547', 0.9);
  }

  // tip star — the muzzle of heaven
  ctx.save();
  ctx.translate(0, TOP - 2);
  const st = 0.7 + pulse * 0.5;
  ctx.rotate(t * 0.8);
  for (let i = 0; i < 4; i++) {
    ctx.rotate(Math.PI / 2);
    ctx.beginPath();
    ctx.moveTo(0, -2);
    ctx.lineTo(1.6, -2);
    ctx.lineTo(0, -9 * st - 3);
    ctx.lineTo(-1.6, -2);
    ctx.closePath();
    ctx.fillStyle = `rgba(255,253,246,${0.75 * pulse + glow * 0.25})`;
    ctx.fill();
    ctx.strokeStyle = `rgba(217,154,38,${0.7})`;
    ctx.lineWidth = 0.5;
    ctx.stroke();
  }
  glowDot(ctx, 0, 0, 3 * st, '#ffd98a', '#ffffff', 0.85);
  ctx.restore();

  // orbiting sparks at the tip
  for (let i = 0; i < 3; i++) {
    const a = t * 1.6 + (i * TAU) / 3;
    glowDot(ctx, Math.cos(a) * 10, TOP - 2 + Math.sin(a) * 4, 1.1, '#e8b64c', '#fffdf6', 0.8);
  }

  /* ---------------- GANJA WULUNG ---------------- */
  ctx.beginPath();
  ctx.moveTo(-16, 38);
  ctx.quadraticCurveTo(0, 31, 16, 38);
  ctx.lineTo(7, 51);
  ctx.quadraticCurveTo(0, 56, -7, 51);
  ctx.closePath();
  ctx.fillStyle = lg(ctx, 0, 31, 0, 56, [
    [0, GOLD.bright],
    [0.5, GOLD.mid],
    [1, GOLD.dark],
  ]);
  ctx.fill();
  ctx.strokeStyle = GOLD.ink;
  ctx.lineWidth = 1;
  ctx.stroke();
  // lotus engraving on ganja
  ctx.strokeStyle = 'rgba(110,66,10,0.7)';
  ctx.lineWidth = 0.8;
  for (const m of [-1, 0, 1]) {
    ctx.beginPath();
    ctx.moveTo(m * 9, 40);
    ctx.quadraticCurveTo(m * 4.5, 46, m * 2.5, 50);
    ctx.stroke();
  }
  glowDot(ctx, 0, 43.5, 2.4, '#ff8aa0', '#e02547', 0.85 + pulse * 0.15);

  /* ---------------- MENDAK — jewelled cup ---------------- */
  ctx.beginPath();
  ctx.moveTo(-18, 52);
  ctx.lineTo(18, 52);
  ctx.lineTo(13.5, 63);
  ctx.quadraticCurveTo(0, 67, -13.5, 63);
  ctx.closePath();
  ctx.fillStyle = lg(ctx, 0, 52, 0, 67, [
    [0, GOLD.hi],
    [0.5, GOLD.deep],
    [1, '#6e4710'],
  ]);
  ctx.fill();
  ctx.strokeStyle = GOLD.ink;
  ctx.lineWidth = 1;
  ctx.stroke();
  const gemsCols = ['#2fbfae', '#e02547', '#f0b43c', '#2fbfae'];
  gemsCols.forEach((c, i) => {
    glowDot(ctx, -9 + i * 6, 57.5, 2, c, c === '#f0b43c' ? '#fff6cf' : c, 0.95);
  });

  /* ---------------- crescent guard (warangka bow) ---------------- */
  ctx.beginPath();
  ctx.moveTo(-24, 63);
  ctx.quadraticCurveTo(0, 79, 24, 63);
  ctx.quadraticCurveTo(0, 71, -24, 63);
  ctx.closePath();
  ctx.fillStyle = lg(ctx, 0, 63, 0, 79, [
    [0, GOLD.hi],
    [1, GOLD.dark],
  ]);
  ctx.fill();
  ctx.strokeStyle = GOLD.ink;
  ctx.lineWidth = 0.9;
  ctx.stroke();
  // curled tips
  for (const m of [-1, 1]) {
    ctx.beginPath();
    ctx.arc(m * 24, 61.5, 3.2, 0, TAU);
    ctx.fillStyle = GOLD.mid;
    ctx.fill();
    ctx.strokeStyle = GOLD.ink;
    ctx.lineWidth = 0.7;
    ctx.stroke();
  }

  /* ---------------- HULU — the sacred grip ---------------- */
  ctx.beginPath();
  ctx.moveTo(-13, 101);
  ctx.bezierCurveTo(-18, 93, -16, 83, -9, 75);
  ctx.bezierCurveTo(-4.5, 70, -4, 66, -6, 62);
  ctx.lineTo(6, 62);
  ctx.bezierCurveTo(4, 66, 4.5, 70, 9, 75);
  ctx.bezierCurveTo(16, 83, 18, 93, 13, 101);
  ctx.bezierCurveTo(6, 106, -6, 106, -13, 101);
  ctx.closePath();
  ctx.fillStyle = lg(ctx, -18, 60, 18, 106, [
    [0, '#d9a431'],
    [0.4, '#a8721c'],
    [0.8, '#5c3a0a'],
    [1, '#3f2a08'],
  ]);
  ctx.fill();
  ctx.strokeStyle = '#2e1c04';
  ctx.lineWidth = 1.2;
  ctx.stroke();

  // hulu carvings — flame filigree
  ctx.strokeStyle = 'rgba(255,224,138,0.55)';
  ctx.lineWidth = 1.1;
  for (const m of [-1, 1]) {
    ctx.beginPath();
    ctx.moveTo(m * 10, 96);
    ctx.bezierCurveTo(m * 3, 92, m * 2, 84, m * 8, 78);
    ctx.bezierCurveTo(m * 4, 83, m * 5, 88, m * 11, 88);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(m * 7, 93.5, 1.3, 0, TAU);
    ctx.fillStyle = 'rgba(255,224,138,0.6)';
    ctx.fill();
  }
  // heart gem on the grip
  glowDot(ctx, 0, 86, 3.2, '#ff8aa0', '#e02547', 0.75 + pulse * 0.25);
  ctx.beginPath();
  ctx.moveTo(0, 79);
  ctx.quadraticCurveTo(3.4, 84, 0, 90);
  ctx.quadraticCurveTo(-3.4, 84, 0, 79);
  ctx.strokeStyle = 'rgba(110,30,40,0.8)';
  ctx.lineWidth = 0.8;
  ctx.stroke();
  // heel rim
  ctx.beginPath();
  ctx.moveTo(-13, 101);
  ctx.bezierCurveTo(-6, 106, 6, 106, 13, 101);
  ctx.strokeStyle = GOLD.hi;
  ctx.lineWidth = 1.6;
  ctx.stroke();

  /* engraved name on the mendak */
  ctx.save();
  ctx.font = '700 5px "Cinzel Decorative", serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = 'rgba(74,44,21,0.85)';
  ctx.fillText('S A K T I', 0, 51.5);
  ctx.restore();
}

/* ================= ARCANE RIG (magic rings behind weapon) ================= */
export function drawArcaneRig(ctx: CanvasRenderingContext2D, r: number, t: number, pulse: number) {
  const a = 0.4 + pulse * 0.35;
  ctx.save();
  ctx.rotate(t * 0.35);
  ctx.strokeStyle = `rgba(178,112,20,${a})`;
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, TAU);
  ctx.stroke();
  ctx.strokeStyle = `rgba(178,112,20,${a * 0.7})`;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.82, 0, TAU);
  ctx.stroke();
  ctx.strokeStyle = `rgba(201,138,30,${a})`;
  ctx.lineWidth = 1.6;
  for (let i = 0; i < 24; i++) {
    const ang = (i / 24) * TAU;
    const long = i % 6 === 0;
    ctx.beginPath();
    ctx.moveTo(Math.cos(ang) * r, Math.sin(ang) * r);
    ctx.lineTo(Math.cos(ang) * (r - (long ? 9 : 4.5)), Math.sin(ang) * (r - (long ? 9 : 4.5)));
    ctx.stroke();
  }
  ctx.rotate(-t * 0.7);
  for (let i = 0; i < 4; i++) {
    const ang = (i / 4) * TAU;
    const x = Math.cos(ang) * r * 0.82;
    const y = Math.sin(ang) * r * 0.82;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(ang + Math.PI / 2);
    ctx.beginPath();
    ctx.moveTo(0, -5 * (1 + pulse * 0.3));
    ctx.lineTo(3.2, 0);
    ctx.lineTo(0, 5 * (1 + pulse * 0.3));
    ctx.lineTo(-3.2, 0);
    ctx.closePath();
    ctx.fillStyle = `rgba(201,138,30,${a})`;
    ctx.fill();
    ctx.strokeStyle = `rgba(255,246,207,${a})`;
    ctx.lineWidth = 0.6;
    ctx.stroke();
    ctx.restore();
  }
  ctx.restore();
}

/* ================= HOLY FRAME around the mandala ================= */
export function drawHolyRing(ctx: CanvasRenderingContext2D, r: number) {
  ctx.save();
  ctx.strokeStyle = 'rgba(181,125,22,0.4)';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, TAU);
  ctx.stroke();
  ctx.lineWidth = 1.3;
  for (let i = 0; i < 36; i++) {
    const a = (i / 36) * TAU;
    const long = i % 9 === 0;
    ctx.beginPath();
    ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
    ctx.lineTo(Math.cos(a) * (r + (long ? 8 : 3.5)), Math.sin(a) * (r + (long ? 8 : 3.5)));
    ctx.stroke();
  }
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * TAU + Math.PI / 8;
    const x = Math.cos(a) * r;
    const y = Math.sin(a) * r;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(a + Math.PI / 2);
    ctx.beginPath();
    ctx.moveTo(0, -4.2);
    ctx.lineTo(2.6, 0);
    ctx.lineTo(0, 4.2);
    ctx.lineTo(-2.6, 0);
    ctx.closePath();
    ctx.fillStyle = 'rgba(232,182,76,0.65)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(138,90,16,0.6)';
    ctx.lineWidth = 0.6;
    ctx.stroke();
    ctx.restore();
  }
  ctx.restore();
}

/* ================= GOLDEN THUNDER FLASH ================= */
export function drawMuzzleFlash(ctx: CanvasRenderingContext2D, tt: number) {
  const k = 1 - tt;
  if (k <= 0) return;
  ctx.save();

  // radial jagged tendrils across the upward sky
  const tendrils = 7;
  for (let i = 0; i < tendrils; i++) {
    const ang = -Math.PI / 2 + (i - (tendrils - 1) / 2) * 0.48 + Math.sin(i * 7.3) * 0.1;
    const len = (15 + ((i * 37) % 13)) * (1 - tt * 0.4);
    const ex = Math.cos(ang) * len;
    const ey = Math.sin(ang) * len * 1.35;
    drawJolt(ctx, 0, 0, ex, ey, 5, (1.3 - tt * 0.8), 0.85 * k);
  }

  // expanding shock ring
  ctx.beginPath();
  ctx.arc(0, 0, 8 + 30 * tt, 0, TAU);
  ctx.strokeStyle = `rgba(255,190,60,${0.7 * k})`;
  ctx.lineWidth = 2.6 * k + 0.5;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(0, 0, 4 + 16 * tt, 0, TAU);
  ctx.strokeStyle = `rgba(255,244,200,${0.5 * k})`;
  ctx.lineWidth = 1.4 * k + 0.3;
  ctx.stroke();

  // plasma core
  glowDot(ctx, 0, 0, 6.5 * k + 2, '#ffc23c', '#ffffff', k);

  // rising pillar of thunder
  const beamLen = 84 * k;
  const g = ctx.createLinearGradient(0, 0, 0, -beamLen);
  g.addColorStop(0, `rgba(255,255,252,${0.95 * k})`);
  g.addColorStop(0.4, `rgba(255,214,106,${0.65 * k})`);
  g.addColorStop(1, 'rgba(255,180,50,0)');
  ctx.fillStyle = g;
  ctx.fillRect(-2.4 * k - 0.6, -beamLen, 4.8 * k + 1.2, beamLen);
  ctx.restore();
}

/* ================= TARGET MANDALA ================= */
export function drawTargetBody(ctx: CanvasRenderingContext2D, R: number, kind: TargetKind, t: number) {
  const skins: Record<TargetKind, { c: [number, string][]; rim: [number, string][]; ring: string; carve: string; petal: [number, string][] }> = {
    wood: {
      c: [[0, '#e2ad54'], [0.55, '#c08a2e'], [0.85, '#96661a'], [1, '#704a12']],
      rim: [[0, '#ffe6a0'], [0.5, '#eab449'], [1, '#9c6a12']],
      ring: 'rgba(70,40,6,0.35)',
      carve: 'rgba(255,246,214,0.4)',
      petal: [[0, '#f6d383'], [1, '#c08a2e']],
    },
    bronze: {
      c: [[0, '#4ba084'], [0.55, '#357a63'], [0.85, '#235646'], [1, '#1a4034']],
      rim: [[0, '#ffe6a0'], [0.5, '#eab449'], [1, '#9c6a12']],
      ring: 'rgba(6,26,20,0.4)',
      carve: 'rgba(214,255,242,0.3)',
      petal: [[0, '#a9e6d2'], [1, '#357a63']],
    },
    obsidian: {
      c: [[0, '#7c5cae'], [0.55, '#5a3f78'], [0.85, '#422c60'], [1, '#322248']],
      rim: [[0, '#e2c6ff'], [0.5, '#a474e8'], [1, '#6a44a8']],
      ring: 'rgba(16,8,32,0.5)',
      carve: 'rgba(226,198,255,0.35)',
      petal: [[0, '#c9a2ff'], [1, '#5a3f78']],
    },
    boss: {
      c: [[0, '#c22c4c'], [0.5, '#96301f'], [0.85, '#8e1f33'], [1, '#5e1220']],
      rim: [[0, '#ffe6a0'], [0.45, '#e8b64c'], [1, '#9c6a12']],
      ring: 'rgba(40,4,10,0.5)',
      carve: 'rgba(255,170,180,0.4)',
      petal: [[0, '#ff9db0'], [1, '#8e1f33']],
    },
  };
  const s = skins[kind];

  /* lotus petal crown behind the disc */
  const petals = 18;
  for (let i = 0; i < petals; i++) {
    const a = (i / petals) * TAU;
    ctx.save();
    ctx.rotate(a);
    ctx.beginPath();
    ctx.moveTo(0, R * 0.92);
    ctx.quadraticCurveTo(-R * 0.09, R * 1.02, 0, R * 1.17);
    ctx.quadraticCurveTo(R * 0.09, R * 1.02, 0, R * 0.92);
    ctx.closePath();
    ctx.fillStyle = lg(ctx, 0, R * 0.9, 0, R * 1.18, s.petal);
    ctx.fill();
    ctx.strokeStyle = 'rgba(74,44,21,0.55)';
    ctx.lineWidth = 0.9;
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, R * 0.96);
    ctx.lineTo(0, R * 1.13);
    ctx.strokeStyle = 'rgba(74,44,21,0.3)';
    ctx.lineWidth = 0.6;
    ctx.stroke();
    ctx.restore();
  }

  // face
  ctx.beginPath();
  ctx.arc(0, 0, R, 0, TAU);
  const face = ctx.createRadialGradient(-R * 0.3, -R * 0.3, R * 0.1, 0, 0, R);
  for (const [o, c] of s.c) face.addColorStop(o, c);
  ctx.fillStyle = face;
  ctx.fill();

  // carvings
  ctx.save();
  ctx.beginPath();
  ctx.arc(0, 0, R, 0, TAU);
  ctx.clip();

  ctx.lineWidth = 2.6;
  ctx.strokeStyle = s.ring;
  for (const f of [0.84, 0.62, 0.4]) {
    ctx.beginPath();
    ctx.arc(0, 0, R * f, 0, TAU);
    ctx.stroke();
  }
  ctx.lineWidth = 1.2;
  for (const f of [0.72, 0.5, 0.28]) {
    ctx.beginPath();
    for (let i = 0; i <= 40; i++) {
      const a = (i / 40) * TAU;
      const rr = R * f + Math.sin(a * 7 + f * 20) * R * 0.012;
      const x = Math.cos(a) * rr;
      const y = Math.sin(a) * rr;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = s.ring;
    ctx.stroke();
  }
  ctx.strokeStyle = s.carve;
  ctx.lineWidth = 1.6;
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * TAU + 0.39;
    const px = Math.cos(a) * R * 0.56;
    const py = Math.sin(a) * R * 0.56;
    ctx.beginPath();
    ctx.arc(px, py, R * 0.13, a + 1.2, a + Math.PI + 1.2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(px, py, 1.6, 0, TAU);
    ctx.fillStyle = s.carve;
    ctx.fill();
  }
  ctx.restore();

  // rim band
  ctx.beginPath();
  ctx.arc(0, 0, R - 5, 0, TAU);
  ctx.lineWidth = 10;
  ctx.strokeStyle = lg(ctx, -R, -R, R, R, s.rim);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(0, 0, R - 0.8, 0, TAU);
  ctx.lineWidth = 1.6;
  ctx.strokeStyle = 'rgba(74,44,21,0.7)';
  ctx.stroke();

  // studs
  const studs = kind === 'boss' ? 12 : 16;
  for (let i = 0; i < studs; i++) {
    const a = (i / studs) * TAU;
    const x = Math.cos(a) * (R - 5);
    const y = Math.sin(a) * (R - 5);
    glowDot(ctx, x, y, 2.2, '#e8b64c', '#fff6cf', 1);
    ctx.strokeStyle = 'rgba(90,54,8,0.8)';
    ctx.lineWidth = 0.5;
    ctx.beginPath();
    ctx.arc(x, y, 2.2, 0, TAU);
    ctx.stroke();
  }

  // boss spikes
  if (kind === 'boss') {
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU + Math.PI / 8;
      const x = Math.cos(a);
      const y = Math.sin(a);
      ctx.beginPath();
      ctx.moveTo(x * R - y * 5, y * R + x * 5);
      ctx.lineTo(x * (R + 14), y * (R + 14));
      ctx.lineTo(x * R + y * 5, y * R - x * 5);
      ctx.closePath();
      ctx.fillStyle = lg(ctx, x * R, y * R, x * (R + 14), y * (R + 14), [
        [0, GOLD.mid],
        [1, GOLD.dark],
      ]);
      ctx.fill();
      ctx.strokeStyle = 'rgba(74,44,21,0.9)';
      ctx.lineWidth = 0.7;
      ctx.stroke();
    }
  }

  // centre — pusaka sun
  const er = R * (kind === 'boss' ? 0.24 : 0.2);
  if (kind === 'boss') {
    ctx.beginPath();
    ctx.arc(0, 0, er, 0, TAU);
    ctx.fillStyle = rg(ctx, 0, 0, er, [
      [0, '#ff8aa0'],
      [0.5, '#c22544'],
      [1, '#5c0a18'],
    ]);
    ctx.fill();
    ctx.strokeStyle = GOLD.mid;
    ctx.lineWidth = 2.4;
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.4)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, -er);
    ctx.lineTo(er * 0.7, 0);
    ctx.lineTo(0, er);
    ctx.lineTo(-er * 0.7, 0);
    ctx.closePath();
    ctx.stroke();
  } else {
    glowDot(ctx, 0, 0, er, '#e8b64c', '#fffdf6', 0.95);
    ctx.beginPath();
    ctx.arc(0, 0, er, 0, TAU);
    ctx.strokeStyle = 'rgba(138,90,16,0.9)';
    ctx.lineWidth = 1.6;
    ctx.stroke();
    // rotating sun rays on the emblem
    ctx.save();
    ctx.globalAlpha = 0.5;
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU + t * 0.5;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * er * 1.25, Math.sin(a) * er * 1.25);
      ctx.lineTo(Math.cos(a) * er * 1.55, Math.sin(a) * er * 1.55);
      ctx.strokeStyle = 'rgba(232,182,76,0.9)';
      ctx.lineWidth = 1.4;
      ctx.stroke();
    }
    ctx.restore();
    drawKerisGlyph(ctx, er * 0.72, 'rgba(74,44,21,0.9)');
  }
}

/** tiny keris silhouette used as emblem */
export function drawKerisGlyph(ctx: CanvasRenderingContext2D, size: number, color: string) {
  ctx.save();
  ctx.scale(size / 40, size / 40);
  ctx.translate(0, -18);
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.bezierCurveTo(4.5, 5, -4.5, 10, 0, 16);
  ctx.bezierCurveTo(4.5, 22, -4.5, 28, 0, 34);
  ctx.bezierCurveTo(2.2, 37, 1.2, 38.5, 0, 39);
  ctx.bezierCurveTo(-1.2, 38.5, -2.2, 37, 0, 34);
  ctx.bezierCurveTo(-4.5, 28, 4.5, 22, 0, 16);
  ctx.bezierCurveTo(-4.5, 10, 4.5, 5, 0, 0);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-4, 41);
  ctx.lineTo(4, 41);
  ctx.lineTo(0, 45.5);
  ctx.closePath();
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(0, 48.5, 3.4, 2.6, -0.5, 0, TAU);
  ctx.fill();
  ctx.restore();
}

/* ================= GEM ================= */
export function drawGem(ctx: CanvasRenderingContext2D, r: number, tw: number) {
  ctx.save();
  ctx.beginPath();
  ctx.arc(0, 0, r + 2.6, 0, TAU);
  ctx.fillStyle = GOLD.dark;
  ctx.fill();
  ctx.beginPath();
  ctx.arc(0, 0, r + 1.6, 0, TAU);
  ctx.fillStyle = GOLD.hi;
  ctx.fill();
  ctx.strokeStyle = 'rgba(110,66,10,0.7)';
  ctx.lineWidth = 0.7;
  ctx.stroke();
  ctx.beginPath();
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * TAU - Math.PI / 2;
    const x = Math.cos(a) * r;
    const y = Math.sin(a) * r;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
  ctx.fillStyle = rg(ctx, -r * 0.3, -r * 0.35, r, [
    [0, '#ffc4d0'],
    [0.45, '#ff4d6d'],
    [0.8, '#c22544'],
    [1, '#6e0a1e'],
  ]);
  ctx.fill();
  ctx.strokeStyle = 'rgba(110,10,30,0.9)';
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,0.55)';
  ctx.beginPath();
  ctx.moveTo(0, -r * 0.9);
  ctx.lineTo(r * 0.8, 0);
  ctx.lineTo(0, r * 0.9);
  ctx.lineTo(-r * 0.8, 0);
  ctx.closePath();
  ctx.stroke();
  const twk = 0.5 + 0.5 * Math.sin(tw);
  ctx.strokeStyle = `rgba(255,255,255,${0.7 * twk})`;
  ctx.lineWidth = 1;
  const sr = r * (0.5 + twk * 0.5);
  ctx.beginPath();
  ctx.moveTo(-sr, -r * 0.35);
  ctx.lineTo(sr, -r * 0.35);
  ctx.moveTo(0, -r * 0.35 - sr);
  ctx.lineTo(0, -r * 0.35 + sr);
  ctx.stroke();
  ctx.restore();
}

/* ================= TARGET SHARD ================= */
export function drawShard(ctx: CanvasRenderingContext2D, R: number, a0: number, a1: number, kind: TargetKind) {
  const colors: Record<TargetKind, [string, string, string]> = {
    wood: ['#c08a2e', '#704a12', '#eab449'],
    bronze: ['#357a63', '#1a4034', '#eab449'],
    obsidian: ['#5a3f78', '#322248', '#a474e8'],
    boss: ['#96301f', '#5e1220', '#eab449'],
  };
  const [fill, dark, rim] = colors[kind];
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.arc(0, 0, R, a0, a1);
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
  ctx.lineWidth = 1.4;
  ctx.strokeStyle = dark;
  ctx.stroke();
  ctx.save();
  ctx.clip();
  ctx.lineWidth = 2;
  ctx.strokeStyle = dark;
  for (const f of [0.62, 0.84]) {
    ctx.beginPath();
    ctx.arc(0, 0, R * f, a0 - 0.1, a1 + 0.1);
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.arc(0, 0, R - 5, a0, a1);
  ctx.lineWidth = 9;
  ctx.strokeStyle = rim;
  ctx.stroke();
  ctx.restore();
}

/* ================= BRIGHT DAWN BACKDROP ================= */
export function drawBackdrop(
  ctx: CanvasRenderingContext2D,
  W: number,
  H: number,
  cx: number,
  cy: number,
  R: number,
  t: number,
) {
  // sunlit sky of the kraton
  const bg = ctx.createLinearGradient(0, 0, 0, H);
  bg.addColorStop(0, '#fdf3da');
  bg.addColorStop(0.42, '#fbe5b8');
  bg.addColorStop(0.75, '#f4cd8e');
  bg.addColorStop(1, '#eab673');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  // cool celestial wash in the upper corners
  const cw = ctx.createRadialGradient(W / 2, -H * 0.15, 10, W / 2, -H * 0.15, H * 0.75);
  cw.addColorStop(0, 'rgba(190,224,232,0.5)');
  cw.addColorStop(1, 'rgba(190,224,232,0)');
  ctx.fillStyle = cw;
  ctx.fillRect(0, 0, W, H * 0.5);

  // divine halo behind the mandala
  ctx.fillStyle = rg(ctx, cx, cy, R * 3.4, [
    [0, 'rgba(255,255,255,0.75)'],
    [0.35, 'rgba(255,244,214,0.45)'],
    [1, 'rgba(255,244,214,0)'],
  ]);
  ctx.fillRect(cx - R * 3.4, cy - R * 3.4, R * 6.8, R * 6.8);

  // rotating heavenly rays
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(t * 0.1);
  const rays = 14;
  for (let i = 0; i < rays; i++) {
    const a = (i / rays) * TAU;
    const w = 0.08 + 0.03 * Math.sin(t * 0.6 + i * 1.7);
    ctx.save();
    ctx.rotate(a);
    const len = R * 4.6;
    const g = ctx.createLinearGradient(0, 0, len, 0);
    g.addColorStop(0, 'rgba(214,158,64,0.14)');
    g.addColorStop(0.6, 'rgba(214,158,64,0.05)');
    g.addColorStop(1, 'rgba(214,158,64,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, len, -w, w);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
  ctx.restore();

  // warm temple floor
  ctx.fillStyle = rg(ctx, W / 2, H * 1.05, W * 0.6, [
    [0, 'rgba(190,122,32,0.22)'],
    [0.6, 'rgba(190,122,32,0.08)'],
    [1, 'rgba(190,122,32,0)'],
  ]);
  ctx.fillRect(0, H * 0.55, W, H * 0.45);
}
