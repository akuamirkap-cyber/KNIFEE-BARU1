import type { TargetKind } from './types';
import { clamp } from './types';

export interface RotPhase {
  dur: number;
  from: number; // rad/s at start
  to: number;   // rad/s at end
}

export interface LevelSpec {
  shots: number;      // keris needed to shatter the mandala
  obstacles: number;  // pre-embedded enemy keris
  gems: number;       // rubies on the rim
  phases: RotPhase[]; // looping rotation choreography
  kind: TargetKind;
  boss: boolean;
  radiusMul: number;
}

const KINDS: TargetKind[] = ['wood', 'bronze', 'obsidian'];

/** steady spin */
const steady = (s: number): RotPhase[] => [{ dur: 4, from: s, to: s }];

/** breathing speed curve */
const wave = (s: number): RotPhase[] => [
  { dur: 1.6, from: s * 0.45, to: s * 1.55 },
  { dur: 1.6, from: s * 1.55, to: s * 0.45 },
];

/** sudden reversals */
const reverse = (s: number): RotPhase[] => [
  { dur: 1.15, from: s, to: s },
  { dur: 0.55, from: s, to: -s },
  { dur: 1.15, from: -s, to: -s },
  { dur: 0.55, from: -s, to: s },
];

/** sprint then crawl */
const sprint = (s: number): RotPhase[] => [
  { dur: 1.0, from: s * 0.15, to: s * 1.9 },
  { dur: 0.9, from: s * 1.9, to: s * 0.15 },
  { dur: 0.4, from: s * 0.15, to: s * 0.15 },
];

/** erratic boss choreography */
const bossMix = (s: number): RotPhase[] => [
  { dur: 1.0, from: s * 0.5, to: s * 1.7 },
  { dur: 0.6, from: s * 1.7, to: -s * 1.1 },
  { dur: 0.9, from: -s * 1.1, to: -s * 0.4 },
  { dur: 0.5, from: -s * 0.4, to: s * 2.1 },
  { dur: 0.8, from: s * 2.1, to: s * 0.5 },
];

export function specForLevel(level: number): LevelSpec {
  const boss = level % 5 === 0;
  const gens = [steady, wave, reverse, sprint];

  // hand-crafted opening so the game teaches itself
  if (level === 1) return { shots: 3, obstacles: 0, gems: 1, phases: steady(1.45), kind: 'wood', boss: false, radiusMul: 1 };
  if (level === 2) return { shots: 4, obstacles: 0, gems: 1, phases: steady(-2.0), kind: 'wood', boss: false, radiusMul: 1 };
  if (level === 3) return { shots: 4, obstacles: 1, gems: 1, phases: wave(2.1), kind: 'bronze', boss: false, radiusMul: 1 };
  if (level === 4) return { shots: 5, obstacles: 1, gems: 2, phases: reverse(2.1), kind: 'obsidian', boss: false, radiusMul: 1 };
  if (level === 5)
    return { shots: 6, obstacles: 2, gems: 2, phases: bossMix(2.0), kind: 'boss', boss: true, radiusMul: 1.18 };

  // procedural aftermath
  const rnd = (n: number) => {
    const x = Math.sin(level * 127.1 + n * 311.7) * 43758.5453;
    return x - Math.floor(x);
  };

  const cycle = Math.floor(level / 5); // difficulty wave counter
  const base = 1.6 + Math.min(level * 0.09, 1.35) + cycle * 0.12;
  const sign = rnd(1) > 0.5 ? 1 : -1;
  const gen = gens[Math.floor(rnd(2) * gens.length)];

  const shots = boss
    ? clamp(6 + Math.floor(cycle / 2), 6, 9)
    : clamp(3 + Math.floor(level * 0.45 + rnd(3) * 1.4), 4, 8);

  const obstacles = boss
    ? clamp(2 + Math.floor(cycle / 2), 2, 4)
    : clamp(Math.floor(rnd(4) * 3.2) + (level > 7 ? 1 : 0), 0, 4);

  const gems = boss ? 3 : rnd(5) > 0.35 ? (rnd(6) > 0.7 ? 2 : 1) : 0;

  const kind: TargetKind = boss ? 'boss' : KINDS[Math.floor(rnd(7) * KINDS.length)];

  return {
    shots,
    obstacles,
    gems,
    phases: boss ? bossMix(base * sign) : gen(base * sign),
    kind,
    boss,
    radiusMul: boss ? 1.16 : 1,
  };
}
