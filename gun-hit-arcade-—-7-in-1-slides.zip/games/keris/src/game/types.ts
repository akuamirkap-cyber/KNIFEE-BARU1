export type Phase = 'menu' | 'playing' | 'celebrating' | 'dying' | 'gameover';

export type TargetKind = 'wood' | 'bronze' | 'obsidian' | 'boss';

export interface Status {
  phase: Phase;
  level: number;
  boss: boolean;
  score: number;
  best: number;
  isNewBest: boolean;
  gems: number;
  shotsLeft: number;
  shotsTotal: number;
  muted: boolean;
}

export interface Vec {
  x: number;
  y: number;
}

export const TAU = Math.PI * 2;

/** angular distance in [0, PI] */
export function angDiff(a: number, b: number): number {
  return Math.abs(Math.atan2(Math.sin(a - b), Math.cos(a - b)));
}

export function normAng(a: number): number {
  while (a > Math.PI) a -= TAU;
  while (a < -Math.PI) a += TAU;
  return a;
}

export function clamp(v: number, lo: number, hi: number): number {
  return v < lo ? lo : v > hi ? hi : v;
}

export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

export function easeOutBack(t: number): number {
  const c = 1.70158;
  const u = t - 1;
  return 1 + (c + 1) * u * u * u + c * u * u;
}

export function easeOutCubic(t: number): number {
  return 1 - Math.pow(1 - t, 3);
}

/** smooth phase interpolation with soft ease at both ends */
export function phaseEase(t: number): number {
  return t * t * (3 - 2 * t);
}

/** deterministic-ish rng */
export function mulberry(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s |= 0;
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
