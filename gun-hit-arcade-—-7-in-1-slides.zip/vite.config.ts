import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './src'),
      },
    },
    server: {
      port: 3000,
      host: '0.0.0.0',
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
    build: {
      rollupOptions: {
        input: {
          main: path.resolve(__dirname, 'index.html'),
          firework: path.resolve(__dirname, 'games/firework/index.html'),
          keris: path.resolve(__dirname, 'games/keris/index.html'),
          rainbow: path.resolve(__dirname, 'games/rainbow/index.html'),
          weaponskins: path.resolve(__dirname, 'games/weaponskins/index.html'),
          obliterator: path.resolve(__dirname, 'games/obliterator/index.html'),
          gunhitdev: path.resolve(__dirname, 'games/gunhitdev/index.html'),
          sharkgun: path.resolve(__dirname, 'games/sharkgun/index.html'),
        },
      },
    },
  };
});
