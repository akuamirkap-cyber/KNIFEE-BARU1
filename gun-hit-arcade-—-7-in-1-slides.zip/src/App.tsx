/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Maximize2,
  Minimize2,
  Info,
  X,
  Play
} from 'lucide-react';

interface GameItem {
  id: string;
  title: string;
  subtitle: string;
  badge: string;
  path: string;
  accentColor: string;
  gradient: string;
  borderAccent: string;
  glowColor: string;
  weapons: string[];
  description: string;
  tag: string;
  tips: string;
}

const GAMES: GameItem[] = [
  {
    id: 'firework',
    title: 'GUN HIT: FIREWORK',
    subtitle: '5 Senjata Neon Berkilau',
    badge: '🎆 Firework & Gems',
    path: '/games/firework/index.html',
    accentColor: '#ffd75e',
    gradient: 'from-amber-500/20 via-rose-500/20 to-purple-600/20',
    borderAccent: 'border-amber-400',
    glowColor: 'rgba(255, 215, 94, 0.45)',
    weapons: ['🗡️ Keris Emas', '🕳️ Black Hole', '🪀 Yoyo', '💎 Diamond', '🔮 Crystal'],
    description: 'Tembak target lingkaran kayu berputar dengan 5 bilah pusaka magis & ledakan kembang api spektakuler.',
    tag: 'POPULER',
    tips: 'Sentuh layar untuk menembakkan senjata ke celah kosong target. Jangan sampai menabrak senjata lain!'
  },
  {
    id: 'keris',
    title: 'KERIS SAKTI: GUN HIT',
    subtitle: 'Bilah Pusaka Jawa Tradisional',
    badge: '🗡️ Keris Sakti',
    path: '/games/keris/index.html',
    accentColor: '#f0c95c',
    gradient: 'from-yellow-600/20 via-amber-700/20 to-red-900/20',
    borderAccent: 'border-yellow-400',
    glowColor: 'rgba(240, 201, 92, 0.45)',
    weapons: ['🗡️ Keris Naga', '🗡️ Keris Brojol', '🗡️ Pusaka Emas'],
    description: 'Kuasai kekuatan pusaka mistis Jawa bertuah. Tancapkan bilah ke pusaran kayu mistis & taklukkan level bos kuno.',
    tag: 'NUSANTARA',
    tips: 'Perhatikan akselerasi dan deselerasi putaran kayu pusaka di setiap tingkatan level bos.'
  },
  {
    id: 'rainbow',
    title: 'RAINBOW GUN ARCADE',
    subtitle: 'PRISM-07 Holy Railgun',
    badge: '🌈 Holy Rainbow',
    path: '/games/rainbow/index.html',
    accentColor: '#38bdf8',
    gradient: 'from-cyan-500/20 via-fuchsia-500/20 to-indigo-600/20',
    borderAccent: 'border-cyan-400',
    glowColor: 'rgba(56, 189, 248, 0.45)',
    weapons: ['🌈 Prism Railgun', '🕳️ Void Black Hole'],
    description: 'Uji timing dan ritme tembakan suci pada cincin pelangi berputar dinamis dengan mode Sway, Pulse, Ramp & Chaos Boss!',
    tag: 'ARCADE',
    tips: 'Bidik busur emas di ring pelangi untuk mendapatkan bonus PERFECT dan pengganda combo tertinggi!'
  },
  {
    id: 'weaponskins',
    title: 'ARSENAL SKINS & WHEEL',
    subtitle: 'Galeri 11 Skin & Tantangan',
    badge: '⚙️ 11 Arsenal Skins',
    path: '/games/weaponskins/index.html',
    accentColor: '#c084fc',
    gradient: 'from-purple-500/20 via-pink-500/20 to-blue-600/20',
    borderAccent: 'border-purple-400',
    glowColor: 'rgba(192, 132, 252, 0.45)',
    weapons: ['🗡️ Keris', '🕳️ Hole', '🪀 Yoyo', '💎 Diamond', '🔮 Crystal', '❄️ Snow', '💧 Water', '🎉 Party'],
    description: 'Eksplorasi 11 skin senjata bertenaga kode dengan partikel recoil peluru dan mode tantangan Wheel Challenge!',
    tag: 'FULL SKINS',
    tips: 'Pindah ke mode Wheel Challenge di pojok atas untuk bermain game tembak roda berputar berkecepatan tinggi.'
  },
  {
    id: 'obliterator',
    title: 'OBLITERATOR HIT: DOOM',
    subtitle: 'Penghancur Inti Argent Core',
    badge: '💥 Heavy Obliterator',
    path: '/games/obliterator/index.html',
    accentColor: '#f97316',
    gradient: 'from-red-600/20 via-orange-600/20 to-yellow-600/20',
    borderAccent: 'border-orange-500',
    glowColor: 'rgba(249, 115, 22, 0.45)',
    weapons: ['💥 BFG 9000', '⚡ Maykr Laser', '🍌 Banana Cannon', '🐝 Beehive', '🔮 Crystal Core'],
    description: 'Aksi arcade brutal penghancur inti energi! Kumpulkan Argent Gems dan picu Overdrive Charge untuk melumat target!',
    tag: 'EXTREME',
    tips: 'Gunakan tombol Overdrive di bawah saat meteran penuh untuk melipatgandakan poin tembakan secara masif.'
  },
  {
    id: 'gunhitdev',
    title: 'GUN HIT: TAP & STICK',
    subtitle: 'Hypercasual 2D Shooter & Toko Skin',
    badge: '🎯 Tap & Stick',
    path: '/games/gunhitdev/index.html',
    accentColor: '#10b981',
    gradient: 'from-emerald-500/20 via-teal-500/20 to-cyan-600/20',
    borderAccent: 'border-emerald-400',
    glowColor: 'rgba(16, 185, 129, 0.45)',
    weapons: ['🗡️ Keris Jawa', '🕳️ Black Hole', '🪀 Yoyo Neon', '💎 Diamond Gun', '🔮 Crystal Prism'],
    description: 'Putar, bidik waktu, tancapkan lima senjata legendaris ke lingkaran berputar dengan koin & sistem unlock skin toko!',
    tag: 'CLASSIC',
    tips: 'Kumpulkan koin setiap kali menancapkan bilah untuk membuka semua skin senjata di menu Toko Skin.'
  },
  {
    id: 'sharkgun',
    title: 'SHARK GUN: PREDATOR',
    subtitle: 'Apex Predator 2D Gun Hit',
    badge: '🦈 Apex Shark',
    path: '/games/sharkgun/index.html',
    accentColor: '#06b6d4',
    gradient: 'from-cyan-500/20 via-blue-600/20 to-teal-700/20',
    borderAccent: 'border-cyan-400',
    glowColor: 'rgba(6, 182, 212, 0.45)',
    weapons: ['🦈 Great White', '🦈 Megalodon', '🦈 Hammerhead', '🦈 Mako Shark', '🦈 Tiger Shark'],
    description: 'Kuasai predator puncak samudra! Tembak target pusaran laut, kumpulkan sirip emas, dan taklukkan bos Kraken!',
    tag: 'PREDATOR',
    tips: 'Beli laser sight di menu pengaturan untuk akurasi tembakan lebih tajam saat menghadapi Kraken!'
  }
];

export default function App() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [reloadKeys, setReloadKeys] = useState<number[]>([1, 1, 1, 1, 1, 1, 1]);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const sliderRef = useRef<HTMLDivElement>(null);
  const slideRefs = useRef<(HTMLDivElement | null)[]>([]);

  const activeGame = GAMES[activeIndex];

  // Scroll active slide into view smoothly
  const scrollToSlide = useCallback((index: number) => {
    setActiveIndex(index);
    const targetEl = slideRefs.current[index];
    if (targetEl && sliderRef.current) {
      targetEl.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'center'
      });
    }
  }, []);

  const handlePrev = () => {
    const nextIdx = (activeIndex - 1 + GAMES.length) % GAMES.length;
    scrollToSlide(nextIdx);
  };

  const handleNext = () => {
    const nextIdx = (activeIndex + 1) % GAMES.length;
    scrollToSlide(nextIdx);
  };

  const handleReload = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setReloadKeys(prev => {
      const copy = [...prev];
      copy[activeIndex] = (copy[activeIndex] || 0) + 1;
      return copy;
    });
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        handlePrev();
      } else if (e.key === 'ArrowRight') {
        handleNext();
      } else if (e.key.toLowerCase() === 'r' && !e.metaKey && !e.ctrlKey) {
        handleReload();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeIndex]);

  return (
    <div className="relative w-screen h-screen flex flex-col justify-between bg-[#040308] text-white overflow-hidden select-none">
      
      {/* Background ambient lighting */}
      <div className="pointer-events-none absolute inset-0 z-0 overflow-hidden">
        <div
          className="absolute -top-32 left-1/2 -translate-x-1/2 w-[700px] h-[350px] rounded-full blur-[140px] opacity-30 transition-colors duration-700"
          style={{ backgroundColor: activeGame.accentColor }}
        />
        <div className="absolute inset-0 bg-[radial-gradient(#ffffff08_1px,transparent_1px)] [background-size:24px_24px] opacity-35" />
      </div>

      {/* TOP HEADER */}
      <header className="relative z-20 shrink-0 px-4 pt-3 pb-2 flex items-center justify-between border-b border-white/10 bg-[#05040a]/80 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 to-rose-600 flex items-center justify-center shadow-lg shadow-amber-500/20 text-xl font-bold">
            🎯
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-black text-sm sm:text-base tracking-wider uppercase font-['Orbitron'] bg-gradient-to-r from-amber-300 via-rose-300 to-cyan-300 bg-clip-text text-transparent">
                GUN HIT ARCADE
              </h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/10 text-white/80 border border-white/15">
                7 SLIDE 9:16
              </span>
            </div>
            <p className="text-[11px] text-white/50 hidden sm:block">
              Pencet slide mana saja untuk menjalankan game tersebut langsung
            </p>
          </div>
        </div>

        {/* Action badges and helper buttons */}
        <div className="flex items-center gap-2">
          {/* Active game quick indicator badge */}
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs">
            <span className="w-2 h-2 rounded-full animate-ping" style={{ backgroundColor: activeGame.accentColor }} />
            <span className="font-semibold text-white/90">{activeGame.badge}</span>
            <span className="text-white/40">({activeIndex + 1}/7)</span>
          </div>

          <button
            onClick={handleReload}
            title="Muat Ulang Game Aktif (R)"
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 border border-white/10 text-white/70 hover:text-white transition cursor-pointer flex items-center gap-1.5 text-xs font-medium"
          >
            <RotateCcw className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Reset</span>
          </button>

          <button
            onClick={() => setIsFullscreen(prev => !prev)}
            title="Perbesar Layar Game"
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 border border-white/10 text-white/70 hover:text-white transition cursor-pointer"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4 text-cyan-400" /> : <Maximize2 className="w-4 h-4 text-cyan-400" />}
          </button>

          <button
            onClick={() => setShowInfo(true)}
            title="Panduan & Info Game"
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 border border-white/10 text-white/70 hover:text-white transition cursor-pointer"
          >
            <Info className="w-4 h-4 text-rose-400" />
          </button>
        </div>
      </header>

      {/* MAIN CAROUSEL / SLIDE STAGE */}
      <main className="relative z-10 flex-1 flex flex-col justify-center items-center px-2 py-2 overflow-hidden min-h-0">
        
        {/* Floating Left & Right Navigation Arrows */}
        <button
          onClick={handlePrev}
          aria-label="Slide Sebelumnya"
          className="absolute left-2 sm:left-4 z-30 p-3 sm:p-3.5 rounded-full bg-black/60 hover:bg-black/90 text-white/80 hover:text-white border border-white/20 backdrop-blur-md shadow-2xl transition-all duration-200 hover:scale-110 active:scale-95 cursor-pointer flex items-center justify-center group"
        >
          <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 group-hover:-translate-x-0.5 transition-transform" />
        </button>

        <button
          onClick={handleNext}
          aria-label="Slide Selanjutnya"
          className="absolute right-2 sm:right-4 z-30 p-3 sm:p-3.5 rounded-full bg-black/60 hover:bg-black/90 text-white/80 hover:text-white border border-white/20 backdrop-blur-md shadow-2xl transition-all duration-200 hover:scale-110 active:scale-95 cursor-pointer flex items-center justify-center group"
        >
          <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6 group-hover:translate-x-0.5 transition-transform" />
        </button>

        {/* SLIDE TRACK: All 7 games aligned side by side (BERJEJER) */}
        <div
          ref={sliderRef}
          className="w-full h-full flex items-center gap-4 sm:gap-6 md:gap-8 overflow-x-auto no-scrollbar scroll-smooth snap-x snap-mandatory px-[calc(50%-160px)] sm:px-[calc(50%-190px)] md:px-[calc(50%-210px)] py-1"
        >
          {GAMES.map((game, idx) => {
            const isActive = idx === activeIndex;

            return (
              <div
                key={game.id}
                ref={el => { slideRefs.current[idx] = el; }}
                onClick={() => {
                  if (!isActive) scrollToSlide(idx);
                }}
                className={`shrink-0 snap-center relative transition-all duration-500 ease-out cursor-pointer flex flex-col justify-center items-center ${
                  isActive
                    ? 'scale-100 z-20 opacity-100'
                    : 'scale-[0.88] sm:scale-90 z-10 opacity-55 hover:opacity-85 hover:scale-[0.92]'
                }`}
                style={{
                  height: isFullscreen ? 'calc(100vh - 120px)' : 'min(76vh, 670px)',
                  maxHeight: '100%',
                }}
              >
                {/* 9:16 Device Outer Frame Container (Zero-Crop Guarantee) */}
                <div
                  className={`relative w-full h-full rounded-[2rem] sm:rounded-[2.5rem] p-1.5 sm:p-2 bg-gradient-to-b from-white/20 via-white/5 to-white/10 shadow-2xl transition-all duration-500 flex flex-col overflow-hidden ${
                    isActive
                      ? `ring-4 shadow-[0_0_50px_${game.glowColor}]`
                      : 'border border-white/10 hover:border-white/30'
                  }`}
                  style={{
                    aspectRatio: '9 / 16',
                    borderColor: isActive ? game.accentColor : undefined,
                    boxShadow: isActive ? `0 0 45px ${game.glowColor}, inset 0 0 20px ${game.glowColor}` : undefined
                  }}
                >
                  {/* Smartphone Speaker / Sensor Pill Bar (Top Bezel) */}
                  <div className="absolute top-2.5 left-1/2 -translate-x-1/2 z-30 flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-black/80 border border-white/10 pointer-events-none">
                    <span className="w-1.5 h-1.5 rounded-full bg-white/30" />
                    <span className="w-8 h-1 rounded-full bg-white/20" />
                    <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: game.accentColor }} />
                  </div>

                  {/* Top Game Banner in Frame */}
                  <div className="shrink-0 px-3 pt-4 pb-1.5 flex items-center justify-between text-[11px] font-bold z-20 pointer-events-none bg-gradient-to-b from-black/90 to-transparent">
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm">{game.weapons[0].split(' ')[0]}</span>
                      <span className="truncate max-w-[130px] font-['Rajdhani'] font-bold text-white text-xs">
                        {game.title}
                      </span>
                    </div>
                    <span
                      className="px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-wider"
                      style={{
                        backgroundColor: `${game.accentColor}25`,
                        color: game.accentColor,
                        border: `1px solid ${game.accentColor}50`
                      }}
                    >
                      {isActive ? '● SEDANG JALAN' : game.tag}
                    </span>
                  </div>

                  {/* 9:16 Inner Viewport for the Game */}
                  <div className="relative flex-1 w-full h-full rounded-[1.6rem] sm:rounded-[2rem] overflow-hidden bg-black flex items-center justify-center">
                    
                    {/* The Running Game (Loaded when active, or kept alive once launched) */}
                    {isActive ? (
                      <iframe
                        key={`${game.id}-${reloadKeys[idx]}`}
                        src={game.path}
                        title={game.title}
                        className="w-full h-full border-0 block select-none pointer-events-auto"
                        style={{
                          width: '100%',
                          height: '100%',
                          aspectRatio: '9 / 16',
                          backgroundColor: '#000000',
                        }}
                      />
                    ) : (
                      /* Inactive Slide Preview Poster */
                      <div className="w-full h-full flex flex-col justify-between p-5 text-center relative overflow-hidden bg-[#0a0814]">
                        {/* Background pattern */}
                        <div
                          className="absolute inset-0 opacity-20 bg-cover bg-center"
                          style={{
                            background: `radial-gradient(circle at 50% 40%, ${game.accentColor} 0%, transparent 70%)`
                          }}
                        />

                        {/* Slide number watermark */}
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-8xl font-black text-white/5 font-['Orbitron'] pointer-events-none select-none">
                          0{idx + 1}
                        </div>

                        {/* Top info */}
                        <div className="relative z-10 pt-4">
                          <span className="text-4xl drop-shadow-md animate-bounce inline-block">
                            {game.weapons[0].split(' ')[0]}
                          </span>
                          <h3 className="mt-2 text-base font-bold text-white font-['Orbitron']">
                            {game.title}
                          </h3>
                          <p className="text-xs text-white/50 mt-0.5">
                            {game.subtitle}
                          </p>
                        </div>

                        {/* Weapons pill preview */}
                        <div className="relative z-10 my-auto py-2">
                          <div className="flex flex-wrap justify-center gap-1.5 max-w-[200px] mx-auto">
                            {game.weapons.slice(0, 4).map((w, wIdx) => (
                              <span
                                key={wIdx}
                                className="px-2 py-0.5 rounded-full text-[10px] bg-white/10 text-white/80 border border-white/10"
                              >
                                {w}
                              </span>
                            ))}
                          </div>
                        </div>

                        {/* CLICK TO RUN Overlay Button */}
                        <div className="relative z-10 pb-4">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              scrollToSlide(idx);
                            }}
                            className="w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-transform duration-200 hover:scale-105 active:scale-95 cursor-pointer text-black"
                            style={{
                              backgroundColor: game.accentColor,
                              boxShadow: `0 0 20px ${game.glowColor}`
                            }}
                          >
                            <Play className="w-4 h-4 fill-black" />
                            PENCET UNTUK MAINKAN
                          </button>
                          <p className="text-[10px] text-white/40 mt-1.5">
                            Ketuk slide ini untuk menjalankan game
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Active Floating Quick Refresh Button on Top Right */}
                    {isActive && (
                      <div className="absolute top-2 right-2 z-30 flex items-center gap-1.5">
                        <button
                          onClick={handleReload}
                          title="Reset Level Game"
                          className="p-1.5 rounded-lg bg-black/60 hover:bg-black/90 text-white/80 hover:text-white border border-white/20 backdrop-blur-md text-[10px] transition cursor-pointer flex items-center gap-1"
                        >
                          <RotateCcw className="w-3.5 h-3.5 text-amber-300" />
                          <span className="hidden sm:inline">Ulangi</span>
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Device Bottom Home Bar Indicator */}
                  <div className="shrink-0 pt-2 pb-1 flex justify-center">
                    <div className="w-24 h-1 rounded-full bg-white/25" />
                  </div>
                </div>

                {/* Subtitle caption below the slide */}
                <div className="mt-2 text-center">
                  <p className="text-xs font-bold text-white tracking-wide">
                    {game.title}
                  </p>
                  <p className="text-[10px] text-white/40">
                    Rasio 9:16 &bull; {game.subtitle}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </main>

      {/* BOTTOM THUMBNAIL DOCK: 7 Game Tabs */}
      <footer className="relative z-20 shrink-0 px-3 py-2 border-t border-white/10 bg-[#05040a]/90 backdrop-blur-md flex flex-col gap-1.5">
        
        {/* Thumbnails row */}
        <div className="max-w-5xl mx-auto w-full flex items-center justify-start sm:justify-center gap-1.5 sm:gap-2.5 overflow-x-auto no-scrollbar py-1">
          {GAMES.map((game, idx) => {
            const isActive = idx === activeIndex;

            return (
              <button
                key={game.id}
                onClick={() => scrollToSlide(idx)}
                className={`flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-xl text-left transition-all duration-300 cursor-pointer shrink-0 border ${
                  isActive
                    ? 'bg-white/15 text-white shadow-lg ring-1 scale-105'
                    : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10 border-white/10'
                }`}
                style={{
                  borderColor: isActive ? game.accentColor : 'rgba(255,255,255,0.1)',
                  boxShadow: isActive ? `0 0 15px ${game.glowColor}` : undefined
                }}
              >
                <span className="text-base sm:text-lg">
                  {game.weapons[0].split(' ')[0]}
                </span>
                <div className="min-w-0">
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] font-bold text-white/40">
                      0{idx + 1}
                    </span>
                    <span className="text-xs font-bold truncate max-w-[80px] sm:max-w-[110px]">
                      {game.title.replace('GUN HIT: ', '').replace(': GUN HIT', '').replace('GUN HIT — ', '')}
                    </span>
                  </div>
                  <span
                    className="text-[9px] block truncate font-medium"
                    style={{ color: isActive ? game.accentColor : 'rgba(255,255,255,0.4)' }}
                  >
                    {isActive ? '● AKTIF' : game.tag}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Tip text */}
        <div className="text-center text-[10px] text-white/40 flex items-center justify-center gap-2">
          <span>💡 Ketuk slide mana saja untuk langsung menjalankan game</span>
          <span className="hidden sm:inline">&bull; Gunakan tombol panah keyboard ← → untuk beralih</span>
        </div>
      </footer>

      {/* HOW TO PLAY / INFO MODAL */}
      {showInfo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="max-w-lg w-full bg-[#0d0b18] border border-white/20 rounded-3xl p-6 shadow-2xl relative text-left">
            <button
              onClick={() => setShowInfo(false)}
              className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center text-xl">
                🎮
              </div>
              <div>
                <h2 className="text-lg font-bold text-white font-['Orbitron']">
                  7 Koleksi Game Gun Hit (9:16)
                </h2>
                <p className="text-xs text-white/50">
                  Semua game disusun berjejer dan bisa langsung dimainkan
                </p>
              </div>
            </div>

            <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1 no-scrollbar text-xs">
              {GAMES.map((g, idx) => (
                <div
                  key={g.id}
                  onClick={() => {
                    scrollToSlide(idx);
                    setShowInfo(false);
                  }}
                  className="p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 transition cursor-pointer flex items-start gap-3"
                >
                  <span className="text-2xl shrink-0 p-1 bg-white/10 rounded-xl">
                    {g.weapons[0].split(' ')[0]}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-white text-xs">{g.title}</h4>
                      <span className="text-[10px] font-bold" style={{ color: g.accentColor }}>
                        PILIH &bull; 0{idx + 1}
                      </span>
                    </div>
                    <p className="text-white/60 text-[11px] mt-0.5">{g.description}</p>
                    <p className="text-[10px] text-amber-300/80 mt-1 italic">Tips: {g.tips}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-5 pt-4 border-t border-white/10 flex justify-end">
              <button
                onClick={() => setShowInfo(false)}
                className="px-5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-bold text-xs transition cursor-pointer"
              >
                Mulai Main Sekarang
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
